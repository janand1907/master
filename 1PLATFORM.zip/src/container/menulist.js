
import {ReactComponent as Dashboard} from '../assets/images/sidemenu/dashboard.svg'
import {ReactComponent as Domain} from '../assets/images/sidemenu/domain.svg'
import {ReactComponent as Project} from '../assets/images/sidemenu/projects.svg'
import {ReactComponent as Testscript} from '../assets/images/sidemenu/testscript.svg'
import {ReactComponent as Environment} from '../assets/images/sidemenu/environment.svg'
import {ReactComponent as Report} from '../assets/images/sidemenu/report.svg'
import {ReactComponent as Account} from '../assets/images/sidemenu/account.svg'


export const menulist = [
  // {
  //   icon: <Dashboard />,
  //   title: "Dashboard",
  //   to:"/dashboard",
  //   items: []
  // },
  // {
  //   icon: <Domain />,
  //   title: "Domain",
  //   to: "/domain",
  //   items: []
  // },
  // {
  //   icon: <Project />,
  //   title: "Project",
  //   to: "/project/all",
  //   items: []
  // },
  // {
  //   icon: <Testscript />,
  //   title: "Test case",
  //   to: "/testcase/all",
  //   items: []
  // },
  // {
  //   title: "Environment",
  //   icon: <Environment />,
  //   to: "/viewenvironment",
  //   items: []
  // },
  // {
  //   title: "View Runs",
  //   icon: <Report />,
  //   to: "/viewrun",
  //   items: []
  // },









  
  // {
  //   title: "RampupChart",
  //   icon: `${report}`,
  //   to: "/testcasedetails",
  //   items: []
  // },
  
  // {
  //   title: "Platform Admin",
  //   icon: <Account />,
  //   to: "/productsubscribe",
  //   items: []
  // },
  // {
  //   title: "Product Admin",
  //   icon: <Environment />,
  //   to: "/dashboardadmin",
  //   items: []
  // },
  
  
  
  // {
  //   icon: "bi-bezier2",    
  //   title: "Domain Config",
  //   items: [
  //     {
  //       title: "ReleaseBase",
  //       icon: "bi-activity",
  //       to: "/releasebase",
  //     },
      
  //   ]
  // }
  
];
