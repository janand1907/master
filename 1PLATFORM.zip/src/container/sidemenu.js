import React, { useEffect, useState } from 'react';
import Collapse from 'react-bootstrap/Collapse';
import { menulist } from "./menulist";
import { Nav } from 'react-bootstrap';
import { hasChildren } from "../utils/hasChildrenMenu";
import { useSelector, useDispatch } from 'react-redux';
import { NavLink } from 'react-router-dom';
import { sidebarLeftIcon, sidebarRightIcon } from '../Icons/icons';
import { ReactComponent as Account } from '../assets/images/sidemenu/account.svg'
import { ReactComponent as Admin } from '../assets/images/sidemenu/admin.svg'
import { useHistory, useLocation } from 'react-router-dom';
import { activeMenu } from '../ducks/gateway/login/actions';

const SideMenu = () => {
  const dispatch = useDispatch();
  const onActiveMenu = (data, e) => {
    dispatch(activeMenu(data));
  };
  const handleDrawerOpen = () => {
    dispatch({ type: 'OPEN' });
  };
  const handleDrawerClose = () => {
    dispatch({ type: 'CLOSE' });
  };
  const userDetails = useSelector(state => state.user.userInfo.allInfo);
  const _activeMenu = useSelector(state => state.user.activeMenu);
  const location = useLocation();
  const getActiveKey = () => {
    // Extract the active key from the current route
    const pathSegments = location.pathname.split('/');
    return pathSegments[1] || 'home'; // Assuming the first segment is the top-level tab
  };
  return (
    <div className='op_side_menu'>
      {/* <Nav className="sidenav"> */}

      <Nav className="sidenav">

        {menulist.map((item, key) => <MenuItem key={key} item={item} />)}
        {userDetails.platformAdmin ?
          <>
            <NavLink to="/dashboard-admin" className={`nav-link ${_activeMenu === "Dashboard" && "active"}`} exact onClick={() => onActiveMenu("Dashboard")}>
              <div className='icon_title'>
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" width="16" height="16" viewBox="0 0 20.063 20.063">
                  <path id="Path_15791" data-name="Path 15791" d="M20.834,5.229V7.459H16.376V5.229h4.459m-11.146,0v6.688H5.229V5.229H9.688m11.146,8.917v6.688H16.376V14.146h4.459M9.688,18.6v2.229H5.229V18.6H9.688M23.063,3H14.146V9.688h8.917ZM11.917,3H3V14.146h8.917Zm11.146,8.917H14.146V23.063h8.917ZM11.917,16.376H3v6.688h8.917Z" transform="translate(-3 -3)" fill="currentColor" />
                </svg>
              </div>
              <div className="title">Dashboard</div>
            </NavLink>
            <NavLink to="/FeaturesLists" className={`nav-link ${_activeMenu === "Feature" && "active"}`} activeClassName="active" exact onClick={() => onActiveMenu("Feature")}>
              <div className='icon_title'>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                  <path id="Path_16756" data-name="Path 16756" d="M4,20a4,4,0,0,1-4-4V4A4,4,0,0,1,4,0H16a4,4,0,0,1,4,4V16a4,4,0,0,1-4,4ZM2,4V16a2,2,0,0,0,2,2H16a2,2,0,0,0,2-2V4a2,2,0,0,0-2-2H4A2,2,0,0,0,2,4ZM7.018,16.609a.174.174,0,0,1-.175-.149l-.135-.941a2.593,2.593,0,0,1-.6-.348l-.886.356a.18.18,0,0,1-.06.01.178.178,0,0,1-.157-.088l-.71-1.23a.179.179,0,0,1,.042-.228l.75-.586a2.508,2.508,0,0,1,0-.7l-.75-.587a.175.175,0,0,1-.042-.228l.71-1.229a.178.178,0,0,1,.153-.089.194.194,0,0,1,.064.011l.886.355a2.729,2.729,0,0,1,.6-.348l.135-.942A.174.174,0,0,1,7.018,9.5H8.439a.174.174,0,0,1,.175.148l.135.942a2.593,2.593,0,0,1,.6.348l.886-.355a.163.163,0,0,1,.06-.011.179.179,0,0,1,.157.089l.711,1.229a.18.18,0,0,1-.043.228l-.75.587a2.508,2.508,0,0,1,0,.7l.75.586a.18.18,0,0,1,.043.228l-.711,1.23a.177.177,0,0,1-.153.088.22.22,0,0,1-.064-.01l-.886-.356a2.729,2.729,0,0,1-.6.348l-.135.941a.174.174,0,0,1-.175.149Zm-.477-2a2.028,2.028,0,0,0,.437.252l.377.153.057.4.068.48h.5l.071-.48.057-.4.377-.153a2.066,2.066,0,0,0,.444-.259l.32-.242.37.149.451.181.249-.429-.384-.3-.316-.249.05-.4c.011-.106.018-.185.018-.259a1.868,1.868,0,0,0-.018-.259l-.05-.4.316-.248.381-.3-.249-.43-.451.182-.377.152L8.913,11.5a2.028,2.028,0,0,0-.437-.252L8.1,11.093l-.057-.4-.068-.481H7.48l-.071.481-.057.4-.377.153a2.066,2.066,0,0,0-.444.259l-.32.241-.37-.148-.451-.182-.249.43.384.3.316.248-.049.4c-.011.106-.018.188-.018.259s.007.153.018.263l.049.4-.316.249-.384.3.249.43.451-.181.377-.153ZM13,16.5a.5.5,0,0,1,0-1h3a.5.5,0,0,1,0,1ZM6.307,13.055a1.422,1.422,0,1,1,1.422,1.422A1.422,1.422,0,0,1,6.307,13.055Zm.711,0a.711.711,0,1,0,.711-.711A.713.713,0,0,0,7.018,13.055ZM3,8V6H17V8ZM6,5V3H8V5ZM3,5V3H5V5Z" fill="currentColor" />
                </svg>
              </div>
              <div className="title">Feature</div>
            </NavLink>
            <NavLink to="/SubscriptionLists" className={`nav-link ${_activeMenu === "Plan" && "active"}`} activeClassName="active" exact onClick={() => onActiveMenu("Plan")}>
              <div className='icon_title'>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                  <g id="Group_11943" data-name="Group 11943" transform="translate(-2 -2)">
                    <g id="Group_10775" data-name="Group 10775">
                      <path id="Path_14327" data-name="Path 14327" d="M20,2H4A2.074,2.074,0,0,0,2,4V7.01A2.02,2.02,0,0,0,3,8.7V20a2.149,2.149,0,0,0,2,2H19a2.149,2.149,0,0,0,2-2V8.7a2.02,2.02,0,0,0,1-1.69V4A2.074,2.074,0,0,0,20,2ZM19,20H5V9H19ZM20,7H4V4H20Z" fill="currentColor" />
                      <rect id="Rectangle_3068" data-name="Rectangle 3068" width="6" height="2" transform="translate(9 12)" fill="currentColor" />
                    </g>
                  </g>
                </svg>
              </div>
              <div className="title">Plan</div>
            </NavLink>
            <NavLink to="/SubscribedUsersList" className={`nav-link ${_activeMenu === "Manage User" && "active"}`} activeClassName="active" onClick={() => onActiveMenu("Manage User")}>
              <div className='icon_title'>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20 17.146" fill="currentColor">
                  <g id="Group_12268" data-name="Group 12268" transform="translate(-2 -4)">
                    <g id="Group_11958" data-name="Group 11958" transform="translate(2 4)">
                      <path id="Path_15803" data-name="Path 15803" d="M4,18v-.65a.946.946,0,0,1,.41-.81A10.889,10.889,0,0,1,10,15a.22.22,0,0,1,.08.01,6.886,6.886,0,0,1,.59-1.98c-.22-.02-.44-.03-.67-.03a12.876,12.876,0,0,0-6.61,1.82A2.922,2.922,0,0,0,2,17.35V20h9.26a7.133,7.133,0,0,1-.97-2Z" transform="translate(-2 -3.854)" fill="currentColor" />
                      <path id="Path_15804" data-name="Path 15804" d="M10,12A4,4,0,1,0,6,8,4,4,0,0,0,10,12Zm0-6A2,2,0,1,1,8,8,2.006,2.006,0,0,1,10,6Z" transform="translate(-1.943 -4)" fill="currentColor" />
                      <path id="Path_15805" data-name="Path 15805" d="M20.75,16a4.338,4.338,0,0,0-.06-.63l1.14-1.01-1-1.73-1.45.49a3.647,3.647,0,0,0-1.08-.63L18,11H16l-.3,1.49a3.647,3.647,0,0,0-1.08.63l-1.45-.49-1,1.73,1.14,1.01a4.338,4.338,0,0,0-.06.63,4.338,4.338,0,0,0,.06.63l-1.14,1.01,1,1.73,1.45-.49a3.647,3.647,0,0,0,1.08.63L16,21h2l.3-1.49a3.647,3.647,0,0,0,1.08-.63l1.45.49,1-1.73-1.14-1.01A4.338,4.338,0,0,0,20.75,16ZM17,18a2,2,0,1,1,2-2A2.006,2.006,0,0,1,17,18Z" transform="translate(-1.83 -3.854)" fill="currentColor" />
                    </g>
                  </g>
                </svg>
              </div>
              <div className="title">Manage Users</div>
            </NavLink>
            <NavLink to="/paymentMethod" className={`nav-link ${_activeMenu === "Terms of Payment" && "active"}`} activeClassName="active" onClick={() => onActiveMenu("Terms of Payment")}>
              <div className='icon_title'>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-credit-card-fill" viewBox="0 0 16 16">
                  <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1H0V4zm0 3v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7H0zm3 2h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1z" fill="currentColor" />
                </svg>
              </div>
              <div className="title">Terms of Payment</div>
            </NavLink>
            {/* <NavLink to="/plan-discount" className="nav-link" activeClassName="">
              <div className='icon_title'>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
                  <g id="Group_12285" data-name="Group 12285" transform="translate(-2 -1.181)">
                    <g id="Group_12286" data-name="Group 12286" transform="translate(2 1.551)">
                      <path id="Union_12" data-name="Union 12" d="M3,20a2.15,2.15,0,0,1-2-2V6.7A2.018,2.018,0,0,1,0,5.012V2A2.074,2.074,0,0,1,2,0H18a2.074,2.074,0,0,1,2,2V5.012A2.018,2.018,0,0,1,19,6.7V18a2.148,2.148,0,0,1-2,2Zm0-2H17V7H3ZM2,5H18V2H2Zm8.5,9.22A1.777,1.777,0,1,1,12.285,16,1.781,1.781,0,0,1,10.508,14.22Zm1.016,0a.762.762,0,1,0,.762-.762A.76.76,0,0,0,11.523,14.22ZM5.931,15.284l7.42-7.412.712.713L6.651,16Zm0-5.635a1.781,1.781,0,1,1,1.777,1.777A1.777,1.777,0,0,1,5.931,9.649Zm1.016,0a.765.765,0,1,0,.762-.762A.763.763,0,0,0,6.947,9.649Z" transform="translate(0 -0.37)" fill="#757575" />
                    </g>
                  </g>
                </svg>
              </div>
              <div className="title">Product Discount</div>
            </NavLink> || userDetails.superUser === "NEW"*/}
          </>
          : userDetails.superUser === "ADMIN" ?
            <>
              <NavLink to="/dashboard-user" className={`nav-link ${_activeMenu === "Dashboard" && "active"}`} activeClassName="active" onClick={() => onActiveMenu("Dashboard")}>
                <div className='icon_title'>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20.063 20.063" fill="currentColor">
                    <path id="Path_15791" data-name="Path 15791" d="M20.834,5.229V7.459H16.376V5.229h4.459m-11.146,0v6.688H5.229V5.229H9.688m11.146,8.917v6.688H16.376V14.146h4.459M9.688,18.6v2.229H5.229V18.6H9.688M23.063,3H14.146V9.688h8.917ZM11.917,3H3V14.146h8.917Zm11.146,8.917H14.146V23.063h8.917ZM11.917,16.376H3v6.688h8.917Z" transform="translate(-3 -3)" fill="currentColor" />
                  </svg>
                </div>
                <div className="title">Dashboard</div>
              </NavLink>
              {/* <NavLink to="/adminsubscription" className={`nav-link ${_activeMenu === "Subscription" && "active"}`} activeClassName="active" onClick={() => onActiveMenu("Subscription")}>
                <div className='icon_title'>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-credit-card-fill" viewBox="0 0 16 16">
                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1H0V4zm0 3v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7H0zm3 2h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1z" />
                  </svg>
                </div>
                <div className="title">Subscription</div>
              </NavLink> */}
              <NavLink to="/manage-user" className={`nav-link ${_activeMenu === "Manage Users" && "active"}`} activeClassName="active" onClick={() => onActiveMenu("Manage Users")}>
                <div className='icon_title'>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20 17.146" fill="currentColor">
                    <g id="Group_12268" data-name="Group 12268" transform="translate(-2 -4)">
                      <g id="Group_11958" data-name="Group 11958" transform="translate(2 4)">
                        <path id="Path_15803" data-name="Path 15803" d="M4,18v-.65a.946.946,0,0,1,.41-.81A10.889,10.889,0,0,1,10,15a.22.22,0,0,1,.08.01,6.886,6.886,0,0,1,.59-1.98c-.22-.02-.44-.03-.67-.03a12.876,12.876,0,0,0-6.61,1.82A2.922,2.922,0,0,0,2,17.35V20h9.26a7.133,7.133,0,0,1-.97-2Z" transform="translate(-2 -3.854)" fill="currentColor" />
                        <path id="Path_15804" data-name="Path 15804" d="M10,12A4,4,0,1,0,6,8,4,4,0,0,0,10,12Zm0-6A2,2,0,1,1,8,8,2.006,2.006,0,0,1,10,6Z" transform="translate(-1.943 -4)" fill="currentColor" />
                        <path id="Path_15805" data-name="Path 15805" d="M20.75,16a4.338,4.338,0,0,0-.06-.63l1.14-1.01-1-1.73-1.45.49a3.647,3.647,0,0,0-1.08-.63L18,11H16l-.3,1.49a3.647,3.647,0,0,0-1.08.63l-1.45-.49-1,1.73,1.14,1.01a4.338,4.338,0,0,0-.06.63,4.338,4.338,0,0,0,.06.63l-1.14,1.01,1,1.73,1.45-.49a3.647,3.647,0,0,0,1.08.63L16,21h2l.3-1.49a3.647,3.647,0,0,0,1.08-.63l1.45.49,1-1.73-1.14-1.01A4.338,4.338,0,0,0,20.75,16ZM17,18a2,2,0,1,1,2-2A2.006,2.006,0,0,1,17,18Z" transform="translate(-1.83 -3.854)" fill="currentColor" />
                      </g>
                    </g>
                  </svg>
                </div>
                <div className="title">Manage Users</div>
              </NavLink>
            </>
            : userDetails.superUser === "NEW" ?
              <>
                <NavLink to="/dashboard-user" className={`nav-link ${_activeMenu === "Dashboard" && "active"}`} activeClassName="active" onClick={() => onActiveMenu("Dashboard")}>
                  <div className='icon_title'>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20.063 20.063" fill="currentColor">
                      <path id="Path_15791" data-name="Path 15791" d="M20.834,5.229V7.459H16.376V5.229h4.459m-11.146,0v6.688H5.229V5.229H9.688m11.146,8.917v6.688H16.376V14.146h4.459M9.688,18.6v2.229H5.229V18.6H9.688M23.063,3H14.146V9.688h8.917ZM11.917,3H3V14.146h8.917Zm11.146,8.917H14.146V23.063h8.917ZM11.917,16.376H3v6.688h8.917Z" transform="translate(-3 -3)" fill="currentColor" />
                    </svg>
                  </div>
                  <div className="title">Dashboard</div>
                </NavLink>
              </>
              : userDetails.superUser === "USER" &&
              <NavLink to="/dashboard" className={`nav-link ${_activeMenu === "Dashboard" && "active"}`} activeClassName="active" onClick={() => onActiveMenu("Dashboard")}>
                <div className='icon_title'>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20.063 20.063" fill="currentColor">
                    <path id="Path_15791" data-name="Path 15791" d="M20.834,5.229V7.459H16.376V5.229h4.459m-11.146,0v6.688H5.229V5.229H9.688m11.146,8.917v6.688H16.376V14.146h4.459M9.688,18.6v2.229H5.229V18.6H9.688M23.063,3H14.146V9.688h8.917ZM11.917,3H3V14.146h8.917Zm11.146,8.917H14.146V23.063h8.917ZM11.917,16.376H3v6.688h8.917Z" transform="translate(-3 -3)" fill="currentColor" />
                  </svg>
                </div>
                <div className="title">Dashboard</div>
              </NavLink>
        }
      </Nav>
    </div>
  )
}

const MenuItem = ({ item }) => {
  const Component = hasChildren(item) ? MultiLevel : SingleLevel;
  return <Component item={item} />;
};

const SingleLevel = ({ item }) => {
  return (
    <>
      <NavLink to={item.to} className="nav-link d-flex align-items-center" activeClassName="active">
        <div className='icon_title'>{item.icon}</div>
        <div className="title">{item.title}</div>
      </NavLink>
    </>
  );
};

const MultiLevel = ({ item }) => {
  const menuState = useSelector(state => state.menu.isOpen);
  const { items: children } = item;
  const [open, setOpen] = useState(false);

  const handleClick = () => {
    if (menuState) {
      setOpen((prev) => !prev);
    }
    else {
      setOpen(false)
    }

  };
  useEffect(() => {
    setOpen(false)
  }, [menuState])

  return (
    <>
      <li onClick={handleClick}>
        <i className={`bi ${item.icon}`}></i>
        {menuState && <span className="title">{item.title}</span>}
        <span className="arrow-icon"> {open ? <i className="bi bi-arrow-up"></i> : <i className="bi bi-arrow-down"></i>}</span>
        <Collapse in={open}>
          <div>
            {!menuState && <span className="drawerclose-title">{item.title}</span>}
            <ul>
              {children.map((child, key) => (
                <MenuItem key={key} item={child} />
              ))}
            </ul>
          </div>
        </Collapse>
      </li>
    </>
  );
};

export default SideMenu
