import React, { useEffect, useState } from 'react';
import './Header.scss';
import { Dropdown, Tab, Nav } from 'react-bootstrap';
import { Link, NavLink, useHistory } from 'react-router-dom';
import profile from '../assets/images/profile-img.jpg'
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../ducks/gateway/login/actions';
import { getUserSubscriptions } from "../endpoints/subscription/users";
import appIcon from '../assets/images/appicons/app_sel.svg'
// import logo from '../assets/images/op_public/logo.png'
import logo from '../assets/images/op_public/logo.png'
import notificationBell from '../assets/images/notification_bell.png'
import { getUserProducts } from '../endpoints/gateway'
import gear from '../assets/images/other/header/gear.svg'
import Prof from '../assets/images/other/header/prof.svg'
import logoutIcon from '../assets/images/other/header/logout.svg'
import Offcanvas from 'react-bootstrap/Offcanvas';
import { ReactComponent as Dashboard } from '../assets/images/sidemenu/dashboard.svg'
import { ReactComponent as Domain } from '../assets/images/sidemenu/domain.svg'
import { ReactComponent as Project } from '../assets/images/sidemenu/projects.svg'
import { ReactComponent as Testscript } from '../assets/images/sidemenu/testscript.svg'
import { ReactComponent as Environment } from '../assets/images/sidemenu/environment.svg'
import { ReactComponent as Report } from '../assets/images/sidemenu/report.svg'
import { ReactComponent as Account } from '../assets/images/sidemenu/account.svg'
import { activeMenu } from '../ducks/gateway/login/actions';
import moment from 'moment';

// The forwardRef is important!!
// Dropdown needs access to the DOM node in order to position the Menu
const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
  <a href=" " ref={ref} onClick={(e) => { e.preventDefault(); onClick(e); }} className='btn btn_application' >
    {children}
  </a>
));

// forwardRef again here!
// Dropdown needs access to the DOM of the Menu to measure it
const chooseApp = React.forwardRef(
  ({ children, style, className, 'aria-labelledby': labeledBy }, ref) => {

    const [value, setValue] = useState('');

    return (
      <div ref={ref} style={style} className={className} aria-labelledby={labeledBy} >
        <div className='p-3 product_dropdown_title'>Switch to</div>
        <ul className="list-unstyled p-1 pt-2 bg-white m-0">
          {React.Children.toArray(children).filter(
            (child) =>
              !value || child.props.children.toLowerCase().startsWith(value),
          )}
        </ul>
      </div>
    );
  },
);


const Header = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const userState = useSelector(state => state.user);
  const firstInitial = userState.userInfo.firstname.charAt(0);
  const lastInitial = userState.userInfo.lastname.charAt(0);
  const initials = firstInitial + lastInitial;
  const [allProducts, setAllProducts] = useState(null);
  const onLogout = (evt) => {
    evt.preventDefault();
    dispatch(logout());
  };
  const onActiveMenu = (data, e) => {
    dispatch(activeMenu(data));
  };

  useEffect(() => {

    if (!userState.isLoggedIn) {
      history.push("/login");
    }

    let user_type = userState.userInfo.allInfo.superUser;
    if (user_type === "ADMIN" || user_type === "USER") {
      getSubscriptions();
    }


  }, [userState.isLoggedIn])

  const [assignedProject, setassignedProject] = useState([])

  const fetchProduct = async () => {
    let userId = {
      "userId": userState.userInfo.userId
    }
    let response = await getUserProducts(userId)
    setassignedProject(response.data)

  }

  const getSubscriptions = async () => {
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    let response = await getUserSubscriptions(timeZone);
    if (response.status === 200) {
      setAllProducts(response.data.subscribed_products);
    }
  }

  const handleOpenApp = (url) => {
    window.open(`https://dtlehta1thuw9.cloudfront.net/1platformsubsv2${url}`, "_self");
  }

  // header Mobile responsive

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <header id="header" className="header fixed-top d-flex align-items-center">
      <div className='d-flex align-items-center'>
        <Dropdown>
          <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components" className='filter-btn'>
            <img src={appIcon} alt='application' className='application-icon' />
          </Dropdown.Toggle>
          <Dropdown.Menu className='product_dropdown p-0' as={chooseApp}>
            {allProducts?.length > 0 ? <>
              {
                allProducts?.map((val, index) => val.status === "Active" && (
                  <Dropdown.Item key={val.product_id} className='d-flex align-items-center gap-3 p-2 my-1 product_button' onClick={() => handleOpenApp(val.product_access_url)}>
                    <img src={val?.product_logo} className='product_icon' alt='Quantify' />
                    <div className='application_name'>{val.product_name}</div>
                  </Dropdown.Item>
                ))
              }
            </> :
              <>
                <Dropdown.Item className='product_dropdown_title list-unstyled p-1 py-3 bg-white m-0 text-dark text-center'>No Products Found</Dropdown.Item>
              </>
            }
          </Dropdown.Menu>
        </Dropdown>
        <div className='seperator mx-3'></div>
        <div className='logo-block'>
          <img src={logo} alt='logo' className='logoMain' />
        </div>
      </div>
      <nav className="header-nav ms-auto me-4 d-none d-md-block">
        <ul className="nav align-items-center me-auto mb-2 mb-lg-0">
          {/* <li className="nav-item">
            <Dropdown>
              <Dropdown.Toggle className="nav-link count-indicator">
                <svg xmlns="http://www.w3.org/2000/svg" width="18.5" height="21.5" fill="#000" class="bi bi-search" viewBox="0 0 16 16">
                  <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                </svg>
              </Dropdown.Toggle>
            </Dropdown>
          </li>          */}
          <li className="nav-item LoginTime">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">
                <path id="schedule_FILL0_wght400_GRAD0_opsz24" d="M89.31-869.71l.98-.98-2.59-2.59v-3.22H86.3v3.78ZM87-866a6.815,6.815,0,0,1-2.73-.551,7.07,7.07,0,0,1-2.222-1.5,7.069,7.069,0,0,1-1.5-2.223A6.816,6.816,0,0,1,80-873a6.816,6.816,0,0,1,.551-2.73,7.068,7.068,0,0,1,1.5-2.223,7.069,7.069,0,0,1,2.222-1.5A6.815,6.815,0,0,1,87-880a6.815,6.815,0,0,1,2.73.551,7.069,7.069,0,0,1,2.222,1.5,7.068,7.068,0,0,1,1.5,2.223A6.816,6.816,0,0,1,94-873a6.816,6.816,0,0,1-.551,2.73,7.069,7.069,0,0,1-1.5,2.223,7.07,7.07,0,0,1-2.222,1.5A6.815,6.815,0,0,1,87-866ZM87-873Zm0,5.6a5.4,5.4,0,0,0,3.964-1.636A5.4,5.4,0,0,0,92.6-873a5.4,5.4,0,0,0-1.636-3.964A5.4,5.4,0,0,0,87-878.6a5.4,5.4,0,0,0-3.964,1.636A5.4,5.4,0,0,0,81.4-873a5.4,5.4,0,0,0,1.636,3.964A5.4,5.4,0,0,0,87-867.4Z" transform="translate(-80 880)" fill="#828282" />
              </svg>
            </span>
            <ul>
              <li><label>Login time :</label><span>{moment(userState.userInfo.loginTime).format('hh:mm:ss A')}</span></li>
            </ul>
          </li>
          <li className="nav-item">
            <Dropdown>
              <Dropdown.Toggle className="nav-link count-indicator notificationButton">
                <svg xmlns="http://www.w3.org/2000/svg" width="18.5" height="21.5" viewBox="0 0 18.5 21.5">
                  <g id="Group_10754" data-name="Group 10754" transform="translate(0.25 0.25)">
                    <path id="Path_813" data-name="Path 813" d="M12,21a1.5,1.5,0,0,1-1.5-1.5H9a3,3,0,0,0,6,0H13.5A1.5,1.5,0,0,1,12,21Z" transform="translate(-3 -1.5)" stroke="#000" stroke-width="0.5" fill-rule="evenodd" />
                    <path id="Path_814" data-name="Path 814" d="M5.6,16.5A2.973,2.973,0,0,0,6,15V9A6,6,0,0,1,18,9v6a2.973,2.973,0,0,0,.4,1.5ZM19.5,15V9a7.5,7.5,0,0,0-15,0v6A1.5,1.5,0,0,1,3,16.5V18H21V16.5A1.5,1.5,0,0,1,19.5,15Z" transform="translate(-3 -1.5)" stroke="#000" stroke-width="0.5" fill-rule="evenodd" />
                  </g>
                </svg>
              </Dropdown.Toggle>
              <Dropdown.Menu className="dropdown-menu op_drawer navbar-dropdown preview-list p-0">
                <div className="p-3 m-0 dropdown_header">Notifications</div>
                <div className="dropdown-divider"></div>
                <Dropdown.Item className="dropdown-item preview-item" style={{ cursor: 'text' }}>
                  <div className="preview-thumbnail">
                    <div className="preview-icon bg-success">
                      <i className="mdi mdi-calendar"></i>
                    </div>
                  </div>
                  <div className="d-flex align-items-center justify-content-center" style={{ height: '20vh', width: '20vw' }}>
                    <div className='text-center py-4'>
                      <img src={notificationBell} alt='Message' style={{ width: '45px', maxHeight: '59px', opacity: '.5' }} />
                      <div className="preview-subject mt-2 font-weight-normal mb-1">No New Notifications</div>
                    </div>
                  </div>
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </li>
          <li className="nav-item">
            <Dropdown>
              <Dropdown.Toggle className="nav-link count-indicator d-flex align-items-center notificationButton">
                {/* <img src={profile} alt="Profile" className="rounded-circle me-1" /> */}
                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                  <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664z" />
                </svg>
              </Dropdown.Toggle>
              <Dropdown.Menu className="dropdown-menu  profile_drawer navbar-dropdown">
                <div className='user_info userInfoHeader'>
                  <div className="userProfilePic">
                    <span>{initials}</span>
                  </div>
                  <div className="userName">
                    {userState.userInfo.firstname + " " + userState.userInfo.lastname}
                  </div>
                  <div className="user_work" title={userState.userInfo.email}>{userState.userInfo.email}</div>
                </div>
                {/* <div className="dropdown-divider"></div> */}
                <div className='wrapperLoginMenu'>
                  <div className='innerMenu'>
                    <Dropdown.Item onClick={evt => { evt.preventDefault(); onActiveMenu("") }}>
                      <Link to='/user-profile' >
                        <div className="d-flex align-items-center dropdown_list_items">
                          <img src={Prof} alt='' />
                          <div className="mb-0 ps-2">Profile</div>
                        </div>
                      </Link>
                    </Dropdown.Item>
                    {/* <Dropdown.Item onClick={evt => { evt.preventDefault(); onActiveMenu("") }}>
                      <Link to='/user-profile' >
                        <div className="d-flex align-items-center dropdown_list_items">
                          <img src={gear} alt='' />
                          <div className="mb-0 ps-2">Settings</div>
                        </div>
                      </Link>
                    </Dropdown.Item> */}
                  </div>
                  {/* <div className="dropdown-divider"></div> */}
                  <Dropdown.Item onClick={(evt) => { onLogout(evt) }}>
                    <div className="d-flex align-items-center dropdown_list_items">
                      <img src={logoutIcon} alt='' />
                      <div className="mb-0 ps-2">Log Out</div>
                    </div>
                  </Dropdown.Item>
                </div>
              </Dropdown.Menu>
            </Dropdown>
          </li>
        </ul>
      </nav>
      <nav className='header-nav ms-auto me-4 d-block d-md-none' >
        <button className='btn btn_light ' onClick={handleShow}><i class="bi bi-list"></i></button>
      </nav>
      <Offcanvas show={show} onHide={handleClose}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            <div className='logo_section_mobile'>
              <img src={profile} alt="Profile" className=" userPic me-1" />
              <div className='userDetails'>
                <h3>{userState.userInfo.firstname + " " + userState.userInfo.lastname}</h3>
                <p>{userState.userInfo.allInfo?.userEmail}</p>
              </div>
            </div>
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body className='p-0'>
          <div className='mobileMenu'>
            <Tab.Container id="left-tabs-example" defaultActiveKey='sidemenu' unmountOnExit={true}>
              <Nav className='justify-content-center'>
                <Nav.Item className='w-50'><Nav.Link eventKey="sidemenu">App menu</Nav.Link></Nav.Item>
                <Nav.Item className='w-50'><Nav.Link eventKey="profilemenu">Profile menu</Nav.Link></Nav.Item>
              </Nav>
              <Tab.Content className='py-3 tab_body'>
                <Tab.Pane eventKey="sidemenu">
                  <NavLink to="/platformadmin" className="nav-link d-flex gap-2 align-items-center px-3" activeClassName="active">
                    <div className='icon_title'><Dashboard /></div>
                    <div className="title">Company Admin</div>
                  </NavLink>
                  <NavLink to="/approve" className="nav-link d-flex gap-2 align-items-center px-3" activeClassName="active">
                    <div className='icon_title'><Domain /></div>
                    <div className="title">1platform Admin</div>
                  </NavLink>
                </Tab.Pane>
                <Tab.Pane eventKey="profilemenu">
                  <NavLink to="/profile" className="nav-link d-flex gap-2 align-items-center px-3" activeClassName="active">
                    <div className='icon_title'>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-gear" viewBox="0 0 16 16">
                        <path d="M8 4.754a3.246 3.246 0 1 0 0 6.492 3.246 3.246 0 0 0 0-6.492zM5.754 8a2.246 2.246 0 1 1 4.492 0 2.246 2.246 0 0 1-4.492 0z" />
                        <path d="M9.796 1.343c-.527-1.79-3.065-1.79-3.592 0l-.094.319a.873.873 0 0 1-1.255.52l-.292-.16c-1.64-.892-3.433.902-2.54 2.541l.159.292a.873.873 0 0 1-.52 1.255l-.319.094c-1.79.527-1.79 3.065 0 3.592l.319.094a.873.873 0 0 1 .52 1.255l-.16.292c-.892 1.64.901 3.434 2.541 2.54l.292-.159a.873.873 0 0 1 1.255.52l.094.319c.527 1.79 3.065 1.79 3.592 0l.094-.319a.873.873 0 0 1 1.255-.52l.292.16c1.64.893 3.434-.902 2.54-2.541l-.159-.292a.873.873 0 0 1 .52-1.255l.319-.094c1.79-.527 1.79-3.065 0-3.592l-.319-.094a.873.873 0 0 1-.52-1.255l.16-.292c.893-1.64-.902-3.433-2.541-2.54l-.292.159a.873.873 0 0 1-1.255-.52l-.094-.319zm-2.633.283c.246-.835 1.428-.835 1.674 0l.094.319a1.873 1.873 0 0 0 2.693 1.115l.291-.16c.764-.415 1.6.42 1.184 1.185l-.159.292a1.873 1.873 0 0 0 1.116 2.692l.318.094c.835.246.835 1.428 0 1.674l-.319.094a1.873 1.873 0 0 0-1.115 2.693l.16.291c.415.764-.42 1.6-1.185 1.184l-.291-.159a1.873 1.873 0 0 0-2.693 1.116l-.094.318c-.246.835-1.428.835-1.674 0l-.094-.319a1.873 1.873 0 0 0-2.692-1.115l-.292.16c-.764.415-1.6-.42-1.184-1.185l.159-.291A1.873 1.873 0 0 0 1.945 8.93l-.319-.094c-.835-.246-.835-1.428 0-1.674l.319-.094A1.873 1.873 0 0 0 3.06 4.377l-.16-.292c-.415-.764.42-1.6 1.185-1.184l.292.159a1.873 1.873 0 0 0 2.692-1.115l.094-.319z" />
                      </svg>
                    </div>
                    <div className="title">Account Settings</div>
                  </NavLink>
                  <button onClick={(evt) => { onLogout(evt) }} className="nav-link btn w-100 d-flex gap-2 align-items-center px-3" activeClassName="active">
                    <div className='icon_title'>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z" />
                        <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z" />
                      </svg>
                    </div>
                    <div className="title">Logout</div>
                  </button>
                </Tab.Pane>
              </Tab.Content>
            </Tab.Container>
          </div>
        </Offcanvas.Body>
      </Offcanvas>
    </header>
  )
}

export default Header