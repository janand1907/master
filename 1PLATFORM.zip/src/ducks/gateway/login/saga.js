import { call, put, takeLatest, takeEvery, select } from 'redux-saga/effects';
import * as api from '../../../endpoints/gateway';
import * as apiSub from '../../../endpoints/subscription/users';
import * as types from './types';
// import { push } from 'react-router-redux';
import configureStore from '../../../store/configureStore';

function* login({ payload }) {
    try {
        yield put({ type: types.LOGIN_LODING });
        let result;
        result = yield call(api.login, payload.userName, payload.password);
        yield put({ type: types.MENU_ACTIVE_SUCCESS, payload : "Dashboard" });
        if (result.status === 200) {

            if (result.data.force_change_password) {

                const userInfo = {
                    isLoggedIn: true,
                    firstname: result.data.first_name,
                    lastname: result.data.last_name,
                    email: result.data.email,
                    username: result.data.email,
                    isForcePassword: result.data.force_change_password,
                    sessionId: result.data.session_id,
                    loginTime: new Date().getTime()
                };

                yield put({ type: types.LOGIN_SUCCESS, payload: { userInfo } });

            } else {

                localStorage.setItem("Authorization", result.data.secret);

                var allInfo = {
                    email: result.data.email,
                    firstname: result.data.first_name,
                    lastname: result.data.last_name,
                    accessToken: result.data.secret,
                    username: result.data.email,
                    platformAdmin: result.data.platform_admin,
                    superUser: result.data.subscription_user_type
                }

                const userInfo = {
                    isLoggedIn: true,
                    firstname: result.data.first_name,
                    lastname: result.data.last_name,
                    email: result.data.email,
                    username: result.data.email,
                    userId: result.data.userId,
                    loginTime: new Date().getTime(),
                    allInfo
                };

                localStorage.setItem('USER_INFO', JSON.stringify(userInfo));
                yield put({ type: types.LOGIN_SUCCESS, payload: { userInfo } });

            }


        } else if (result.response.status == 500) {
            if(result?.response?.data){
                yield put({ type: types.LOGIN_FAILURE, payload: result.response.data.message });
            }else{
                yield put({ type: types.LOGIN_FAILURE, payload: result.response.data.errors[0].message });
            }
        }else if (result.response.status == 400) {
            yield put({ type: types.LOGIN_FAILURE, payload: result.response.data.errors[0].message });
        } else {
           
            const usererror = {
                dseverity: 'error',
                dAlertTitle: 'Error',
                error: result.response.data.errors[0].message,
                isError: true
            }

            yield put({ type: types.LOGIN_FAILURE, payload: result.response.data.errors[0].message });
        }

    } catch (err) {
        localStorage.clear();
        yield put({ type: types.LOGIN_FAILURE, payload: "Incorrect email or password" });
    }
}

function* logoutUser({ payload }) {
    try {
        localStorage.setItem("Authorization", null);
        localStorage.removeItem('USER_INFO');
        const store = configureStore();
        store.persistor.purge();
        yield put({ type: types.LOGOUT_SUCCESS, payload });
        return { type: types.LOGOUT_SUCCESS };
    } catch (err) {
        yield put({ type: types.LOGOUT_FAILURE, payload: "error" });
    }
}

function* loginReset({ payload }) {
    try {
        yield put({ type: types.LOGIN_RESET_SUCCESS, payload });
    } catch (err) {
        yield put({ type: types.LOGIN_RESET_FAILURE, payload: "error" });
    }
}

// function* forcePassword({ payload }) {
//     try {  

//         yield put({ type: types.LOGIN_LODING });
//         let result;
//         result = yield call(api.forceUpdatePassword, payload.userName, payload.password, payload.sessionId);  

//         if(result.status == 200) {
//             localStorage.setItem("Authorization", result.data.secret);

//             var allInfo = {
//                 email:result.data.email,
//                 firstname:result.data.first_name,
//                 lastname:result.data.last_name,
//                 accessToken:result.data.secret,
//                 username:result.data.email,
//                 platformAdmin:result.data.platform_admin,
//                 superUser:result.data.subscription_user_type,
//             }

//             const userInfo = {                
//                 isLoggedIn: true,
//                 firstname: result.data.first_name,
//                 lastname:result.data.last_name,
//                 email:result.data.email,
//                 username:result.data.email,
//                 userId:result.data.userId,
//                 allInfo
//             };

//             localStorage.setItem('USER_INFO', JSON.stringify(userInfo));            
//             yield put({ type: types.LOGIN_SUCCESS, payload: {userInfo} });

//         }else if(result.response.status == 500){        

//             yield put({ type: types.LOGIN_FAILURE, payload: result.response.data.message }); 

//         }else {

//             const usererror = {
//                 dseverity: 'error',
//                 dAlertTitle: 'Error',
//                 error: result.data.error.message,
//                 isError: true
//             }

//             yield put({ type: types.LOGIN_FAILURE, payload: result.data.error });
//         }

//     } catch (err) {
//         yield put({ type: types.LOGIN_FAILURE, payload: "error" });
//     }
// }

function* forcePassword({ payload }) {
    try {
        yield put({ type: types.LOGIN_LODING });
        let result = payload;
        yield put({ type: types.MENU_ACTIVE_SUCCESS, payload : "Dashboard" });
        if (result.message) {

            yield put({ type: types.LOGIN_FAILURE, payload: result.message });


        } else {
            localStorage.setItem("Authorization", result.secret);

            var allInfo = {
                email: result.email,
                firstname: result.first_name,
                lastname: result.last_name,
                accessToken: result.secret,
                username: result.email,
                platformAdmin: result.platform_admin,
                superUser: result.subscription_user_type,
            }

            const userInfo = {
                isLoggedIn: true,
                firstname: result.first_name,
                lastname: result.last_name,
                email: result.email,
                username: result.email,
                userId: result.userId,
                allInfo
            };

            localStorage.setItem('USER_INFO', JSON.stringify(userInfo));
            yield put({ type: types.LOGIN_SUCCESS, payload: { userInfo } });

        }

    } catch (err) {
        yield put({ type: types.LOGIN_FAILURE, payload: "Invalid session for the user, session is expired." });
    }
}

function* loginFailure({ payload }) {
    // try {  
    //     yield put({ type: types.LOGIN_FAILURE, payload });
    // } catch (err) {
    //     yield put({ type: types.LOGIN_FAILURE, payload: "error" });
    // }
}
function* activeMenu({ payload }) {
    try {
        yield put({ type: types.MENU_ACTIVE_SUCCESS, payload });
    } catch (err) {
        yield put({ type: types.MENU_ACTIVE_FAILURE, payload: "error" });
    }
}

function* loginSaga(data) {
    yield takeLatest(types.LOGIN_REQUEST, login);
    yield takeLatest(types.LOGOUT_REQUEST, logoutUser);
    yield takeLatest(types.LOGIN_RESET_REQUEST, loginReset);
    yield takeLatest(types.FROCE_PASS_REQUEST, forcePassword);
    // yield takeLatest(types.LOGIN_FAILURE, loginFailure);
    yield takeLatest(types.MENU_ACTIVE_REQUEST, activeMenu);

}

export default loginSaga;
