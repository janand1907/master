import * as types from './types';
import configureStore from '../../../store/configureStore';

export function login(userName, password) {
    return { type: types.LOGIN_REQUEST, payload: { userName, password } };
}

// export function forcePassword(userName, password, sessionId) {    
//     return { type: types.FROCE_PASS_REQUEST, payload: { userName, password, sessionId } };
// }

export function forcePassword(payload) {
    debugger;
    return { type: types.FROCE_PASS_REQUEST, payload };
}

export function loginSuccess(userInfo) {
    return { type: types.LOGIN_SUCCESS, payload: { userInfo } };
}

export function loginFailure(message) {
    return { type: types.LOGIN_FAILURE, payload: message };
}

export const logoutUser = () => {
    const store = configureStore();
    localStorage.removeItem('USER_INFO');
    store.persistor.purge();
    return { type: types.LOGOUT_SUCCESS };
};

export function loginReset(payload) {
    return { type: types.LOGIN_RESET_REQUEST, payload: payload };
}

export const logout = () => {

    const payload = {
        userInfo: {
            isLoggedIn: false,
            firstname: '',
            lastname: '',
            email: '',
            username: '',
            allInfo: {}
        },
        error: [],
        isLoggedIn: false,
        isError: false,
        isPending: false
    }

    return { type: types.LOGOUT_REQUEST, payload };
};
export function activeMenu(payload) {
    return { type: types.MENU_ACTIVE_REQUEST, payload: payload };
}