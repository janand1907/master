import * as types from './types';

export function signup(details) {    
	return { type: types.REGISTER_REQUEST, payload: details };
}


export function signupComplete() { 
	return { type: types.REGISTER_COMPLETE};
}

export function signupUpdate() { 
	return { type: types.REGISTER_SUCCESS};
}
