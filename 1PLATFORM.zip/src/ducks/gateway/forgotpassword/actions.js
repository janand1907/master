import * as types from './types';

export function createcode(userName, password) {
	return { type: types.CODE_REQUEST, payload: { userName, password } };
}

export function createcodereset() {
	return { type: types.CODE_RESET};
}

export function resetclear() {
	return { type: types.FORGOT_RESET};
}



export function resetpassword(userName, password,confirmCode){
    
    return { type: types.FORGOT_REQUEST, payload: { userName, password,confirmCode } };
}