import loginSaga from '../gateway/login/saga';
import signup from '../gateway/signup/saga';
import createcode from '../gateway/forgotpassword/saga';
import resetpassword from '../gateway/forgotpassword/resetsaga';

export {
    loginSaga, signup, createcode, resetpassword,
}