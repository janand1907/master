import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import './subscriptiontabs.scss'
import { useHistory } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import { getSubscribe } from '../../../endpoints/gateway';
import { saveMonthlySubscribePlan } from '../../../endpoints/gateway';
import { color } from 'highcharts';

const Annually = ({ subscriptionModeId, productId }) => {
  
  const history = useHistory();
  const dispatch = useDispatch();
  const userDetails = useSelector(state => state.user.userInfo.allInfo);
  const [planDetails, setplanDetails] = useState([])


  const [concurrentUser, setConcurrentUser] = useState(0);
  const [loadGenerator, setLoadGenerator] = useState(0);
  const [maxTestDuration, setMaxTestDuration] = useState(0);
  const [apmMonitoring, setApmMonitoring] = useState(0);
  const [virtualUser, setVirtualUser] = useState(0);
  const [apiCalls, setApiCalls] = useState(0);

  const [concurrentUserError, setConcurrentUserError] = useState("");
  const [loadGeneratorError, setLoadGeneratorError] = useState("");
  const [maxTestDurationError, setMaxTestDurationError] = useState("");
  const [apmMonitoringError, setApmMonitoringError] = useState("");
  const [virtualUserError, setVirtualUserError] = useState("");
  const [apiCallsError, setApiCallsError] = useState("");

  const [totalPrice, setTotalPrice] = useState(0);
  const [data, setData] = useState([]);

  useEffect(() => {
    getAnnualPlan()
  }, [])

  const getAnnualPlan = async () => {

    let response = await getSubscribe(productId, subscriptionModeId)
    setplanDetails(response.data)
  }

  const handleCalculate = async () => {
    if (concurrentUser === 0) { setConcurrentUserError("required"); return; } else { setConcurrentUserError(""); }
    if (loadGenerator === 0) { setLoadGeneratorError("required"); return; } else { setLoadGeneratorError(""); }
    if (maxTestDuration === 0) { setMaxTestDurationError("required"); return; } else { setMaxTestDurationError(""); }
    if (apmMonitoring === 0) { setApmMonitoringError("required"); return; } else { setApmMonitoringError(""); }
    if (virtualUser === 0) { setVirtualUserError("required"); return; } else { setVirtualUserError(""); }
    if (apiCalls === 0) { setApiCallsError("required"); return; } else { setApiCallsError(""); }

    let resData = {
      "concurrentUsers": concurrentUser,
      "loadGenerator": loadGenerator,
      "virtualUserHours": virtualUser,
      "maxTestDuration": maxTestDuration,
      "apmMonitoring": apmMonitoring,
      "apiCalls": apiCalls,
      "subscriptionModeId": 2,
      "productId": 1
    }

    let response = await saveMonthlySubscribePlan(`/feedOnDemandCalculate/${userDetails.userId}`, 'POST', resData)
    if (response) {
      setData(response.data.data);
      setTotalPrice(response.data.data.totalPrice);
    }

  }

  const subscribe = (subscriptionId, subscriptionPlanId) => {
    
    let payload = {
      subscriptionId: 2,
      subscriptionPlanId: 1,
      subscriptionModeId: 1,
      productId: 1
    }
    dispatch({ type: 'addSubscription', payload: payload });
    history.push(`/billing`);
  }
  const check = <svg xmlns="http://www.w3.org/2000/svg" width="14.914" height="11.161" viewBox="0 0 14.914 11.161">
    <path id="done_FILL0_wght400_GRAD0_opsz48_2" data-name="done_FILL0_wght400_GRAD0_opsz48 2" d="M12.345,21.947,7.7,17.3l.892-.892,3.753,3.753L20.308,12.2l.892.892Z" transform="translate(-6.993 -11.493)" fill="#828282" stroke="#828282" stroke-width="1" />
  </svg>
  return (
    <div>
      <div className='row justify-content-center g-3'>
        {planDetails?.map((val, index) => (

          <div className='col-md-4' key={index}>
            <div className='subscribe_panel card'>
              <div className='pan_header card-header py-3'>
                <div className='panel_title'>{val.subscribeTypes.subscriptionName}</div>
                {/* <div className='d-flex gap-2 justify-content-center'>
        <div className='main_price'><div className='dollar'>$</div>{val.totalPrice}</div>
      </div> */}
                <div className='d-flex gap-2 justify-content-center'>
                  <div className='strike_price my-2'>$ {val.totalPrice}</div>
                  <div className='main_price'><div className='dollar'>$</div>{val.offerPrice}</div>
                </div>
                <div className='pan_notes'>(Billed Monthly)</div>
              </div>
              <div className='card-body py-0 pan_body'>
                <div className='pan_body_title'>It Includes:</div>
                <div className='feature_list_panel my-2'>
                  <ul className='features_list'>
                    <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>{val.concurrentUsers} </b>Concurrent Users</p> </li>
                    <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>{val.loadGenerator}  </b> Load Generator</p> </li>
                    <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>{val.maxTestDuration} h </b> Max Test Duration</p> </li>
                    <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>{val.apiCalls}</b> API Calls</p> </li>
                    <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>{val.virtualUserHours} </b> Virtual User Hours</p> </li>
                    <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>{val.apmMonitoring} </b> APM  Monitoring</p> </li>
                    {/* <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>Mock</b> Services</p> </li> */}
                  </ul>
                </div>
              </div>
              <div className='card-footer mb-3 pan_footer mx-0'>
                <button onClick={() => subscribe(val.subscribeTypes.subscriptionId, val.subscriptionPlanId)} className='btn btn_primary' style={{ width: '100%', fontSize: '1rem' }}>Subscribe</button>
              </div>
            </div>
          </div>
        ))

        }
        {/* <div className='col-md-4'>
            <div className='subscribe_panel card'>
                <div className='pan_highlight'>Most Popular</div>
                <div className='pan_header card-header py-3'>
                    <div className='panel_title'>Pro - Unlimited</div>
                    <div className='d-flex gap-2 justify-content-center'>
                      <div className='strike_price my-2'>$ 499</div>
                      <div className='main_price'><div className='dollar'>$</div>424.15</div>
                    </div>
                    <div className='pan_notes'>(Billed Monthly)</div>
                </div>
                <div className='card-body py-0 pan_body'>
                  <div className='pan_body_title'>Require Package:</div>
                  <div className='feature_list_panel my-2'>
                    <ul className='features_list'>
                      <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>5,000</b> Concurrent Users</p></li>
                      <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>20</b> Load Generator</p></li>
                      <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>5h</b> Max Test Duration</p></li>
                      <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>APM Monitoring</p> </li>
                      <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>6,500</b> Virtual User Hours</p></li>
                      <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>300000</b> API calls API Monitoring and API Functional Testing per year. (<b>25,000</b> API Monitoring and API Functional testing per Month)</p> </li>
                      <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'><b>Mock</b> Services</p> </li>
                    </ul>                                              
                  </div>
                </div>
                <div className='card-footer mb-3 pan_footer text-center'>
                  <Link to="/billing" className='btn btn_subscribe' style={{width:'100%', fontSize:'1rem'}}>Subscribe</Link>
                </div>
            </div>
          </div>   */}
        <div className='col-md-4'>
          {/* <div className='subscribe_panel card'>
            <div className='pan_header card-header py-3'>
              <div className='panel_title'>OnDemand</div>
              <div className='d-flex gap-2 justify-content-center'>
                <div className='main_price'><div className='dollar'>$</div>{totalPrice}</div>
              </div>
              <div className='pan_notes'>(Billed Monthly)</div>
            </div>
            <div className='card-body py-0 pan_body'>
              <div className='pan_body_title'>Customise your require</div>
              <div className='feature_list_panel my-2'>
              <ul className='features_list'>
                  <li className='row g-1 align-items-center py-1'> <div className='col-md-6 sub_label text-end me-2'>Concurrent Users</div><div className='col'><input type='number' name="concurrentUsers" className="form-control" value={concurrentUser} onChange={(e) => setConcurrentUser(e.target.value)} min="0" /><span style={{fontSize:'.75rem',color:'#FF0000'}}>{concurrentUserError}</span></div> </li>
                  <li className='row g-1 align-items-center py-1'> <div className='col-md-6 sub_label text-end me-2'>Load Generators</div><div className='col'><input type='number' name="loadGenerator" className="form-control" value={loadGenerator} onChange={(e) => setLoadGenerator(e.target.value)} min="0" /><span style={{fontSize:'.75rem',color:'#FF0000'}}>{loadGeneratorError}</span></div> </li>
                  <li className='row g-1 align-items-center py-1'> <div className='col-md-6 sub_label text-end me-2'>Max Test Duration</div><div className='col'><input type='number' name="maxTestDuration" className="form-control" value={maxTestDuration} onChange={(e) => setMaxTestDuration(e.target.value)} min="0" /><span style={{fontSize:'.75rem',color:'#FF0000'}}>{maxTestDurationError}</span></div> </li>
                  <li className='row g-1 align-items-center py-1'> <div className='col-md-6 sub_label text-end me-2'>APM Monitoring</div><div className='col'><input type='number' name="apmMonitoring" className="form-control" value={apmMonitoring} onChange={(e) => setApmMonitoring(e.target.value)} min="0" /><span style={{fontSize:'.75rem',color:'#FF0000'}}>{apmMonitoringError}</span></div> </li>
                  <li className='row g-1 align-items-center py-1'> <div className='col-md-6 sub_label text-end me-2'>Virtual User Hours</div><div className='col'><input type='number' name="virtualUserHours" className="form-control" value={virtualUser} onChange={(e) => setVirtualUser(e.target.value)} min="0" /><span style={{fontSize:'.75rem',color:'#FF0000'}}>{virtualUserError}</span></div> </li>
                  <li className='row g-1 align-items-center py-1'> <div className='col-md-6 sub_label text-end me-2'>API calls</div><div className='col'><input type='number' name="apiCalls" className="form-control" value={apiCalls} onChange={(e) => setApiCalls(e.target.value)} min="0" /><span style={{fontSize:'.75rem',color:'#FF0000'}}>{apiCallsError}</span></div> </li>
                  <li className='row py-1'> <div className='col text-end me-1' ><button className='btn_link_underline' onClick={handleCalculate}>Calculate</button></div></li>
                </ul>
              </div>

            </div>
            <div className='card-footer mb-3 pan_footer text-center mx-0'>
              <Link to={{ pathname: "/billing", state: { data: data } }} className='btn btn_primary' style={{ width: '100%', fontSize: '1rem' }}>Subscribe</Link>
            </div>
          </div> */}

          <div className='subscribe_panel card'>
            <div className='pan_header card-header py-3'>
              <div className='ribbon_wrapper'>
                <div className='ribbon_main'>Annually</div>
              </div>
              <div className='panel_title'>Pro<br /> Unlimited</div>
              <div className='needMorevu my-3'>Need more<br /> VUs?</div>
              <Link className='sub_contact text-center'>quantify_info@1tx.io</Link>
            </div>
            <div className='card-body py-0 pan_body'>
              <div className='feature_list_panel my-2'>
                <ul className='features_list'>
                  <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>Volume Discounts</p> </li>
                  <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>Fixed Costs (Unlimited) Plans</p> </li>
                  <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>Dedicated IPs </p> </li>
                  <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>On Premise Options</p> </li>
                  <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>Priority Support</p></li>
                </ul>
              </div>
            </div>
            <div className='card-footer mb-3 pan_footer mx-0'>
              {/* <button className='btn btn_primary' style={{width:'100%', fontSize:'1rem'}}>Contact Us</button> */}
              <Link to={{ pathname: "/billing", state: { data: data,type:2 } }} className='btn btn_primary' style={{ width: '100%', fontSize: '1rem' }}>Contact Us</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Annually