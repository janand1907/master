import React from 'react'
import './subscriptiontabs.scss'
import { Link } from 'react-router-dom'
const Enterprise = ({subscriptionModeId,productId}) => {
  
    const check = <svg xmlns="http://www.w3.org/2000/svg" width="14.914" height="11.161" viewBox="0 0 14.914 11.161">
    <path id="done_FILL0_wght400_GRAD0_opsz48_2" data-name="done_FILL0_wght400_GRAD0_opsz48 2" d="M12.345,21.947,7.7,17.3l.892-.892,3.753,3.753L20.308,12.2l.892.892Z" transform="translate(-6.993 -11.493)" fill="#828282" stroke="#828282" stroke-width="1"/>
    </svg>     
  return (
    <div>
       <div className='row justify-content-center g-3'>
         <div className='col-md-4'>
           <div className='subscribe_panel card'>
               <div className='pan_header card-header py-3'>
                  <div className='ribbon_wrapper'>
                    <div className='ribbon_main'>Annually</div>
                  </div>
                  <div className='panel_title'>Enterprise<br /> on-premise</div>
                  <div className='needMorevu my-3'>Need more<br/> VUs?</div>
                  <Link className='sub_contact text-center'>contactsales@qassure.com</Link>
               </div>                                        
               <div className='card-body py-0 pan_body'>
                 <div className='feature_list_panel my-2'>
                   <ul className='features_list'>
                     <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>Volume Discounts</p> </li>
                     <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>Fixed Costs (Unlimited) Plans</p> </li>
                     <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>Dedicated IPs </p> </li>
                     <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>On Premise Options</p> </li>
                     <li className='features_list_item py-2'> <span className='checkIcon  me-2'>{check}</span><p className='mb-0'>Priority Support</p></li>
                   </ul>
                 </div>
               </div>
               <div className='card-footer mb-3 pan_footer mx-0'>
                 <button className='btn btn_primary' style={{width:'100%', fontSize:'1rem'}}>Contact Us</button>
               </div>
           </div>
         </div>                                      
       </div>        
    </div>
  )
}

export default Enterprise