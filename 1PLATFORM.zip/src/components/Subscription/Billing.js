import React, { useState, useEffect } from 'react'
import { Form, Modal } from 'react-bootstrap'
import { Link, useHistory } from 'react-router-dom'
import './Billing.scss';
import { useSelector } from 'react-redux';
import { useForm, Controller } from "react-hook-form";
import warning from '../../assets/images/warning.png'
import { toast } from 'react-toastify';
import { fetchCompanyUser, saveSubscribe, userSubscriptionRequest } from '../../endpoints/gateway'
import { backBtnIcon } from '../../Icons/icons';
import Select from 'react-select';

const Billing = () => {
  const history = useHistory();
  // Warning PopUp Hooks    
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  //   End of Warning PopUp Hooks 
  const [duration, setDuration] = useState(null);
  const [subscriptionPeriod, setSubscriptionPeriod] = useState([
    {
        "duration": 30,
        "productName": "1 Month",
        "productLogo": null
    },
    {
      "duration": 60,
      "productName": "2 Month",
      "productLogo": null
    },
    {
      "duration": 90,
      "productName": "3 Month",
      "productLogo": null
    },
    {
      "duration": 120,
      "productName": "4 Month",
      "productLogo": null
    },
    {
      "duration": 150,
      "productName": "5 Month",
      "productLogo": null
    },
    {
      "duration": 180,
      "productName": "6 Month",
      "productLogo": null
    },
    {
      "duration": 210,
      "productName": "7 Month",
      "productLogo": null
    },
    {
      "duration": 240,
      "productName": "8 Month",
      "productLogo": null
    },
    {
      "duration": 270,
      "productName": "9 Month",
      "productLogo": null
    },
    {
      "duration": 300,
      "productName": "10 Month",
      "productLogo": null
    },
    {
      "duration": 330,
      "productName": "11 Month",
      "productLogo": null
    },
    {
      "duration": 364,
      "productName": "12 Month",
      "productLogo": null
    }
])
  const userDetails = useSelector(state => state.user.userInfo.allInfo);
  
  const userSubscription = useSelector(state => state.subscription);
  
  const [billingDetails, setbillingDetails] = useState()
  useEffect(() => {
    //fetchCompanyDetails()
  }, [])

  const { register,
    handleSubmit, setValue,
    formState: { errors, isValid }, control, reset } = useForm({
      mode: 'onChange'
    });

  const fetchCompanyDetails = async () => {
    let response = await fetchCompanyUser(userDetails.userId)
    setbillingDetails(response.data)
  }


  const submit = async () => {
    // let payload = {
    //   "productId": userSubscription.productId,
    //   "userId": userDetails.userId,
    //   "companyId": billingDetails.companyId,
    //   "subscriptionId": userSubscription.subscriptionId,
    //   "subscriptionPlanId": userSubscription.subscriptionPlanId,
    //   "subscriptionModeId": userSubscription.subscriptionModeId
    // }
    // let response = await saveSubscribe(payload)

    let plan_id = history.location?.state?.data;
    let product_id = history.location?.state.type;
    let plan_duration = duration;
    
    if(plan_duration === null || plan_duration === undefined || plan_duration === ""){
      toast.warning("Please choose Subscription Duration");
      return;
    }
    
    let response = await userSubscriptionRequest(product_id, plan_id, plan_duration);
    
    if(response.status && response.status === 200){
        toast.success(response.data.message);
        handleClose(); 
        history.push('/checkout');
    }else{
      toast.error(response.response.data.message);
    }

    // if(response.response.data){
    //   if(response.response.data.message === "Already Subscription Requested"){
    //     toast.warning(response.response.data.message);
    //   }else{
    //     toast.success(response.response.data.message);
    //     handleClose(); 
    //     history.push('/checkout')
    //   }
      
    // }

    
  }

  const movePlatform = () => {
    history.push('/platformadmin')
  }

  const getDuration = (val) => {
     setDuration(val);
  }

  return (
    <div className='Billing'>
      <div className="mt-2 custom-head-card">
        <div className="d-flex gap-2 align-items-center">
          <button type="button" onClick={() => history.goBack()} className="btn btn_light">{backBtnIcon}</button>
          <div className='h3'>Update your Billing Information</div>
        </div>
      </div>
      <div className='my-3'>
        <div className='op_card card'>
          <div className='card-body px-4'>
            <Form className='billingForm'>
              <div className='row g-4'>
                {/* <div className='col-md-12'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >Company Name</label>
                    <input disabled type="text" className="form-control" placeholder="Enter Company name" value={billingDetails?.companyName} />
                  </div>
                </div> */}
                {/* <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >Company Name</label>
                    <input disabled type="text" className="form-control" placeholder="Enter First Name" value={billingDetails?.companyName} />
                  </div>
                </div> */}
                <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >First Name</label>
                    <input disabled type="text" className="form-control" placeholder="Enter First Name" value={userDetails?.firstname} />
                  </div>
                </div>
                <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >Last Name</label>
                    <input disabled type="text" className="form-control" placeholder="Enter Last Name" value={userDetails?.lastname} />
                  </div>
                </div>
                <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >Email Id</label>
                    <input disabled type="text" className="form-control" placeholder="Enter Email Id" value={userDetails?.email} />
                  </div>
                </div>
                <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >Subscription No of Months</label>
                    <Controller
                        name="duration"
                        control={control}
                        render={({ field: { onChange, value } }) => <Select
                            value={subscriptionPeriod.find((c) => c.duration === value)}
                            onChange={(val) => { getDuration(val.duration) }}
                            options={subscriptionPeriod}
                            getOptionLabel={(option) => option.productName}
                            getOptionValue={(option) => option.duration}
                            style={{ width: "100%" }}
                            className='form-select p-0 border-0'
                        />}
                        rules={{ required: true }}
                    />
                  </div>
                </div>
                {/* <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >Country</label>
                    <input disabled type="text" className="form-control" placeholder="Enter Country" value={billingDetails?.country} />
                  </div>
                </div>
                <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >Address</label>
                    <textarea disabled className="form-control" id="exampleFormControlTextarea1" rows={5} value={billingDetails?.address} style={{ minHeight: '8rem' }} />
                  </div>
                </div> */}
                {/* <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >Phone <span style={{ color: '#828282' }}></span></label>
                    <input disabled type="tel" className="form-control" placeholder="XXXXXXXXXXXXXXXXX" value={userDetails?.phoneNo} />
                  </div>
                </div> */}
                {/* <div className='col-md-6'>
                  <div className="form-group">
                    <label className='billingLabel mb-1' >VAT Number <span style={{ color: '#828282' }}></span></label>
                    <input disabled type="tel" className="form-control" placeholder="XXXXXXXXXXXXXXXXX" value={billingDetails?.uen} />
                  </div>
                </div>*/}
                <div className='col-md-12 text-center py-3'>
                  <button onClick={movePlatform} className='btn btn_outline mx-2'>Cancel</button>
                  {/* <button type='button' className='btn btn_primary mx-2' onClick={handleShow}>Subscribe</button> */}
                  <button type='button' className='btn btn_primary mx-2' onClick={submit}>Proceed Checkout</button>
                </div> 
              </div>
            </Form>
          </div>
        </div>
      </div>
      <Modal show={show} onHide={handleClose} centered backdrop="static" keyboard={false} className='warningModal'>
        <Modal.Header className='border-0  m-0' closeButton>
        </Modal.Header>
        <Modal.Body className='py-0'>
          <div className='modal_body'>
            <div className='warningPanel'>
              <img src={warning} className='warningicon' alt='warning' />
              <div className='contentBlock'>
                <div className='warnTitle mt-2'>Are you sure?</div>
                <div className='warnContent my-2'>Proceed to Subscribe the product</div>
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer className='justify-content-center border-0 pt-2 pb-3'>
          <button className='btn btn_primary px-3 mx-2' onClick={submit}>Proceed Checkout</button>
        </Modal.Footer>
      </Modal>

    </div>
  )
}

export default Billing