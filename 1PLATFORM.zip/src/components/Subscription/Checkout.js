import React from 'react'
import { Form } from 'react-bootstrap'
import { useHistory } from 'react-router-dom'
import './Checkout.scss'
import american from '../../assets/images/checkout/a.png'
import master from '../../assets/images/checkout/b.png'
import union from '../../assets/images/checkout/c.png'
import visa from '../../assets/images/checkout/d.png'
import creditimages from '../../assets/images/checkout/cardImges.png'
import { backBtnIcon } from '../../Icons/icons';
import thanks from '../../assets/images/other/thanks.svg'
const Checkout = () => {
  const history = useHistory();

  const handleBackTo = () => {

    history.push(
        {
            pathname: `/platformadmin`,
        }
    );
}

  return (
    <div className='Checkout h-100'>
      <div className="mt-2 custom-head-card">
        <div className="d-flex gap-2 align-items-center">
          <button type="button" onClick={() => handleBackTo()} className="btn btn_light">{backBtnIcon}</button>
          <div className='h3'>Thank you for Subscription</div>
        </div>
      </div>
      <div className='my-3 thankyoucomp'>
        <div className='text-center'>
          <img src={thanks} alt='img' className='m-auto w-75' />
          <div className='thankYouPanel mt-5'>
            <div className='thankheading'>Thank you for the subscription !!</div>
            <div className='thankContent'>our team will reach out to you soon</div>
          </div>
        </div>
      </div>
      {/* <div className='my-3'>
          <div className='op_card card'>
            <div className='card-body px-4'>
              <Form className='billingForm'>
                <div className='row g-4'>
                  <div className='col-md-6 p-3'>
                    <div className='checkout_panel'>
                      <div className='subs_header'>
                        <div className='subsLabel'>Subscribe to Pro-unlimited-annual</div>
                        <div className='d-flex align-items-center gap-4'>
                          <div className='price_Subscribe'>$ 5088.80</div>
                          <div className='price_Label'>Every<br /> 12 months</div>
                        </div>
                      </div>
                      <div className='subs_body pt-5'>
                        <div className='d-flex align-items-center justify-content-between'>
                          <div className='subs_item_block'>
                            <div className='subs_label'>Selected Plan Name</div>
                            <div className='subs_item'>Pro-unlimited-annual</div>
                          </div>
                          <div className='subs_body_price'>$5089.80</div>
                        </div>
                        <div className='d-flex mt-4 align-items-center justify-content-between py-2 border-bottom border-2'>
                            <div className='substotal'>Subtotal</div>
                            <div className='subs_body_price'>$5089.80</div>
                        </div>
                        <div className='d-flex mt-2 align-items-center justify-content-between py-2 border-bottom border-2'>
                            <div className='taxLabel'>Tax (18%)</div>
                            <div className='taxLabel'>$916.16</div>
                        </div> 
                        <div className='d-flex mt-2 align-items-center justify-content-between py-2'>
                            <div className='total'>Total</div>
                            <div className='total'>$6014.96</div>
                        </div>                                           
                      </div>                      
                    </div>
                  </div>
                  <div className='col-md-6 px-5'>
                    <div className="form-group my-4">
                      <input type="text" className="form-control" value='gopi2designer@gmail.com' disabled/>
                    </div> 
                    <div className="form-group my-4">
                      <label  className='billingLabel mb-1' >Card Information</label>
                      <div className='row'>
                        <div className='col-md-12'>
                          <div className='d-flex creditCardLayout'>
                            <input type='text' placeholder="1234 1234 1234 1234" className='form-control border-0 bg-transparent'/>
                            <div className='d-flex align-items-center gap-1'>
                              <img className='creditcard_image' src={creditimages} alt='img' />
                            </div>
                          </div>
                          <div className='d-flex align-items-center gap-3'>
                            <div className='ccvpanel'>
                              <input type="text" className="form-control border-0" placeholder="MM/YY" />
                            </div>
                            <div className='ccvpanel'>
                              <input type="text" className="form-control border-0" placeholder="CCV" />
                            </div>
                          </div>
                        </div>
                      </div>
                      
                    </div>  
                    <div className="form-group my-4">
                      <label  className='billingLabel mb-1' >Name on Card</label>
                      <input type="text" className="form-control" placeholder="Enter the Name of the Card" />
                    </div>
                    <div className="form-group my-4">
                      <label  className='billingLabel mb-1' >Country or Region</label>
                      <select className="form-select">
                        <option selected>Singapore</option>
                        <option value={1}>India</option>
                        <option value={2}>Europe</option>
                      </select>
                    </div>   
                    <div className="custom-control custom-checkbox d-flex align-items-center my-2">
                      <input type="checkbox" className="custom-control-input me-2" id="customCheck1" />
                      <label className="custom-control-label" htmlFor="customCheck1">Save my info for secure 1-click checkout</label>
                    </div>                                     
                    <div className='text-center py-3 mb-2'>
                      <button className='btn btn_billing_submit px-5  mx-2'>Proceed Payment</button>  
                    </div> 
                    <div className='text-center checkPara mx-3 mb-3'>By confirming your subscription, you allow One Platform - Quantify to charge your card for this payment and future payments in accordance with their terms. You can always cancel your subscription.</div>                                                                              
                  </div>                                                                                      
                </div>
              </Form>
            </div>
          </div>
        </div>                    */}
    </div>
  )
}

export default Checkout