import React, { useState, useEffect } from 'react'
import './Subscribe.scss'
import {Tab, Nav } from 'react-bootstrap'
import { Link, useHistory } from 'react-router-dom'
import Monthly from './SubscriptionTabs/Monthly'
import Annually from './SubscriptionTabs/Annually'
import Enterprise from './SubscriptionTabs/Enterprise'
import { getProductPlans } from '../../endpoints/gateway';

const Subscribe = (props) => {
  const check = <svg xmlns="http://www.w3.org/2000/svg" width="14.914" height="11.161" viewBox="0 0 14.914 11.161">
  <path id="done_FILL0_wght400_GRAD0_opsz48_2" data-name="done_FILL0_wght400_GRAD0_opsz48 2" d="M12.345,21.947,7.7,17.3l.892-.892,3.753,3.753L20.308,12.2l.892.892Z" transform="translate(-6.993 -11.493)" fill="#828282" stroke="#828282" stroke-width="1"/>
</svg>

  const history = useHistory();
  const [productDetails, setproductDetails] = useState();

  useEffect(() => {
     fetchSpecficproduct()
  }, [])

  const fetchSpecficproduct = async () => {
    let response = await getProductPlans(props.match.params.productId)
    
    setproductDetails(response.data)
  }

  return (

    <div className='Subscribe'>
        <div className="mt-2 custom-head-card">
            <div className="d-flex gap-2 align-items-center">
                <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
                <div className='h3'>Subscription</div>
            </div>
        </div> 
        <div className='row mt-2'>
            <div className='col-md-12'>
                <div className='op_card py-3'>
                  <div className='nav_subscribe'>
                    <Tab.Container id="left-tabs-example" defaultActiveKey="first" unmountOnExit={true}>
                        <Nav>
                            {/* {productDetails && productDetails.map(
                              Item => Item.plan_type === "Monthly" ?
                                  <Nav.Item><Nav.Link eventKey="first">Monthly</Nav.Link></Nav.Item>
                                  :Item.plan_type === "Annually" ?
                                  <Nav.Item><Nav.Link eventKey="second">Annually</Nav.Link></Nav.Item>  
                                  :Item.plan_type === "Enterprise" &&
                                  <Nav.Item><Nav.Link eventKey="third">Enterprise</Nav.Link></Nav.Item> 
                              )
                            } */}
                            {productDetails && productDetails.map(
                              Item => Item.plan_type === "Monthly" &&
                                  <Nav.Item><Nav.Link eventKey="first">Monthly</Nav.Link></Nav.Item>
                              )
                            }
                        </Nav>
                        <div className='py-4'>
                            <Tab.Content>
                            {productDetails && productDetails.map(
                              Item => Item.plan_type === "Monthly" ?
                                <Tab.Pane eventKey="first">
                                  <Monthly subscriptionModeId={Item.plan_id} productId={props.match.params.productId} data={Item}/>
                                </Tab.Pane>
                                :Item.plan_type === "Annually" ?
                                <Tab.Pane eventKey="second" >
                                  <Annually subscriptionModeId={Item.plan_id} productId={props.match.params.productId} data={Item}/>
                                </Tab.Pane>
                                :Item.plan_type === "Enterprise" &&
                                <Tab.Pane eventKey="third" >
                                    <Enterprise subscriptionModeId={Item.plan_id} productId={props.match.params.productId} data={Item}/>
                                </Tab.Pane>
                              )
                            }
                            </Tab.Content>
                        </div>
                    </Tab.Container>                                        
                  </div>
                </div>
            </div>
        </div>                
    </div>
  )
}

export default Subscribe