import React, { useState, useEffect, useMemo } from 'react'
import '../platformadmin.scss'
import { Form, Modal, Tab, Tabs, Dropdown, Popover, Button } from 'react-bootstrap'
import { Link } from "react-router-dom";
import { getAllUserProduct, subscribedProducts, deleteUser } from "../../../endpoints/subscription/users";
import { getAllproducts } from "../../../endpoints/subscription/lookup";
import { useHistory } from "react-router-dom";
import { toast } from 'react-toastify';
import icon1 from '../../../assets/images/dashboard/5.png'
import icon2 from '../../../assets/images/dashboard/3.png'
import icon3 from '../../../assets/images/dashboard/4.png'
import UserImg from '../../../assets/images/profile/UserPic.png'
import { TablePagination, Pagination } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Search from '../../Common/Search/Search';
import CreateUser from './CreateUser';

const ManageUsers = () => {
    const history = useHistory();
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [Usershow, UsersetShow] = useState(false);
    const UserhandleShow = () => UsersetShow(true);


    const [allMemebers, setallMembers] = useState(null);
    const [showPopoverId, setShowPopoverId] = useState(0);
    const [products, setProducts] = useState(null);
    const [productName, setProductName] = useState("All");
    const [productId, setProductId] = useState(0);

    const [statusName, setStatusName] = useState("Active");
    const [dropstatus, setStatus] = useState("All");
    const [showPopover, setShowPopover] = useState(false);

    const [email, setEmail] = useState(null);
    const [searchOpen, setSearchOpen] = useState(false);

    const [subProducts, setSubProducts] = useState(null);
    const [subProductName, setSubProductName] = useState("Select Sub Product Name");

    const animateSearch = () => {
        setSearchOpen(!searchOpen);
    }

    useEffect(() => {
        getProductsName();
        fetchallMemebers(productId, dropstatus);
    }, []);

    const UserhandleClose = () => {
        getProductsName();
        fetchallMemebers(productId, dropstatus);
        UsersetShow(false);
        setFrom('');
        setuser('');
        setEditproductId(0);
        settype('');
        setUserEdit(false);
    };

    const getProductsName = async () => {
        let response = await subscribedProducts("json");
        if (response.status === 200) {
            setProducts(response.data);
        } else {
            setProducts([]);
        }
    }

    const handleChange = (item) => {
        if (item.is_sub_product) {
            setallMembers(null);
            setProductName(item.product_name);
        } else {
            setallMembers(null);
            setProductName(item.product_name);
            setProductId(item.product_id);
            fetchallMemebers(item.product_id, dropstatus);
        }

    }

    const handleChangeStatus = (status) => {
        setStatus(status);
        fetchallMemebers(productId, status);
    }


    const fetchallMemebers = async (product_id, status) => {
        let response = await getAllUserProduct(product_id, status === "All" ? "" : status);
        if (response.status === 200) {
            setPage(1);
            setallMembers(response.data);
        }
    }
    const [gridAction, setGridAction] = useState(false);

    const handleGridAction = (index) => {
        setGridAction(false);
        setGridAction(prevAction => ({
            ...prevAction,
            [index]: !gridAction[index]
        }));
    }

    const [userEdit, setUserEdit] = useState(false);
    const [edituser, setuser] = useState(null);
    const [editproductId, setEditproductId] = useState(0);
    const [edittype, settype] = useState(false);
    const [from, setFrom] = useState("");

    const handleUpdateUser = (user, product_id, type, from) => {
        setFrom(from);
        setuser(user);
        setEditproductId(product_id);
        settype(type);
        setUserEdit(true);
        UsersetShow(true);
        // history.push({
        //     pathname: "/update-user",
        //     state: {
        //         user,
        //         product_id,
        //         type
        //     }
        // });

    }

    const deleteUserOn = async () => {

        if (email === null) {
            toast.error("Email is required");
        } else {

            let response = await deleteUser(email);
            if (response.status === 200) {
                setEmail(null);
                handleClose();
                fetchallMemebers(productId, dropstatus);
                toast.success(response.data.message);
            } else {

                if (response.Error.response.data !== "") {
                    toast.error(response.Error.response.data.errors[0].message);

                } else {
                    toast.error("Error in request");
                }
            }

        }
    }

    const handleChangeSubProduct = (item) => {

        setSubProductName(item.product_name);
        if (item.product_key) {
            //setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null });
            //getProductFeatures(item.product_key);
            setProductId(item.product_id);
            fetchallMemebers(item.product_id, dropstatus);
            fetchallMemebers(item.product_id, dropstatus);
        }
    }

    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const handleChangePagination = (event, value) => {

        setPage(value);
    };

    const theme = createTheme({
        palette: {
            neutral: {
                main: '#bae6f3',
                contrastText: '#0e699c',
            },
        },
    });

    /*pagination with search */
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");

    const ITEMS_PER_PAGE = 10;


    const allUsersFilter = useMemo(() => {
        // debugger
        if (allMemebers === null || allMemebers?.length === 0) {
            setTotalItems(0);
            return allMemebers;
        }
        let computedviewDomain = productName === "All" && allMemebers?.length > 0 ? allMemebers : allMemebers?._list;

        if (search) {
            computedviewDomain = computedviewDomain?.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(search.toLowerCase())
            );
        }
        setTotalItems(computedviewDomain?.length);

        return computedviewDomain?.slice(
            (currentPage - 1) * ITEMS_PER_PAGE,
            (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [allMemebers, currentPage, search]);

    const editIcon = <svg xmlns="http://www.w3.org/2000/svg" height="15" viewBox="0 -960 960 960" width="15">
        <path d="M200-200h57l391-391-57-57-391 391v57Zm-80 80v-170l528-527q12-11 26.5-17t30.5-6q16 0 31 6t26 18l55 56q12 11 17.5 26t5.5 30q0 16-5.5 30.5T817-647L290-120H120Zm640-584-56-56 56 56Zm-141 85-28-29 57 57-29-28Z" />
    </svg>

    const deleteIcon = <svg xmlns="http://www.w3.org/2000/svg" height="15" viewBox="0 -960 960 960" width="15">
        <path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" />
    </svg>
    const ViewIcon = <svg xmlns="http://www.w3.org/2000/svg" width="15.047" height="10.388" viewBox="0 0 15.047 10.388">
        <path id="Union_7" data-name="Union 7" d="M21347.029-5141.024a8.59,8.59,0,0,1-2.986-3.683l-.043-.1.043-.1a8.653,8.653,0,0,1,2.986-3.683,7.66,7.66,0,0,1,4.492-1.41,7.663,7.663,0,0,1,4.5,1.41,8.653,8.653,0,0,1,2.986,3.683l.043.1-.043.1a8.59,8.59,0,0,1-2.986,3.683,7.668,7.668,0,0,1-4.5,1.415A7.665,7.665,0,0,1,21347.029-5141.024Zm.965-6.449a6.862,6.862,0,0,0-2.418,2.669,6.882,6.882,0,0,0,2.418,2.665,6.386,6.386,0,0,0,3.527,1.04,6.389,6.389,0,0,0,3.531-1.04,6.725,6.725,0,0,0,2.4-2.665,6.706,6.706,0,0,0-2.4-2.669,6.433,6.433,0,0,0-3.531-1.04A6.43,6.43,0,0,0,21347.994-5147.473Zm1.367,4.83a2.959,2.959,0,0,1-.891-2.161,2.962,2.962,0,0,1,.891-2.166,2.959,2.959,0,0,1,2.16-.89,2.966,2.966,0,0,1,2.166.89,2.96,2.96,0,0,1,.889,2.166,2.957,2.957,0,0,1-.889,2.161,2.966,2.966,0,0,1-2.166.89A2.959,2.959,0,0,1,21349.361-5142.643Zm1.029-3.3a1.529,1.529,0,0,0-.461,1.136,1.526,1.526,0,0,0,.461,1.131,1.521,1.521,0,0,0,1.131.461,1.531,1.531,0,0,0,1.137-.461,1.526,1.526,0,0,0,.461-1.131,1.529,1.529,0,0,0-.461-1.136,1.531,1.531,0,0,0-1.137-.461A1.521,1.521,0,0,0,21350.391-5145.94Z" transform="translate(-21344 5149.998)" fill="#333" />
    </svg>

    /*pagination with search */

    return (
        <>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Manage Users</div>
                    </div>
                    <div className="d-flex gap-3">
                        <button className="primaryBtn" onClick={() => UsersetShow(true)}>+ Add User</button>
                    </div>
                </div>
            </div>
            <div className='productSelect'>
                <div className="dropdownWithLable">
                    <label>Product</label>
                    <Dropdown className={"customDropdown"} >
                        <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                            {productName}
                        </Dropdown.Toggle>

                        <Dropdown.Menu className={"dropdownList"}>
                            <Dropdown.Item eventKey="0" onClick={() => handleChange({ product_name: 'All', product_id: 0 })} >All</Dropdown.Item>
                            {products && products.map(
                                product =>
                                    <Dropdown.Item eventKey={product.product_key} onClick={() => handleChange(product)} >{product.product_name}</Dropdown.Item>
                            )
                            }
                        </Dropdown.Menu>
                    </Dropdown>
                </div>
            </div>
            {productName !== "All" && allMemebers?._slots &&
                <section className="usersStatuswrap">
                    <ul className="statusLists DashboardStatus">
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon1} alt="" />
                                    </div>
                                    <div className='Counttitle'>
                                        <h1 className="usersCount">{String(allMemebers?._slots?.purchased_slots).padStart(2, '0')}</h1>
                                        <div className="userLabel"># of User Licenses</div>
                                    </div>
                                </div>

                            </div>
                        </li>
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon2} alt="" />
                                    </div>
                                    <div className='Counttitle'>
                                        <h1 className="usersCount">{String(allMemebers?._slots?.used_slots).padStart(2, '0')}</h1>
                                        <div className="userLabel"># of Used User Licenses</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon3} alt="" />
                                    </div>
                                    <div className='Counttitle'>
                                        <h1 className="usersCount">{String(allMemebers?._slots?.remaining_slots).padStart(2, '0')}</h1>
                                        <div className="userLabel"># of Unused User Licenses</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </section>
            }
            <div className='row my-3'>
                <div>
                    <div className='card-body px-0 pb-0'>
                        <div className='d-flex align-items-center manageFilters justify-content-end'>
                            {/* <div className='heading_approval'># of User List</div> */}
                            <div className="d-flex gap-3 manageFields">
                                <div className="dropdownWithLable">
                                    <Search
                                        className='searchinput'
                                        searchOpen={searchOpen}
                                        animateSearch={animateSearch}
                                        placeholder={"Search by email"}
                                        onSearch={value => {
                                            setSearch(value);
                                            setCurrentPage(1);
                                        }}
                                    />
                                </div>
                                {/* <div className="dropdownWithLable">
                                    <label>Product</label>
                                    <Dropdown
                                        className={"customDropdown"}
                                    >
                                        <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                            {productName}
                                        </Dropdown.Toggle>

                                        <Dropdown.Menu className={"dropdownList"}>
                                            <Dropdown.Item eventKey="0" onClick={() => handleChange({ product_name: 'All', product_id: 0 })} >All</Dropdown.Item>
                                            {products && products.map(
                                                product =>
                                                    <Dropdown.Item eventKey={product.product_key} onClick={() => handleChange(product)} >{product.product_name}</Dropdown.Item>
                                            )
                                            }
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </div> */}
                                {/* {subProducts && 
                                    <div className="dropdownWithLable">
                                        <label>Choose Sub-Product</label>
                                        <Dropdown
                                            className={"customDropdown"}
                                        >
                                            <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                {subProductName}
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu className={"dropdownList"}>
                                                {subProducts && subProducts.map(
                                                    subProduct =>
                                                        <Dropdown.Item eventKey={subProduct.product_key} onClick={() => handleChangeSubProduct(subProduct)} >{subProduct.product_name}</Dropdown.Item>
                                                )
                                                }
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </div>
                                } */}
                                <div className="dropdownWithLable">
                                    <label>Status</label>
                                    <Dropdown
                                        className={"customDropdown"}
                                    >
                                        <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                            {dropstatus}
                                        </Dropdown.Toggle>

                                        <Dropdown.Menu className={"dropdownList"}>
                                            <Dropdown.Item eventKey="All" onClick={() => handleChangeStatus("All")}>All</Dropdown.Item>
                                            <Dropdown.Item eventKey="Active" onClick={() => handleChangeStatus("Active")}>Active</Dropdown.Item>
                                            <Dropdown.Item eventKey="Inactive" onClick={() => handleChangeStatus("Inactive")}>Inactive</Dropdown.Item>
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </div>
                            </div>
                        </div>
                        <table className="table manageuser_grid mb-0">
                            <thead>
                                <tr className='px-3 py-4'>
                                    <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Email<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    {productName === "All" &&
                                        <th scope="col" className='text-center'>No. of Products<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    }
                                    <th scope="col">Created On<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Status</th>
                                    <th scope="col" className='text-center'>Action</th>
                                </tr>
                            </thead>
                            <tbody className='border-top-0'>
                                {productName === "All" && allUsersFilter && allUsersFilter?.length > 0 && allUsersFilter?.map((val, index) =>
                                    <tr>
                                        <td><img src={UserImg} />{val.first_name} {val.last_name}</td>
                                        <td>{val.email}</td>
                                        <td className='text-center'>
                                            {val.total_products === "0" ?
                                                <div className="planFeature">
                                                    <span>{val.total_products}</span>
                                                </div>
                                                :
                                                <div className="planFeature" onClick={() => { setShowPopover(!showPopover); setShowPopoverId(index) }}>
                                                    <span>{val.total_products}</span>
                                                    {showPopoverId === index && showPopover &&
                                                        <Popover id="popover-basic" className="featuresPop productsTagged">
                                                            <Popover.Body>
                                                                <ul className="featuresListinpop">
                                                                    {val.products.map(
                                                                        prod =>
                                                                            <li>{prod}</li>
                                                                    )
                                                                    }
                                                                </ul>
                                                            </Popover.Body>
                                                        </Popover>
                                                    }
                                                </div>
                                            }
                                            {/* <div className="planFeature" onClick={() => { setShowPopover(!showPopover); setShowPopoverId(index) }}>
                                                <span>{val.total_products}</span>
                                                {showPopoverId === index && showPopover &&
                                                    <Popover id="popover-basic" className="featuresPop productsTagged">
                                                        <Popover.Body>
                                                            <ul className="featuresListinpop">
                                                                {val.products.map(
                                                                    prod =>
                                                                        <li>{prod}</li>
                                                                )
                                                                }
                                                            </ul>
                                                        </Popover.Body>
                                                    </Popover>
                                                }
                                            </div> */}
                                        </td>
                                        <td>{val.created_on}</td>
                                        <td>{val.status ? "Active" : "In-Active"}</td>
                                        <td className="text-center">
                                            {/* <div className="middleAlign manageAction">
                                                <span className={"actionIcons"} onClick={() => handleUpdateUser(val, 0, false)}>
                                                    <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="EditIcon"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path></svg>
                                                </span>
                                                {val.products.length === 0 &&
                                                    <span className={"actionIcons"} onClick={() => { setEmail(val.email); handleShow(true) }}>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                                                            <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5ZM11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H2.506a.58.58 0 0 0-.01 0H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1h-.995a.59.59 0 0 0-.01 0H11Zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5h9.916Zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47ZM8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5Z" />
                                                        </svg>
                                                    </span>
                                                }
                                            </div> */}
                                            <div className="actionDropDown">
                                                <span className="hamburIcon" onClick={() => handleGridAction(index)}>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                    </svg>
                                                </span>
                                                {/* {gridAction[index] && */}
                                                <ul className="actionPopup" onClick={() => handleGridAction(index)}>
                                                    <li onClick={() => handleUpdateUser(val, 0, false, "Edit")}>
                                                        <span>{editIcon}</span>
                                                        Edit</li>
                                                    {val.products.length === 0 &&
                                                        <li onClick={() => { setEmail(val.email); handleShow(true) }}>
                                                            <span>{deleteIcon}</span>
                                                            Delete</li>
                                                    }
                                                </ul>
                                                {/* } */}
                                            </div>
                                            {/* <div className="actionDropDown">
                                                <span className="hamburIcon" onClick={() => handleGridAction(index)}>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                    </svg>
                                                </span>
                                                {gridAction[index] &&
                                                    <ul className="actionPopup" onClick={() => handleGridAction(index)}>
                                                        <li onClick={() => handleUpdateUser(val, 0, false)}>Assign</li>
                                                        <li onClick={() => handleUpdateUser(val, 0, false)}>Edit</li>
                                                        {val.products.length === 0 &&
                                                            <li onClick={() => { setEmail(val.email); handleShow(true) }}>Delete</li>
                                                        }
                                                    </ul>
                                                }
                                            </div> */}
                                        </td>
                                    </tr>
                                )}
                                {productName !== "All" && allUsersFilter && allUsersFilter?.length > 0 && allUsersFilter?.map((val, index) =>
                                    <tr>
                                        <td>{val.first_name} {val.last_name}</td>
                                        <td>{val.email}</td>
                                        <td>{val.created_on}</td>
                                        <td>{val.status ? "Active" : "In-Active"}</td>
                                        <td className="text-center">
                                            <div className="actionDropDown">
                                                <span className="hamburIcon" onClick={() => handleGridAction(index)}>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                    </svg>
                                                </span>
                                                {/* {gridAction[index] && */}
                                                <ul className="actionPopup" onClick={() => handleGridAction(index)}>
                                                    {val.role !== "ADMIN" && <li onClick={() => handleUpdateUser(val, productId, false, "Edit")}><span>{editIcon}</span>Edit</li>}
                                                    <li onClick={() => handleUpdateUser(val, productId, false, "View")}><span>{ViewIcon}</span>View</li>
                                                </ul>
                                                {/* } */}
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                        <div className='my-3 pe-3 paginationBlock'>
                            <ThemeProvider theme={theme}>
                                <Pagination
                                    count={Math.ceil(totalItems / ITEMS_PER_PAGE)}
                                    onChange={(page, i) => setCurrentPage(i)}
                                    shape="rounded"
                                    variant="outlined"
                                    style={{ float: 'right' }}
                                />
                            </ThemeProvider>
                        </div>
                    </div>
                    <Modal
                        show={show}
                        size="md"
                        aria-labelledby="contained-modal-title-vcenter"
                        centered
                        className="subscriptionModal"
                        onHide={handleClose}
                    >
                        <Modal.Header closeButton>
                            <Modal.Title id="contained-modal-title-vcenter">
                                Confirm Delete
                            </Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <p className="text-center">Are you sure, you want to delete?</p>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button className="secondaryBtn" onClick={handleClose}>Cancel</Button>
                            <Button className="primaryBtn" onClick={() => deleteUserOn()}>OK</Button>
                        </Modal.Footer>
                    </Modal>

                    <div className={""}>
                        <Modal
                            show={Usershow}
                            size="md"
                            aria-labelledby=""
                            centered
                            className="subscriptionModal CreateUser"
                            onHide={UserhandleClose}
                        >
                            <Modal.Header closeButton>
                                <Modal.Title id="contained-modal-title-vcenter">
                                    {from === "" ? "Add" : from} User
                                </Modal.Title>
                            </Modal.Header>
                            <Modal.Body>
                                {from === "Edit" ?
                                    <CreateUser
                                        edituser={edituser}
                                        edittype={edittype}
                                        editproductId={editproductId}
                                        userEdit={userEdit}
                                        UserhandleClose={UserhandleClose}
                                        type={"Edit"}
                                    />
                                    : from === "View" ?
                                        <CreateUser
                                            edituser={edituser}
                                            edittype={edittype}
                                            editproductId={editproductId}
                                            userEdit={userEdit}
                                            UserhandleClose={UserhandleClose}
                                            type={"View"}
                                        />
                                        :
                                        <CreateUser
                                            UserhandleClose={UserhandleClose}
                                            type={"Create"}
                                        />
                                }
                            </Modal.Body>
                        </Modal>
                    </div>
                </div>
            </div>
        </>
    )

}
export default ManageUsers
