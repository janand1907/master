import React, { useState, useEffect } from 'react';
import './Edituser.scss';
import profilePicture from '../../../assets/images/usermanagement/profilepicture.png'
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button } from 'react-bootstrap';

const Edituser = ({ productDetails, addUser, addUserErr, handleFreetext, handleCloseTwo, changeImageHandler, file, ref }) => {

    // const [addUser, setAddUser] = useState({
    //     "profile_logo": "",
    //     "first_name": "",
    //     "last_name": "",
    //     "status": false
    // });

    // const [addUserErr, setAddUserErr] = useState({
    //     "first_name": "",
    //     "last_name": "",
    //     "email": "",
    //     "server": ""
    // });

    // const handleFreetext = (e) => {
    //     let name = e.target.id;
    //     let value = e.target.value;
    //     setAddUser({ ...addUser, [name]: value });
    // }
    
    useEffect(() => {
       
    }, [])

    return (
        <div className='custom_modalContainer'>
            <div className="envHealthCheck_modal card">
                <div className="modal_header card-header m-0">
                    <div className="modal_header-title">Edit Profile</div>
                    <button className="close" onClick={() => handleCloseTwo()}><i class="bi bi-x"></i></button>
                </div>
                <div className='modal_body card-body'>
                    <div className='editUser'>
                        <Form className="profile_update">
                            <div className='row mx-4'>
                                <div className='col-md-4 text-center'>
                                    <div className='profilePicture_panel my-4'>
                                        {/* <img className='profile_picture' src={profilePicture} alt='profileImage' /> */}
                                        <img src={file} className='profile_picture' alt='Profilepic' />
                                        <div className='profile_update_layout'>
                                            <button className='btn profile_update_btn'><i class="bi bi-camera"></i></button>
                                            <input accept="image/png, image/gif, image/jpeg, image/jpg" name="file" className='customfileinput' type="file" ref={ref} onChange={changeImageHandler} />
                                        </div>
                                    </div>
                                </div>
                                <div className='col-md-8'>
                                    <Form.Group className="mb-3">
                                        <Form.Label>
                                            <span>Product name *</span>
                                        </Form.Label>
                                        <Form.Control type="text" value={productDetails?.product_name} id='product_id' placeholder='Current Owner' disabled/>
                                    </Form.Group>
                                    <Form.Group className="mb-3">
                                        <Form.Label>
                                            <span>First Name *</span>
                                        </Form.Label>
                                        <Form.Control type="text" value={addUser.first_name} id='first_name' onChange={(e) => handleFreetext(e)} placeholder='User name' />
                                        <Form.Text className="d-flex subErors">
                                            {addUserErr.first_name}
                                        </Form.Text>
                                    </Form.Group>
                                    <Form.Group className="mb-3">
                                        <Form.Label>
                                            <span>Last Name *</span>
                                        </Form.Label>
                                        <Form.Control type="text" value={addUser.last_name} id='last_name' onChange={(e) => handleFreetext(e)} placeholder='User name' />
                                        <Form.Text className="d-flex subErors">
                                            {addUserErr.last_name}
                                        </Form.Text>
                                    </Form.Group>
                                    <Form.Group className="mb-3">
                                        <Form.Label>
                                            <span>Email Id *</span>
                                        </Form.Label>
                                        <Form.Control disabled type="email" value={addUser.email} id='email' onChange={(e) => handleFreetext(e)} placeholder='User email' />
                                        <Form.Text className="d-flex subErors">
                                            {addUserErr.email}
                                        </Form.Text>
                                    </Form.Group>
                                    <Form.Group className="mb-3">
                                        <Form.Label>
                                            <span>Status *</span>
                                        </Form.Label>
                                        <Form.Check
                                            type="switch"
                                            id="status"
                                        />
                                    </Form.Group>
                                </div>
                                <div className='col-md-12 text-center'>
                                    <button className='btn btn_update' onClick={() => handleCloseTwo()}>Cancel</button>
                                    <button className='btn btn_update' type="submit">Update</button>
                                </div>
                            </div>
                        </Form>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default Edituser