import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { getUserSubscriptions, manualSubscriptionRequest } from "../../../endpoints/subscription/users";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import nodata from '../../../assets/images/nodata.svg';
import ManualPayment from "../Modal/ManualPayment";

const Dashboard = (props) => {
    const history = useHistory();
    const [showPopover, setShowPopover] = useState(false);
    const [showPopoverId, setShowPopoverId] = useState(0);
    const userDetails = useSelector(state => state?.user?.userInfo?.allInfo);
    const [allProducts, setAllProducts] = useState(null);

    const [detailView, setdetailView] = useState(false);
    const viewLicensedetails = () => {
        setdetailView(!detailView);
    }
    useEffect(() => {
        getSubscriptions();
    }, []);

    const getSubscriptions = async () => {
        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        let response = await getUserSubscriptions(timeZone);
        if (response.status === 200) {
            setAllProducts(response.data);
        }

    }

    const viewPlans = (is_sub_product, type, _product_id, product_logo, product_name) => {
        if (is_sub_product) {
            // history.push({
            //     pathname: "/subproduct",
            //     state: {
            //         _product_id,
            //         type,
            //         product_logo,
            //         product_name
            //     }
            // });
            history.push({
                pathname: "/plandetails",
                state: {
                    _product_id,
                    type,
                    product_logo: product_logo,
                    product_name: product_name,
                    is_sub_product: is_sub_product,
                    main_name: product_name
                }
            });
        } else {
            history.push({
                pathname: "/plandetails",
                state: {
                    _product_id,
                    type,
                    product_logo: product_logo,
                    product_name: product_name,
                    is_sub_product: is_sub_product,
                    main_name: product_name
                }
            });
        }

    }

    const viewRenewPlans = (type, _product_id, plan) => {

        // if(plan.customize_plan){

        //     handleSubmitRequest(type, plan);

        // }else{

        history.push({
            pathname: "/payment",
            state: {
                _product_id,
                plan,
                type,
                product_logo: plan.product_logo,
                product_name: plan.product_name
            }
        });
        // }
    }

    const handleSubmitRequest = async (requestType, plan) => {
        setPlanDetailsErr({ ...planDetailsErr, server: null });
        var payload = {
            plan_id: plan.plan_id,
            duration: plan.plan_duration,
            user_slot: 0,
            request_type: requestType
        }

        let response = await manualSubscriptionRequest(payload);
        if (response.status === 200) {
            setShowManualPaymentModal(true);
        } else {
            if (response.Error.response.data !== "") {
                setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
            } else {
                setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
            }
            setShowManualPaymentModal(true);
        }
    }

    const viewProductDetails = (product) => {

        history.push({
            pathname: "/productview",
            state: {
                product
            }
        });

    }

    const handleOpenApp = (url) => {
        window.open(`https://dtlehta1thuw9.cloudfront.net/1platformsubsv2${url}`, "_self");
    }

    const handleBack = () => {
        history.goBack();
    }

    const [showManualPaymentModal, setShowManualPaymentModal] = useState(false);
    const handleManualPaymentClose = () => setShowManualPaymentModal(false);

    const [planDetailsErr, setPlanDetailsErr] = useState({
        duration: null,
        userslot: null,
        server: null,
        durationId: null,
        userslotId: null,
    });

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Welcome back, {userDetails?.firstname} {userDetails?.lastname}.</div>
                    </div>
                </div>
            </div>
            {allProducts && allProducts.subscribed_products?.length === 0 &&
                <div className='mt-3'>
                    <div className='heading_approval dashBoardHead'>
                        <span>Subscribed Product Details</span>
                    </div>
                    <div className='NoSubscribed'>
                        <p>You do not have any subscribed products. Please find below the products available for subscription.</p>
                    </div>
                </div>
            }
            {allProducts && allProducts.subscribed_products?.length > 0 &&
                <div className="customTabContainer">
                    <div className='transBg'>
                        <div className='card-body px-0 py-0'>
                            <div className='d-flex align-items-center justify-content-between'>
                                <div className='heading_approval dashBoardHead'>
                                    <span>Subscribed Product Details</span>
                                </div>
                            </div>
                            <div class="row DashProductDetail">
                                {allProducts.subscribed_products.map(
                                    (product, index) =>
                                        <div class="col-md-6 col-lg-4 mb-3">
                                            <div class={`card op_card`}>
                                                <div className={`card-body ${product.status === "InActive" ? "borderInActive" : ""}`}>
                                                    <div className="planName"><span>Plan Type:</span> {product.plan_name}</div>
                                                    {product.status === "InActive" &&
                                                        <div className="planInActive">{product.status}</div>
                                                    }
                                                    <div className="clear"></div>
                                                    <div className="d-flex align-items-center mb-4">
                                                        <div className='productlogoPannel'>
                                                            <img src={product.product_logo ? product.product_logo : nodata} alt="product-thumbnail" className="product_thumbnail" />
                                                        </div>
                                                        <div className="product_title ms-2">
                                                            {/* {product.product_name} */}
                                                            {product.is_sub_product ? product.main_name + " - " + product.product_name : product.product_name}
                                                        </div>
                                                    </div>
                                                    <div className="product_desc my-2">
                                                        <h3>Description</h3>
                                                        <p title={product.product_description}>{product.product_description}</p>
                                                    </div>
                                                    <ul class="cardPlan-footer bg-transparent px-0 py-0">
                                                        <li className="withIcon">
                                                            {/* <span>Subscription On</span> */}
                                                            <div className="cardCalendar">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="15.712" height="17.458" viewBox="0 0 15.712 17.458">
                                                                    <path id="Path_21285" data-name="Path 21285" d="M16.966,2.746h-.873V1H14.347V2.746H7.364V1H5.619V2.746H4.746A1.745,1.745,0,0,0,3,4.492v12.22a1.745,1.745,0,0,0,1.746,1.746h12.22a1.751,1.751,0,0,0,1.746-1.746V4.492A1.751,1.751,0,0,0,16.966,2.746Zm0,13.966H4.746V7.983h12.22Zm0-10.475H4.746V4.492h12.22ZM6.492,9.729h4.364v4.364H6.492Z" transform="translate(-3 -1)" fill="#9c9c9c" />
                                                                </svg>
                                                            </div>
                                                            <div className="withIconLabels">
                                                                <span>Start Date</span>
                                                                <span>{product.plan_started_on}</span>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            {/* <span>Subscription End</span> */}

                                                            <span>Expiry Date</span>
                                                            <span>{product.plan_expire_on}</span>
                                                        </li>
                                                    </ul>
                                                    <div className={`d-flex align-items-center licenseDetails my-1 justify-content-between px-3`}>
                                                        <Button className="primaryBtn px-4" activeClassName="active" onClick={() => handleOpenApp(product?.product_access_url)}>Launch</Button>
                                                        <Button className="secondaryBtn  px-4" activeClassName="active" onClick={() => viewProductDetails(product)}>View Details</Button>
                                                        {/* {product.is_renewal && <Button className="secondaryBtn  px-4" activeClassName="active" onClick={() => viewRenewPlans("renewal_plan", product.product_id, product)}>Renew Plan</Button>} */}
                                                    </div>
                                                </div>
                                                {/* <div class="d-flex align-items-center licenseDetails my-1 justify-content-between px-3 mb-3">
                                                    <Button className="secondaryBtn px-4" activeClassName="active" onClick={() => viewProductDetails(product)}>View Details</Button>
                                                    {product.is_renewal && <Button className="primaryBtn px-4" activeClassName="active" onClick={() => viewRenewPlans("renewal_plan", product.product_id, product)}>Renew Plan</Button>}
                                                </div> */}
                                            </div>
                                        </div>
                                )
                                }
                            </div>
                        </div>
                    </div>
                </div>
            }
            {allProducts && allProducts.available_products?.length > 0 &&
                <div className="customTabContainer">
                    <div>
                        <div className='card-body px-0 pb-0'>
                            <div className='d-flex align-items-center justify-content-between'>
                                <div className='heading_approval dashBoardHead'>
                                    <span>All Products</span>
                                </div>
                            </div>
                            <div class="row dashboardPurchase">
                                {allProducts.available_products.map(
                                    product =>
                                        <div class="col-md-6 col-lg-4 mb-3">
                                            <div class="card op_card" style={{ height: "250px" }}>
                                                <div className="card-body">
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="d-flex align-items-center">
                                                            <div className='productlogoPannel'>
                                                                <img src={product.product_logo ? product.product_logo : nodata} alt="product-thumbnail" className="product_thumbnail" />
                                                            </div>
                                                            <div className="product_title ms-2">{product.product_name}</div>
                                                        </div>
                                                    </div>
                                                    <div className="product_desc productDescAvail">
                                                        <p title={product.product_description}>{product.product_description}</p>
                                                    </div>
                                                </div>
                                                <div class="bg-transparent mx-3 mb-3 px-0 py-0">
                                                    <div class="d-flex align-items-center gap-2 justify-content-center">
                                                        <Button className="primaryBtn px-5 my-3" activeClassName="active" onClick={() => viewPlans(product.is_subProduct, "new_plan", product.product_key, product.product_logo, product.product_name)}>Subscribe</Button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                )
                                }
                            </div>
                        </div>
                    </div>
                </div>
            }
            <ManualPayment
                show={showManualPaymentModal}
                handleClose={handleManualPaymentClose}
                handleLoadMain={handleManualPaymentClose}
                planDetailsErr={planDetailsErr}
            />
        </div >
    )
}

export default Dashboard;