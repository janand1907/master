import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../platformadmin.scss';
// import './Plandetail.scss'
import Accordion from 'react-bootstrap/Accordion';
import { useAccordionButton } from 'react-bootstrap/AccordionButton';
import Card from 'react-bootstrap/Card';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from "react-router-dom";
import {
    getPaymentOptions, getDiscountDetails, getChargeDetails, getUserSlots,
    submitUserRequest, manualSubscriptionRequest, getAdditionalSlotCharge, getPlanTerms
} from "../../../endpoints/subscription/users";
import { getDiscountDuration } from "../../../endpoints/subscription/lookup";
import { createPaymentSession } from "../../../endpoints/subscription/payment";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import nodata from '../../../assets/images/nodata.svg';
import { toast } from 'react-toastify';
import paypal from '../../../assets/images/paypal.png'
import stripe from '../../../assets/images/stripe.png'
import Spinner from 'react-bootstrap/Spinner'
import TermsModal from '../Modal/TermsModal'
import OnlinePayment from "../Modal/OnlinePayment";
import ManualPayment from "../Modal/ManualPayment";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import PhoneInput, {
    getCountryCallingCode, isValidPhoneNumber
} from "react-phone-number-input";
import "react-phone-number-input/style.css";

function CustomToggle({ children, eventKey }) {
    const decoratedOnClick = useAccordionButton(eventKey, () =>
        console.log('totally custom!'),
    );

    return (
        <div
            className="accordButton"
            type="button"
            onClick={decoratedOnClick}
        >
            {children}
        </div>
    );
}

const Payment = (props) => {
    const history = useHistory();
    let [count, setCount] = useState(0);
    const userDetails = useSelector(state => state.user);
    const [pending, setPending] = useState(false);
    const [productName, setProductName] = useState(null);
    const [productLogo, setProductLogo] = useState(null);
    const [paymentOption, setPaymentOption] = useState(null);
    const [discountDetails, setDiscountDetails] = useState(null);
    const [planTerms, setPlanTerms] = useState(null);
    const [chargeDetails, setChargeDetails] = useState(null);
    const [priceFormat, setPriceFormat] = useState(null);
    const [userSlots, setUserSlots] = useState({
        "enable": false,
        "slot_unit_price": 0
    });
    const [slotError, setSlotError] = useState(null);
    const [requestSuccess, setRequestSuccess] = useState(null);
    const [disableUser, setDisableUser] = useState(false);
    const [disableDuration, setDisableDuration] = useState(false);
    const [plan, setPlan] = useState(null);
    const [planType, setPlanType] = useState(false);

    const [selectedPlanDuration, setSelectedPlanDuration] = useState("Select Plan Duration");
    const [selectedUser, setSelectedUser] = useState("Select User");
    const [gateway_id, setGatewayID] = useState(0);
    const [gateway_name, setGatewayName] = useState("");


    const [features, setFeatures] = useState([]);
    const [planDetails, setPlanDetails] = useState({
        duration: null,
        userslot: 0,
        durationId: 0,
        userslotId: 0,
        _request_type: ""
    });

    const [planDetailsErr, setPlanDetailsErr] = useState({
        duration: null,
        userslot: null,
        server: null,
        durationId: null,
        userslotId: null,
    });

    const [userSlotDetails, setUserSlotDetails] = useState({
        "required_user_slot": 0,
        "user_slot_per_unit_price": 0,
        "total_user_slot_price": 0,
    });

    const [showPayment, setShowPayment] = useState(false);
    const [showButton, setShowButton] = useState(false);

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);

    const [showPaymentModal, setShowpaymentModal] = useState(false);
    const handlePaymentClose = () => setShowpaymentModal(false);

    const [showManualPaymentModal, setShowManualPaymentModal] = useState(false);
    const handleManualPaymentClose = () => setShowManualPaymentModal(false);
    const [phoneCountryCode, phoneCountryCodeSetter] = useState("DE");

    const personalSchema = Yup.object().shape({

    });

    const onSubmit = async (data) => {

    }

    const { register,
        handleSubmit, setValue,
        formState: { errors, isValid }, control, reset } = useForm({
            resolver: yupResolver(personalSchema), mode: 'onChange'
        });

    useEffect(() => {

        if (props.location.state) {

            setPlanType(props.location.state.planType);
            setProductName(props.location.state.product_name);
            setProductLogo(props.location.state.product_logo);
            setPlanDetails({ ...planDetails, _request_type: props.location.state.type });

            if (props.location.state.type === "new_plan") {
                setPlan(props.location.state.plan);
            } else if (props.location.state.type === "renewal_plan") {
                var plan = props.location.state.plan;
                setPlan({
                    ...plan,
                    "product_id": plan.product_id,
                    "plan_id": plan.plan_id,
                    "plan_name": plan.plan_name,
                    "plan_description": plan.product_description,
                    "order_number": null,
                    "most_popular": null,
                    "features": plan.plan_features
                });
                setDisableUser(true);
            } else if (props.location.state.type === "change_plan") {
                setPlan(props.location.state.plan);
            } else if (props.location.state.type === "upgrade_addon") {
                var plan = props.location.state.plan;
                setPlan({
                    ...plan,
                    "product_id": plan.product_id,
                    "plan_id": plan.plan_id,
                    "plan_name": plan.plan_name,
                    "plan_description": plan.product_description,
                    "order_number": null,
                    "most_popular": null,
                    "features": plan.plan_features
                });
                //setDisableDuration(true);
            }
            if (!props.location.state.plan.customize_plan) {
                planTermsConditions();
                PaymentOptions();
                getUserSlot(props.location.state.plan.plan_id, props.location.state.plan.customize_plan, props.location.state.type);
            }
        }

        window.scrollTo(0, 0);

    }, []);

    const PaymentOptions = async () => {

        let response = await getPaymentOptions();
        if (response.status === 200) {
            setPaymentOption(response.data);
            if (response.data.payment_mode[1] === "Online") {
                setGatewayID(response.data.gateway_list[0].gateway_id);
                setGatewayName(response.data.gateway_list[0].gateway_name);
            }
        }
    }

    const getUserSlot = async (_plan_id, customize_plan, type) => {
        if (type === "renewal_plan") {
            getchargeDetail(0);
        } else {
            let response = await getAdditionalSlotCharge(_plan_id);
            if (response.status === 200) {

                setUserSlots(response.data);
                setCount(0);

                if (!customize_plan) {
                    getchargeDetail(0);
                }
            }
        }
    }

    const planTermsConditions = async () => {
        let response = await getPlanTerms();
        if (response.status === 200) {
            setPlanTerms(response.data);
        }
    }

    const handleChangeDuration = (duration) => {

        let value = duration.duration;

        setSelectedPlanDuration(duration.duration);
        setPlanDetails({ ...planDetails, duration: value, durationId: duration.id });
        setPlanDetailsErr({ ...planDetailsErr, duration: null })
        setShowButton(false);
    }

    const handleChange = (userSlot) => {

        let value = userSlot.slot;
        setSelectedUser(userSlot.slot_option);
        setPlanDetails({ ...planDetails, userslot: value, userslotId: userSlot.serial_no });
        setPlanDetailsErr({ ...planDetailsErr, userslot: null })
        setShowButton(false);
    }


    const getDiscountDetail = async (_plan_id) => {

        let response = await getDiscountDetails(_plan_id);
        if (response.status === 200) {
            setDiscountDetails(response.data);
        }

    }
    const getchargeDetail = async (userslot) => {

        if (planDetails._request_type === "new_plan") {

            // if (count === 0 || count < userSlots.min || count > userSlots.max) {
            //     setSlotError("Choose add on slot")
            //     return;
            // }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "renewal_plan") {

            // if (planDetails.durationId === 0) {
            //     setPlanDetailsErr({ ...planDetailsErr, duration: "Choose duration" });
            //     return;
            // }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "change_plan") {

            // if (count === 0 || count < userSlots.min || count > userSlots.max) {
            //     setSlotError("Choose add on slot")
            //     return;
            // }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "upgrade_addon") {

            // if (count === 0 || count < userSlots.min || count > userSlots.max) {
            //     setSlotError("Choose add on slot")
            //     return;
            // }
            setSlotError(null)

        }
        setPlanDetailsErr({ ...planDetailsErr, server: null, duration: null, userslot: null })
        setSlotError(null);


        let requestType = props.location.state.type;
        let plan_id = props.location.state.plan.plan_id;
        let duration = 0;
        if (requestType === "upgrade_addon") {
            duration = 0;
        } else if (requestType === "renewal_plan") {
            duration = props.location.state.plan.plan_duration;
        } else {
            duration = props.location.state.planType ? 2 : 1;
        }

        let response = await getChargeDetails(requestType, plan_id, duration, userslot);

        if (response.status === 200) {
            setChargeDetails(response.data);
            setPriceFormat(response.data?.final_price?.toLocaleString("en-US"));
            setShowButton(true);
            setFeatures(response.data.features);
            setUserSlotDetails({
                ...userSlotDetails,
                "required_user_slot": response.data.required_user_slot,
                "user_slot_per_unit_price": response.data.user_slot_per_unit_price,
                "total_user_slot_price": response.data.total_user_slot_price,
            });

        } else {
            if (response.Error.response.data !== "") {
                setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
            } else {
                setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
            }
        }
    }


    const handleSubmitRequest = async () => {

        let requestType = props.location.state.type;
        let plan_id = props.location.state.plan.plan_id;
        let duration = 0;
        if (plan.customize_plan) {
            setPending(true);
            setPlanDetailsErr({ ...planDetailsErr, server: null })

            var payload = {
                plan_id: plan_id,
                duration: props.location.state.planType ? 2 : 1,
                user_slot: 0,
                request_type: requestType
            }

            let response = await manualSubscriptionRequest(payload);
            if (response.status === 200) {
                //toast.success(response.data.message);
                setRequestSuccess(true);
                setPending(false);
                setShowManualPaymentModal(true);
            } else {
                setPending(false);
                if (response.Error.response.data !== "") {
                    //setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
                    toast.error(response.Error.response.data.errors[0].message);
                } else {
                    //setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" });
                    toast.error("Error in request");
                }
            }
        } else {

            if (planDetails._request_type === "upgrade_addon") {
                duration = 0;
                if (count === 0 || count < 0) {
                    setSlotError("Choose add on slot");
                    return;
                }
                setSlotError(null)

            } else {
                duration = props.location.state.planType ? 2 : 1;
            }

            if (planDetails._request_type === "new_plan") {

                if (duration === 0) {
                    setPlanDetailsErr({ ...planDetailsErr, server: "Choose duration" });
                    return;
                }
                // else if (count === 0) {
                //     setPlanDetailsErr({ ...planDetailsErr, server: "Choose add on slot" })
                //     return;
                // }
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

            } else if (planDetails._request_type === "renewal_plan") {

                if (duration === 0) {
                    setPlanDetailsErr({ ...planDetailsErr, server: "Choose duration" });
                    return;
                }
                setPlanDetailsErr({ ...planDetailsErr, server: null })

            } else if (planDetails._request_type === "change_plan") {

                if (duration === 0) {
                    setPlanDetailsErr({ ...planDetailsErr, server: "Choose duration" });
                    return;
                }
                // else if (count === 0) {
                //     setPlanDetailsErr({ ...planDetailsErr, server: "Choose add on slot" })
                //     return;
                // }
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

            } else if (planDetails._request_type === "upgrade_addon") {

                if (count === 0) {
                    setPlanDetailsErr({ ...planDetailsErr, server: "Choose add on slot" })
                    return;
                }
                setPlanDetailsErr({ ...planDetailsErr, server: null })

            }

            if (paymentOption && paymentOption.payment_mode[1] === "Manual") {
                setPending(true);
                setPlanDetailsErr({ ...planDetailsErr, server: null })

                var payload = {
                    plan_id: plan_id,
                    duration: duration,
                    user_slot: count,
                    request_type: requestType
                }

                let response = await manualSubscriptionRequest(payload);
                if (response.status === 200) {
                    //toast.success(response.data.message);
                    setRequestSuccess(true);
                    setPending(false);
                    setShowManualPaymentModal(true);
                } else {
                    setPending(false);
                    if (response.Error.response.data !== "") {
                        //setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
                        toast.error(response.Error.response.data.errors[0].message);
                    } else {
                        setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
                        toast.error("Error in request");
                    }
                }

            } else {
                if (gateway_id === 0) {
                    setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null, server: "Choose Payment Option" })
                    return;
                }
                setPending(true);
                setPlanDetailsErr({ ...planDetailsErr, server: null })
                var payload = {
                    gateway_id: gateway_id
                }

                // let response = await createPaymentSession(payload, plan.plan_id, planDetails.durationId, planDetails.userslotId, planDetails._request_type);
                let response = await createPaymentSession(payload, plan.plan_id, duration, count, planDetails._request_type);
                if (response.status === 200) {
                    setPending(false);
                    window.open(response.data.session_url, "_self");
                } else {
                    setPending(false);
                    if (response.Error.response.data !== "") {
                        //setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
                        toast.error(response.Error.response.data.errors[0].message);
                    } else {
                        //setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
                        toast.error("Error in request");
                    }
                }

            }

        }

    }

    const handleLoadMain = () => {
        handleManualPaymentClose(false);
        history.push("/dashboard-user");//dashboard-user
    }

    const handleBack = () => {
        history.goBack();
    }

    const tickIcon = () => {
        return (
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16">
                <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
            </svg>
        )
    }

    function incrementCount() {

        count = count + 1;
        if (count < 0) {
            return setSlotError("Slot can't be less than " + userSlots.min);
        }
        // if(count > userSlots.max){
        //     return setSlotError("Slot can't be greater than " + userSlots.max);
        // }
        setSlotError(null);
        setCount(count);
        getchargeDetail(count);
    }

    function decrementCount() {
        count = count - 1;
        if (count < 0) {
            return setSlotError("Slot can't be less than " + userSlots.min);
        }
        // if(count > userSlots.max){
        //     return setSlotError("Slot can't be greater than " + userSlots.max);
        // }
        setSlotError(null);

        setCount(count);
        getchargeDetail(count);
    }

    return (
        <div className="innerContainer">
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        {/* <button className="btn btn_light" onClick={() => handleBack()}>{backBtnIcon}</button> */}
                        {/* <div className='h3'>Plan Subscription Details</div> */}
                        <div className='h3'>Subscribe to the {productName}</div>

                    </div>
                    {plan && plan.customize_plan &&
                        <a onClick={() => history.goBack()} className={"changeLinkLL"}>Change Plan</a>
                    }
                </div>
            </div>
            <div className='row g-3 my-1'>
                <div className={`col-lg-8 col-md-12 paymentReviewWrap ${plan?.customize_plan && "customiseReviewWrap"}`}>
                    <div className='p_card paymentCardwrap'>
                        <div className={`card-body px-0 py-0 ${plan?.customize_plan && "customiseWrapper"}`}>
                            {/* <Accordion defaultActiveKey={plan?.customize_plan ? "0" : ""}> */}

                            <div class="pricecard paymentPriceCard" tabindex="0">

                                <div class="pricingCard">
                                    <div class="planDetailsTop">
                                        <h4 class="planName">
                                            <strong>{plan && plan.plan_name}</strong>
                                            {planDetails._request_type === "renewal_plan" ?
                                                <span></span>
                                                :
                                                <span>{plan && plan.plan_description}</span>
                                            }
                                        </h4>
                                    </div>
                                    <div class="subscribeNewBtnWrap">
                                        <div class="letstalk">
                                            <h4>Let's talk for Pricing</h4>
                                        </div>
                                        {/* <button class="primaryBtn">Contact Us</button> */}
                                    </div>
                                    <ul class="planFeaturs">
                                        {plan && plan.features && plan.features.map(
                                            feature => plan.customize_plan &&
                                                <li>
                                                    <span class="iconColor">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path></svg>
                                                    </span>
                                                    {/* <span> Penetration web scan</span> */}
                                                    <span><strong>{feature[2] === "0" ? "" : feature[2]}</strong>&nbsp;{feature[0]}</span>

                                                </li>
                                        )}
                                    </ul>
                                </div>
                            </div>
                            <Accordion>
                                <Card className="setMonthsWrap">
                                    <Card.Header>
                                        <div className="productRight">
                                            <div className="productName">
                                                <div className="leftSide">
                                                    <div className="planNameWrapper">
                                                        <span>Plan Name: </span><h1>{plan && plan.plan_name}</h1>
                                                        <CustomToggle eventKey="0">
                                                            <span className="accordArrow">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-down" viewBox="0 0 16 16">
                                                                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z" />
                                                                </svg>
                                                            </span>
                                                        </CustomToggle>
                                                    </div>
                                                    <div>
                                                        <a className="changeLink">{planDetails?._request_type === "new_plan" ? "New Plan" : planDetails?._request_type === "renewal_plan" ? "Renew Plan" : planDetails?._request_type === "change_plan" ? "Upgrade Plan" : planDetails?._request_type === "upgrade_addon" && "Add on Slot"}</a>
                                                        {plan && plan.customize_plan &&
                                                            <a onClick={() => history.goBack()} className={"changeLinkLL"}>Change Plan</a>
                                                        }
                                                    </div>
                                                </div>
                                                {/* <span>{plan && plan.plan_description}</span> */}
                                                {plan && !plan.customize_plan &&
                                                    <div className={"planDetailsTop"}>
                                                        <h4 className={"planName"}>
                                                            <strong>${priceFormat}<span>/{planType ? 'per year' : 'per month'}</span></strong>
                                                        </h4>
                                                    </div>
                                                }

                                            </div>
                                        </div>
                                    </Card.Header>
                                    <Accordion.Collapse eventKey="0" className={`${plan?.customize_plan && "customiseCollapse"}`}>
                                        <Card.Body>
                                            {planDetails._request_type !== "upgrade_addon" &&
                                                <ul className="featuresList">
                                                    {plan && plan.features && plan.features.map(
                                                        feature => plan.customize_plan ?
                                                            <li>
                                                                <span className={"iconColor"}>{tickIcon()}</span>
                                                                <span>{feature[2] === "0" ? "No. of" : feature[2]}</span>
                                                                {feature[0]}
                                                            </li>
                                                            :
                                                            <li>
                                                                <span className={"iconColor"}>{tickIcon()}</span>
                                                                <span>{feature[1]}</span>
                                                                {feature[0]}
                                                            </li>
                                                    )}
                                                </ul>}
                                        </Card.Body>
                                    </Accordion.Collapse>
                                </Card>
                            </Accordion>
                            {!plan?.customize_plan && planDetails._request_type !== "renewal_plan" &&
                                <div className='addONwrap'>
                                    <h5 className="addonTitle">Add-on</h5>
                                    <div className="addonwrapper card">

                                        <div className="addonUserCharge">
                                            <div className="unitaddWrapper">
                                                <div className="left">
                                                    <h4>No. of Additional Users</h4>
                                                    <span>** (Plan have {"0"} user license)</span>
                                                </div>
                                            </div>
                                            <div className="wrappingIncrement">
                                                <div className="input-group">
                                                    <input type="button" value="-" className="button-minus" data-field="quantity" onClick={decrementCount} />
                                                    <input type="number" step="1" min="0" value={count} name="quantity" className="quantity-field" />
                                                    <input type="button" value="+" className="button-plus" data-field="quantity" onClick={incrementCount}></input>
                                                    <Form.Text className="d-flex subErors serverError">
                                                        {slotError}
                                                    </Form.Text>
                                                </div>
                                                <span>(Per user price <strong>${userSlots.slot_unit_price}</strong> - Validity as per plan)</span>
                                            </div>
                                            <div className="rightValue">
                                                <h4>${chargeDetails ? chargeDetails?.total_user_slot_price : 0.00}</h4>
                                            </div>
                                        </div>
                                        {/* <div className="addonUserCharge DedicatedService">
                                            <div  className="unitaddWrapper"><h4>Dedicated Services</h4></div>
                                            <Dropdown className={"customDropdown"}>
                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                    Select Service
                                                </Dropdown.Toggle>

                                                <Dropdown.Menu className={"dropdownList"}>
                                                <Dropdown.Item href="#/action-1">Elastic Search</Dropdown.Item>
                                                <Dropdown.Item href="#/action-2">VM instance</Dropdown.Item>
                                                <Dropdown.Item href="#/action-3">S3 cloudfront</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                            <div className="rightValue">
                                                <h4>${chargeDetails ? chargeDetails?.total_user_slot_price : 0.00}</h4>
                                            </div>
                                        </div>
                                        <div className="addonUserCharge DedicatedService">
                                            <div  className="unitaddWrapper"><h4>Support</h4></div>
                                            <Dropdown className={"customDropdown"}>
                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                    Select Support
                                                </Dropdown.Toggle>

                                                <Dropdown.Menu className={"dropdownList"}>
                                                <Dropdown.Item href="#/action-1">Select Support</Dropdown.Item>
                                                <Dropdown.Item href="#/action-2">Standard Premium</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                            <div className="rightValue">
                                                <h4>${chargeDetails ? chargeDetails?.total_user_slot_price : 0.00}</h4>
                                            </div>
                                        </div>
                                        <div className="addonUserCharge DedicatedService">
                                            <div className="unitaddWrapper">
                                                <div className="left">
                                                    <h4>Data Backup</h4>
                                                    <span>$3,200 /year</span>
                                                </div>
                                            </div>
                                            <div className="CheckBox">
                                                <input type="checkbox" step="1" min="0" value={count} name="quantity"/>
                                            </div>
                                            <div className="rightValue">
                                                <h4>${chargeDetails ? chargeDetails?.total_user_slot_price : 0.00}</h4>
                                            </div>
                                        </div>

                                        <div className="addonUserCharge AddTotalCal ">
                                            <div className='addTotal'>
                                                <label>Add-on total</label>  
                                                <div className="rightValue">
                                                    <h4>${chargeDetails ? chargeDetails?.total_user_slot_price : 0.00}</h4>
                                                </div>           
                                            </div>
                                        </div> */}
                                    </div>
                                </div>
                            }
                            <div className="addonwrapper card">
                                {plan?.customize_plan ?
                                    <h5 className="addonTitle billingTitle">Contact Details</h5>
                                    :
                                    <h5 className="addonTitle billingTitle">Billing Details</h5>

                                }
                                <div className="billformWrapper">
                                    <Form className={"px-4 py-3"}>
                                        <Form.Group className={`mb-3 formGroup`}>
                                            <Form.Label>
                                                <span>First Name</span>
                                            </Form.Label>
                                            <div className="rightField">
                                                <Form.Control type="text" value={userDetails?.userInfo?.firstname} id='first_name' disabled={true} />
                                            </div>
                                        </Form.Group>
                                        <Form.Group className={`mb-3 formGroup`}>
                                            <Form.Label>
                                                <span>Last Name</span>
                                            </Form.Label>
                                            <div className="rightField">
                                                <Form.Control type="text" value={userDetails?.userInfo?.lastname} id='last_name' disabled={true} />
                                            </div>
                                        </Form.Group>
                                        <Form.Group className={`mb-3 formGroup`}>
                                            <Form.Label>
                                                <span>Email</span>
                                            </Form.Label>
                                            <div className="rightField">
                                                <Form.Control type="email" value={userDetails?.userInfo?.email} id='email' disabled={true} />
                                            </div>
                                        </Form.Group>
                                        {/* <Form.Group className={`mb-3 formGroup`}>
                                            <Form.Label>
                                                <span>Company Name</span>
                                            </Form.Label>
                                            <div className="rightField">
                                                <Form.Control type="text" value="" id='company' disabled={true} />
                                            </div>
                                        </Form.Group> */}

                                        {/* <Form.Group className={`mb-3 formGroup`}>
                                            <Form.Label>
                                                <span>Designation (Optional)</span>
                                            </Form.Label>
                                            <div className="rightField">
                                                <Form.Control type="text" />
                                            </div>
                                        </Form.Group>

                                        <Form.Group className={`mb-3 formGroup`}>
                                            <Form.Label>
                                                <span>Contact Number (Optional)</span>
                                            </Form.Label>
                                            <Controller
                                                name="phoneNo"
                                                control={control}
                                                render={({ field }) => (
                                                    <PhoneInput
                                                        {...field}
                                                        className="form-control d-flex gap-2"
                                                        onCountryChange={(v) => phoneCountryCodeSetter(v)}
                                                        limitMaxLength={true}
                                                        international={false}
                                                        defaultCountry="SG"
                                                        addInternationalOption={false}

                                                    />
                                                )}
                                            />
                                        </Form.Group> */}

                                        {/* <Form.Group className={`mb-3 formGroup`}>
                                            <Form.Label>
                                                <span>Company Name (Optional)</span>
                                            </Form.Label>
                                            <div className="rightField">
                                                <Form.Control type="text" />
                                            </div>
                                        </Form.Group> */}
                                        {/* <Form.Group className={`mb-3 formGroup`}>
                                        <div className='row'>
                                            <div className='col-6'>
                                                <Form.Label>
                                                    <span>Country</span>
                                                </Form.Label>
                                                <Dropdown className={"customDropdown"}>
                                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                        Select Country
                                                    </Dropdown.Toggle>

                                                    <Dropdown.Menu className={"dropdownList"}>
                                                    <Dropdown.Item href="#/action-1">India</Dropdown.Item>
                                                    <Dropdown.Item href="#/action-2">USA</Dropdown.Item>
                                                    </Dropdown.Menu>
                                                </Dropdown>
                                            </div>
                                            <div className='col-6'>
                                                <Form.Label>
                                                    <span>State</span>
                                                </Form.Label>
                                                <Dropdown className={"customDropdown"}>
                                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                        Select State
                                                    </Dropdown.Toggle>

                                                    <Dropdown.Menu className={"dropdownList"}>
                                                    <Dropdown.Item href="#/action-1">Tamil Nadu</Dropdown.Item>
                                                    <Dropdown.Item href="#/action-2">Karnataka</Dropdown.Item>
                                                    </Dropdown.Menu>
                                                </Dropdown>
                                            </div>
                                        </div>
                                    </Form.Group>
                                    <Form.Group className={`mb-3 formGroup`}>
                                        <div className='row'>
                                            <div className='col-6'>
                                                <Form.Label>
                                                    <span>City</span>
                                                </Form.Label>
                                                <Dropdown className={"customDropdown"}>
                                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                        Select City
                                                    </Dropdown.Toggle>

                                                    <Dropdown.Menu className={"dropdownList"}>
                                                    <Dropdown.Item href="#/action-1">India</Dropdown.Item>
                                                    <Dropdown.Item href="#/action-2">USA</Dropdown.Item>
                                                    </Dropdown.Menu>
                                                </Dropdown>
                                            </div>
                                            <div className='col-6'>
                                                <Form.Label>
                                                    <span>Zipcode</span>
                                                </Form.Label>
                                                <div className="rightField">
                                                    <Form.Control type="number" value="" id='' />
                                                </div>
                                            </div>
                                        </div>
                                    </Form.Group> */}
                                        {plan?.customize_plan && <div className="btnWrapper autoBtnWidth">
                                            <Button className="primaryBtn"
                                                disabled={count < userSlots.min ? true : false}
                                                onClick={() => handleSubmitRequest()}>
                                                {pending ?
                                                    <span>
                                                        <Spinner
                                                            as="span"
                                                            animation="border" variant="light"
                                                            size="sm"
                                                            role="status"
                                                            aria-hidden="true"
                                                        /> Submit</span> : <>Submit</>
                                                }
                                            </Button>
                                            <Form.Text className="d-flex subErors popError errorCenter">
                                                {!chargeDetails && planDetailsErr.server}
                                            </Form.Text>
                                        </div>
                                        }
                                    </Form>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                {!plan?.customize_plan && <div class="col-md-6 col-lg-4 orderSummaryCardWrap">
                    <div class="card orderSummaryCard">
                        <div className="card-body px-0 py-0">
                            <div className={"popularBand"}>
                                <span>Order Summary</span>
                                <a onClick={() => history.goBack()} className={"ChangePlantxt"}>Change Plan</a>
                            </div>
                            <ul className="featuresList">
                                {!disableDuration && <li>
                                    <div className="featureName">Plan - ({plan && plan.plan_name})</div>
                                    <div className="rightValue">
                                        {/* <h4>${chargeDetails ? (chargeDetails?.monthly_price * chargeDetails?.required_month) : 0}</h4> */}
                                        <h4>${chargeDetails?.monthly_price ? chargeDetails?.monthly_price : 0.00}</h4>
                                    </div>
                                </li>}
                                {!disableDuration && <li>
                                    <div className="featureName">Plan discount - {chargeDetails?.plan_discount?.discount_percent ? chargeDetails?.plan_discount?.discount_percent : 0}%</div>
                                    <div className="rightValue">
                                        <h4>(-) $ {chargeDetails?.plan_discount?.discount_amount ? chargeDetails?.plan_discount?.discount_amount : 0}</h4>
                                    </div>
                                </li>}
                                <li className="divider"></li>
                                <li className="boldedCont">
                                    <div className="featureName">Sub-total</div>
                                    <div className="rightValue">
                                        <h4>${chargeDetails?.total_price ? chargeDetails?.total_price : 0.00}</h4>
                                    </div>
                                </li>
                                {!disableUser && <li>
                                    <div className="featureName">No. of Additional Users</div>
                                    <div className="rightValue">
                                        <h4>${chargeDetails?.total_user_slot_price ? chargeDetails?.total_user_slot_price : 0.00}</h4>
                                    </div>
                                </li>}
                                {/* {!disableUser && <li>
                                    <div className="featureName">Tax - (18%) (B)</div>
                                    <div className="rightValue">
                                        <h4>${chargeDetails?.total_user_slot_price ? chargeDetails?.total_user_slot_price : 0.00}</h4>
                                    </div>
                                </li>} */}
                                <li className="divider"></li>
                                <li className="boldedCont totalAmount">
                                    <div className="featureName">Total Amount</div>
                                    <div className="rightValue">
                                        <h4>${chargeDetails?.final_price ? chargeDetails?.final_price : 0.00}</h4>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    {/* <div className="planEnterPrise">
                        <label>
                            <span>Plan Name: </span>
                            <span>Enterprise</span>
                        </label>
                        <div className="EnterPriseDetail">
                            <ul className={"planFeaturs"}>
                                <li>
                                    <span className={"iconColor"}>{tickIcon()}</span>
                                    <span className={"textBold"}>{"No. of"}</span>
                                    User License
                                </li>
                                <li>
                                    <span className={"iconColor"}>{tickIcon()}</span>
                                    <span className={"textBold"}>{"No. of"}</span>
                                    User License
                                </li>
                                <li>
                                    <span className={"iconColor"}>{tickIcon()}</span>
                                    <span className={"textBold"}>{"No. of"}</span>
                                    User License
                                </li>
                            </ul> 
                        </div>
                    </div>                 */}


                    <span className="termsLink" onClick={() => setShow(true)}> * Terms of Service
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-up-right" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8.636 3.5a.5.5 0 0 0-.5-.5H1.5A1.5 1.5 0 0 0 0 4.5v10A1.5 1.5 0 0 0 1.5 16h10a1.5 1.5 0 0 0 1.5-1.5V7.864a.5.5 0 0 0-1 0V14.5a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h6.636a.5.5 0 0 0 .5-.5z" />
                            <path fill-rule="evenodd" d="M16 .5a.5.5 0 0 0-.5-.5h-5a.5.5 0 0 0 0 1h3.793L6.146 9.146a.5.5 0 1 0 .708.708L15 1.707V5.5a.5.5 0 0 0 1 0v-5z" />
                        </svg>
                    </span>
                    <div className="btnWrapper autoBtnWidth MidiumFullbtn reviewBtn my-3">
                        {paymentOption?.payment_mode[1] === "Online" ?
                            <Button
                                className="primaryBtn"
                                //disabled={count < userSlots.min ? true : false} 
                                onClick={() => setShowpaymentModal(true)}>
                                Proceed to Pay
                            </Button>
                            :
                            <Button className="primaryBtn"
                                //disabled={count < userSlots.min ? true : false}  
                                onClick={() => handleSubmitRequest()}>
                                {pending ?
                                    <span>
                                        <Spinner
                                            as="span"
                                            animation="border" variant="light"
                                            size="sm"
                                            role="status"
                                            aria-hidden="true"
                                        /> Subscribe</span> : <>Subscribe</>
                                }</Button>
                        }
                        <Form.Text className="d-flex subErors serverError">
                            {planDetailsErr.server}
                        </Form.Text>
                    </div>
                </div>
                }
            </div>
            <TermsModal
                terms={planTerms?.term_description}
                show={show}
                handleClose={handleClose}
            />
            <OnlinePayment
                show={showPaymentModal}
                handleClose={handlePaymentClose}
                paymentOption={paymentOption}
                setGatewayID={setGatewayID}
                handleSubmitRequest={handleSubmitRequest}
                pending={pending}
                planDetailsErr={planDetailsErr}
                chargeDetails={chargeDetails}
                gateway_name={gateway_name}
                gateway_id={gateway_id}
                setGatewayName={setGatewayName}
                productName={productName}
                productLogo={productLogo}
            />
            <ManualPayment
                show={showManualPaymentModal}
                handleClose={handleManualPaymentClose}
                handleLoadMain={handleLoadMain}
                planDetailsErr={planDetailsErr}
            />
        </div >
    )
}

export default Payment;