import React, { useState, useEffect } from "react";
import "./Plandetail.scss";
import { backBtnIcon } from "../../../Icons/icons";
import { backBtnIconSlide } from "../../../Icons/icons";
import { Link } from "react-router-dom";
import { getUserPlan, getchangePlans, getSubProducts } from "../../../endpoints/subscription/users";
import { useHistory } from "react-router-dom";
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, } from "react-bootstrap";
import Slider from "react-slick";
import Carousel from "react-elastic-carousel";
import Accordion from "react-bootstrap/Accordion";
import { StrapiURL } from '../../Common/APIPath'
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
import oip from '../../../assets/images/productLogos/OIP.svg'
import cp from '../../../assets/images/productLogos/CyberPredictor.svg'
import quantify from '../../../assets/images/productLogos/Quantify.svg'
import quadrant from '../../../assets/images/productLogos/Quadrant.svg'

const Plandetails = (props) => {
  const history = useHistory();
  const [productId, setproductId] = useState(0);
  const [showSubProduct, setShowSubProduct] = useState(false);
  const [subProducts, setSubProducts] = useState(null);
  const [subProductName, setSubProductName] = useState("Select Sub Product");
  const [subProductId, setSubProductId] = useState();
  const [products, setproducts] = useState(
    [
      {
        "product_key": "1",
        "product_name": "Quantify",
        "is_sub_product": false,
        "logo": quantify
      },
      {
        "product_key": "cyber_predictor",
        "product_name": "Cyber Predictor",
        "is_sub_product": true,
        "logo": cp
      },
      {
        "product_key": "4",
        "product_name": "Open Innovation Platform(OIP)",
        "is_sub_product": false,
        "logo": oip
      },
      {
        "product_key": "7",
        "product_name": "Quantum",
        "is_sub_product": false,
        "logo": "https://1platform.s3.ap-south-1.amazonaws.com/Quantum.svg"
      }]
  );
  const [planType, setPlanType] = useState(false);
  const [allPlans, setAllPlans] = useState(null);
  const [proDetails, setProDetails] = useState("");
  const [planFAQs, setFAQs] = useState(null);
  useEffect(() => {
    getPlanFAQs();
    if (props.location.state) {

      if (props.location.state.is_sub_product && props.location.state.type !== "change_plan") {
        var name = props.location.state.main_name.replace(' ', '_').toLowerCase();
        setproductId(props.location.state.main_name.replace(' ', '_').toLowerCase());
        setSubProductName(props.location.state.product_name);

        getProductSubPro(name);
        setShowSubProduct(props.location.state.is_sub_product);

      } else {
        setShowSubProduct(false);
        setSubProducts(null);
        setproductId(props.location.state._product_id)
        if (props.location.state.type === "change_plan") {
          getChangeProductPlan(props.location.state._product_id, 1);
        } else {
          getProductPlan(props.location.state._product_id, 1);
        }
      }

      // setproductId(props.location.state._product_id);
      // if (props.location.state.type === "change_plan") {
      //   getChangeProductPlan(props.location.state._product_id, 1);
      // } else {
      //   getProductPlan(props.location.state._product_id, 1);
      // }
      setProDetails(props.location.state.product_name);
    }
  }, []);

  const getPlanFAQs = () => {
    return fetch(StrapiURL + `/platform-fa-qs`)
      .then(data => data.json())
      .then((data) => {

        let dataInput = data.slice().sort((a, b) => a.order - b.order);
        setFAQs(dataInput)

      },
        (error) => {

        }
      );
  }

  const getProductSubPro = async (_product_key) => {

    let response = await getSubProducts(_product_key);
    if (response.status === 200) {
      setSubProducts(response.data);
      if (response.data.length > 0) {
        setSubProductName(response.data[0].productname);
        setSubProductId(response.data[0].productid);
        if (props.location.state.type === "change_plan") {
          getChangeProductPlan(response.data[0].productid, 1);
        } else {
          getProductPlan(response.data[0].productid, 1);
        }
      }
    }

  }

  const [productMessage, setProductMessage] = useState(null);

  const getProductPlan = async (_product_id, _duration_id) => {
    let response = await getUserPlan(_product_id, _duration_id);
    if (response.status === 200) {
      setAllPlans(response.data);
      setProductMessage(null);
    } else {
      debugger;
      if (response.Error.response.data !== "") {
        setProductMessage(response.Error.response.data.errors[0].message);
        setAllPlans([]);
      } else {
        setProductMessage("The product is already in your cart; to explore a different plan, use the 'Change Plan' option");
        setAllPlans([]);
      }
    }
  };

  const getChangeProductPlan = async (_product_id, _duration_id) => {
    let response = await getchangePlans(_product_id, _duration_id);
    if (response.status === 200) {
      setAllPlans(response.data);
      setProductMessage(null);
    } else {
      if (response.Error.response.data !== "") {
        setProductMessage(response.Error.response.data.errors[0].message);
        setAllPlans([]);
      } else
        setAllPlans([]);
    }
  };

  const handleChangePlanType = (evt) => {
    var type = evt.target.checked;
    setPlanType(type);

    if (props.location.state.type === "change_plan") {
      getChangeProductPlan(props.location.state.is_sub_product ? subProductId : props.location.state._product_id, type ? 2 : 1);
    } else {
      getProductPlan(props.location.state.is_sub_product ? subProductId : props.location.state._product_id, type ? 2 : 1);
    }
  };

  const viewDetailPlan = (plan) => {
    history.push({
      pathname: "/payment",
      state: {
        plan,
        type: props.location.state.type,
        product_logo: props.location.state.product_logo,
        product_name: props.location.state.product_name,
        planType: planType,
      },
    });
  };

  const handleBack = () => {
    history.goBack();
  };

  const loadPlans = (product) => {
    setproductId(product.product_key);
    if (product.is_sub_product) {
      getProductSubPro(product.product_key);
      setShowSubProduct(product.is_sub_product);

    } else {
      setShowSubProduct(false);
      setSubProducts(null);
      setSubProductName("Select Sub Product");
      if (props.location.state.type === "change_plan") {
        getChangeProductPlan(product.product_key, 1);
      } else {
        getProductPlan(product.product_key, 1);
      }
    }

  }

  const loadSubPlans = (subProduct) => {
    setSubProductName(subProduct.productname);
    setproductId(subProduct.productid);
    if (props.location.state.type === "change_plan") {
      getChangeProductPlan(subProduct.productid, 1);
    } else {
      getProductPlan(subProduct.productid, 1);
    }
  }

  const tickIcon = () => {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        fill="currentColor"
        class="bi bi-check2"
        viewBox="0 0 16 16"
      >
        <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
      </svg>
    );
  };
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  const [itemsToShow, setItemsToShow] = useState(3);
  const breakPoints = [
    { width: 1, itemsToShow: 1 },
    { width: 650, itemsToShow: 2, itemsToScroll: 2, pagination: false },
    { width: 1000, itemsToShow: 3 },
    { width: 1400, itemsToShow: 4, itemsToScroll: 2 },
    { width: 1450, itemsToShow: 5 },
    { width: 1750, itemsToShow: 6 },
  ];

  const addIcon = () => {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" height="12" viewBox="0 -960 960 960" width="12">
        <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
      </svg>
    )
  }
  const removeIcon = () => {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" height="12" viewBox="0 -960 960 960" width="12">
        <path d="M200-440v-80h560v80H200Z" />
      </svg>
    )
  }

  return (
    <div className="userAdminplanWrap ChoosePlan">
      <div className="mt-2 custom-head-card">
        <div className="d-flex gap-2 align-items-center">
          <button
            type="button"
            className="btn btn_light"
            onClick={() => handleBack()}
          >
            {backBtnIcon}
          </button>
          <div className="h3">Choose a Plan</div>
        </div>
      </div>
      <div className={"pricingCardwrap"}>
        {props.location?.state?.type !== "change_plan" &&
          <div className={"ChoosePlanTabs GeneralTabs"}>
            {/* <button type="button" className="btn btn_light BckIcon" disabled={true}>
              {backBtnIconSlide}
            </button> */}
            <Tab.Container defaultActiveKey={productId} unmountOnExit={true} transition={false} id="noanim-tab-example" className="mb-3">
              <Nav className={"nav-tabs"}>
                {products && products.map(item =>
                  <Nav.Item>
                    <Nav.Link className={productId === item.product_key ? "active" : ""} onClick={() => loadPlans(item)}>
                      <span className="productLogoPlan">
                        <img src={item.logo} alt="" />
                      </span>
                      {item.product_name}
                    </Nav.Link>
                  </Nav.Item>
                )}
              </Nav>
            </Tab.Container>
            {/* <button type="button" className="btn btn_light NxtIcon" disabled={true}>
              {backBtnIconSlide}
            </button> */}
          </div>
        }

        {allPlans && allPlans.length > 0 && !productMessage &&
          <div className="formWrapper">
            <div class="can-toggle demo-rebrand-2 toggleYearly">
              <input
                type="checkbox"
                id="custom-switch"
                checked={planType}
                onChange={handleChangePlanType}
              />
              <label for="custom-switch" className="planSwitch">
                <div
                  class="can-toggle__switch"
                  data-checked="Annually"
                  data-unchecked="Monthly"
                ></div>
              </label>
            </div>
            {props.location?.state?.type !== "change_plan" && showSubProduct && 
              <div className={"ProductChoose"}>
                <label>Choose Sub-product</label>
                <Dropdown className={"customDropdown subProductDropdown"} >
                  <Dropdown.Toggle className={"form-control"} id="dropdown-basic" disabled={!showSubProduct}>{subProductName}</Dropdown.Toggle>
                  <Dropdown.Menu className={"dropdownList"}>
                    {subProducts && subProducts.map(
                      subProduct =>
                        <Dropdown.Item eventKey={subProduct.productid} onClick={() => loadSubPlans(subProduct)} >{subProduct.productname}</Dropdown.Item>
                    )}
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            }
          </div>
        }

        {allPlans && allPlans.length === 0 && productMessage &&
          <section className="carouselWrap" >
            <h3 className="alreadyError">{productMessage}</h3>
          </section>
        }
        {allPlans && allPlans.length > 0 && !productMessage &&
          <section className="carouselWrap" style={{ width: allPlans?.length === 2 && "820px" }}>
            <Carousel
              itemsToShow={3}
              pagination={false}
              breakPoints={breakPoints}
            >
              {allPlans &&
                allPlans.length > 0 &&
                allPlans.map((plan) => (
                  <div className="pricecard">
                    <div className={"pricingCard"}>
                      {plan.most_popular && (
                        <div className={"popularBand"}>
                          <span>Most Popular</span>
                        </div>
                      )}
                      <div className={"planDetailsTop"}>
                        <h4 className={"planName"}>
                          <strong>{plan.plan_name}</strong>
                          <span>{plan.plan_description}</span>
                        </h4>
                      </div>
                      {!plan.customize_plan && (
                        <div className={"planDetailsTop"}>
                          <h4 className={"planName planPricewithStrike"}>
                            <strong className="planPriceValue actualPrize">
                              {plan.actual_price > plan.final_price && (
                                <>
                                  ${plan.actual_price.toLocaleString("en-US")}
                                </>
                              )}
                            </strong>
                            <strong className="planPriceValue">
                              ${plan.final_price.toLocaleString("en-US")}{" "}
                              <span>/{planType ? "year" : "month"}</span>
                            </strong>
                          </h4>
                        </div>
                      )}
                      <div className={"subscribeNewBtnWrap"}>
                        {plan.customize_plan ? (
                          <>
                            <div className={"letstalk"}>
                              <h4>Let's talk for Pricing</h4>
                            </div>
                            <button
                              className={"primaryBtn"}
                              onClick={() => viewDetailPlan(plan)}
                            >
                              Contact Us
                            </button>
                          </>
                        ) : (
                          <button
                            className={"primaryBtn"}
                            onClick={() => viewDetailPlan(plan)}
                          >
                            Buy
                          </button>
                        )}
                      </div>
                      <ul className={"planFeaturs"}>
                        {plan.features.map((feature) =>
                          plan.customize_plan ? (
                            <li>
                              <span className={"iconColor"}>{tickIcon()}</span>
                              {feature[1].includes('Add-on') ?
                                <span className={"SelectedItem"}>
                                  {feature[2] !== "0" &&
                                    <span className={"textBold"}>{feature[2] === "0" ? "" : feature[2]}</span>
                                  }
                                  {" "}{feature[1]}</span>
                                : feature[1].includes('User License') ?
                                  <span className={"SelectedItem"}>
                                    {feature[2] !== "0" &&
                                      <span className={"textBold"}>{feature[2] === "0" ? "" : feature[2]}</span>
                                    }
                                    {" "}{feature[1]}</span>
                                  :
                                  <span>
                                    {feature[2] !== "0" &&
                                      <span className={"textBold"}>{feature[2] === "0" ? "" : feature[2]}</span>
                                    }
                                    {" "}{feature[1]}</span>
                              }
                            </li>
                          ) : (
                            <li>
                              <span className={"iconColor"}>{tickIcon()}</span>
                              {feature[0].includes('Add-on') ?
                                <span className={"SelectedItem"}>
                                  {feature[2] !== "0" &&
                                    <span className={"textBold"}>{feature[1]}</span>
                                  }
                                  {" "}{feature[0]}</span>
                                : feature[0].includes('User License') ?
                                  <span className={"SelectedItem"}>
                                    {feature[2] !== "0" &&
                                      <span className={"textBold"}>{feature[1]}</span>
                                    }
                                    {" "}{feature[0]}</span>
                                  :
                                  <span>
                                    {feature[2] !== "0" &&
                                      <span className={"textBold"}>{feature[1]}</span>
                                    }
                                    {" "}{feature[0]}</span>
                              }
                            </li>
                          )
                        )}
                      </ul>
                    </div>
                  </div>
                ))}
            </Carousel>
          </section>
        }
        {planFAQs && planFAQs.length > 0 &&
          <div className={"FrequentlyQs"}>
            <div className="heading_approval dashBoardHead">
              Frequently Asked Questions
            </div>
            <div className={"FrequentlyPart GeneralTabs"}>
              <div className="tab-content">
                <Accordion defaultActiveKey={planFAQs[0].id}>
                  {planFAQs && planFAQs.map((faq, index) =>
                    <Accordion.Item eventKey={faq.id}>
                      <Accordion.Header>{faq.Question} <span className={"Closed"}>{addIcon()}</span> <span className={"Opened"}>{removeIcon()}</span></Accordion.Header>
                      <Accordion.Body>
                        <p><ReactMarkdown rehypePlugins={[rehypeRaw]} children={faq.Answers} /></p>
                      </Accordion.Body>
                    </Accordion.Item>
                  )}
                </Accordion>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  );
};

export default Plandetails;
