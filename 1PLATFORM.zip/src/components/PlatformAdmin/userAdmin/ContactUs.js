import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { getPaymentOptions, getDiscountDetails, getChargeDetails, getUserSlots, submitUserRequest, manualSubscriptionRequest } from "../../../endpoints/subscription/users";
import { getDiscountDuration } from "../../../endpoints/subscription/lookup";
import { createPaymentSession } from "../../../endpoints/subscription/payment";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import nodata from '../../../assets/images/nodata.svg';
import { toast } from 'react-toastify';
import paypal from '../../../assets/images/paypal.png'
import stripe from '../../../assets/images/stripe.png'
import Spinner from 'react-bootstrap/Spinner'

const ContactUs = (props) => {
    const history = useHistory();
    const userDetails = useSelector(state => state.user);
    const [pending, setPending] = useState(false);
    const [productLogo, setProductLogo] = useState(nodata);
    const [paymentOption, setPaymentOption] = useState(null);
    const [discountDetails, setDiscountDetails] = useState(null);
    const [chargeDetails, setChargeDetails] = useState(null);
    const [userSlots, setUserSlots] = useState(null);
    const [requestSuccess, setRequestSuccess] = useState(null);
    const [disableUser, setDisableUser] = useState(false);
    const [disableDuration, setDisableDuration] = useState(false);
    const [plan, setPlan] = useState(null);
    const [planDuration, setPlanDuration] = useState([
        {
            "id": 1,
            "duration": "1 Months"
        },
        {
            "id": 2,
            "duration": "2 Months"
        },
        {
            "id": 3,
            "duration": "3 Months"
        },
        {
            "id": 4,
            "duration": "4 Months"
        },
        {
            "id": 5,
            "duration": "5 Months"
        },
        {
            "id": 6,
            "duration": "6 Months"
        },
        {
            "id": 7,
            "duration": "7 Months"
        },
        {
            "id": 8,
            "duration": "8 Months"
        },
        {
            "id": 9,
            "duration": "9 Months"
        },
        {
            "id": 10,
            "duration": "10 Months"
        },
        {
            "id": 11,
            "duration": "11 Months"
        },
        {
            "id": 12,
            "duration": "12 Months"
        }
    ]);
    const [selectedPlanDuration, setSelectedPlanDuration] = useState("Select Plan Duration");
    const [selectedUser, setSelectedUser] = useState("Select User");
    const [gateway_id, setGatewayID] = useState(0);
    const [features, setFeatures] = useState([]);
    const [planDetails, setPlanDetails] = useState({
        duration: null,
        userslot: 0,
        durationId: 0,
        userslotId: 0,
        _request_type: ""
    });

    const [planDetailsErr, setPlanDetailsErr] = useState({
        duration: null,
        userslot: null,
        server: null,
        durationId: null,
        userslotId: null,
    });

    const [userSlotDetails, setUserSlotDetails] = useState({
        "required_user_slot": 0,
        "user_slot_per_unit_price": 0,
        "total_user_slot_price": 0,
    });

    const [showPayment, setShowPayment] = useState(false);
    const [showButton, setShowButton] = useState(false);

    useEffect(() => {

        if (props.location.state) {
            
            setProductLogo(props.location.state.product_logo ? props.location.state.product_logo : nodata);
            setPlanDetails({ ...planDetails, _request_type: props.location.state.type });
            PaymentOptions();
            getDiscountDetail(props.location.state.plan.plan_id);
            userSlot(props.location.state.plan.plan_id);
            if (props.location.state.type === "new_plan") {
                setPlan(props.location.state.plan);
                let features = [];
                for (var a = 0; a < props.location.state.plan.features.length; a++) {
                    var feature = {
                        "feature_name": props.location.state.plan.features[a][0],
                        "feature_value": props.location.state.plan.features[a][1],
                        "per_unit_price": 0,
                        "price": 0
                    }
                    features.push(feature);
                }
                setFeatures(features);
            } else if (props.location.state.type === "renewal_plan") {
                var plan = props.location.state.plan;
                setPlan({
                    ...plan,
                    "product_id": plan.product_id,
                    "plan_id": plan.plan_id,
                    "plan_name": plan.plan_name,
                    "plan_description": plan.product_description,
                    "order_number": null,
                    "most_popular": null,
                    "features": plan.plan_features
                });
                let features = [];
                for (var a = 0; a < props.location.state.plan.plan_features.length; a++) {
                    var feature = {
                        "feature_name": props.location.state.plan.plan_features[a][0],
                        "feature_value": props.location.state.plan.plan_features[a][1],
                        "per_unit_price": 0,
                        "price": 0
                    }
                    features.push(feature);
                }
                setFeatures(features);
                setDisableUser(true);
            } else if (props.location.state.type === "change_plan") {
                setPlan(props.location.state.plan);
                let features = [];
                for (var a = 0; a < props.location.state.plan.features.length; a++) {
                    var feature = {
                        "feature_name": props.location.state.plan.features[a][0],
                        "feature_value": props.location.state.plan.features[a][1],
                        "per_unit_price": 0,
                        "price": 0
                    }
                    features.push(feature);
                }
                setFeatures(features);
            } else if (props.location.state.type === "upgrade_addon") {
                var plan = props.location.state.plan;
                setPlan({
                    ...plan,
                    "product_id": plan.product_id,
                    "plan_id": plan.plan_id,
                    "plan_name": plan.plan_name,
                    "plan_description": plan.product_description,
                    "order_number": null,
                    "most_popular": null,
                    "features": plan.plan_features
                });
                setDisableDuration(true);
            }
        }
    }, []);

    const PaymentOptions = async () => {

        let response = await getPaymentOptions();
        if (response.status === 200) {
            setPaymentOption(response.data);
        }

    }

    const userSlot = async (_plan_id) => {

        let response = await getUserSlots(_plan_id);
        if (response.status === 200) {
            setUserSlots(response.data);
        }

    }

    const discountDuration = async () => {

        let response = await getDiscountDuration("json");
        if (response.status === 200) {
            setPlanDuration(response.data);
        }

    }

    const handleChangeDuration = (duration) => {

        let value = duration.duration;

        setSelectedPlanDuration(duration.duration);
        setPlanDetails({ ...planDetails, duration: value, durationId: duration.id });
        setPlanDetailsErr({ ...planDetailsErr, duration: null })
        setShowButton(false);
    }

    const handleChange = (userSlot) => {

        let value = userSlot.slot;
        setSelectedUser(userSlot.slot_option);
        setPlanDetails({ ...planDetails, userslot: value, userslotId: userSlot.serial_no });
        setPlanDetailsErr({ ...planDetailsErr, userslot: null })
        setShowButton(false);
    }


    const getDiscountDetail = async (_plan_id) => {

        let response = await getDiscountDetails(_plan_id);
        if (response.status === 200) {
            setDiscountDetails(response.data);
        }

    }

    const getchargeDetail = async () => {


        if (planDetails._request_type === "new_plan") {

            if (planDetails.durationId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: "Choose duration" });
                return;
            } else if (planDetails.userslotId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: "Choose user slot" })
                return;
            }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "renewal_plan") {

            if (planDetails.durationId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: "Choose duration" });
                return;
            }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "change_plan") {

            if (planDetails.durationId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: "Choose duration" });
                return;
            } else if (planDetails.userslotId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: "Choose user slot" })
                return;
            }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "upgrade_addon") {

            if (planDetails.userslotId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: "Choose user slot" })
                return;
            }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        }
        setPlanDetailsErr({ ...planDetailsErr, server: null, duration: null, userslot: null })
        let response = await getChargeDetails(planDetails._request_type, plan.plan_id, planDetails.durationId, planDetails.userslotId);
        //let response = await getChargeDetails(4, 10, 10);
        if (response.status === 200) {
            setChargeDetails(response.data);
            setShowButton(true);
            setFeatures(response.data.features);
            setUserSlotDetails({
                ...userSlotDetails,
                "required_user_slot": response.data.required_user_slot,
                "user_slot_per_unit_price": response.data.user_slot_per_unit_price,
                "total_user_slot_price": response.data.total_user_slot_price,
            });

        } else {
            if (response.Error.response.data !== "") {
                setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
            } else {
                setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
            }
        }

    }

    const handleSubmitRequest = async () => {

        if (planDetails._request_type === "new_plan") {

            if (planDetails.durationId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: "Choose duration" });
                return;
            } else if (planDetails.userslotId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: "Choose user slot" })
                return;
            }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "renewal_plan") {

            if (planDetails.durationId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: "Choose duration" });
                return;
            }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "change_plan") {

            if (planDetails.durationId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: "Choose duration" });
                return;
            } else if (planDetails.userslotId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: "Choose user slot" })
                return;
            }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        } else if (planDetails._request_type === "upgrade_addon") {

            if (planDetails.userslotId === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: "Choose user slot" })
                return;
            }
            setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null })

        }


        if (paymentOption && paymentOption.payment_mode[1] === "Manual") {
            setPending(true);
            setPlanDetailsErr({ ...planDetailsErr, server: null })
            var payload = {
                plan_id: plan.plan_id,
                duration: planDetails.durationId,
                user_slot: planDetails.userslotId,
                request_type: planDetails._request_type
            }

            let response = await manualSubscriptionRequest(payload);
            if (response.status === 200) {
                toast.success(response.data.message);
                setRequestSuccess(true);
                //handleLoadMain();
                setPending(false);
                //window.open(response.data.session_url, "_self");
            } else {
                setPending(false);
                if (response.Error.response.data !== "") {
                    setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
                } else {
                    setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
                }
            }

        } else {
            if (gateway_id === 0) {
                setPlanDetailsErr({ ...planDetailsErr, duration: null, userslot: null, server: "Choose Payment Option" })
                return;
            }
            setPending(true);
            setPlanDetailsErr({ ...planDetailsErr, server: null })
            var payload = {
                gateway_id: gateway_id
            }

            let response = await createPaymentSession(payload, plan.plan_id, planDetails.durationId, planDetails.userslotId, planDetails._request_type);
            if (response.status === 200) {
                //toast.success(response.data.message);
                //handleLoadMain();
                setPending(false);
                window.open(response.data.session_url, "_self");
            } else {
                setPending(false);
                if (response.Error.response.data !== "") {
                    setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
                } else {
                    setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
                }
            }

        }

    }

    const handleLoadMain = () => {
        history.push("/dashboard-user");
    }

    const handleBack = () => {
        history.goBack();
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <button className="btn btn_light" onClick={() => handleBack()}>{backBtnIcon}</button>
                        <div className='h3'>Plan Subscription Details</div>
                    </div>
                </div>
            </div>
            <div className='row g-3 my-1'>
                <div className='col-lg-8 col-md-12'>
                    <div className='card p_card paymentCardwrap'>
                        {showPayment ?
                            <>
                                {paymentOption && paymentOption.payment_mode[1] === "Online" &&
                                    <div className='card-body px-0 pb-0 gatewayWrapper'>
                                        {/* <div className='d-flex align-items-center justify-content-between'>
                                            <div className='heading_approval'>
                                                <span>Payment Method</span>
                                            </div>
                                        </div> */}
                                        <div class="my-4">
                                            <ul className="gatewayTypes">
                                                {paymentOption && paymentOption.gateway_list.map(
                                                    payment => payment.gateway_name === "Paypal" ?
                                                        <li onClick={() => setGatewayID(payment.gateway_id)}>
                                                            <div className="gatewayNameWrap">
                                                                <input type="radio" name="gateway" />
                                                                <div className="gatewayName">
                                                                    <img src={paypal} alt="" />
                                                                </div>
                                                            </div>
                                                        </li>
                                                        :
                                                        <li onClick={() => setGatewayID(payment.gateway_id)}>
                                                            <div className="gatewayNameWrap">
                                                                <input type="radio" name="gateway" />
                                                                <div className="gatewayName">
                                                                    <img src={stripe} alt="" />
                                                                </div>
                                                            </div>
                                                        </li>
                                                )
                                                }
                                            </ul>
                                        </div>
                                        <div className="btnWrapper autoBtnWidth my-3">
                                            <Button className="secondaryBtn" onClick={() => setShowPayment(false)}>Back</Button>
                                            <Button className="primaryBtn"
                                                disabled={pending}
                                                onClick={() => handleSubmitRequest()}>
                                                {pending ?
                                                    <span>
                                                        <Spinner
                                                            as="span"
                                                            animation="border" variant="light"
                                                            size="sm"
                                                            role="status"
                                                            aria-hidden="true"
                                                        /> Proceed Payment</span> : <>Proceed Payment</>
                                                }
                                            </Button>
                                            <Form.Text className="d-flex subErors serverError">
                                                {planDetailsErr.server}
                                            </Form.Text>
                                        </div>
                                        {/* <p className="termscontent">By confirming your subscription, you allow One Platform - OIP to charge your card for this payment and future payments in accordance with their terms. You can always cancel your subscription.</p> */}
                                    </div>
                                }
                                {paymentOption && paymentOption.payment_mode[1] === "Manual" &&
                                    <>
                                        {requestSuccess ?
                                            <div className='card-body px-0 pb-0 gatewayWrapper'>
                                                <div class="my-4">
                                                    <h4>Thank You</h4>
                                                    <p>Your Request has been submitted. You will notofied once the request is approved.</p>
                                                </div>
                                                <div className="btnWrapper autoBtnWidth my-3">
                                                    <Button className="secondaryBtn" onClick={() => handleLoadMain()}>Go to Subscription</Button>
                                                </div>
                                            </div>
                                            :
                                            <div className='card-body px-0 pb-0 gatewayWrapper'>
                                                <div class="my-4">
                                                    <Form className={"py-4 inlineForm"}>
                                                        <Form.Group className={`mb-3 formGroup`} controlId="exampleForm.ControlInput1">
                                                            <Form.Label>
                                                                <span>First Name</span>
                                                            </Form.Label>
                                                            <div className="rightField">
                                                                <Form.Control type="text" value={userDetails?.userInfo?.firstname} id='first_name' disabled={true} />
                                                            </div>
                                                        </Form.Group>
                                                        <Form.Group className={`mb-3 formGroup`} controlId="exampleForm.ControlInput1">
                                                            <Form.Label>
                                                                <span>Last Name</span>
                                                            </Form.Label>
                                                            <div className="rightField">
                                                                <Form.Control type="text" value={userDetails?.userInfo?.lastname} id='last_name' disabled={true} />
                                                            </div>
                                                        </Form.Group>
                                                        <Form.Group className={`mb-3 formGroup`} controlId="exampleForm.ControlInput1">
                                                            <Form.Label>
                                                                <span>Email</span>
                                                            </Form.Label>
                                                            <div className="rightField">
                                                                <Form.Control type="email" value={userDetails?.userInfo?.email} id='email' disabled={true} />
                                                            </div>
                                                        </Form.Group>
                                                    </Form>
                                                </div>
                                                <div className="btnWrapper autoBtnWidth my-3">
                                                    <Button className="secondaryBtn" onClick={() => setShowPayment(false)}>Back</Button>
                                                    <Button className="primaryBtn"
                                                        disabled={pending}
                                                        onClick={() => handleSubmitRequest()}>
                                                        {pending ?
                                                            <span>
                                                                <Spinner
                                                                    as="span"
                                                                    animation="border" variant="light"
                                                                    size="sm"
                                                                    role="status"
                                                                    aria-hidden="true"
                                                                /> Submit Request</span> : <>Submit Request</>
                                                        }
                                                    </Button>
                                                    <Form.Text className="d-flex subErors serverError">
                                                        {planDetailsErr.server}
                                                    </Form.Text>
                                                </div>
                                                {/* <p className="termscontent">By confirming your subscription, you allow One Platform - OIP to charge your card for this payment and future payments in accordance with their terms. You can always cancel your subscription.</p> */}
                                            </div>
                                        }
                                    </>
                                }
                            </>
                            :
                            <div className='card-body px-0 py-0'>
                                <div className="setMonthsWrap">
                                    <div className="productIcon">
                                        <img src={productLogo} alt="product-thumbnail" className="product_thumbnail" />
                                    </div>
                                    <div className="productRight">
                                        <div className="productName">
                                            <h1>{plan && plan.plan_name}</h1>
                                            <span>{plan && plan.plan_description}</span>
                                        </div>
                                        {!disableDuration && <ul className="featuresList">
                                            {features && features.map(
                                                feature =>
                                                    <li>
                                                        <div className="featureName"># of {feature.feature_name} - {feature.feature_value}</div>
                                                        <div className="rightValue">
                                                            <span>{feature.feature_name}</span>
                                                            <h4>${parseFloat(feature.price).toLocaleString("en-US")}</h4>
                                                        </div>
                                                    </li>
                                            )}
                                            <li>
                                                <div className="featureName"></div>
                                                <div className="rightValue">
                                                    <span>Plan Per Month</span>
                                                    <h4>${chargeDetails ? parseFloat(chargeDetails?.monthly_price).toLocaleString("en-US") : 0.00}</h4>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="featureName"></div>
                                                <div className="rightValue planTotalbdr">
                                                    <span>Plan-Total</span>
                                                    <h4>${chargeDetails ? (parseFloat(chargeDetails?.monthly_price * chargeDetails?.required_month)).toLocaleString("en-US") : 0.00}</h4>
                                                </div>
                                            </li>
                                        </ul>}
                                        {!disableDuration &&
                                            <Form className="inlineForm planDurationForm">
                                                <Form.Group className={`mb-3 formGroup ${planDetailsErr.duration ? "errorFields" : ""}`} controlId="CI-ProName">
                                                    <Form.Label>Plan Duration</Form.Label>
                                                    <Dropdown
                                                        className={"customDropdown"}
                                                    >
                                                        <Dropdown.Toggle className={"form-control"} id="dropdown-basic" >
                                                            {selectedPlanDuration}
                                                        </Dropdown.Toggle>

                                                        <Dropdown.Menu className={"dropdownList"} disable={disableDuration}>
                                                            {planDuration && planDuration.map(
                                                                duration =>
                                                                    <Dropdown.Item eventKey={duration.id} onClick={() => handleChangeDuration(duration)}>{duration.duration}</Dropdown.Item>
                                                            )
                                                            }
                                                        </Dropdown.Menu>
                                                        <span className="d-flex subErors">
                                                            {planDetailsErr.duration}
                                                        </span>
                                                    </Dropdown>

                                                </Form.Group>
                                            </Form>
                                        }
                                        {/* <div className="rightfinalPrice">
                                        <div className="rightValue">
                                            <span>Plan Total</span>
                                            <h4>${chargeDetails?.monthly_price}</h4>
                                        </div>
                                    </div> */}
                                    </div>
                                </div>
                                {planDetails._request_type !== "renewal_plan" &&
                                    <div className="addonwrapper">
                                        <h5 className="addonTitle">Add-on Users</h5>
                                        <div className="mt-3">
                                            <div className="addonUserCharge">
                                                <Form className="inlineForm">
                                                    {!disableUser &&
                                                        <Form.Group className={`mb-3 formGroup ${planDetailsErr.userslot ? "errorFields" : ""}`} controlId="CI-ProName">
                                                            <Form.Label># of Users Required</Form.Label>
                                                            <Dropdown
                                                                className={"customDropdown"}
                                                            >
                                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic" disable={disableUser} >
                                                                    {selectedUser}
                                                                </Dropdown.Toggle>

                                                                <Dropdown.Menu className={"dropdownList"}>
                                                                    {userSlots && userSlots.map(
                                                                        slot =>
                                                                            <Dropdown.Item eventKey={slot.serial_no} onClick={() => handleChange(slot)} >{slot.slot_option}</Dropdown.Item>
                                                                    )
                                                                    }
                                                                </Dropdown.Menu>
                                                                <span className="d-flex subErors">
                                                                    {planDetailsErr.userslot}
                                                                </span>
                                                            </Dropdown>

                                                        </Form.Group>
                                                    }
                                                </Form>
                                                <ul className="addonCalculate">
                                                    <li>
                                                        <div className="rightValue">
                                                            <div className="left">
                                                                <span>Add-on User</span>
                                                                <span className="calculateunit">({userSlotDetails.required_user_slot} x ${parseFloat(userSlotDetails.user_slot_per_unit_price).toLocaleString("en-US")})</span>
                                                            </div>
                                                            <h4>${parseFloat(userSlotDetails.total_user_slot_price).toLocaleString("en-US")}</h4>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="rightValue planTotalbdr">
                                                            <span>Add-on User Total</span>
                                                            <h4>${parseFloat(userSlotDetails.total_user_slot_price).toLocaleString("en-US")}</h4>
                                                        </div>
                                                    </li>
                                                </ul>

                                            </div>
                                            {/* <div className="rightfinalPrice">
                                            <div className="rightValue">
                                                <span>Add-on User</span>
                                                <h4>$1,800.00</h4>
                                            </div>
                                        </div> */}
                                        </div>
                                    </div>
                                }
                                <div className="btnWrapper autoBtnWidth my-3">
                                    <Button className="primaryBtn" onClick={() => getchargeDetail()}>View Details</Button>
                                    <Button className="primaryBtn" disabled={!showButton} onClick={() => setShowPayment(true)}>Proceed Payment</Button>
                                    <Form.Text className="d-flex subErors serverError">
                                        {!chargeDetails && planDetailsErr.server}
                                    </Form.Text>
                                </div>
                            </div>
                        }
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card op_card orderSummaryCard">
                        <div className="card-body px-0 py-0">
                            <div className={"popularBand"}>
                                <span>Order Summary</span>
                            </div>
                            <ul className="featuresList">
                                {!disableDuration && <li>
                                    <div className="featureName">Plan</div>
                                    <div className="rightValue">
                                        {/* <h4>${chargeDetails ? (chargeDetails?.monthly_price * chargeDetails?.required_month) : 0}</h4> */}
                                        <h4>${chargeDetails ? parseFloat(chargeDetails?.monthly_price * chargeDetails?.required_month).toLocaleString("en-US") : 0.00}</h4>
                                    </div>
                                </li>}
                                {!disableDuration && <li>
                                    <div className="featureName">Plan discount - {chargeDetails ? parseFloat(chargeDetails?.plan_discount.discount_percent).toLocaleString("en-US") : 0.00}%</div>
                                    <div className="rightValue">
                                        <h4>(-) ${chargeDetails ? parseFloat(chargeDetails?.plan_discount.discount_amount).toLocaleString("en-US") : 0.00}</h4>
                                    </div>
                                </li>}
                                <li className="divider"></li>
                                <li className="boldedCont">
                                    <div className="featureName">Sub-total</div>
                                    <div className="rightValue">
                                        <h4>${chargeDetails ? parseFloat(chargeDetails?.total_price).toLocaleString("en-US") : 0.00}</h4>
                                    </div>
                                </li>
                                {!disableUser && <li>
                                    <div className="featureName">Add-on Users</div>
                                    <div className="rightValue">
                                        <h4>${chargeDetails ? parseFloat(chargeDetails?.total_user_slot_price).toLocaleString("en-US") : 0.00}</h4>
                                    </div>
                                </li>}
                                <li className="divider"></li>
                                <li className="boldedCont totalAmount">
                                    <div className="featureName">Total Amount</div>
                                    <div className="rightValue">
                                        <h4>${chargeDetails ? parseFloat(chargeDetails?.final_price).toLocaleString("en-US") : 0.00}</h4>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    )
}

export default ContactUs;