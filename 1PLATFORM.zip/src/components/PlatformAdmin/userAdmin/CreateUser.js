import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { purchasedSlotDetails, checkUser, createUser, updateUserProduct } from "../../../endpoints/subscription/users";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import nodata from '../../../assets/images/nodata.svg';
import { Checkbox } from '@mui/material';
import { toast } from 'react-toastify';
import ReactMultiSelectCheckboxes from "react-multiselect-checkboxes";

const CreateUser = (props) => {
    const history = useHistory();

    const [options, setOptions] = useState([]);
    const [selectedOptions, setSelectedOptions] = useState([]);
    // console.log(selectedOptions.length)
    // console.log(selectedOptions.value)

    const [payload, setPayload] = useState({
        "first_name": null,
        "last_name": null,
        "email": null,
        "product_id": []
    });

    const [payloadErr, setPayloadErr] = useState({
        "first_name": null,
        "last_name": null,
        "email": null,
        "product_id": null,
        "main": null,
        "status": null
    });

    const [allProducts, setAllProducts] = useState(null);

    const [productNames, setProductNames] = useState(null);

    const [isEmailValid, setEmailValid] = useState(null);

    const [disabled, setDisabled] = useState(false);

    const [view, setView] = useState(false);

    function validateEmailCheck(email) {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
            return (true)
        }
        return (false)
    }

    useEffect(() => {

        if (props.userEdit && props.edituser && props.edituser.products) {

            if (props.userEdit) {
                setDisabled(true);
                setView(props.edittype);
                var user = props.edituser;
                if (props.edituser) {
                    setPayload({
                        ...payload,
                        "first_name": user.first_name,
                        "last_name": user.last_name,
                        "email": user.email,
                        "product_id": [],
                        "status": user.status
                    });
                }
            }
            purchasedProductp();
        } else if (props.userEdit && props.edituser && !props.edituser.products) {
            setDisabled(true);
            setView(props.edittype);
            var user = props.edituser;
            if (props.edituser) {
                setPayload({
                    ...payload,
                    "first_name": user.first_name,
                    "last_name": user.last_name,
                    "email": user.email,
                    "product_id": [],
                    "status": user.status
                });
            }
            purchasedProductInvd();
        } else {
            purchasedProductp();
        }

    }, []);

    const purchasedProductp = async () => {

        let response = await purchasedSlotDetails();
        if (response.status === 200) {
            setAllProducts(response.data);

            var pro = [];
            var proSel = [];
            for (var a = 0; a < response.data.length; a++) {

                let mainProduct = response.data[a].main_product_name
                let product = response.data[a].product_name
                let withSub = mainProduct !== product ? mainProduct + " - " + product : product
                var list = {
                    label: withSub + " ( Unused licenses " + response.data[a].remaining_slots + " )",
                    id: response.data[a].product_id,
                    value: response.data[a].product_name
                }
                pro.push(list);

                if (props.userEdit && props.edituser && props.edituser.products) {

                    if (props.edituser.products.indexOf(response.data[a].product_name) === -1) {

                    } else {
                        proSel.push(list);
                    }

                }
            }

            setOptions(pro);
            setSelectedOptions(proSel);
        }

    }

    const purchasedProductInvd = async () => {

        let response = await purchasedSlotDetails();
        if (response.status === 200) {
            setAllProducts(response.data);
            var pro = [];
            var proSel = [];
            for (var a = 0; a < response.data.length; a++) {

                var list = {
                    label: response.data[a].product_name + " ( Unused licenses " + response.data[a].remaining_slots + " )",
                    id: response.data[a].product_id,
                    value: response.data[a].product_name
                }

                if (props.editproductId === response.data[a].product_id) {
                    proSel.push(list);
                    pro.push(list);
                }
            }
            setOptions(pro);
            setSelectedOptions(proSel);
        }

    }

    const validateEmail = async () => {

        if (payload.email === null || payload.email === "") {
            setPayloadErr({ ...payloadErr, email: 'email is required' });
            return;
        }
        // else if (!validateEmailCheck(payload.email)) {
        //     setPayloadErr({ ...payloadErr, email: 'enter valid email' });
        //     return;
        // }

        setPayloadErr({ ...payloadErr, email: null });
        let response = await checkUser(payload.email);
        if (response.status === 200) {
            if (response.data.is_user) {
                setPayloadErr({ ...payloadErr, email: 'User already exist' });
            } else {
                setEmailValid(false);
            }
        } else {
            if (response.Error.response.data !== "") {
                setPayloadErr({ ...payloadErr, email: response.Error.response.data.errors[0].message });
            } else {
                setPayloadErr({ ...payloadErr, email: response.data.message })
            }
        }

    }

    const handleCreateUser = async () => {

        if (payload.first_name === null || payload.first_name === "") {
            setPayloadErr({ ...payloadErr, first_name: 'First name is required' });
            return;
        } else if (payload.first_name.length < 3) {
            setPayloadErr({ ...payloadErr, first_name: 'Minimum 3 characters required' });
            return;
        }
        else if (payload.last_name.length < 3) {
            setPayloadErr({ ...payloadErr, first_name: null, last_name: 'Minimum 3 characters required' });
            return;
        }
        else if (payload.last_name === null || payload.last_name === "") {
            setPayloadErr({ ...payloadErr, first_name: null, last_name: 'Last name is required' });
            return;
        }
        else if (payload.email === null || payload.email === "") {
            setPayloadErr({ ...payloadErr, first_name: null, last_name: null, email: 'email is required' });
            return;
        } else {

            if (selectedOptions.length === 0) {
                if (disabled) {
                    setPayloadErr({ ...payloadErr, first_name: null, last_name: null, email: null, product: null });
                } else {
                    setPayloadErr({ ...payloadErr, first_name: null, last_name: null, email: null, product: 'Select Product' });
                    return;
                }
            }

            setPayloadErr({ ...payloadErr, first_name: null, last_name: null, email: null, product: null, main: null });
            var product = [];

            for (var x = 0; x < selectedOptions.length; x++) {

                product.push(selectedOptions[x].id);

            }
            setPayload({ ...payload, product_id: product })

            if (disabled) {
                // debugger
                var payloads = {
                    "first_name": payload.first_name,
                    "last_name": payload.last_name,
                    "email": payload.email,
                    "product_id": product,
                    "status": payload.status
                }

                let response = await updateUserProduct(payloads);
                if (response.status === 200) {
                    toast.success(response.data.message);
                    props.UserhandleClose();
                    debugger

                } else {
                    if (response.Error.response.data !== "") {
                        setPayloadErr({ ...payloadErr, main: response.Error.response.data.errors[0].message })
                    } else {
                        setPayloadErr({ ...payloadErr, main: response.data.message })
                    }
                }
            } else {
                let response = await createUser({ ...payload, product_id: product });
                if (response.status === 200) {
                    toast.success(response.data.message);
                    props.UserhandleClose();
                } else {
                    if (response.Error.response.data !== "") {
                        setPayloadErr({ ...payloadErr, main: response.Error.response.data.errors[0].message })
                    } else {
                        setPayloadErr({ ...payloadErr, main: response.data.message })
                    }
                }
            }
        }

    }

    const handleFreetext = (e) => {
        let name = e.target.id;
        let value = e.target.value;

        if (name === "email") {
            setEmailValid(true);
        }

        if (name === "status") {
            setPayload({ ...payload, status: e.target.checked });
            setPayloadErr({ ...payloadErr, [name]: null });
        } else {
            setPayload({ ...payload, [name]: value });
            setPayloadErr({ ...payloadErr, [name]: null });
        }
    }

    const handleChangeProduct = (e) => {

    }

    const handleBack = () => {
        history.goBack();
    }

    const handleDeleteProd = (keyIndex) => {

        selectedOptions.splice(keyIndex, 1);
        setSelectedOptions([...selectedOptions]);
    }

    function refreshIcon() {
        return (
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z" />
                <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z" />
            </svg>
        )
    }

    function checkIcon() {
        return (
            <svg xmlns="http://www.w3.org/2000/svg" color="green" width="16" height="16" fill="currentColor" class="bi bi-shield-check" viewBox="0 0 16 16">
                <path d="M5.338 1.59a61.44 61.44 0 0 0-2.837.856.481.481 0 0 0-.328.39c-.554 4.157.726 7.19 2.253 9.188a10.725 10.725 0 0 0 2.287 2.233c.346.244.652.42.893.533.12.057.218.095.293.118a.55.55 0 0 0 .101.025.615.615 0 0 0 .1-.025c.076-.023.174-.061.294-.118.24-.113.547-.29.893-.533a10.726 10.726 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067c-.53 0-1.552.223-2.662.524zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.775 11.775 0 0 1-2.517 2.453 7.159 7.159 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7.158 7.158 0 0 1-1.048-.625 11.777 11.777 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 62.456 62.456 0 0 1 5.072.56z" />
                <path d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z" />
            </svg>
        )
    }

    function onChange(value, event) {
        setSelectedOptions(value);
    }

    function closeIcon() {
        return (
            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
            </svg>
        )
    }

    function getDropdownButtonLabel({ placeholderButtonLabel, value }) {
        if (value && value.some((o) => o.value === "*")) {
            return `${placeholderButtonLabel}: All`;
        } else {
            return `${placeholderButtonLabel}: ${value.length} selected`;
        }
    }


    return (
        <div>
            <Form className={"pb-2 createUserForm"}>
                <Form.Group className={`mb-3 formGroup ${payloadErr.first_name ? "errorFields" : ""}`} controlId="exampleForm.ControlInput1">
                    <Form.Label>
                        <span>First Name</span>
                    </Form.Label>
                    <div className="rightField">
                        <Form.Control type="text" value={payload.first_name} id='first_name' onChange={(e) => handleFreetext(e)} />
                        <Form.Text className="d-flex subErors">
                            {payloadErr.first_name}
                        </Form.Text>
                    </div>
                </Form.Group>
                <Form.Group className={`mb-3 formGroup ${payloadErr.last_name ? "errorFields" : ""}`} controlId="exampleForm.ControlInput1">
                    <Form.Label>
                        <span>Last Name</span>
                    </Form.Label>
                    <div className="rightField">
                        <Form.Control type="text" value={payload.last_name} id='last_name' onChange={(e) => handleFreetext(e)} />
                        <Form.Text className="d-flex subErors">
                            {payloadErr.last_name}
                        </Form.Text>
                    </div>
                </Form.Group>
                <Form.Group className={`mb-3 formGroup ${payloadErr.email ? "errorFields" : ""}`} controlId="exampleForm.ControlInput1">
                    <Form.Label>
                        <span>Email</span>
                    </Form.Label>
                    <div className="rightField emailValidation">
                        <Form.Control type="email" value={payload.email} onBlur={() => validateEmail()} id='email' onChange={(e) => handleFreetext(e)} disabled={disabled} />
                        {isEmailValid === true ?
                            <></>
                            : isEmailValid === false &&
                            <span className="refreshIcon checkIcon">{checkIcon()}</span>
                        }

                        <Form.Text className="d-flex subErors">
                            {payloadErr.email}
                        </Form.Text>
                    </div>
                </Form.Group>
                <Form.Group className={`mb-3 labelTop formGroup ${payloadErr.product ? "errorFields" : ""}`} controlId="exampleForm.ControlInput1">
                    <Form.Label>Product Name</Form.Label>
                    <div className={`productMultiselect`}>
                        <div className={props.type === "View" ? "disabledrop" : ""} data-opt={`Select a product: ${selectedOptions.length} selected`}>
                            <ReactMultiSelectCheckboxes
                                options={options}
                                placeholderButtonLabel={"Select a product"}
                                value={selectedOptions}
                                onChange={onChange}
                                getDropdownButtonLabel={getDropdownButtonLabel}
                                className={`productMultiselectInner`}
                            />
                        </div>

                        <ul className="selectedProducts">
                            {selectedOptions && selectedOptions.map(
                                (prod, index) =>
                                    <li>
                                        {prod.value}
                                        {props.type !== "View" && <span className="closeIcon" onClick={() => handleDeleteProd(index)}>
                                            {closeIcon()}
                                        </span>}
                                    </li>
                            )}
                        </ul>
                    </div>

                    <Form.Text className="d-flex subErors">
                        {payloadErr.product}
                    </Form.Text>
                </Form.Group>
                {disabled &&
                    <Form.Group className={`mb-3 formGroup statusWrapper ${payloadErr.status ? "errorFields" : ""}`} controlId="exampleForm.ControlInput1">
                        <Form.Label>
                            <span>Status</span>
                        </Form.Label>
                        <div className="rightField toggleWithText">
                            {/* <Form.Check
                                type="switch"
                                id="status"
                                checked={payload.status}
                                onClick={(e) => handleFreetext(e)}
                                disabled={props.type === "View" ? true : false}
                            /> */}
                            <label class="toggle">
                                <input
                                    type={"checkbox"}
                                    id="status"
                                    // value={planDiscounts.published}
                                    // onChange={(e) => handleTermFreetext(e)}
                                    onClick={(e) => handleFreetext(e)}

                                    // checked={planDiscounts.published}
                                    checked={payload.status}

                                    disabled={props.type === "View" ? true : false}
                                />
                                <span class={`slider`}></span>
                                <span class="labels" data-on="Active" data-off="Inactive"></span>
                            </label>
                            <Form.Text className="d-flex subErors">
                                {payloadErr.status}
                            </Form.Text>
                        </div>
                    </Form.Group>
                }
                {view ?
                    <Form.Group className={`mb-3 formGroup`} controlId="exampleForm.ControlInput1">
                        <Form.Label>
                            <span>&nbsp;</span>
                        </Form.Label>
                        <div>
                            <Button className="secondaryBtn" onClick={() => props.UserhandleClose()}>Cancel</Button>
                        </div>
                    </Form.Group>

                    :
                    <Form.Group className={`mb-3 formGroup`} controlId="exampleForm.ControlInput1">
                        <Form.Label>
                            <span>&nbsp;</span>
                        </Form.Label>
                        <div className="btnWrapper mangeUserBtnWrap">
                            <Button className="secondaryBtn" onClick={() => props.UserhandleClose()}>Cancel</Button>
                            {props.type !== "View" &&
                                <>
                                    {disabled ?
                                        <Button className="primaryBtn" onClick={() => handleCreateUser()}>Update</Button>
                                        :
                                        <Button className="primaryBtn" disabled={isEmailValid === false ? false : true} onClick={() => handleCreateUser()}>Add</Button>
                                    }
                                </>
                            }
                            <Form.Text className="d-flex subErors">
                                {payloadErr.main}
                            </Form.Text>
                        </div>
                    </Form.Group>

                }
                {/* <div className="btnWrapper">
                        <Button className="primaryBtn" onClick={() => handleBack()}>Cancel</Button>
                        { disabled ?
                            <Button className="primaryBtn" onClick={() => handleCreateUser()}>Update</Button>
                        :
                            <Button className="primaryBtn" disabled={isEmailValid === false ? false : true} onClick={() => handleCreateUser()}>Create</Button>
                        }
                    </div> */}
            </Form>
        </div >
    )
}

export default CreateUser;