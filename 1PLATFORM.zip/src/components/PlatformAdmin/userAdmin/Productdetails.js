import React, { useState, useEffect, useRef, useMemo } from 'react'
import { Link } from 'react-router-dom'
import './Productdetails.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import user1 from '../../../assets/images/usermanagement/users/user1.png';
import { backBtnIcon } from '../../../Icons/icons';
import { getMappedUsers } from '../../../endpoints/gateway';
import { getAllUserProduct, createUserProduct, updateUserProduct, uploadFiles, manualSubscriptionRequest } from "../../../endpoints/subscription/users";
import moment from 'moment';
import { useHistory } from "react-router-dom";
import { toast } from 'react-toastify';
import Edituser from './Edituser';
import icon1 from '../../../assets/images/dashboard/5.png';
import icon2 from '../../../assets/images/dashboard/3.png';
import icon3 from '../../../assets/images/dashboard/4.png';
import profilePicture from '../../../assets/images/usermanagement/profilepicture.png'
import { TablePagination, Pagination } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Search from '../../Common/Search/Search';
import ManualPayment from "../Modal/ManualPayment";
import '../platformadmin.scss'
import CreateUser from './CreateUser';

const Productdetails = (props) => {
    // const firstInitial = allUsersFilter.first_name.charAt(0);
    // const lastInitial = allUsersFilter.last_name.charAt(0);
    // const initials = firstInitial + lastInitial;
    const dateIcon = <svg id="today_black_24dp" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
        <path id="Path_13531" data-name="Path 13531" d="M0,0H20V20H0Z" fill="none" />
        <path id="Path_13532" data-name="Path 13532" d="M17.885,2.783h-.93V1H15.094V2.783H7.652V1H5.791V2.783h-.93A1.823,1.823,0,0,0,3,4.566V17.048a1.823,1.823,0,0,0,1.861,1.783H17.885a1.828,1.828,0,0,0,1.861-1.783V4.566A1.828,1.828,0,0,0,17.885,2.783Zm0,14.265H4.861V8.132H17.885Zm0-10.7H4.861V4.566H17.885ZM6.721,9.915h4.652v4.458H6.721Z" transform="translate(-1.373 -0.458)" fill='#757575' />
    </svg>

    const eye = <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" class="bi bi-eye" viewBox="0 0 16 16">
        <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z" fill="#333333" />
        <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z" />
    </svg>

    const edit = <svg xmlns="http://www.w3.org/2000/svg" width="13.512" height="14.771" viewBox="0 0 13.512 14.771">
        <path id="border_color_FILL0_wght400_GRAD0_opsz48" d="M4,19.045V17H17.512v2.044Zm1.385-3.834V12.964l6.3-6.3,2.246,2.246-6.3,6.3ZM6.4,14.2h.76l5.32-5.32-.76-.76L6.4,13.437Zm8.276-6.03L12.428,5.921,13.847,4.5a.573.573,0,0,1,.422-.228.646.646,0,0,1,.473.228L16.059,5.82a.654.654,0,0,1,.22.464.709.709,0,0,1-.186.464ZM6.4,14.2Z" transform="translate(-4 -4.274)" fill="#333333" />
    </svg>

    const del = <svg xmlns="http://www.w3.org/2000/svg" width="12.537" height="14.52" viewBox="0 0 12.537 14.52">
        <g id="Component_100_22" data-name="Component 100 – 22" transform="translate(0.25 0.25)">
            <path id="Path_14027" data-name="Path 14027" d="M601.222,838.493c-.992,0-1.985.005-2.977,0a1.3,1.3,0,0,1-1.408-1.352q-.352-4.734-.707-9.468c-.025-.343-.041-.621-.512-.569a.39.39,0,0,1-.423-.453c.02-.3.222-.423.515-.421.843.006,1.687-.009,2.53.009.291.006.395-.055.4-.382a1.263,1.263,0,0,1,1.373-1.371c.81-.008,1.621-.011,2.431,0a1.258,1.258,0,0,1,1.339,1.353c0,.364.141.4.433.4.81-.015,1.621,0,2.431-.008.328,0,.586.1.583.455,0,.325-.255.468-.556.431-.37-.046-.347.208-.365.439q-.218,2.87-.433,5.741c-.1,1.309-.194,2.619-.3,3.928a1.279,1.279,0,0,1-1.332,1.272C603.24,838.5,602.231,838.493,601.222,838.493Zm-.008-11.377c-1.29,0-2.579.006-3.869,0-.276,0-.413.024-.385.377q.381,4.73.721,9.463c.037.525.259.688.753.683,1.785-.019,3.571-.008,5.357-.008.875,0,.9-.018.969-.925.233-3.054.458-6.108.7-9.161.025-.321-.032-.438-.377-.432C603.793,827.128,602.5,827.116,601.213,827.116Zm-.011-.885c.446,0,.894-.027,1.337.008.359.028.414-.135.384-.436-.034-.343-.238-.454-.539-.454h-1.437c-.33,0-.661-.013-.991.005-.391.022-.466.289-.459.635.008.407.3.222.466.232C600.375,826.248,600.789,826.231,601.2,826.231Z" transform="translate(-595.194 -824.476)" fill="#333" stroke="#333" stroke-width="0.5" />
            <path id="Path_2435" data-name="Path 2435" d="M639.29,862.35c0,.878,0,1.756,0,2.633,0,.227-.014.46-.416.456s-.406-.239-.405-.465q0-2.616,0-5.231c0-.232.03-.46.419-.457s.406.238.4.466C639.287,860.618,639.29,861.484,639.29,862.35Z" transform="translate(-633.911 -853.789)" fill="#333" stroke="#333" stroke-width="0.5" />
            <path id="Path_2436" data-name="Path 2436" d="M665.261,862.4c0,.866,0,1.732,0,2.6,0,.23-.019.459-.418.454s-.406-.241-.406-.465q0-2.616,0-5.232c0-.232.032-.46.422-.455s.4.239.4.467C665.257,860.645,665.261,861.523,665.261,862.4Z" transform="translate(-657.784 -853.803)" fill="#333" stroke="#333" stroke-width="0.5" />
        </g>
    </svg>

    const ref = useRef();
    const history = useHistory();
    const [show, setShow] = useState(false);
    const [showPopover, setShowPopover] = useState(false);
    const [showPopoverId, setShowPopoverId] = useState(0);
    const [searchOpen, setSearchOpen] = useState(false);
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(7);
    const [Usershow, UsersetShow] = useState(false);

    const animateSearch = () => {
        setSearchOpen(!searchOpen);
    }

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(false);

    const [showTwo, setShowTwo] = useState(false);

    const handleCloseTwo = () => setShowTwo(false);
    const handleShowTwo = () => setShowTwo(true);

    const [productDetails, setproductDetails] = useState();
    const [allMemebers, setallMembers] = useState(null);
    const [productId, setProductId] = useState(0);

    const [logoUploadResponse, setlogoUploadResponse] = useState();
    const [file, setFile] = useState(profilePicture);

    const [addUser, setAddUser] = useState({
        "first_name": "",
        "last_name": "",
        "email": ""
    });

    const [addUserErr, setAddUserErr] = useState({
        "first_name": "",
        "last_name": "",
        "email": "",
        "server": ""
    });

    const [editUser, setEditUser] = useState({
        "profile_logo": "",
        "first_name": "",
        "last_name": "",
        "email": "",
        "status": false
    });

    const [editUserErr, setEditUserErr] = useState({
        "profile_logo": "",
        "first_name": "",
        "last_name": "",
        "email": "",
        "status": "",
        "server": ""
    });

    const [planDetailsErr, setPlanDetailsErr] = useState({
        duration: null,
        userslot: null,
        server: null,
        durationId: null,
        userslotId: null,
    });

    useEffect(() => {
        if (props.location.state) {
            setProductId(props.location.state.product.product_id);
            setproductDetails(props.location.state.product);
            fetchallMemebers(props.location.state.product.product_id, "");
        }
    }, [])

    const UserhandleClose = () => {
        UsersetShow(false);
        if (props.location.state) {
            setProductId(props.location.state.product.product_id);
            setproductDetails(props.location.state.product);
            fetchallMemebers(props.location.state.product.product_id, "");
        }
    };

    const fetchallMemebers = async (product_id, status) => {
        let response = await getAllUserProduct(product_id, status);
        if (response.status === 200) {
            setallMembers(response.data);
        }
    }

    const viewRenewPlans = (type, _product_id, plan) => {
        if (type === "change_plan") {
            history.push({
                pathname: "/plandetails",
                state: {
                    _product_id,
                    type,
                    product_logo: plan.product_logo,
                    product_name: plan.product_name,
                    is_sub_product: plan.is_sub_product,
                    main_name: plan.main_name
                }
            });
        } else if (type === "upgrade_addon") {
            history.push({
                pathname: "/payment",
                state: {
                    _product_id,
                    plan,
                    type,
                    product_logo: plan.product_logo,
                    product_name: plan.product_name
                }
            });
        } else {
            history.push({
                pathname: "/payment",
                state: {
                    _product_id,
                    plan,
                    type,
                    product_logo: plan.product_logo,
                    product_name: plan.product_name
                }
            });
        }
    }

    const handleSubmitRequest = async (requestType, plan) => {

        setPlanDetailsErr({ ...planDetailsErr, server: null });
        var payload = {
            plan_id: plan.plan_id,
            duration: requestType === "upgrade_addon" ? 0 : plan.plan_duration,
            user_slot: 0,
            request_type: requestType
        }

        let response = await manualSubscriptionRequest(payload);
        if (response.status === 200) {
            setShowManualPaymentModal(true);
        } else {
            if (response.Error.response.data !== "") {
                setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
            } else {
                setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
            }
            setShowManualPaymentModal(true);
        }
    }

    const handleFreetext = (e) => {
        let name = e.target.id;
        let value = e.target.value;

        setAddUser({ ...addUser, [name]: value });

    }

    const handleFreetextEdit = (e) => {
        let name = e.target.id;
        let value = e.target.value;

        setEditUser({ ...editUser, [name]: value });

    }



    const handleAddUser = async () => {

        let product_id = productDetails?.product_id;
        if (addUser.first_name === "") {
            setAddUserErr({ ...addUserErr, first_name: "Enter first name" });
            return;
        } else if (addUser.last_name === "") {
            setAddUserErr({ ...addUserErr, first_name: null, last_name: "Enter last name" });
            return;
        } else if (addUser.email === "") {
            setAddUserErr({ ...addUserErr, first_name: null, first_name: null, email: "Enter email" });
            return;
        } else if (product_id === 0) {
            setAddUserErr({ ...addUserErr, first_name: null, first_name: null, email: null, server: "Product is not found" });
            return;
        } else {
            setAddUserErr({ ...addUserErr, first_name: null, first_name: null, email: null, server: null });
        }

        let response = await createUserProduct(addUser, product_id);

        if (response.status === 200) {
            toast.success(response.data.message);
            handleClose();
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);
                setAddUserErr({ ...addUserErr, server: response.Error.response.data.errors[0].message });
            } else {
                toast.error("Error in request");
                setAddUserErr({ ...addUserErr, server: "Error in request" });
            }
        }

    }

    const changeImageHandler = async (event) => {

        // setlogoformaterror(false)
        if (imageValidation(event.target.files[0])) {
            // setselectedLogo(event.target.files[0])
            // setislogoPicked(true)
            setFile(URL.createObjectURL(event.target.files[0]));
            uploadLogo(event.target.files[0]);
        } else {
            ref.current.value = "";
            // setlogoformaterror(true);
            // setselectedLogo('')
            // setislogoPicked(false)
        }
    }

    const imageValidation = (file) => {

        const fileType = file['type'];
        const validImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/jpg'];
        if (!validImageTypes.includes(fileType)) {
            return false
        }
        return true
    }

    const uploadLogo = async (file) => {
        const formData = new FormData();
        formData.append('files', file);
        let response = await uploadFiles(formData)
        setlogoUploadResponse(response.data);
        if (response.data.message) {
            toast.success(response.data.message);
        }
    };

    // const handleUpdateUser = (user, product_id, type) => {
    //     history.push({
    //         pathname: "/update-user",
    //         state: {
    //             user,
    //             product_id,
    //             type
    //         }
    //     });
    // }

    const [userEdit, setUserEdit] = useState(false);
    const [edituser, setuser] = useState(null);
    const [editproductId, setEditproductId] = useState(0);
    const [edittype, settype] = useState(false);
    const [from, setFrom] = useState("");

    const handleUpdateUser = (user, product_id, type, from) => {
        setFrom(from);
        setuser(user);
        setEditproductId(product_id);
        settype(type);
        setUserEdit(true);
        UsersetShow(true);

    }

    const handleChange = (event, value) => {
        setPage(value);
    };

    const theme = createTheme({
        palette: {
            neutral: {
                main: '#bae6f3',
                contrastText: '#0e699c',
            },
        },
    });

    /*pagination with search */
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");

    const ITEMS_PER_PAGE = 5;


    const allUsersFilter = useMemo(() => {
        if (allMemebers === null) {
            return allMemebers;
        }
        let computedviewDomain = allMemebers?._list;
        if (search) {
            computedviewDomain = computedviewDomain.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(search.toLowerCase())
            );
        }
        setTotalItems(computedviewDomain.length);

        return computedviewDomain.slice(
            (currentPage - 1) * ITEMS_PER_PAGE,
            (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [allMemebers, currentPage, search]);

    /*pagination with search */

    const handleLoadMain = () => {
        handleManualPaymentClose(false);
        //history.push("/dashboard-user");
    }

    const [showManualPaymentModal, setShowManualPaymentModal] = useState(false);
    const handleManualPaymentClose = () => setShowManualPaymentModal(false);

    const handleOpenApp = (url) => {
        window.open(`https://dtlehta1thuw9.cloudfront.net/1platformsubsv2${url}`, "_self");
    }

    return (
        <div className='productDetails'>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <Link to="/dashboard-user" className='btn btn_light'>{backBtnIcon} </Link>
                        <div className='h3'>Product License Details</div>
                    </div>
                    {/* {productDetails?.status === "Active" &&
                        <div className='d-flex align-items-center gap-3'>
                            <Button className="primaryBtn" onClick={() => viewRenewPlans("upgrade_addon", productDetails?.product_id, productDetails)}>Add-on License</Button>
                        </div>
                    } */}
                </div>
            </div>
            {allMemebers?._slots &&
                <ul className="statusLists mt-3 DashboardStatus">
                    <li>
                        <div className="cardWrap">
                            <div className="countWthcircle">
                                <div className="square whitebg">
                                    <img src={icon1} alt="" />
                                </div>
                                <div className='Counttitle'>
                                    <h1 className="usersCount">{String(allMemebers?._slots?.purchased_slots).padStart(2, '0')}</h1>
                                    <div className="userLabel"># of User Licenses</div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div className="cardWrap">
                            <div className="countWthcircle">
                                <div className="square whitebg">
                                    <img src={icon2} alt="" />
                                </div>
                                <div className='Counttitle'>
                                    <h1 className="usersCount">{String(allMemebers?._slots?.used_slots).padStart(2, '0')}</h1>
                                    <div className="userLabel"># of Used User Licenses</div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div className="cardWrap">
                            <div className="countWthcircle">
                                <div className="square whitebg">
                                    <img src={icon3} alt="" />
                                </div>
                                <div className='Counttitle'>
                                    <h1 className="usersCount">{String(allMemebers?._slots?.remaining_slots).padStart(2, '0')}</h1>
                                    <div className="userLabel"># of Unused User Licenses</div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            }
            <div className='row g-3 my-1'>
                <div class="col-md-6 col-lg-4 align-self-start">
                    <div class="card op_card">
                        <div className="card-body">
                            {parseInt(productDetails?.remaing_days) > 0 &&
                                parseInt(productDetails?.remaing_days) < 20 && <div className="planName expireLabel">Expires in <span>&nbsp;{productDetails?.remaing_days} days</span></div>
                            }
                            {productDetails?.status === "Expired" &&
                                <div className="planName expireLabel">Expired</div>
                            }
                            <div className="clear"></div>
                            <div className="d-flex align-items-center">
                                <div className='productlogoPannel'>
                                    <img src={`${productDetails?.product_logo}`} alt="product-thumbnail" className="product_thumbnail" />
                                </div>
                                <div className="product_title ms-2">{productDetails?.product_name}</div>
                            </div>
                            <div className="product_desc my-2">
                                <h3>Description</h3>
                                <p>{productDetails?.product_description}</p>
                            </div>
                            <div className="planFeature viewPlanDetails" onClick={() => { setShowPopover(!showPopover) }}>
                                <span>View Product Feature List</span>
                                <span className="viewIcon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-up-right" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8.636 3.5a.5.5 0 0 0-.5-.5H1.5A1.5 1.5 0 0 0 0 4.5v10A1.5 1.5 0 0 0 1.5 16h10a1.5 1.5 0 0 0 1.5-1.5V7.864a.5.5 0 0 0-1 0V14.5a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h6.636a.5.5 0 0 0 .5-.5z" />
                                        <path fill-rule="evenodd" d="M16 .5a.5.5 0 0 0-.5-.5h-5a.5.5 0 0 0 0 1h3.793L6.146 9.146a.5.5 0 1 0 .708.708L15 1.707V5.5a.5.5 0 0 0 1 0v-5z" />
                                    </svg>
                                </span>
                                {showPopover &&
                                    <Popover id="popover-basic" className="featuresPop">
                                        <Popover.Header as="h3">
                                            <span>Product Features</span>
                                            <span onClick={() => (setShowPopover(false))}>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                                                    <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                                </svg>
                                            </span>
                                        </Popover.Header>
                                        <Popover.Body>
                                            <ul className="featuresListinpop withoutMarker">
                                                {productDetails && productDetails.plan_features.length > 0 && productDetails.plan_features.map(
                                                    list =>
                                                        <li>No. of {list[0]} - {list[1]}</li>
                                                )
                                                }
                                            </ul>
                                        </Popover.Body>
                                    </Popover>
                                }
                            </div>
                            <ul class="cardPlan-footer bg-transparent mt-4 mb-3 px-0">
                                <li className="withIcon">
                                    <div className="cardCalendar">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="15.712" height="17.458" viewBox="0 0 15.712 17.458">
                                            <path id="Path_21285" data-name="Path 21285" d="M16.966,2.746h-.873V1H14.347V2.746H7.364V1H5.619V2.746H4.746A1.745,1.745,0,0,0,3,4.492v12.22a1.745,1.745,0,0,0,1.746,1.746h12.22a1.751,1.751,0,0,0,1.746-1.746V4.492A1.751,1.751,0,0,0,16.966,2.746Zm0,13.966H4.746V7.983h12.22Zm0-10.475H4.746V4.492h12.22ZM6.492,9.729h4.364v4.364H6.492Z" transform="translate(-3 -1)" fill="#9c9c9c" />
                                        </svg>
                                    </div>
                                    <div className="withIconLabels">
                                        <span>Start Date</span>
                                        <span>{productDetails?.plan_started_on}</span>
                                    </div>
                                </li>
                                <li>
                                    <span>Expiry Date</span>
                                    <span>{productDetails?.plan_expire_on}</span>
                                </li>
                            </ul>
                        </div>
                        {productDetails?.status === "Active" &&
                            <div class="d-flex align-items-center detailsCardWrap justify-content-center px-4 mb-4">
                                <div className={`cardLinkWrapper ${(productDetails?.is_change_plan && productDetails?.is_renewal) && "justify-content-center"}`}>
                                    {/* {productDetails?.is_change_plan && <a className="cardLink" activeClassName="active" onClick={() => viewRenewPlans("change_plan", productDetails?.product_id, productDetails)}>Upgrade Plan</a>} */}
                                    {productDetails?.is_renewal && <a className="cardLink" activeClassName="active" onClick={() => viewRenewPlans("renewal_plan", productDetails?.product_id, productDetails)}>Renew Plan</a>}
                                </div>
                                <Button className="primaryBtn fullWidthBtn MidiumFullbtn px-4 mt-4" activeClassName="active" onClick={() => handleOpenApp(productDetails?.product_access_url)}>Launch</Button>
                            </div>
                        }
                    </div>
                </div>

                <div className='col-lg-8 col-md-12'>
                    <div className='card p_card'>
                        <div className='card-header p_card_header py-3'>
                            <div className='user_detail'>User Details</div>
                            <Search
                                className='searchinput'
                                searchOpen={searchOpen}
                                animateSearch={animateSearch}
                                onSearch={value => {
                                    setSearch(value);
                                    setCurrentPage(1);
                                }}
                            />
                        </div>
                        <div className='card-body px-0 p_body_scrollable my-2'>
                            <div className='list-group px-2'>
                                {allUsersFilter && allUsersFilter?.length > 0 && allUsersFilter?.map((val, index) =>
                                    // {allMemebers?._list?.map((val, index) =>
                                    <>
                                        <div className='list-group-item ' key={index}>

                                            <div className='d-flex justify-content-between align-items-end'>

                                                <div className='d-flex align-items-center gap-2'>
                                                    {
                                                        !val.userProfile === "" ?
                                                            <span className="userIcon">
                                                                <img src={val.userProfile} alt="users" className="Profile_picture" />
                                                            </span>
                                                            :
                                                            // <img src={user1} alt="users" className="Profile_picture" />
                                                            <span className="userIcon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                                                                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                                                                </svg>
                                                            </span>
                                                    }

                                                    <div className='user_details'>
                                                        <div className='user_name'>{val.first_name} {val.last_name}</div>
                                                        <div className='user_email'>{val.role}</div>
                                                        {/* <div className='telNo'><a href="tel:+91 87654 56432">+91 87654 56432</a></div> */}
                                                        <div className='user_email email'>{val.email}</div>
                                                    </div>
                                                </div>
                                                {val.role === "USER" &&
                                                    <div className='action_btns px-2'>
                                                        <button className='btn p-0' onClick={() => handleUpdateUser(val, productId, true, "View")}>{eye} </button>
                                                        <button className='btn p-0' onClick={() => handleUpdateUser(val, productId, false, "Edit")}>{edit} </button>
                                                        {/* <button className='btn p-0' >{del} </button> */}
                                                    </div>
                                                }
                                            </div>
                                        </div>
                                        {index < allMemebers.length - 1 && <hr className='my-1 userdetail_seperator' key={index} />}
                                    </>
                                )}
                            </div>
                            <div className='my-3 pe-3 paginationBlock'>
                                <ThemeProvider theme={theme}>
                                    {/* <Pagination
                                        count={Math.ceil(allMemebers?._list?.length / rowsPerPage)}
                                        onChange={handleChange}
                                        page={page}
                                        shape="rounded"
                                        variant="outlined"
                                    /> */}
                                    <Pagination
                                        count={Math.ceil(totalItems / ITEMS_PER_PAGE)}
                                        onChange={(page, i) => setCurrentPage(i)}
                                        shape="rounded"
                                        variant="outlined"
                                        style={{ float: 'right' }}
                                    />
                                </ThemeProvider>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <ManualPayment
                show={showManualPaymentModal}
                handleClose={handleManualPaymentClose}
                handleLoadMain={handleLoadMain}
                planDetailsErr={planDetailsErr}
            />
            <div className={""}>
                <Modal
                    show={Usershow}
                    size="md"
                    aria-labelledby=""
                    centered
                    className="subscriptionModal CreateUser"
                    onHide={UserhandleClose}
                >
                    <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">
                            {from} User
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        {from === "Edit" ?
                            <CreateUser
                                edituser={edituser}
                                edittype={edittype}
                                editproductId={editproductId}
                                userEdit={userEdit}
                                UserhandleClose={UserhandleClose}
                                type={"Edit"}
                            />
                            :
                            <CreateUser
                                edituser={edituser}
                                edittype={edittype}
                                editproductId={editproductId}
                                userEdit={userEdit}
                                UserhandleClose={UserhandleClose}
                                type={"View"}
                            />
                        }
                    </Modal.Body>
                </Modal>
            </div>
        </div>
    )
}

export default Productdetails