import React, { useState, useEffect } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { getSubProducts } from "../../../endpoints/subscription/users";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import nodata from '../../../assets/images/nodata.svg';

const UserSubPlan = (props) => {
    const history = useHistory();

    const [allSubProduct, setAllSubProduct] = useState(null);
    const [productLogo, setProductLogo] = useState(nodata);
    const [proDetails, setProDetails] = useState({
        logo: "",
        name: ""
    });


    useEffect(() => {
        if (props.location.state) {
            getProductSubPro(props.location.state._product_id);
            setProductLogo(props.location.state.product_logo ? props.location.state.product_logo : nodata);
            setProDetails({
                logo: props.location.state.product_logo,
                name: props.location.state.product_name
            })

        }
    }, []);
    console.log(proDetails)
    const getProductSubPro = async (_product_key) => {

        let response = await getSubProducts(_product_key);
        if (response.status === 200) {
            setAllSubProduct(response.data);
        }

    }

    const viewPlans = (subscribed, _product_id, productname) => {

        if (subscribed) {
            // history.push({
            //     pathname: "/EditSubscribedUser",
            //     state: {
            //         _product_id
            //     }
            // });
        } else {
            history.push({
                pathname: "/plandetails",
                state: {
                    _product_id,
                    type: props.location.state.type,
                    product_logo: props.location.state.product_logo,
                    product_name: productname
                }
            });
        }

    }

    const handleBack = () => {
        history.goBack();
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <button className="btn btn_light" onClick={() => handleBack()}>{backBtnIcon}</button>
                        <div className='h3'>{proDetails.name} - Sub Products</div>
                    </div>
                </div>
            </div>

            <div className="customTabContainer">
                <div>
                    <div className='card-body px-0 pb-0'>
                        {/* <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                            <div className='heading_approval'>Available Subscription Products</div>
                        </div> */}
                        <div class="row mt-3">
                            {allSubProduct && allSubProduct.length > 0 && allSubProduct.map(
                                product => !product.subscribed &&
                                    <div class="col-md-6 col-lg-4">
                                        <div class="card op_card" style={{ height: "350px" }}>
                                            <div className="card-body">
                                                <div className="d-flex justify-content-between align-items-center">
                                                    <div className="d-flex align-items-center">
                                                        <div className='productlogoPannel'>
                                                            {/* <img src={productLogo} alt="product-thumbnail" className="product_thumbnail" /> */}
                                                            <img src={proDetails.logo} alt="product-thumbnail" className="product_thumbnail" />
                                                        </div>
                                                        <div className="product_title ms-2">{product.productname}</div>
                                                    </div>
                                                </div>
                                                <div className="product_desc my-4">
                                                    {/* <p>Descrption</p> */}
                                                    <p>{product.productdescription}</p>
                                                </div>
                                            </div>
                                            <div class="bg-transparent mx-3 px-0 py-0">
                                                <div class="d-flex align-items-center gap-2 my-1 justify-content-center">
                                                    <Button className="primaryBtn px-4 my-3" activeClassName="active" onClick={() => viewPlans(product.subscribed, product.productid, product.productname)}>Purchase Plan</Button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            )
                            }
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UserSubPlan;