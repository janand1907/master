import React, { useState, useEffect } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { getUserSubscriptions, userViewBoards, manualSubscriptionRequest } from "../../../endpoints/subscription/users";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import nodata from '../../../assets/images/nodata.svg';
import icon1 from '../../../assets/images/dashboard/5.png'
import icon2 from '../../../assets/images/dashboard/3.png'
import icon3 from '../../../assets/images/dashboard/4.png'
import ManualPayment from "../Modal/ManualPayment";

const UserProductList = (props) => {
    const history = useHistory();
    const [showPopover, setShowPopover] = useState(false);
    const [showPopoverId, setShowPopoverId] = useState(0);

    const [allProducts, setAllProducts] = useState(null);
    const [viewBoard, setViewBoard] = useState(null);

    const [showManualPaymentModal, setShowManualPaymentModal] = useState(false);
    const handleManualPaymentClose = () => setShowManualPaymentModal(false);

    const [planDetailsErr, setPlanDetailsErr] = useState({
        duration: null,
        userslot: null,
        server: null,
        durationId: null,
        userslotId: null,
    });

    useEffect(() => {
        getUserViewBoard();
        getSubscriptions();
    }, []);

    const getSubscriptions = async () => {
        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        let response = await getUserSubscriptions(timeZone);
        if (response.status === 200) {
            setAllProducts(response.data);
        }

    }

    const getUserViewBoard = async () => {

        let response = await userViewBoards();
        if (response.status === 200) {
            setViewBoard(response.data);
        }

    }

    const viewPlans = (is_sub_product, type, _product_id, product_logo, product_name) => {

        if (is_sub_product) {
            history.push({
                pathname: "/subproduct",
                state: {
                    _product_id,
                    type,
                    product_logo,
                    product_name
                }
            });
        } else {
            history.push({
                pathname: "/plandetails",
                state: {
                    _product_id,
                    type,
                    product_logo,
                    product_name
                }
            });
        }

    }

    const viewRenewPlans = (type, _product_id, plan) => {

        // if(plan.customize_plan){

        //     handleSubmitRequest(type, plan);

        // }else{
        //     history.push({
        //         pathname: "/payment",
        //         state: {
        //             _product_id,
        //             plan,
        //             type,
        //             product_logo: plan.product_logo
        //         }
        //     });
        // }
        history.push({
            pathname: "/payment",
            state: {
                _product_id,
                plan,
                type,
                product_logo: plan.product_logo,
                product_name: plan.product_name
            }
        });

    }

    const handleSubmitRequest = async (requestType, plan) => {
        setPlanDetailsErr({ ...planDetailsErr, server: null });
        var payload = {
            plan_id: plan.plan_id,
            duration: plan.plan_duration,
            user_slot: 0,
            request_type: requestType
        }

        let response = await manualSubscriptionRequest(payload);
        if (response.status === 200) {
            setShowManualPaymentModal(true);
        } else {
            if (response.Error.response.data !== "") {
                setPlanDetailsErr({ ...planDetailsErr, server: response.Error.response.data.errors[0].message })
            } else {
                setPlanDetailsErr({ ...planDetailsErr, server: "Error in request" })
            }
            setShowManualPaymentModal(true);
        }
    }

    const viewProductDetails = (product) => {

        history.push({
            pathname: "/productview",
            state: {
                product
            }
        });

    }

    const handleBack = () => {
        history.goBack();
    }

    const handleLoadMain = () => {
        handleManualPaymentClose(false);
        //history.push("/dashboard-user");
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        {/* <button className="btn btn_light" onClick={() => handleBack()}>{backBtnIcon}</button> */}
                        <div className='h3'>Product List</div>
                    </div>
                </div>
            </div>
            <section className="usersStatuswrap">
                {viewBoard &&
                    <ul className="statusLists DashboardStatus">
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon1} alt="" />
                                    </div>
                                    <div className="Counttitle">
                                        <h1 className="usersCount">{viewBoard?.total_products ? viewBoard?.total_products : 0}</h1>
                                        <div className="userLabel">Products</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon2} alt="" />
                                    </div>
                                    <div className="Counttitle">
                                        <h1 className="usersCount">{viewBoard?.used_license ? viewBoard?.used_license : 0}</h1>
                                        <div className="userLabel">Active Users</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon3} alt="" />
                                    </div>
                                    <div className="Counttitle">
                                        <h1 className="usersCount">{viewBoard?.unused_license ? viewBoard?.unused_license : 0}</h1>
                                        <div className="userLabel">Inactive Users</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>}
            </section>
            <div className="customTabContainer">
                <div className='transBg' >
                    <div className='card-body px-0 pb-0'>
                        <div className='d-flex align-items-center justify-content-between'>
                            <div className='heading_approval dashBoardHead'>
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                    </svg>
                                </span>
                                <span>List of Subscription Products</span>
                            </div>
                        </div>
                        <div class="row ProductList">
                            {allProducts && allProducts.subscribed_products.length > 0 && allProducts.subscribed_products.map(
                                (product, index) =>
                                    <div class="col-md-6 col-lg-4 mb-3">
                                        <div class="card op_card">
                                            <div className={`card-body ${product.status === "InActive" ? "borderInActive" : ""}`}>
                                                <div className="planNameWrapper">
                                                    {product.status === "InActive" &&
                                                        <div className="planInActive">{product.status}</div>
                                                    }
                                                    <div className="planName"><span>Plan Type:</span> {product.plan_name}</div>
                                                </div>
                                                <div className="clear"></div>
                                                <div className="d-flex align-items-center my-3">
                                                    <div className='productlogoPannel'>
                                                        <img src={product.product_logo ? product.product_logo : nodata} alt="product-thumbnail" className="product_thumbnail" />
                                                    </div>
                                                    <div className="product_title ms-2">
                                                        {/* {product.product_name} */}
                                                        {product.is_sub_product ? product.main_name + " - " + product.product_name : product.product_name}
                                                    </div>
                                                </div>
                                                <div className="product_desc my-4">
                                                    <h3>Description</h3>
                                                    <p>{product.product_description}</p>
                                                </div>
                                                <ul class="cardPlan-footer bg-transparent mx-3 px-0 py-0">
                                                    <li>
                                                        <span>Subscription On</span>
                                                        <span>{product.plan_started_on}</span>
                                                    </li>
                                                    <li>
                                                        <span>Subscription End</span>
                                                        <span>{product.plan_expire_on}</span>
                                                    </li>
                                                </ul>
                                                {/* <div class="d-flex align-items-center licenseDetails my-1 mb-3"> */}
                                                <div className={`d-flex align-items-center licenseDetails my-1 ${product.is_renewal ? "justify-content-between" : "justify-content-center"} px-3`}>
                                                    <Button className="primaryBtn px-4" activeClassName="active" onClick={() => viewProductDetails(product)}>View Details</Button>
                                                    {product.is_renewal && <Button className="secondaryBtn  px-4" activeClassName="active" onClick={() => viewRenewPlans("renewal_plan", product.product_id, product)}>Renew Plan</Button>}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            )
                            }
                        </div>
                    </div>
                </div>
            </div>
            {allProducts && allProducts.available_products.length > 0 &&
                <div className="customTabContainer">
                    <div className='trabsbg'>
                        <div className='card-body px-0 pb-0'>
                            <div className='d-flex align-items-center justify-content-between'>
                                <div className='heading_approval dashBoardHead'>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                        </svg>
                                    </span>
                                    <span>Available Subscription Products</span>
                                </div>
                            </div>
                            <div class="row">
                                {allProducts.available_products.map(
                                    product =>
                                        <div class="col-md-6 col-lg-4">
                                            <div class="card op_card" style={{ height: "350px" }}>
                                                <div className="card-body">
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="d-flex align-items-center">
                                                            <div className='productlogoPannel'>
                                                                <img src={product.product_logo ? product.product_logo : nodata} alt="product-thumbnail" className="product_thumbnail" />
                                                            </div>
                                                            <div className="product_title ms-2">{product.product_name}</div>
                                                        </div>
                                                    </div>
                                                    <div className="product_desc my-4">
                                                        {/* <p>Descrption</p> */}
                                                        <p>{product.product_description}</p>
                                                    </div>
                                                </div>
                                                <div class="bg-transparent mx-3 px-0 py-0">
                                                    <div class="d-flex align-items-center gap-2 my-1 justify-content-center">
                                                        <Button className="primaryBtn px-4 my-3" activeClassName="active" onClick={() => viewPlans(product.is_subProduct, "new_plan", product.product_key, product.product_logo, product.product_name)}>Purchase Plan</Button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                )
                                }
                            </div>
                        </div>
                    </div>
                </div>}
            <ManualPayment
                show={showManualPaymentModal}
                handleClose={handleManualPaymentClose}
                handleLoadMain={handleLoadMain}
                planDetailsErr={planDetailsErr}
            />
        </div>
    )
}

export default UserProductList;