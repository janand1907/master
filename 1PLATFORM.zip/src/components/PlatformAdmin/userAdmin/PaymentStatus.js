import React, { useState, useEffect } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { getUserPaymentStatus } from "../../../endpoints/subscription/payment";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import nodata from '../../../assets/images/nodata.svg';
import moment from 'moment';

const PaymentStatus = (props) => {
    const history = useHistory();
    const [paymentStatus, setPaymentStatus] = useState(null);
    const [validation, setValidation] = useState(null);
    useEffect(() => {
        var _session_id = window.location.search.split('=')[1];
        getPaymentStatus(_session_id);
    }, []);

    const getPaymentStatus = async (_session_id) => {

        let response = await getUserPaymentStatus(_session_id);
        if (response.status === 200) {
            setPaymentStatus(response.data);
        } else {
            setValidation("There was a problem processing your request.");
        }

    }

    const handleLoadMain = () => {
        history.push("/dashboard-user");
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Plan Subscription {paymentStatus && " - " + paymentStatus.request_type}</div>
                    </div>
                </div>
            </div>
            {paymentStatus && paymentStatus.payment_status === "Failed" ?
                <div className="customTabContainer">
                    <div className='card op_card'>
                        <div className='card-body px-0 pb-0'>
                            <div class="mt-4 statusWrapper">
                                <div className="statusInner">
                                    {paymentStatus.payment_status === "Failed" ?
                                        <span className="statusIcon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="83.419" height="83.419" viewBox="0 0 83.419 83.419">
                                                <path id="error_black_24dp" d="M43.709,2A41.709,41.709,0,1,0,85.419,43.709,41.725,41.725,0,0,0,43.709,2ZM47.88,64.564H39.539V56.222H47.88Zm0-16.684H39.539V22.855H47.88Z" transform="translate(-2 -2)" fill="red" />
                                            </svg>
                                        </span>
                                        :
                                        <span className="statusIcon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" transform="translate(-2 -2)" fill="green" />
                                            </svg>
                                        </span>
                                    }
                                    <h1>{paymentStatus.Payment_failed_reason}</h1>
                                    <p>Don’t worry your money is safe! If money was debited from your account, it will be refunded automatically in 5-7 working days.</p>
                                </div>
                                {/* <h3>{paymentStatus.payment_status}</h3> */}
                                <ul className="statusListsList">
                                    <li>
                                        <span className="statusLabel">Payment ID:</span>
                                        <span>{paymentStatus.payment_id}</span>
                                    </li>
                                    <li>
                                        <span className="statusLabel">Time:</span>
                                        <span>{moment(new Date()).format('MMM Do, YYYY h:mm a')}</span>
                                    </li>
                                </ul>
                                {/* <p>Product Name: {paymentStatus.product_name}</p>
                                <p>Plan Name: {paymentStatus.plan_name}</p>
                                <p>Start Date: {paymentStatus.plan_starts_on}</p>
                                <p>End Date: {paymentStatus.plan_expired_on}</p>
                                <p>Recived Amount: {paymentStatus.received_amount}</p>
                                <p>Status: {paymentStatus.status}</p> */}
                            </div>
                            <div className="btnWrapper autoBtnWidth my-3">
                                <Button className="primaryBtn" onClick={() => handleLoadMain()}>Go to Subscription</Button>
                            </div>
                        </div>
                    </div>
                </div>
                : paymentStatus && paymentStatus.payment_status === "approved" &&
                <div className="customTabContainer">
                    <div className='card op_card'>
                        <div className='card-body px-0 pb-0'>
                            <div class="mt-4 statusWrapper">
                                <div className="statusInner">
                                    <span className="statusIcon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                                        </svg>
                                    </span>
                                    <h1 className="success">Payment Successful</h1>
                                    <p>You will receive a confirmation email shortly</p>
                                </div>
                                {/* <h3>{paymentStatus.payment_status}</h3> */}
                                <ul className="statusListsList">
                                    <li>
                                        <span className="statusLabel">Product Name:</span>
                                        <span>{paymentStatus.product_name}</span>
                                    </li>
                                    <li>
                                        <span className="statusLabel">Plan Name:</span>
                                        <span>{paymentStatus.plan_name}</span>
                                    </li>
                                    <li>
                                        <span className="statusLabel">Payment ID:</span>
                                        <span>{paymentStatus.payment_id}</span>
                                    </li>
                                    <li>
                                        <span className="statusLabel">Paid To:</span>
                                        <span>1TX Technologies</span>
                                    </li>
                                    <li>
                                        <span className="statusLabel">Amount:</span>
                                        <span>${parseFloat(paymentStatus.received_amount).toLocaleString("en-US")}</span>
                                    </li>

                                    <li>
                                        <span className="statusLabel">Paid On:</span>
                                        <span>{moment(new Date()).format('MMM Do, YYYY h:mm a')}</span>
                                    </li>
                                </ul>
                                {/* <p>Product Name: {paymentStatus.product_name}</p>
                                <p>Plan Name: {paymentStatus.plan_name}</p>
                                <p>Start Date: {paymentStatus.plan_starts_on}</p>
                                <p>End Date: {paymentStatus.plan_expired_on}</p>
                                <p>Recived Amount: {paymentStatus.received_amount}</p>
                                <p>Status: {paymentStatus.status}</p> */}
                                <p className="text-center">We've sent the receipt to {paymentStatus.receiver_email}</p>
                            </div>
                            <div className="btnWrapper autoBtnWidth my-3">
                                <Button className="primaryBtn" onClick={() => handleLoadMain()}>Go to Subscription</Button>
                            </div>
                        </div>
                    </div>
                </div>
            }
            {validation &&
                <div className="customTabContainer">
                    <div className='card op_card'>
                        <div className='card-body px-0 pb-0'>
                            <div class="mt-4 statusWrapper">
                                <div className="statusInner">
                                    <span className="statusIcon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="83.419" height="83.419" viewBox="0 0 83.419 83.419">
                                            <path id="error_black_24dp" d="M43.709,2A41.709,41.709,0,1,0,85.419,43.709,41.725,41.725,0,0,0,43.709,2ZM47.88,64.564H39.539V56.222H47.88Zm0-16.684H39.539V22.855H47.88Z" transform="translate(-2 -2)" fill="red" />
                                        </svg>
                                    </span>
                                    <h1>{validation}</h1>
                                    <p>Don’t worry your money is safe! If money was debited from your account, it will be refunded automatically in 5-7 working days.</p>
                                </div>
                            </div>
                            <div className="btnWrapper autoBtnWidth my-3">
                                <Button className="primaryBtn" onClick={() => handleLoadMain()}>Go to Subscription</Button>
                            </div>
                        </div>
                    </div>
                </div>
            }
        </div>
    )
}

export default PaymentStatus;