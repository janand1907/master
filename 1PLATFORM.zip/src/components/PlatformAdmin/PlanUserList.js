import React, { useState, useEffect } from 'react';
import './platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { getAllActiveUsers } from "../../endpoints/subscription/plan";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../Icons/icons';
import { TablePagination, Pagination } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';

const PlanUserList = (props) => {
    const history = useHistory();
    const [searchOpen, setSearchOpen] = useState(false);
    const animateSearch = () => {
        setSearchOpen(!searchOpen);
    }

    const [allUsers, setAllUsers] = useState(null);



    useEffect(() => {
        if (props.location.state) {
            getAllActivePlanUsers(props.location.state.productId, props.location.state.plan_id);
        }
    }, []);

    const getAllActivePlanUsers = async (_product_id, _plan_id) => {

        let response = await getAllActiveUsers(_product_id, _plan_id);
        if (response.status === 200) {
            setPage(1);
            setAllUsers(response.data);
        }

    }

    const handleBack = () => {
        history.goBack();
    }

    const viewDetails = (type, email, planId) => {
        //updateplan
        if (type === 0) {
            history.push({
                pathname: "/EditSubscribedUser",
                state: {
                    email,
                    planId,
                    planUser: true
                }
            });
        } else {
            history.push({
                pathname: "/ViewSubscribedUser",
                state: {
                    email,
                    planId,
                    planUser: true
                }
            });
        }

    }

    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const handleChangePagination = (event, value) => {
        setPage(value);
    };

    const theme = createTheme({
        palette: {
            neutral: {
                main: '#bae6f3',
                contrastText: '#0e699c',
            },
        },
    });

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <button className="btn btn_light" onClick={() => handleBack()}>{backBtnIcon}</button>
                        <div className='h3'>Plan User Details</div>
                    </div>
                </div>
            </div>
            <div className="customTabContainer">
                <div className='card op_card'>
                    <div className='card-body px-0 pb-0'>
                        <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                            <div className='heading_approval'># of Users List</div>
                            <div className="subTblFilter">
                                <div className="filterSearchWrapper">
                                    <div className={`filterSearch ${searchOpen ? "open" : ""}`}>
                                        <input type="text" />
                                        <span className="searchIcon" onClick={animateSearch}>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                                            </svg>
                                        </span>
                                        <span className="closeIcon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
                                                <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z" />
                                            </svg>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <table className="table manageuser_grid mb-0">
                            <thead>
                                <tr className='px-3 py-4'>
                                    <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Email ID <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Company Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Added Date<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th className="text-center" scope="col">Action<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                </tr>
                            </thead>
                            <tbody className='border-top-0'>
                                {allUsers && allUsers?.length > 0 && allUsers?.slice((page - 1) * rowsPerPage, page * rowsPerPage).map(
                                    user =>
                                        <tr>
                                            <td>{user.first_name} {user.last_name}</td>
                                            <td>{user.email}</td>
                                            <td>{user.company_name}</td>
                                            <td>{user.activated_on}</td>
                                            <td className="text-center">
                                                <div className={"middleAlign"}>
                                                    <span className={"actionIcons"} onClick={() => viewDetails(1, user.email, user.plan_id)}>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                                            <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z" />
                                                            <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z" />
                                                        </svg>
                                                    </span>
                                                    <span className={"actionIcons"} onClick={() => viewDetails(0, user.email, user.plan_id)}>
                                                        <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="EditIcon"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path></svg>
                                                    </span>
                                                </div>
                                            </td>
                                        </tr>
                                )}
                            </tbody>
                        </table>
                        <div className='my-3 pe-3 paginationBlock'>
                            <ThemeProvider theme={theme}>
                                <Pagination
                                    count={Math.ceil(allUsers?.length / rowsPerPage)}
                                    onChange={handleChangePagination}
                                    page={page}
                                    shape="rounded"
                                    variant="outlined"
                                />
                            </ThemeProvider>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default PlanUserList;