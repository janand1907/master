import React, { useState, useEffect } from 'react'
import './platformadmin.scss'
import { Form, Modal, Tab, Tabs, Dropdown, Popover, Button } from 'react-bootstrap'
import { Link } from "react-router-dom";
import { getAllProductFeatures, getFeaturesDetails, deleteFeature } from "../../endpoints/subscription/features";
import { getProducts, getSubProducts } from "../../endpoints/subscription/lookup";
import { useHistory } from "react-router-dom";
import { toast } from 'react-toastify';
import { TablePagination, Pagination } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import deleteIcon from '../../assets/images/delete.png'

const FeaturesLists = () => {
    const history = useHistory();
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [showPopover, setShowPopover] = useState(false);
    const [showPopoverId, setShowPopoverId] = useState(0);

    const [products, setProducts] = useState(null);
    const [productId, setProductId] = useState(0);
    const [productName, setProductName] = useState("Select Product");

    const [subProducts, setSubProducts] = useState(null);
    const [subProductName, setSubProductName] = useState("Select Sub Product");

    const [productsList, setProductsList] = useState(null);

    const [featureDetails, setFeatureDetails] = useState(null);

    const [feature_config_id, SetFeatureConfigId] = useState(0);

    const [gridAction, setGridAction] = useState(false);

    useEffect(() => {
        getProductsName();
    }, []);
    const handleGridAction = (index) => {
        setGridAction(false);
        setGridAction(prevAction => ({
            ...prevAction,
            [index]: !gridAction[index]
        }));
    }
    const getProductsName = async () => {
        let response = await getProducts("json");
        if (response.status === 200) {
            setProducts(response.data);
            if (response.data.length > 0) {
                for (var a = 0; a < response.data.length; a++) {
                    if (response.data[a].is_sub_product) {
                        getAllSubProducts(response.data[a].product_key);
                        return;
                    } else {
                        setProductName(response.data[a].product_name);
                        setProductId(response.data[a].product_key);
                        getFeaturesList(response.data[a].product_key);
                        return;
                    }
                }
            }
        }
    }

    const handleChange = (item) => {
        setProductsList(null);
        setProductName(item.product_name);
        if (item.is_sub_product) {
            getAllSubProducts(item.product_key);
        } else {
            setSubProducts(null);
            setProductId(item.product_key);
            getFeaturesList(item.product_key);
        }
    }

    const getFeaturesList = async (product_key) => {
        let response = await getAllProductFeatures(product_key);
        if (response.status === 200) {
            setPage(1);
            setProductsList(response.data);
        }
    }

    const getAllSubProducts = async (_product_key) => {

        let response = await getSubProducts(_product_key, "json");
        if (response.status === 200) {
            setSubProducts(response.data);
            for (var a = 0; a < response.data.length; a++) {
                setSubProductName(response.data[a].product_name);
                setProductId(response.data[a].product_key);
                getFeaturesList(response.data[a].product_key);
                return;
            }
        }
    }

    const handleChangeSubProduct = (item) => {

        setSubProductName(item.product_name);
        if (item.product_key) {
            setProductId(item.product_key);
            getFeaturesList(item.product_key);
        }
    }

    const handleUpdatePlan = (feature_config_id, type) => {
        //updateplan
        history.push({
            pathname: "/updatefeature/" + feature_config_id,
            state: {
                feature_config_id,
                type
            }
        });

    }

    const getFeatureConfigDetails = async (feature_config_id) => {

        let response = await getFeaturesDetails(feature_config_id);
        if (response.status === 200) {
            setFeatureDetails(response.data.feature_config);
        }
    }

    const handleDeleteFeature = async () => {

        let response = await deleteFeature(feature_config_id);
        if (response.status === 200) {
            getFeaturesList(productId);
            toast.success(response.data.message);
            setShow(false);
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);
            } else {
                toast.error(response.data.message);
            }
        }
    }

    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const handleChangePagination = (event, value) => {
        setPage(value);
    };

    const theme = createTheme({
        palette: {
            neutral: {
                main: '#bae6f3',
                contrastText: '#0e699c',
            },
        },
    });

    return (
        <>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>List of Features</div>
                    </div>
                    <div className="d-flex gap-3">
                        <Link to="./CreatePlanFeature" className="primaryBtn">+ Create Feature</Link>
                    </div>
                </div>
            </div>
            <div className='row my-3'>
                <div className='col-md-12'>
                    <div>
                        <div className='card-body px-0 pb-0'>
                            <div className='d-flex align-items-center justify-content-between px-3 gridHeader featureGridHeader'>
                                <div className='heading_approval'>Features Overview</div>
                                <div className="d-flex gap-3">
                                    <div className="dropdownWithLable">
                                        <label>Product</label>
                                        <Dropdown
                                            className={"customDropdown"}
                                        >
                                            <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                {productName}
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu className={"dropdownList"}>
                                                {products && products.map(
                                                    product =>
                                                        <Dropdown.Item eventKey={product.product_key} onClick={() => handleChange(product)} >{product.product_name}</Dropdown.Item>
                                                )
                                                }
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </div>
                                    {subProducts &&
                                        <div className="dropdownWithLable">
                                            <label>Sub Product</label>
                                            <Dropdown
                                                className={"customDropdown"}
                                            >
                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                    {subProductName}
                                                </Dropdown.Toggle>

                                                <Dropdown.Menu className={"dropdownList"}>
                                                    {subProducts && subProducts.map(
                                                        subProduct =>
                                                            <Dropdown.Item eventKey={subProduct.product_key} onClick={() => handleChangeSubProduct(subProduct)} >{subProduct.product_name}</Dropdown.Item>
                                                    )
                                                    }
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </div>}
                                </div>
                            </div>
                            <table className="table manageuser_grid mb-0">
                                <thead>
                                    <tr className='px-3 py-4'>
                                        {/* <th scope="col" className='px-3'>Feature Group<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col" className="text-center"># of Features <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col" className="text-center">Profile used plans <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Created On <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col" className='text-center'>Action</th> */}
                                        <th cope="col">Profile</th>
                                        <th cope="col" className="text-center">Feature Group</th>
                                        <th cope="col" className="text-center">Used Plans</th>
                                        <th cope="col">Created On</th>
                                        <th cope="col" className="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody className='border-top-0'>
                                    {
                                        !productsList && <tr>
                                            <td colspan="5" className="text-center">No Records Found</td>
                                        </tr>
                                    }
                                    {
                                        productsList && productsList.length === 0 && <tr>
                                            <td colspan="5" className="text-center">No Records Found</td>
                                        </tr>
                                    }
                                    {productsList && productsList?.length > 0 && productsList?.slice((page - 1) * rowsPerPage, page * rowsPerPage).map(
                                        (list, index) =>
                                            <tr>
                                                <td className='px-3'>{list.profile_name}</td>
                                                <td className="text-center">
                                                    <div className="planFeature" onClick={() => { getFeatureConfigDetails(list.feature_config_id); setShowPopover(!showPopover); setShowPopoverId(index) }}>
                                                        <span>{list.feature_count}</span>
                                                        <span>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-up-right" viewBox="0 0 16 16">
                                                                <path fill-rule="evenodd" d="M8.636 3.5a.5.5 0 0 0-.5-.5H1.5A1.5 1.5 0 0 0 0 4.5v10A1.5 1.5 0 0 0 1.5 16h10a1.5 1.5 0 0 0 1.5-1.5V7.864a.5.5 0 0 0-1 0V14.5a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h6.636a.5.5 0 0 0 .5-.5z" />
                                                                <path fill-rule="evenodd" d="M16 .5a.5.5 0 0 0-.5-.5h-5a.5.5 0 0 0 0 1h3.793L6.146 9.146a.5.5 0 1 0 .708.708L15 1.707V5.5a.5.5 0 0 0 1 0v-5z" />
                                                            </svg>
                                                        </span>
                                                        {showPopoverId === index && showPopover &&
                                                            <Popover id="popover-basic" className="featuresPop">
                                                                <Popover.Header as="h3">
                                                                    <span># of Feature Details</span>
                                                                    <span onClick={() => (setShowPopover(false))}>
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                                                                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                                                        </svg>
                                                                    </span>
                                                                </Popover.Header>
                                                                <Popover.Body>
                                                                    <ul className="featuresListinpop">
                                                                        {featureDetails && featureDetails.map(
                                                                            list =>
                                                                                <li>{list.feature_name}</li>
                                                                        )
                                                                        }
                                                                    </ul>
                                                                </Popover.Body>
                                                            </Popover>
                                                        }
                                                    </div>
                                                </td>
                                                <td className="text-center">{list.plan_usage}</td>
                                                <td>{list.created_on}</td>
                                                <td className='text-center'>
                                                    <div className="actionDropDown">
                                                        <span className="hamburIcon" onClick={() => handleGridAction(index)}>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                                <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                            </svg>
                                                        </span>
                                                        {/* {gridAction[index] && */}
                                                        <ul className="actionPopup" onClick={() => handleGridAction(index)}>
                                                            <li onClick={() => handleUpdatePlan(list.feature_config_id, true)}>
                                                                <span className={""}>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15.047" height="10.388" viewBox="0 0 15.047 10.388">
                                                                        <path id="Union_7" data-name="Union 7" d="M21347.029-5141.024a8.59,8.59,0,0,1-2.986-3.683l-.043-.1.043-.1a8.653,8.653,0,0,1,2.986-3.683,7.66,7.66,0,0,1,4.492-1.41,7.663,7.663,0,0,1,4.5,1.41,8.653,8.653,0,0,1,2.986,3.683l.043.1-.043.1a8.59,8.59,0,0,1-2.986,3.683,7.668,7.668,0,0,1-4.5,1.415A7.665,7.665,0,0,1,21347.029-5141.024Zm.965-6.449a6.862,6.862,0,0,0-2.418,2.669,6.882,6.882,0,0,0,2.418,2.665,6.386,6.386,0,0,0,3.527,1.04,6.389,6.389,0,0,0,3.531-1.04,6.725,6.725,0,0,0,2.4-2.665,6.706,6.706,0,0,0-2.4-2.669,6.433,6.433,0,0,0-3.531-1.04A6.43,6.43,0,0,0,21347.994-5147.473Zm1.367,4.83a2.959,2.959,0,0,1-.891-2.161,2.962,2.962,0,0,1,.891-2.166,2.959,2.959,0,0,1,2.16-.89,2.966,2.966,0,0,1,2.166.89,2.96,2.96,0,0,1,.889,2.166,2.957,2.957,0,0,1-.889,2.161,2.966,2.966,0,0,1-2.166.89A2.959,2.959,0,0,1,21349.361-5142.643Zm1.029-3.3a1.529,1.529,0,0,0-.461,1.136,1.526,1.526,0,0,0,.461,1.131,1.521,1.521,0,0,0,1.131.461,1.531,1.531,0,0,0,1.137-.461,1.526,1.526,0,0,0,.461-1.131,1.529,1.529,0,0,0-.461-1.136,1.531,1.531,0,0,0-1.137-.461A1.521,1.521,0,0,0,21350.391-5145.94Z" transform="translate(-21344 5149.998)" fill="#333" />
                                                                    </svg>
                                                                </span>
                                                                View</li>
                                                            {list.plan_usage === 0 &&
                                                                <>
                                                                    <li onClick={() => handleUpdatePlan(list.feature_config_id, false)}>
                                                                        <span className={""}>
                                                                            <svg id="edit_black_24dp" xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15">
                                                                                <path id="Path_14389" data-name="Path 14389" d="M0,0H17.577V17.577H0Z" fill="none" />
                                                                                <path id="Path_14390" data-name="Path 14390" d="M11.1,7.409l.674.674L5.139,14.718H4.465v-.674L11.1,7.409M13.737,3a.733.733,0,0,0-.513.212l-1.34,1.34L14.63,7.3l1.34-1.34a.729.729,0,0,0,0-1.033L14.257,3.212A.719.719,0,0,0,13.737,3ZM11.1,5.336,3,13.436v2.746H5.746l8.1-8.1L11.1,5.336Z" transform="translate(-0.803 -0.803)" />
                                                                            </svg>
                                                                        </span>Edit</li>

                                                                    <li onClick={() => { SetFeatureConfigId(list.feature_config_id); handleShow() }}>
                                                                        <svg xmlns="http://www.w3.org/2000/svg" height="15" viewBox="0 -960 960 960" width="15">
                                                                            <path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" />
                                                                        </svg>Remove</li>
                                                                </>
                                                            }
                                                        </ul>
                                                        {/* } */}

                                                    </div>
                                                    {/* <div className={"middleAlign"}>
                                                        <span className={"actionIcons"} onClick={() => handleUpdatePlan(list.feature_config_id)}>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                                                <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z" />
                                                                <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z" />
                                                            </svg>
                                                        </span>
                                                        <span className={"actionIcons"} onClick={() => handleUpdatePlan(list.feature_config_id)}>
                                                            <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="EditIcon"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path></svg>
                                                        </span>
                                                        {list.plan_usage === 0 &&
                                                            <span className={"actionIcons"} onClick={() => { SetFeatureConfigId(list.feature_config_id); handleShow() }}>
                                                                <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-1om0hkc" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="DeleteOutlineOutlinedIcon"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9zm7.5-5-1-1h-5l-1 1H5v2h14V4h-3.5z"></path></svg>
                                                            </span>
                                                        }
                                                    </div> */}
                                                </td>
                                            </tr>
                                    )}
                                </tbody>
                            </table>
                            <div className='my-3 pe-3 paginationBlock'>
                                <ThemeProvider theme={theme}>
                                    <Pagination
                                        count={Math.ceil(productsList?.length / rowsPerPage)}
                                        onChange={handleChangePagination}
                                        page={page}
                                        shape="rounded"
                                        variant="outlined"
                                    />
                                </ThemeProvider>
                            </div>
                        </div>
                        <Modal
                            show={show}
                            size="md"
                            aria-labelledby="contained-modal-title-vcenter"
                            centered
                            className="subscriptionModal"
                            onHide={handleClose}
                        >
                            <Modal.Header closeButton>
                                <Modal.Title id="contained-modal-title-vcenter">
                                    Confirm Delete
                                </Modal.Title>
                            </Modal.Header>
                            <Modal.Body>
                                <span className="deleIcon">
                                    <img src={deleteIcon} alt="" />
                                </span>
                                <p className="text-center">Are you sure, you want to delete?</p>
                            </Modal.Body>
                            <Modal.Footer>
                                <Button className="secondaryBtn" onClick={handleClose}>Cancel</Button>
                                <Button className="primaryBtn" onClick={() => handleDeleteFeature()}>OK</Button>
                            </Modal.Footer>
                        </Modal>
                    </div>
                </div>
            </div>
        </>
    )

}
export default FeaturesLists
