import React, { useState, useEffect } from 'react';
import './platformadmin.scss';
import { Form, Modal, Dropdown, Container, Row, Col, Button } from 'react-bootstrap';
import { addFeature, getAllProductFeatures, featureUpdate, getFeaturesDetails } from "../../endpoints/subscription/features";
import { getProducts, getSubProducts, getFeatures } from "../../endpoints/subscription/lookup";
import { ToastContainer, toast } from 'react-toastify';
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";

const CreatePlanFeature = (props) => {

    const history = useHistory();
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [disabled, setDisabled] = useState(false);

    const [planFeatureData, setPlanFeatureData] = useState({
        "feature_id": 0,
        "actual_feature_name": "",
        "feature_name": "",
        "min_value": 0,
        "max_value": 0,
        "price": 0
    });
    const [planFeatureErrorData, setPlanFeatureErrorData] = useState({
        "product_id": null,
        "feature_id": null,
        "feature_name": null,
        "min_value": null,
        "max_value": null,
        "price": null,
        "profile_name": null
    });

    const [gridArr, setgridArr] = useState([]);
    const [planFeatureProfileData, setPlanFeatureProfileData] = useState({
        "product_id": 0,
        "profile_name": "",
        "feature_config": []
    });
    const [editFeature, setEditFeature] = useState(null);
    const [edit, setEdit] = useState(false);
    const [type, setType] = useState('Add');
    const [products, setProducts] = useState(null);
    const [productName, setProductName] = useState("Select Product Name");

    const [subProducts, setSubProducts] = useState(null);
    const [subProductName, setSubProductName] = useState("Select Sub Product Name");

    const [features, setFeatures] = useState(null);
    const [featuresName, setFeaturesName] = useState("Select Feature Name");

    const [featureList, setFeatureList] = useState(null);

    const [serverError, setServerError] = useState(null);
    const [serverMainError, setServerMainError] = useState(null);

    useEffect(() => {

        getProductsName();

        if (props.location.state) {

            var feature_config_id = props.location.state.feature_config_id;

            var isDisable = props.location.state.type
            setDisabled(isDisable);
            getFeatureConfigDetails(feature_config_id);

        }

    }, []);

    const getFeatureConfigDetails = async (feature_config_id) => {

        let response = await getFeaturesDetails(feature_config_id);
        if (response.status === 200) {

            var data = response.data;
            //setType("Edit");
            setEdit(true);
            setEditFeature(data);
            setProductName(data.product_name);

            if (data.sub_product) {
                getAllSubProducts(data.product_key);
                getProductFeatures(data.sub_product_key);
                setSubProductName(data.sub_product_name);
            } else {
                getProductFeatures(data.product_key);
            }

            setPlanFeatureProfileData({
                ...planFeatureProfileData,
                profile_name: data.profile,
                product_id: data.product_key,
                feature_config: data.feature_config
            });
            setgridArr(data.feature_config);
        }

    }

    const getProductsName = async () => {
        let response = await getProducts("json");
        if (response.status === 200) {
            setProducts(response.data);
        }
    }

    const handleChange = (item) => {
        setSubProducts(null);
        setPlanFeatureData({
            ...planFeatureData,
            feature_id: 0,
            actual_feature_name: "",
            feature_name: "",
            min_value: 0,
            max_value: 0,
            price: 0,
        });
        setgridArr([]);
        setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: null, feature_name: null, min_value: null, max_value: null, price: null, profile_name: null });
        setSubProductName("Select Sub Product Name");
        setFeaturesName("Select Feature Name");
        setProductName(item.product_name);
        if (item.is_sub_product) {
            setPlanFeatureProfileData({ ...planFeatureProfileData, product_id: 0 })
            getAllSubProducts(item.product_key);
        } else {
            setSubProducts(null);
            getProductFeatures(item.product_key);
        }
    }

    const getAllSubProducts = async (_product_key) => {

        let response = await getSubProducts(_product_key, "json");
        if (response.status === 200) {
            setSubProducts(response.data);
        }
    }

    const handleChangeSubProduct = (item) => {

        setSubProductName(item.product_name);
        if (item.product_key) {
            setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null });
            getProductFeatures(item.product_key);
        }
    }

    const getProductFeatures = async (_product_key) => {

        //setPlanFeatureData({ ...planFeatureData, product_id: _product_key });
        setPlanFeatureProfileData({ ...planFeatureProfileData, product_id: _product_key });
        setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null });
        let response = await getFeatures(_product_key, "json");
        if (response.status === 200) {
            setFeatures(response.data);
            // getAllProductFeaturesList(_product_key);
        }
    }

    const handleChangeFeatures = (item) => {
        setFeaturesName(item.feature_name);

        if (type === "Add") {
            setPlanFeatureData({
                ...planFeatureData, actual_feature_name: item.feature_name, feature_name: item.feature_name, feature_id: item.feature_id
            });
        } else {
            setPlanFeatureData({
                ...planFeatureData, feature_name: item.feature_name, feature_id: item.feature_id
            });
        }

        setPlanFeatureErrorData({ ...planFeatureErrorData, feature_id: null, feature_name: null });
    }

    const handleFreetext = (e) => {

        let name = e.target.id;
        let value = e.target.value;

        setPlanFeatureData({ ...planFeatureData, [name]: value });
        setPlanFeatureErrorData({ ...planFeatureErrorData, [name]: null });
        if (name === "price") {
            // Validate the input using a regex pattern
            const decimalPattern = /^\d+(\.\d{0,1})?$/;
            const isValid = decimalPattern.test(value);

            // If the input is not valid, remove the last entered character
            if (!isValid) {
                setPlanFeatureData({ ...planFeatureData, [name]: value.slice(0, -1) })
            }
        }
    }

    const handleProfileFreetext = (e) => {
        let name = e.target.id;
        let value = e.target.value;

        setPlanFeatureProfileData({ ...planFeatureProfileData, [name]: value });
        setPlanFeatureErrorData({ ...planFeatureErrorData, [name]: null });
    }

    const getAllProductFeaturesList = async (_product_id) => {

        let response = await getAllProductFeatures(_product_id);

        if (response.status === 200) {
            setFeatureList(response.data);
        }

    }


    const handleAddFeatureGrid = (type) => {
        setServerError(null);
        setServerMainError(null);

        if (planFeatureProfileData) {
            var error = {
                product_id: planFeatureProfileData.product_id === 0 ? "Select Product" : null,
                feature_id: planFeatureData.feature_id === 0 ? "Select Feature" : null,
                feature_name: (planFeatureData.feature_name === "" || planFeatureData.feature_name === null) ? "Enter Custom feature name" : null,
                min_value: (planFeatureData.min_value === null || planFeatureData.min_value === " " || planFeatureData.min_value === "" || planFeatureData.min_value === 0 || planFeatureData.min_value < 0) ? "Enter min value" : null,
                max_value: (planFeatureData.max_value === null || planFeatureData.max_value === " " || planFeatureData.max_value === "" || planFeatureData.max_value === 0 || planFeatureData.max_value < 0) ? "Enter max value" : null,
                // price: (planFeatureData.price === null || planFeatureData.price === " " || planFeatureData.price === "" || planFeatureData.price === 0 || planFeatureData.price < 0) ? "Enter price value" : null
                price: (planFeatureData.price === null || planFeatureData.price === " " || planFeatureData.price === "" || planFeatureData.price === 0 || planFeatureData.price < 0) ? "Enter price value" : null
            }
            if (error.product_id || error.feature_id || error.feature_name || error.min_value || error.max_value || error.price || error.profile_name) {
                setPlanFeatureErrorData({
                    ...planFeatureErrorData,
                    product_id: error.product_id,
                    feature_id: error.feature_id,
                    feature_name: error.feature_name,
                    min_value: error.min_value,
                    max_value: error.max_value,
                    price: error.price,
                });
                return;
            }

        }

        // if (planFeatureProfileData.product_id === 0) {
        //     setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: "Select Product" });
        //     return;
        // } else if (planFeatureData.feature_id === 0) {

        //     if (features && features.length === 0) {
        //         setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: null });
        //     } else {
        //         setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: "Select Feature" });
        //     }
        //     return;
        // } else if (planFeatureData.feature_name === "" || planFeatureData.feature_name === null) {
        //     setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: null, feature_name: "Enter Custom feature name" });
        //     return;
        // } else if (planFeatureData.min_value === null || planFeatureData.min_value === " " || planFeatureData.min_value === "" || planFeatureData.min_value === 0 || planFeatureData.min_value < 0) {
        //     setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: null, feature_name: null, min_value: "Enter min value" });
        //     return;
        // } else if (planFeatureData.max_value === null || planFeatureData.max_value === " " || planFeatureData.max_value === "" || planFeatureData.max_value === 0 || planFeatureData.max_value < 0) {
        //     setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: null, feature_name: null, min_value: null, max_value: "Enter max value" });
        //     return;
        // } else if (parseInt(planFeatureData.max_value) <= parseInt(planFeatureData.min_value)) {

        //     setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: null, feature_name: null, min_value: null, max_value: "Enter valid max value" });
        //     return;
        // } else if (planFeatureData.price === null || planFeatureData.price === " " || planFeatureData.price === "" || planFeatureData.price === 0 || planFeatureData.price < 0) {
        //     setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: null, feature_name: null, min_value: null, max_value: null, price: "Enter price value" });
        //     return;
        // }

        if (parseInt(planFeatureData.max_value) <= parseInt(planFeatureData.min_value)) {
            setPlanFeatureErrorData({ ...planFeatureErrorData, max_value: "Enter valid max value" });
            return;
        }

        setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, feature_id: null, feature_name: null, min_value: null, max_value: null, price: null, profile_name: null });
        var grid = [...gridArr];
        if (type === "Add") {


            if (grid.length === 0) {
                grid.push(planFeatureData);
            } else {
                for (var a = 0; a < grid.length; a++) {
                    if (grid[a].feature_name === planFeatureData.feature_name) {
                        setServerError("Feature name already exits");
                        return;
                    }
                    if (grid[a].feature_id === planFeatureData.feature_id) {
                        setServerError("Feature already added in grid");
                        return;
                    }
                }
                grid.push(planFeatureData);
            }

            setgridArr(grid);

        } else {

            for (var b = 0; b < grid.length; b++) {

                if (grid[b].feature_id === planFeatureData.feature_id) {
                    grid[b].actual_feature_name = featuresName;
                    grid[b].feature_name = planFeatureData.feature_name;
                    grid[b].min_value = planFeatureData.min_value;
                    grid[b].max_value = planFeatureData.max_value;
                    grid[b].price = planFeatureData.price;

                }

            }

            setgridArr(grid);

        }
        setFeaturesName("Select Feature Name");
        setPlanFeatureData({
            ...planFeatureData,
            feature_id: 0,
            actual_feature_name: "",
            feature_name: "",
            min_value: 0,
            max_value: 0,
            price: 0,
        });
        handleCancelUpdate();
    }
    const [gridAction, setGridAction] = useState(false);
    const handleGridAction = (index) => {
        setGridAction(false);
        setGridAction(prevAction => ({
            ...prevAction,
            [index]: !gridAction[index]
        }));
    }
    const handleAddFeature = async (type) => {

        setServerMainError(null);
        setServerError(null);
        var grid = [...gridArr];
        if (grid.length === 0) {
            setServerMainError("Features are not added.");
            return;
        } else if (planFeatureProfileData.product_id === 0) {
            setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: "Select product" });
            return;
        } else if (planFeatureProfileData.profile_name === "" || planFeatureProfileData.profile_name === null) {
            setPlanFeatureErrorData({ ...planFeatureErrorData, profile_name: "Enter profile name" });
            return;
        }

        setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, profile_name: null });

        let payload = planFeatureProfileData;


        var array = [];
        var checkAddOn = false;
        for (var a = 0; a < gridArr.length; a++) {
            if (gridArr[a].actual_feature_name === "Add-on Users") {
                checkAddOn = true;
            }
            var grid = {
                feature_id: gridArr[a].feature_id,
                feature_name: gridArr[a].feature_name,
                min_value: gridArr[a].min_value,
                max_value: gridArr[a].max_value,
                price: gridArr[a].price,
            };
            array.push(grid);
        }

        if (!checkAddOn) {
            setServerMainError("Add-on Users Feature is required");
            return;
        }

        payload.feature_config = array;

        let response = await addFeature(payload);

        if (response.status === 200 || response.status === 201) {
            if (response.data.message) {
                toast.success(response.data.message);
                setFeaturesName("Select Feature Name");
                setPlanFeatureData({
                    ...planFeatureData,
                    feature_id: 0,
                    actual_feature_name: "",
                    feature_name: "",
                    min_value: 0,
                    max_value: 0,
                    price: 0,
                });
                setgridArr([]);
                setPlanFeatureProfileData({
                    "product_id": 0,
                    "profile_name": "",
                    "feature_config": []
                });
                history.push({
                    pathname: "/FeaturesLists"
                });
            }
        } else {

            if (response.Error.response.data !== "") {
                setServerMainError(response.Error.response.data.errors[0].message);
            } else {
                setServerMainError("Error in request");
            }
        }

    }

    const handleCancelUpdate = () => {
        setPlanFeatureData({
            ...planFeatureData,
            feature_id: 0,
            actual_feature_name: "",
            feature_name: "",
            min_value: 0,
            max_value: 0,
            price: 0,
        });
        setType('Add');
        setFeaturesName("Select Feature Name");
    }

    const handleEditFeature = async (payload) => {
        setType('Update');

        setPlanFeatureData({
            ...planFeatureData,
            feature_id: payload.feature_id,
            actual_feature_name: payload.actual_feature_name,
            feature_name: payload.feature_name,
            min_value: payload.min_value,
            max_value: payload.max_value,
            price: payload.price,
        });
        setFeaturesName(payload.actual_feature_name);
    }

    const handleDelete = (item) => {

        var grid = [...gridArr];
        grid.splice(grid.findIndex(a => a.feature_id === item.feature_id), 1)
        setgridArr(grid);
    }

    const handleDeleteFeature = async () => {
        // let response = await featureDelete(planFeatureData.product_id, planFeatureData.feature_id);
        // if (response.status === 200) {
        //     toast.success(response.data.message);
        //     setShow(false);
        //     setPlanFeatureData({ ...planFeatureData, feature_id: 0 });
        //     getProductFeatures(planFeatureData.product_id);
        // } else {
        //     if (response.Error.response.data !== "") {
        //         toast.success(response.Error.response.data.errors[0].message);
        //     } else {
        //         toast.success(response.data.message);
        //     }
        // }
    }

    const handleEditAllFeature = async () => {


        var grid = [...gridArr];
        if (grid.length === 0) {
            setServerMainError("Features are not added.");
            return;
        } else if (planFeatureProfileData.product_id === 0) {
            setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: "Select product" });
            return;
        } else if (planFeatureProfileData.profile_name === "" || planFeatureProfileData.profile_name === null) {
            setPlanFeatureErrorData({ ...planFeatureErrorData, profile_name: "Enter profile name" });
            return;
        }

        setPlanFeatureErrorData({ ...planFeatureErrorData, product_id: null, profile_name: null });

        var array = [];
        var checkAddOn = false;
        for (var a = 0; a < gridArr.length; a++) {
            if (gridArr[a].actual_feature_name === "Add-on Users") {
                checkAddOn = true;
            }
            var grid = {
                feature_id: gridArr[a].feature_id,
                feature_name: gridArr[a].feature_name,
                min_value: gridArr[a].min_value,
                max_value: gridArr[a].max_value,
                price: gridArr[a].price,
            };
            array.push(grid);
        }

        if (!checkAddOn) {
            setServerMainError("Add-on Users Feature is required");
            return;
        }

        var payload = {
            profile_name: planFeatureProfileData.profile_name,
            feature_config: array
        };

        let response = await featureUpdate(payload, props.location.state.feature_config_id);

        if (response.status === 200) {
            toast.success(response.data.message);
            history.push({
                pathname: "/FeaturesLists"
            });

        } else {
            if (response.Error.response.data !== "") {
                toast.success(response.Error.response.data.errors[0].message);
            } else {
                toast.success(response.data.message);
            }
        }

    }

    const handleBack = () => {
        history.push({
            pathname: "/FeaturesLists"
        });
    }


    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>{disabled ? "View" : !disabled && props.location.state ? "Edit" : "Create"} Feature Group</div>
                    </div>
                    {/* <div className="d-flex gap-3">
                        <Link to="/CreateSubscriptionPlan" className="primaryBtn">+ Create New Plan</Link>
                    </div> */}
                </div>
            </div>
            <div className='row my-3'>
                <div className="col-md-4">
                    <div className='card op_card'>
                        <div className='card-body px-0 py-0'>
                            <div className="cardTitle d-flex align-items-center">{type} Features</div>
                            <Container className={"px-4"}>
                                <Row>
                                    <Form className={"py-4"}>
                                        <Form.Group className={`mb-3 formGroup ${!subProducts && planFeatureErrorData.product_id ? "errorFields" : ""}`} controlId="CI-ProName">
                                            <Form.Label>Product</Form.Label>
                                            <Dropdown
                                                className={"customDropdown"}

                                            >
                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic" disabled={(type === 'Update' || edit) ? true : false}>
                                                    {productName}
                                                </Dropdown.Toggle>

                                                <Dropdown.Menu className={"dropdownList"}>
                                                    {products && products.map(
                                                        product =>
                                                            <Dropdown.Item eventKey={product.product_key} onClick={() => handleChange(product)} >{product.product_name}</Dropdown.Item>
                                                    )
                                                    }
                                                </Dropdown.Menu>
                                            </Dropdown>
                                            <Form.Text className="d-flex subErors">
                                                {!subProducts && planFeatureErrorData.product_id}
                                            </Form.Text>
                                        </Form.Group>
                                        {subProducts &&
                                            <Form.Group className={`mb-3 formGroup ${subProducts && planFeatureErrorData.product_id ? "errorFields" : ""}`} controlId="CI-SubProName" disabled={(type === 'Update' || edit) ? true : false}>
                                                <Form.Label className="withInfoIcon">
                                                    <span>Choose Sub-Product</span>
                                                    <div className="labelInfo">
                                                        <span>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                                <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                                            </svg>
                                                        </span>
                                                        <span className="infoContent">
                                                            Choose the sub-product for Cyber Predictor based on the plan.
                                                        </span>
                                                    </div>
                                                </Form.Label>
                                                <Dropdown
                                                    className={"customDropdown"}
                                                >
                                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic" disabled={(type === 'Update' || edit) ? true : false}>
                                                        {subProductName}
                                                    </Dropdown.Toggle>
                                                    <Dropdown.Menu className={"dropdownList"}>
                                                        {subProducts && subProducts.map(
                                                            subProduct =>
                                                                <Dropdown.Item eventKey={subProduct.product_key} onClick={() => handleChangeSubProduct(subProduct)} >{subProduct.product_name}</Dropdown.Item>
                                                        )
                                                        }
                                                    </Dropdown.Menu>
                                                </Dropdown>
                                                <Form.Text className="d-flex subErors">
                                                    {planFeatureErrorData.product_id ? "Select sub product" : null}
                                                </Form.Text>
                                            </Form.Group>
                                        }
                                        <Form.Group disabled={disabled} className={`mb-3 formGroup ${planFeatureErrorData.feature_id ? "errorFields" : ""}`} controlId="CI-FeaName">
                                            <Form.Label className="withInfoIcon">
                                                <span>Choose Feature</span>
                                                {/* <div className="labelInfo">
                                                    <span>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                            <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                                        </svg>
                                                    </span>
                                                    <span className="infoContent">
                                                        Choose the feature plan name to based on the plan.
                                                    </span>
                                                </div> */}
                                            </Form.Label>
                                            <Dropdown
                                                className={"customDropdown"}
                                            //onSelect={(eventKey) => handleSelect(eventKey, 'dropdown2')}
                                            >
                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic" disabled={disabled || type === 'Update' ? true : false}>
                                                    {/* {features < 1 ? "All Features Added" : featuresName} */}
                                                    {featuresName}
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu className={"dropdownList"}>
                                                    {features && features.length > 0 ?
                                                        <>
                                                            {features.map(
                                                                feature =>
                                                                    <Dropdown.Item eventKey={feature.feature_id} onClick={() => handleChangeFeatures(feature)} >{feature.feature_name}</Dropdown.Item>
                                                            )
                                                            }
                                                        </>
                                                        :
                                                        <Dropdown.Item>{"All Features Added"}</Dropdown.Item>
                                                    }
                                                </Dropdown.Menu>
                                            </Dropdown>
                                            <Form.Text className="d-flex subErors">
                                                {planFeatureErrorData.feature_id}
                                            </Form.Text>
                                        </Form.Group>
                                        <Form.Group className={`mb-3 formGroup ${planFeatureErrorData.feature_name ? "errorFields" : ""}`} controlId="CI-CusFeaName">
                                            <Form.Label className="withInfoIcon">
                                                <span>Customize your Feature name</span>
                                                <div className="labelInfo">
                                                    <span>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                            <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                                        </svg>
                                                    </span>
                                                    <span className="infoContent">
                                                        Choose the name of feature as for your wish.
                                                    </span>
                                                </div>
                                            </Form.Label>
                                            <Form.Control disabled={disabled} type="text" value={planFeatureData.feature_name} id='feature_name' onChange={(e) => handleFreetext(e)} />
                                            <Form.Text className="d-flex subErors">
                                                {planFeatureErrorData.feature_name}
                                            </Form.Text>
                                        </Form.Group>
                                        <Row>
                                            <Col>
                                                <Form.Group className={`mb-3 formGroup ${planFeatureErrorData.min_value ? "errorFields" : ""}`} controlId="CI-MinVal">
                                                    <Form.Label className="withInfoIcon">
                                                        <span>Min Value</span>
                                                        <div className="labelInfo">
                                                            <span>
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                                    <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                                                </svg>
                                                            </span>
                                                            <span className="infoContent">
                                                                Enter the min value of user or other based on the feature choose.
                                                            </span>
                                                        </div>
                                                    </Form.Label>
                                                    <Form.Control disabled={disabled} type="number" value={planFeatureData.min_value > 0 && planFeatureData.min_value} placeholder="0" min="0" id='min_value' onChange={(e) => handleFreetext(e)} />
                                                    <Form.Text className="d-flex subErors">
                                                        {planFeatureErrorData.min_value}
                                                    </Form.Text>
                                                </Form.Group>
                                            </Col>
                                            <Col>
                                                <Form.Group className={`mb-3 formGroup ${planFeatureErrorData.max_value ? "errorFields" : ""}`} controlId="CI-Maxval">
                                                    <Form.Label className="withInfoIcon">
                                                        <span>Max Value</span>
                                                        <div className="labelInfo">
                                                            <span>
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                                    <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                                                </svg>
                                                            </span>
                                                            <span className="infoContent">
                                                                Enter the max value of user or other based on the feature choose
                                                            </span>
                                                        </div>
                                                    </Form.Label>
                                                    <Form.Control disabled={disabled} type="number" value={planFeatureData.max_value > 0 && planFeatureData.max_value} placeholder="0" min="0" id='max_value' onChange={(e) => handleFreetext(e)} />
                                                    <Form.Text className="d-flex subErors">
                                                        {planFeatureErrorData.max_value}
                                                    </Form.Text>
                                                </Form.Group>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col sm={6}>
                                                <Form.Group className={`mb-3 formGroup ${planFeatureErrorData.price ? "errorFields" : ""}`} controlId="CI-Price">
                                                    <Form.Label className="withInfoIcon">
                                                        <span>Price</span>
                                                        <div className="labelInfo">
                                                            <span>
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                                    <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                                                </svg>
                                                            </span>
                                                            <span className="infoContent">
                                                                Set there unit price in the price field. Based on this value update the plan
                                                            </span>
                                                        </div>
                                                    </Form.Label>
                                                    <Form.Control disabled={disabled} type="number" value={planFeatureData.price > 0 && planFeatureData.price} placeholder="$0.00" min="0" id='price' controlId='price' onChange={(e) => handleFreetext(e)} />
                                                    <Form.Text className="d-flex subErors priceErrorStatic">
                                                        {planFeatureErrorData.price}
                                                    </Form.Text>
                                                    <Form.Text className="d-flex justify-content-end">
                                                        (Price Per Unit)
                                                    </Form.Text>

                                                </Form.Group>
                                            </Col>
                                        </Row>
                                        {!disabled &&
                                            <div className="btnWrapper autoBtnWidth mt-3 mb-2">
                                                {type === 'Update' &&
                                                    <Button className="secondaryBtn" onClick={() => handleCancelUpdate()}>Cancel</Button>
                                                }
                                                <Button className="primaryBtn" onClick={() => handleAddFeatureGrid(type)}>{type} Feature</Button>
                                                <Form.Text className="d-flex subErors addFeatureError">
                                                    {serverError}
                                                </Form.Text>
                                            </div>
                                        }
                                    </Form>
                                </Row>
                            </Container>
                        </div>
                    </div>
                </div>
                <div className='col-md-8 FeaturePage'>
                    <div className='TableHeading'>
                        <div className='heading_approval'>Detailed Feature Set</div>
                    </div>
                    <div className='FeatureTable'>
                        <table className="table manageuser_grid mb-0">
                            <thead>
                                <tr className='px-3 py-4'>
                                    {/* <th scope="col" className='px-3'>Features <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Customised Feature Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Min Value <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Max Value <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Price<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        {!disabled && <th scope="col" className='text-center'>Action</th>} */}
                                    <th scope="col" className='px-3'>Features</th>
                                    <th scope="col">Min Value</th>
                                    <th scope="col">Max Value</th>
                                    <th scope="col">Price</th>
                                    {!disabled && <th scope="col" className='text-center'>Action</th>}
                                </tr>
                            </thead>
                            <tbody className='border-top-0'>
                                {
                                    gridArr.length === 0 && <tr>
                                        <td colspan="7" className="text-center">No Records Found</td>
                                    </tr>
                                }
                                {gridArr && gridArr.length > 0 && gridArr.map(
                                    (list, index) =>
                                        <tr>
                                            {/* <td className='px-3'>{list.actual_feature_name}</td> */}
                                            <td className='px-3'>{list.feature_name}</td>
                                            <td>{list.min_value}</td>
                                            <td>{list.max_value}</td>
                                            <td>${list.price}</td>
                                            {!disabled && <td className='text-center'>
                                                {/* <div className={"middleAlign"}>
                                                        <span className={"actionIcons"} onClick={() => handleEditFeature(list)}>
                                                            
                                                            <svg id="edit_black_24dp" xmlns="http://www.w3.org/2000/svg" width="17.577" height="17.577" viewBox="0 0 17.577 17.577">
                                                                <path id="Path_14389" data-name="Path 14389" d="M0,0H17.577V17.577H0Z" fill="none" />
                                                                <path id="Path_14390" data-name="Path 14390" d="M11.1,7.409l.674.674L5.139,14.718H4.465v-.674L11.1,7.409M13.737,3a.733.733,0,0,0-.513.212l-1.34,1.34L14.63,7.3l1.34-1.34a.729.729,0,0,0,0-1.033L14.257,3.212A.719.719,0,0,0,13.737,3ZM11.1,5.336,3,13.436v2.746H5.746l8.1-8.1L11.1,5.336Z" transform="translate(-0.803 -0.803)" />
                                                            </svg>
                                                        </span>
                                                        <span className={"actionIcons"} onClick={() => { handleDelete(list) }}>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="12.376" height="13.923" viewBox="0 0 12.376 13.923">
                                                                <path id="delete_FILL0_wght400_GRAD0_opsz48" d="M9.953,19.923a1.155,1.155,0,0,1-1.16-1.16V7.74H8V6.58h3.636V6h5.105v.58h3.636V7.74h-.793V18.763a1.19,1.19,0,0,1-1.16,1.16ZM18.423,7.74H9.953V18.763h8.47ZM12,17.1h1.16V9.384H12Zm3.21,0h1.16V9.384h-1.16ZM9.953,7.74v0Z" transform="translate(-8 -6)" />
                                                            </svg>
                                                            
                                                        </span>
                                                    </div> */}
                                                <div className="actionDropDown">
                                                    <span className="hamburIcon" onClick={() => handleGridAction(index)}>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                            <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                        </svg>
                                                    </span>
                                                    {gridAction[index] &&
                                                        <ul className="actionPopup">
                                                            <li onClick={() => handleEditFeature(list)}>
                                                                <span className={""}>
                                                                    <svg id="edit_black_24dp" xmlns="http://www.w3.org/2000/svg" width="17.577" height="17.577" viewBox="0 0 17.577 17.577">
                                                                        <path id="Path_14389" data-name="Path 14389" d="M0,0H17.577V17.577H0Z" fill="none" />
                                                                        <path id="Path_14390" data-name="Path 14390" d="M11.1,7.409l.674.674L5.139,14.718H4.465v-.674L11.1,7.409M13.737,3a.733.733,0,0,0-.513.212l-1.34,1.34L14.63,7.3l1.34-1.34a.729.729,0,0,0,0-1.033L14.257,3.212A.719.719,0,0,0,13.737,3ZM11.1,5.336,3,13.436v2.746H5.746l8.1-8.1L11.1,5.336Z" transform="translate(-0.803 -0.803)" />
                                                                    </svg>
                                                                </span>
                                                                Edit
                                                            </li>
                                                            <li onClick={() => { handleDelete(list) }}>
                                                                <span className={""}>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="12.376" height="13.923" viewBox="0 0 12.376 13.923">
                                                                        <path id="delete_FILL0_wght400_GRAD0_opsz48" d="M9.953,19.923a1.155,1.155,0,0,1-1.16-1.16V7.74H8V6.58h3.636V6h5.105v.58h3.636V7.74h-.793V18.763a1.19,1.19,0,0,1-1.16,1.16ZM18.423,7.74H9.953V18.763h8.47ZM12,17.1h1.16V9.384H12Zm3.21,0h1.16V9.384h-1.16ZM9.953,7.74v0Z" transform="translate(-8 -6)" />
                                                                    </svg>
                                                                </span>
                                                                Remove
                                                            </li>
                                                        </ul>
                                                    }
                                                </div>
                                            </td>}
                                        </tr>
                                )
                                }
                            </tbody>
                        </table>

                        <Modal
                            show={show}
                            size="md"
                            aria-labelledby="contained-modal-title-vcenter"
                            centered
                            className="subscriptionModal"
                            onHide={handleClose}
                        >
                            <Modal.Header closeButton>
                                <Modal.Title id="contained-modal-title-vcenter">
                                    Confirm Delete
                                </Modal.Title>
                            </Modal.Header>
                            <Modal.Body>
                                <p className="text-center">Are you sure, you want to delete?</p>
                            </Modal.Body>
                            <Modal.Footer>
                                <Button className="secondaryBtn" onClick={handleClose}>Cancel</Button>
                                <Button className="primaryBtn" onClick={() => handleDeleteFeature()}>OK</Button>
                            </Modal.Footer>
                        </Modal>
                        <Form.Group className={`mb-3 formGroup tblinlineForm ${planFeatureErrorData.profile_name ? "errorFields" : ""}`}>
                            <Form.Label className="withInfoIcon">
                                <span>Feature's Group</span>
                            </Form.Label>
                            <div className="rightField">
                                <Form.Control disabled={disabled} type="text" placeholder="Enter Group Title" value={planFeatureProfileData.profile_name} id='profile_name' onChange={(e) => handleProfileFreetext(e)} />
                                <Form.Text className="d-flex subErors">
                                    {planFeatureErrorData.profile_name}
                                </Form.Text>
                            </div>
                        </Form.Group>
                        <Form.Group className={`mb-3 formGroup tblinlineForm ${planFeatureErrorData.profile_name ? "errorFields" : ""}`}>
                            <Form.Label className="withInfoIcon">
                                <span>&nbsp;</span>
                            </Form.Label>
                            <div className="rightField">
                                {!disabled ?
                                    <div className="btnWrap justify-content-start">
                                        {props.location.state ?
                                            <>
                                                {/* <Button className="secondaryBtn" onClick={() => handleBack()} >Back</Button> */}
                                                <Button className="primaryBtn" onClick={() => handleEditAllFeature()} >Update</Button>
                                                <Form.Text className="d-flex subErors serverError">
                                                    {serverMainError}
                                                </Form.Text>
                                            </>
                                            :
                                            <>
                                                <Button className="primaryBtn" onClick={() => handleAddFeature()} >Save</Button>
                                                <Form.Text className="d-flex subErors serverError">
                                                    {serverMainError}
                                                </Form.Text>
                                            </>
                                        }

                                    </div>
                                    :
                                    <div className="btnWrap justify-content-start">
                                        <Button className="primaryBtn" onClick={() => handleBack()} >Close</Button>
                                    </div>
                                }
                            </div>
                        </Form.Group>


                    </div>
                </div>
            </div>
        </div>
    )
}

export default CreatePlanFeature