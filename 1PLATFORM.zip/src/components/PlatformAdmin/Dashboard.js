import React, { useState, useEffect, useMemo } from 'react';
import { useSelector } from 'react-redux';
import './platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from 'react-router-dom/cjs/react-router-dom';
import { getBoardView, getAllUsers, getActionDetails, setPlanRequestAction, requestPlanDetails, setAction } from "../../endpoints/subscription/manageuser";
import { useHistory } from "react-router-dom";
import icon1 from '../../assets/images/dashboard/5.png'
import icon2 from '../../assets/images/dashboard/3.png'
import icon3 from '../../assets/images/dashboard/4.png'
import { toast } from 'react-toastify';
import { TablePagination, Pagination } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Search from '../Common/Search/Search';

const Dashboard = () => {
    const history = useHistory();
    const userDetails = useSelector(state => state.user.userInfo.allInfo);
    const [show, setShow] = useState(false);
    const [showTwo, setShowTwo] = useState(false);
    const [showThree, setShowThree] = useState(false);
    const [gridAction, setGridAction] = useState(false);
    const handleGridAction = (index) => {
        setGridAction(false);
        setGridAction(prevAction => ({
            ...prevAction,
            [index]: !gridAction[index]
        }));
    }
    const handleClose = () => {
        setShow(false);
        setRequestType(null);
        setComments(null);
        setCommentsErr(null);
        setRequestId(0);
    };
    const handleCloseTwo = () => {
        setRequestPlanDetail(null);
        setShowTwo(false);
    };
    const handleCloseThree = () => {
        setShowThree(false);
    };
    const handleShow = () => setShow(true);
    const handleShowTwo = () => setShowTwo(true);
    const handleShowThree = () => setShowThree(true);
    const [showPopover, setShowPopover] = useState(false);
    const [showPopoverId, setShowPopoverId] = useState(0);
    const [searchOpen, setSearchOpen] = useState(false);
    const animateSearch = () => {
        setSearchOpen(!searchOpen);
    }

    const [boardViewData, setBoardViewData] = useState(null);
    const [allUsers, setAllUsers] = useState(null);
    const [pendingUsers, setPendingUsers] = useState(null);
    const [rejectedUsers, setRejectedUsers] = useState(null);
    const [message, setMessage] = useState(null);
    const [requestType, setRequestType] = useState(null);
    const [request_id, setRequestId] = useState(0);
    const [comments, setComments] = useState(null);
    const [commentsErr, setCommentsErr] = useState(null);
    const [requestPlanDetail, setRequestPlanDetail] = useState(null);

    const [renewal, setRenewal] = useState(0);
    const [upgrade, setUpgrade] = useState(0);
    const [subscription, setSubscription] = useState(0);

    const [pURenewal, setPendingUsersRenewal] = useState(0);
    const [pUUpgrade, setPendingUsersUpgrade] = useState(0);
    const [pUSubscription, setPendingUsersSubscription] = useState(0);

    const [rURenewal, setRejectedUsersRenewal] = useState(0);
    const [rUUpgrade, setRejectedUsersUpgrade] = useState(0);
    const [rUSubscription, setRejectedUsersSubscription] = useState(0);

    const [activeTab, setActiveTab] = useState('pending');

    const [userData, setUserData] = useState({
        "products": 0,
        "email": null,
        "firstname": null,
        "lastname": null,
        "companyname": null,
        "status": false
    });
    useEffect(() => {
        //getAllBoardView();
        getToken();
        getSunscribedUsersList();
        getPendingUsersList();
        getRejectedUsersList();
    }, []);

    const tabChange = (tab) => {
        setFilterName('All');
        setActiveTab(tab);
        setSearch("");
        setCurrentPage(1);
        setPSearch("");
        setPCurrentPage(1);
        setRSearch("");
        setRCurrentPage(1);
    }

    const getAllBoardView = async () => {
        let response = await getBoardView("json");
        if (response.status === 200) {
            setBoardViewData(response.data);
        }
    }

    const getSunscribedUsersList = async () => {
        let response = await getAllUsers("approved_users");
        if (response.status === 200) {
            setAllUsers(response.data);
        }
    }

    const getPendingUsersList = async () => {
        let response = await getAllUsers("pending_approvals");
        if (response.status === 200) {
            setPendingUsers(response.data);
        }
    }

    const getRejectedUsersList = async () => {
        let response = await getAllUsers("rejected_users");
        if (response.status === 200) {
            setRejectedUsers(response.data);
        }
    }

    const getCommentDetails = async (request_id) => {
        let response = await getActionDetails(request_id);
        if (response.status === 200) {
            setMessage(response.data);
        }
    }

    const getCommentDetailsView = async (request_id) => {
        let response = await getActionDetails(request_id);
        if (response.status === 200) {
            return response.data;
        } else {
            return "No reason";
        }
    }

    const handleApprovePopUp = (request_id) => {
        handleShow(); setRequestType(true);
        setRequestId(request_id);
    }

    const handleRejectPopUp = (request_id) => {
        handleShow(); setRequestType(false);
        setRequestId(request_id);
    }

    const handleApproveRequest = async () => {

        if (comments === "") {
            setCommentsErr("Enter Comments");
            return;
        }
        setCommentsErr(null);

        var payload = {
            "approve": requestType,
            "comments": comments
        }

        let response = await setPlanRequestAction(payload, request_id);
        if (response.status === 200) {
            handleClose();
            //getSunscribedUsersList();
            getPendingUsersList();
            getRejectedUsersList();
            toast.success(response.data.message);
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);

            } else {
                toast.error("Error in request");
            }
        }
    }

    const handleRejectRequest = async () => {
        debugger;
        if (comments && comments === "") {
            setCommentsErr("Enter Comments");
            return;
        } else if (comments && comments.length < 10) {
            setCommentsErr("Comments length required min 10 chars");
            return;
        } else if (comments && comments.length > 255) {
            setCommentsErr("Comments length allows only 255 chars max");
            return;
        }
        setCommentsErr(null);
        var payload = {
            "approve": requestType,
            "comments": comments
        }

        let response = await setPlanRequestAction(payload, request_id);
        if (response.status === 200) {
            handleClose();
            //getSunscribedUsersList();
            getPendingUsersList();
            getRejectedUsersList();
            toast.success(response.data.message);
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);

            } else {
                toast.error("Error in request");
            }
        }
    }

    const handleFreetext = (e) => {
        let name = e.target.id;
        let value = e.target.value;
        setComments(value);
    }

    const handleRequestPlanDetails = async (request_id) => {

        let response = await requestPlanDetails(request_id);
        if (response.status === 200) {
            setRequestPlanDetail(response.data);
            handleShowTwo();
        }
    }


    const handlePopUpUser = (item) => {
        setUserData({
            ...userData,
            "products": item.products,
            "email": item.email,
            "firstname": item.firstname,
            "lastname": item.lastname,
            "companyname": item.companyname,
            "status": item.status,
        });
        handleShowThree();

    }

    const handleStaheStatus = (e) => {

        let value = e.target.checked;

        setUserData({ ...userData, status: value })
    }

    const handleUpdasteUserStatus = async () => {

        var payload = {
            "email": userData.email,
            "status": userData.status
        }

        let response = await setAction(payload);
        if (response.status === 200) {
            //getAllBoardView();
            //getSunscribedUsersList();
            setShowThree(false);
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);
            } else {
                toast.error("Error in request");
            }
        }

    }

    const handleApprovePending = (request_id, request) => {
        history.push({
            pathname: "/approve-contact",
            state: {
                request_id,
                request
            }
        });
    }

    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const handleChangePagination = (event, value) => {
        setPage(value);
    };

    const theme = createTheme({
        palette: {
            neutral: {
                main: '#bae6f3',
                contrastText: '#0e699c',
            },
        },
    });

    /*pagination with search */
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");

    const [p_totalItems, setPTotalItems] = useState(0);
    const [p_currentPage, setPCurrentPage] = useState(1);
    const [p_search, setPSearch] = useState("");

    const [r_totalItems, setRTotalItems] = useState(0);
    const [r_currentPage, setRCurrentPage] = useState(1);
    const [r_search, setRSearch] = useState("");
    const [filterName, setFilterName] = useState('All');
    const ITEMS_PER_PAGE = 10;

    const allUsersFilter = useMemo(() => {
        if (allUsers === null) {
            return allUsers;
        }
        let computedviewDomain = allUsers;

        var renew = 0;
        var upgrade = 0;
        var subscription = 0

        for (var a = 0; a < allUsers.length; a++) {

            if (allUsers[a].request_type === "Renewal Plan") {
                renew = parseInt(renew) + 1;
            }

            if (allUsers[a].request_type === "Change Plan") {
                upgrade = parseInt(upgrade) + 1;
            }

            if (allUsers[a].request_type === "New Plan") {
                subscription = parseInt(subscription) + 1;
            }
        }
        setRenewal(renew);
        setUpgrade(upgrade);
        setSubscription(subscription);

        if (filterName) {
            if (filterName === "All") {
                computedviewDomain = allUsers;
            } else {
                computedviewDomain = computedviewDomain.filter(
                    viewDomain =>
                        viewDomain.request_type.toLowerCase().includes(filterName.toLowerCase())
                );
            }
        }

        if (search) {
            computedviewDomain = computedviewDomain.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(search.toLowerCase()) ||
                    viewDomain.plan_name.toLowerCase().includes(search.toLowerCase())
            );
        }
        setTotalItems(computedviewDomain.length);

        return computedviewDomain.slice(
            (currentPage - 1) * ITEMS_PER_PAGE,
            (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [allUsers, currentPage, search, filterName]);

    const pendingUsersFilter = useMemo(() => {
        if (pendingUsers === null || pendingUsers?.length === 0) {
            setPTotalItems(0);
            return pendingUsers;
        }
        let computedviewDomain = pendingUsers;
        var renew = 0;
        var upgrade = 0;
        var subscription = 0

        for (var a = 0; a < pendingUsers.length; a++) {

            if (pendingUsers[a].request_type === "Renewal Plan") {
                renew = parseInt(renew) + 1;
            }

            if (pendingUsers[a].request_type === "Change Plan") {
                upgrade = parseInt(upgrade) + 1;
            }

            if (pendingUsers[a].request_type === "New Plan") {
                subscription = parseInt(subscription) + 1;
            }
        }
        setPendingUsersRenewal(renew);
        setPendingUsersUpgrade(upgrade);
        setPendingUsersSubscription(subscription);

        if (filterName) {
            if (filterName === "All") {
                computedviewDomain = pendingUsers;
            } else {
                computedviewDomain = computedviewDomain.filter(
                    viewDomain =>
                        viewDomain.request_type.toLowerCase().includes(filterName.toLowerCase())
                );
            }

        }

        if (p_search) {
            computedviewDomain = computedviewDomain.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(p_search.toLowerCase()) ||
                    viewDomain.plan_name.toLowerCase().includes(p_search.toLowerCase())
            );
        }

        setPTotalItems(computedviewDomain.length);

        return computedviewDomain.slice(
            (p_currentPage - 1) * ITEMS_PER_PAGE,
            (p_currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [pendingUsers, p_currentPage, p_search, filterName]);

    const rejectedUsersFilter = useMemo(() => {
        if (rejectedUsers === null || rejectedUsers?.length === 0) {
            setRTotalItems(0);
            return rejectedUsers;
        }
        let computedviewDomain = rejectedUsers;
        var renew = 0;
        var upgrade = 0;
        var subscription = 0

        for (var a = 0; a < rejectedUsers.length; a++) {

            if (rejectedUsers[a].request_type === "Renewal Plan") {
                renew = parseInt(renew) + 1;
            }

            if (rejectedUsers[a].request_type === "Change Plan") {
                upgrade = parseInt(upgrade) + 1;
            }

            if (rejectedUsers[a].request_type === "New Plan") {
                subscription = parseInt(subscription) + 1;
            }
        }
        setRejectedUsersRenewal(renew);
        setRejectedUsersUpgrade(upgrade);
        setRejectedUsersSubscription(subscription);

        if (filterName) {
            if (filterName === "All") {
                computedviewDomain = rejectedUsers;
            } else {
                computedviewDomain = computedviewDomain.filter(
                    viewDomain =>
                        viewDomain.request_type.toLowerCase().includes(filterName.toLowerCase())
                );
            }

        }

        if (r_search) {
            computedviewDomain = computedviewDomain.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(r_search.toLowerCase()) ||
                    viewDomain.plan_name.toLowerCase().includes(r_search.toLowerCase())
            );
        }
        setRTotalItems(computedviewDomain.length);

        return computedviewDomain.slice(
            (r_currentPage - 1) * ITEMS_PER_PAGE,
            (r_currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [rejectedUsers, r_currentPage, r_search, , filterName]);


    const handleChange = (filter) => {
        setFilterName(filter);
        setPCurrentPage(1);
        setCurrentPage(1);
        setRCurrentPage(1);

    }

    const [cards, setCards] = useState([
        {
            id: 1,
            url: "views/imda_New/Dashboard7",
            name: "Registered User Count"
        }
    ])

    const [token, setToken] = useState(null);

    const options = {
        height: 100,
        width: 100,
        hideTabs: false,
        // added interval support - an integer can be passed as milliseconds in the options object and refreshDataAsync() will refresh the data automatically on your preferred interval.
        // All other vizCreate options are supported here, too
        // They are listed here: https://help.tableau.com/current/api/js_api/en-us/JavaScriptAPI/js_api_ref.htm#vizcreateoptions_record
    };

    const getToken = () => {
        return fetch(`https://dtlehta1thuw9.cloudfront.net/oipbaseportalstaging/api/tableau/getToken`,
            {
                method: 'GET',
                headers: {
                    'Authorization': "eyJhbGciOiJIUzUxMiJ9.eyJlbWFpbCI6InZhcmFkaGFyYWpwcmFrYXNoLnZwKzUyNkBnbWFpbC5jb20iLCJpZCI6OSwiYXV0aG9yaXR5IjoiMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsNTg1MDAsMjEiLCJpYXQiOjE3MDk3MzEyNzEsImV4cCI6MTcwOTczODQ3MX0.vQYXHWMR30b576FTChvSYER-cSLRHXU4bkSm0rX8P32-QLs6rsmQmLNbDbuy7y-ap9JNobahAQ6zKPx_C0F3iA"
                }
            })
            .then(async response => {
                const data = await response.json();
                setToken(data.trust_key);

            },
                (error) => {
                    setToken(null);
                }
            );
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Welcome back, {userDetails.firstname} {userDetails.lastname}</div>
                    </div>
                </div>
            </div>
            <section className="usersStatuswrap">
                {activeTab === "pending" ?
                    <ul className="statusLists">
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon1} alt="" />
                                    </div>
                                    <h1 className="usersCount">{String(pUSubscription ? pUSubscription : 0).padStart(2, '0')}</h1>
                                </div>
                                <div className="userLabel">New Plan</div>
                            </div>
                        </li>
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon2} alt="" />
                                    </div>
                                    <h1 className="usersCount">{String(pURenewal ? pURenewal : 0).padStart(2, '0')}</h1>
                                </div>
                                <div className="userLabel">Renewals</div>
                            </div>
                        </li>
                        <li>
                            <div className="cardWrap">
                                <div className="countWthcircle">
                                    <div className="circle">
                                        <img src={icon3} alt="" />
                                    </div>
                                    <h1 className="usersCount">{String(pUUpgrade ? pUUpgrade : 0).padStart(2, '0')}</h1>
                                </div>
                                <div className="userLabel">Upgrades</div>
                            </div>
                        </li>
                    </ul>
                    : activeTab === "approved" ?
                        <ul className="statusLists">
                            <li>
                                <div className="cardWrap">
                                    <div className="countWthcircle">
                                        <div className="circle">
                                            <img src={icon1} alt="" />
                                        </div>
                                        <h1 className="usersCount">{String(subscription ? subscription : 0).padStart(2, '0')}</h1>
                                    </div>
                                    <div className="userLabel">New Plan</div>
                                </div>
                            </li>
                            <li>
                                <div className="cardWrap">
                                    <div className="countWthcircle">
                                        <div className="circle">
                                            <img src={icon2} alt="" />
                                        </div>
                                        <h1 className="usersCount">{String(renewal ? renewal : 0).padStart(2, '0')}</h1>
                                    </div>
                                    <div className="userLabel">Renewals</div>
                                </div>
                            </li>
                            <li>
                                <div className="cardWrap">
                                    <div className="countWthcircle">
                                        <div className="circle">
                                            <img src={icon3} alt="" />
                                        </div>
                                        <h1 className="usersCount">{String(upgrade ? upgrade : 0).padStart(2, '0')}</h1>
                                    </div>
                                    <div className="userLabel">Upgrades</div>
                                </div>
                            </li>
                        </ul>
                        : activeTab === "rejected" &&
                        <ul className="statusLists">
                            <li>
                                <div className="cardWrap">
                                    <div className="countWthcircle">
                                        <div className="circle">
                                            <img src={icon1} alt="" />
                                        </div>
                                        <h1 className="usersCount">{String(rUSubscription ? rUSubscription : 0).padStart(2, '0')}</h1>
                                    </div>
                                    <div className="userLabel">New Plan</div>
                                </div>
                            </li>
                            <li>
                                <div className="cardWrap">
                                    <div className="countWthcircle">
                                        <div className="circle">
                                            <img src={icon2} alt="" />
                                        </div>
                                        <h1 className="usersCount">{String(rURenewal ? rURenewal : 0).padStart(2, '0')}</h1>
                                    </div>
                                    <div className="userLabel">Renewals</div>
                                </div>
                            </li>
                            <li>
                                <div className="cardWrap">
                                    <div className="countWthcircle">
                                        <div className="circle">
                                            <img src={icon3} alt="" />
                                        </div>
                                        <h1 className="usersCount">{String(rUUpgrade ? rUUpgrade : 0).padStart(2, '0')}</h1>
                                    </div>
                                    <div className="userLabel">Upgrades</div>
                                </div>
                            </li>
                        </ul>
                }
            </section>
            <div className="customTabContainer">
                <Tab.Container id="left-tabs-example" defaultActiveKey="pending" unmountOnExit={true}>
                    <Nav>
                        <Nav.Item><Nav.Link eventKey="pending" onClick={() => tabChange('pending')}>Awaiting Approvals <span className="count">{String(pendingUsers && pendingUsers.length ? pendingUsers.length : 0).padStart(2, '0')}</span></Nav.Link></Nav.Item>
                        <Nav.Item><Nav.Link eventKey="approved" onClick={() => tabChange('approved')}>Approved <span className="count">{String(allUsers && allUsers.length ? allUsers.length : 0).padStart(2, '0')}</span></Nav.Link></Nav.Item>
                        <Nav.Item><Nav.Link eventKey="rejected" onClick={() => tabChange('rejected')}>Declined Requests <span className="count">{String(rejectedUsers && rejectedUsers.length ? rejectedUsers.length : 0).padStart(2, '0')}</span></Nav.Link></Nav.Item>
                    </Nav>
                    <Tab.Content>
                        <Tab.Pane eventKey="approved">
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-end mb-3 mx-3'>
                                        <Search
                                            className='searchinput'
                                            searchOpen={searchOpen}
                                            animateSearch={animateSearch}
                                            placeholder={"Search by"}
                                            onSearch={value => {
                                                setSearch(value);
                                                setCurrentPage(1);
                                            }}
                                        />
                                        <div className="dropdownWithLable">
                                            <label>Request Type</label>
                                            <Dropdown
                                                className={"customDropdown"}
                                            >
                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                    {filterName}
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu className={"dropdownList"}>
                                                    <Dropdown.Item eventKey={"All"} onClick={() => handleChange("All")}>All</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"New Plan"} onClick={() => handleChange("New Plan")}>New</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"Change Plan"} onClick={() => handleChange("Change Plan")}>Upgrade</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"Renewal Plan"} onClick={() => handleChange("Renewal Plan")}>Renewal</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </div>
                                    </div>
                                    <table className="table manageuser_grid mb-0">
                                        <thead>
                                            <tr className='px-3 py-4'>
                                                <th scope="col">Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Email <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Product <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Category<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Plan Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Request Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Requested On <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col" className='text-center'>Approved On</th>
                                            </tr>
                                        </thead>
                                        <tbody className='border-top-0'>
                                            {allUsersFilter && allUsersFilter?.length > 0 && allUsersFilter.map((user, index) => {
                                                return (
                                                    <tr>
                                                        <td>{user.first_name} {user.last_name}</td>
                                                        <td>{user.email}</td>
                                                        <td>{user.product_name} {user.sub_product !== '-' && "- " + user.sub_product}</td>
                                                        <td>{user.customize_plan ? "Contact Us" : "General"}</td>
                                                        {/* <td className='text-theme-medium' onClick={() => handleApprovePending(user.request_id, user)}>{user.plan_name}</td> */}
                                                        <td>{user.plan_name}</td>
                                                        <td>{user.request_type}</td>
                                                        <td>{user.requested_on}</td>
                                                        <td>{user.action_on}</td>
                                                    </tr>
                                                )
                                            }
                                            )}
                                        </tbody>
                                    </table>
                                    <div className='my-3 pe-3 paginationBlock'>
                                        <ThemeProvider theme={theme}>
                                            <Pagination
                                                count={Math.ceil(totalItems / ITEMS_PER_PAGE)}
                                                onChange={(page, i) => setCurrentPage(i)}
                                                shape="rounded"
                                                variant="outlined"
                                                style={{ float: 'right' }}
                                            />
                                        </ThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </Tab.Pane>
                        <Tab.Pane eventKey="pending">
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-end mb-3 mx-3'>
                                        <Search
                                            className='searchinput me-4'
                                            searchOpen={searchOpen}
                                            animateSearch={animateSearch}
                                            placeholder={"Search by"}
                                            onSearch={value => {
                                                setPSearch(value);
                                                setPCurrentPage(1);
                                            }}
                                        />
                                        <div className="dropdownWithLable">
                                            <label>Request Type</label>
                                            <Dropdown
                                                className={"customDropdown"}
                                            >
                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                    {filterName}
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu className={"dropdownList"}>
                                                    <Dropdown.Item eventKey={"All"} onClick={() => handleChange("All")}>All</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"New Plan"} onClick={() => handleChange("New Plan")}>New</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"Change Plan"} onClick={() => handleChange("Change Plan")}>Upgrade</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"Renewal Plan"} onClick={() => handleChange("Renewal Plan")}>Renewal</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </div>
                                    </div>
                                    <table className="table manageuser_grid mb-0">
                                        <thead>
                                            <tr className='px-3 py-4'>
                                                <th scope="col">Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Email <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Product <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Category<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Plan Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Request Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Requested On <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col" className='text-center'>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody className='border-top-0'>
                                            {pendingUsersFilter && pendingUsersFilter?.length > 0 && pendingUsersFilter.map(
                                                (user, index) =>
                                                    <tr>
                                                        <td>{user.first_name} {user.last_name}</td>
                                                        <td>{user.email}</td>
                                                        <td>{user.product_name} {user.sub_product !== '-' && "- " + user.sub_product}</td>
                                                        <td>{user.customize_plan ? "Contact Us" : "General"}</td>
                                                        <td className='text-theme-medium' onClick={() => handleApprovePending(user.request_id, user)}>{user.plan_name}</td>
                                                        <td>{user.request_type}</td>
                                                        <td>{user.requested_on}</td>
                                                        <td className='text-center'>
                                                            <div className="actionDropDown">
                                                                <span className="hamburIcon" onClick={() => handleGridAction(index)}>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                                    </svg>
                                                                </span>
                                                                {/* {gridAction[index] && */}
                                                                <ul className="actionPopup pendingDroppop" onClick={() => handleGridAction(index)}>
                                                                    <li onClick={() => handleApprovePending(user.request_id, user)}>
                                                                        View & Approve
                                                                    </li>
                                                                    <li onClick={() => handleRejectPopUp(user.request_id)}>
                                                                        Reject
                                                                    </li>
                                                                </ul>
                                                                {/* } */}
                                                            </div>
                                                        </td>
                                                    </tr>
                                            )}
                                        </tbody>
                                    </table>
                                    <div className='my-3 pe-3 paginationBlock'>
                                        <ThemeProvider theme={theme}>
                                            <Pagination
                                                count={Math.ceil(p_totalItems / ITEMS_PER_PAGE)}
                                                onChange={(page, i) => setPCurrentPage(i)}
                                                shape="rounded"
                                                variant="outlined"
                                                style={{ float: 'right' }}
                                            />
                                        </ThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </Tab.Pane>
                        <Tab.Pane eventKey="rejected" >
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-end mb-3 mx-3'>
                                        <Search
                                            className='searchinput'
                                            searchOpen={searchOpen}
                                            animateSearch={animateSearch}
                                            placeholder={"Search by "}
                                            onSearch={value => {
                                                setRSearch(value);
                                                setRCurrentPage(1);
                                            }}
                                        />
                                        <div className="dropdownWithLable">
                                            <label>Request Type</label>
                                            <Dropdown
                                                className={"customDropdown"}
                                            >
                                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                    {filterName}
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu className={"dropdownList"}>
                                                    <Dropdown.Item eventKey={"All"} onClick={() => handleChange("All")}>All</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"New Plan"} onClick={() => handleChange("New Plan")}>New</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"Change Plan"} onClick={() => handleChange("Change Plan")}>Upgrade</Dropdown.Item>
                                                    <Dropdown.Item eventKey={"Renewal Plan"} onClick={() => handleChange("Renewal Plan")}>Renewal</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </div>
                                    </div>
                                    <table className="table manageuser_grid mb-0">
                                        <thead>
                                            <tr className='px-3 py-4'>
                                                <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Email <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Product <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Request Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Rejected Message</th>
                                            </tr>
                                        </thead>
                                        <tbody className='border-top-0'>
                                            {rejectedUsersFilter && rejectedUsersFilter?.length > 0 && rejectedUsersFilter?.map(
                                                (user, index) =>
                                                    <tr>
                                                        <td>{user.first_name} {user.last_name}</td>
                                                        <td>{user.email}</td>
                                                        <td>{user.product_name} {user.sub_product !== '-' && "- " + user.sub_product}</td>
                                                        <td>{user.request_type}</td>
                                                        <td >
                                                            <div className="planFeature"
                                                                onMouseLeave={() => (setShowPopover(false))}
                                                                onMouseOver={() => { setShowPopover(!showPopover); setShowPopoverId(index) }}
                                                            >
                                                                <span>{"View"}</span>
                                                                {showPopoverId === index && showPopover &&
                                                                    <Popover id="popover-basic" className="featuresPop declinePop" onClick={() => (setShowPopover(false))}>
                                                                        <Popover.Body>
                                                                            <div className="featuresListinpop">
                                                                                <span>{user.reject_reason}</span>
                                                                            </div>
                                                                        </Popover.Body>
                                                                    </Popover>
                                                                }
                                                            </div>
                                                        </td>
                                                    </tr>
                                            )}
                                        </tbody>
                                    </table>
                                    <div className='my-3 pe-3 paginationBlock'>
                                        <ThemeProvider theme={theme}>
                                            <Pagination
                                                count={Math.ceil(r_totalItems / ITEMS_PER_PAGE)}
                                                onChange={(page, i) => setRCurrentPage(i)}
                                                shape="rounded"
                                                variant="outlined"
                                                style={{ float: 'right' }}
                                            />
                                        </ThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </Tab.Pane>
                    </Tab.Content>
                </Tab.Container>
            </div>
            {/* <div>
                <h1>table AU</h1>
                <tableau-viz 
                    id='tableau-viz' 
                    src='https://prod-useast-b.online.tableau.com/t/1tx/views/imda_New/Dashboard8' 
                    width='800' 
                    height='540' 
                    hide-tabs 
                    toolbar='bottom' 
                    token=""
                >
                </tableau-viz>                                                
            </div> */}

            <Modal
                show={show}
                size="md"
                aria-labelledby=""
                centered
                className="subscriptionModal CreateUser"
                onHide={handleClose}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        {requestType ? "Confirm Request" : "Decline Reason"}
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {requestType &&
                        // <p className="text-center">Are you sure, you want to {requestType ? "approve" : "reject"}</p>
                        <p className="text-center">Are you sure, you want to approve</p>
                    }
                    <Form.Group className="my-3" controlId="exampleForm.ControlInput1">
                        <div className="declineInner">
                            <Form.Label className="startLabel">
                                <span>Comment</span>
                            </Form.Label>
                            <Form.Control as="textarea" rows={2} value={comments} id='comments' onChange={(e) => handleFreetext(e)} />
                            <Form.Text className="d-flex subErors">
                                {commentsErr}
                            </Form.Text>
                        </div>
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                    <Button className="secondaryBtn" onClick={handleClose}>Cancel</Button>
                    {requestType ?
                        <Button className="primaryBtn" onClick={() => handleApproveRequest()}>Approve</Button>
                        :
                        <Button className="primaryBtn" onClick={() => handleRejectRequest()}>Reject</Button>
                    }
                </Modal.Footer>
            </Modal>
            <Modal
                show={showTwo}
                size="md"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className="subscriptionModal"
                onHide={handleCloseTwo}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Plan Details
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {requestPlanDetail &&
                        <>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Plan Name: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{requestPlanDetail.plan_name}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span># of Users: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{requestPlanDetail.user_slot}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Duration: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{requestPlanDetail.plan_duration}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Plan Discount: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{requestPlanDetail.plan_discount}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Total Price: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>$ {requestPlanDetail.total_price}</span>
                                </Form.Label>
                            </Form.Group>
                        </>
                    }
                </Modal.Body>
                <Modal.Footer>
                    <Button className="primaryBtn" onClick={handleCloseTwo}>Ok</Button>
                </Modal.Footer>
            </Modal>
            <Modal
                show={showThree}
                size="md"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className="subscriptionModal"
                onHide={handleCloseThree}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        User Details
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {userData &&
                        <>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>First Name </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{userData.firstname}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Last name </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{userData.lastname}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Email ID </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{userData.email}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Status </span>
                                </Form.Label>
                                <Form.Check
                                    type="switch"
                                    id="status"
                                    checked={userData.status}
                                    onClick={(e) => handleStaheStatus(e)}
                                />
                            </Form.Group>
                        </>
                    }
                </Modal.Body>
                <Modal.Footer>
                    <Button className="secondaryBtn" onClick={handleCloseThree}>Cancel</Button>
                    <Button className="primaryBtn" onClick={() => handleUpdasteUserStatus()}>Update</Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default Dashboard;