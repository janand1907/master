import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { getUserSubscriptions, getAdminEmailDetails } from "../../../endpoints/subscription/users";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import nodata from '../../../assets/images/nodata.svg';

const Dashboard = (props) => {
    const history = useHistory();
    const userDetails = useSelector(state => state.user.userInfo.allInfo);
    const [showPopover, setShowPopover] = useState(false);
    const [showPopoverId, setShowPopoverId] = useState(0);
    const [adminEmail, setAdminEmail] = useState(null);

    const [allProducts, setAllProducts] = useState(null);

    useEffect(() => {
        getAdminEmail();
        getSubscriptions();
    }, []);

    const getSubscriptions = async () => {
        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        let response = await getUserSubscriptions(timeZone);
        if (response.status === 200) {
            setAllProducts(response.data);
        }

    }

    const getAdminEmail = async () => {

        let response = await getAdminEmailDetails();
        if (response.status === 200) {
            setAdminEmail(response.data.contact);
        }

    }

    const viewRenewPlans = (type, _product_id) => {
        // history.push({
        //     pathname: "/plandetails",
        //     state: {
        //         _product_id,
        //         type
        //     }
        // });
    }

    const handleOpenApp = (url) => {
        window.open(`https://dtlehta1thuw9.cloudfront.net/1platformsubsv2${url}`, "_self");
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Welcome back, {userDetails?.firstname} {userDetails?.lastname}.</div>
                    </div>
                </div>
            </div>
            {allProducts?.subscribed_products?.length === 0 &&
                <div className='mt-3'>
                    {/* <div className='heading_approval dashBoardHead'>
                    <span>Subscription Product Details</span>
                </div> */}
                    <div className='NoSubscribed'>
                        <p>You do not have any subscribed products. Please contact your admin <a href={`mailto:${adminEmail}`}>{adminEmail}</a></p>
                    </div>
                </div>
            }
            {allProducts && allProducts.subscribed_products?.length > 0 &&
                <div className="customTabContainer">
                    <div>
                        <div className='card-body px-0 pb-0'>
                            <div className='d-flex align-items-center justify-content-between'>
                                <div className='heading_approval'>List of Subscription Products</div>
                            </div>
                            <div class="row mt-3">
                                {allProducts.subscribed_products.map(
                                    (product, index) =>
                                        <div class="col-md-6 col-lg-4 mb-3">
                                            <div class={`card op_card`}>
                                                {/* <div className="card-body">
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="d-flex align-items-center">
                                                            <div className='productlogoPannel'>
                                                                <img src={product.product_logo ? product.product_logo : nodata} alt="product-thumbnail" className="product_thumbnail" />
                                                            </div>
                                                            <div className="product_title ms-2">{product.product_name}</div>
                                                        </div>
                                                    </div>
                                                    <div className="product_desc my-4">
                                                        <h3>Descrption</h3>
                                                        <p>{product.product_description}</p>
                                                    </div>
                                                    {product.status === "InActive" &&
                                                        <div class="d-flex align-items-center gap-2 my-1 justify-content-center">
                                                            <Button className="primaryBtn px-4 my-3" activeClassName="active" onClick={() => viewRenewPlans(product.product_id)}>Open</Button>
                                                        </div>
                                                    }
                                                </div> */}
                                                <div className={`card-body ${product.status === "InActive" ? "borderInActive" : ""}`}>
                                                    {/* <div className="planName">Plan Type: {product.plan_name}</div> */}
                                                    {product.status === "InActive" &&
                                                        <div className="planInActive">Status: {product.status}</div>
                                                    }
                                                    <div className="clear"></div>
                                                    <div className="d-flex align-items-center my-3">
                                                        <div className='productlogoPannel'>
                                                            <img src={product.product_logo ? product.product_logo : nodata} alt="product-thumbnail" className="product_thumbnail" />
                                                        </div>
                                                        <div className="product_title ms-2">
                                                            {/* {product.product_name} */}
                                                            {product.is_sub_product ? product.main_name + " - " + product.product_name : product.product_name}
                                                        </div>
                                                    </div>
                                                    <div className="product_desc my-4">
                                                        <h3>Description</h3>
                                                        <p title={product.product_description}>{product.product_description}</p>
                                                    </div>
                                                    {/* <ul class="cardPlan-footer bg-transparent mx-3 px-0 py-0">
                                                        <li>
                                                            <span>Subscription On</span>
                                                            <span>{product.plan_started_on}</span>
                                                        </li>
                                                        <li>
                                                            <span>Subscription End</span>
                                                            <span>{product.plan_expire_on}</span>
                                                        </li>
                                                    </ul> */}
                                                    {product.status === "Active" &&
                                                        <div class="d-flex align-items-center gap-2 my-1 justify-content-center">
                                                            {/* <Button className="primaryBtn px-4 my-3" activeClassName="active" onClick={() => handleOpenApp(product.product_access_url)}>Open the App</Button> */}
                                                            <Button className="primaryBtn px-4 my-3" activeClassName="active" onClick={() => handleOpenApp(product.product_access_url)}>Launch</Button>
                                                        </div>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                )
                                }
                            </div>
                        </div>
                    </div>
                </div>
            }
        </div>
    )
}

export default Dashboard;