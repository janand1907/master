import React, { useState, useEffect } from 'react'
import '../platformadmin.scss'
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button } from 'react-bootstrap'
import { Link } from "react-router-dom";

const BasicDetails = ({ edit, productName, products, planData, subProducts, subProductName,
    handleChange, handleChangeSubProduct, handleFreetext, handleCheckNext, planDataError, disabled,
    planDiscounts, handleTermFreetext, ...props }) => {

    return (
        <div className="box-wrapper">
            <Form className={"inlineForm"}>
                {/* <Form.Group className="mb-3">
                    <Form.Label>
                        Mode of Plan
                    </Form.Label>
                    <Form.Check
                        className="displayContent"
                        type={"checkbox"} id="customize_option"
                        value={planData.customize_option}
                        onChange={(e) => handleFreetext(e)}
                        checked={planData.customize_option}
                        label={"Enterprise Plan which customer will contact OnePlatform"}
                        disabled={disabled}
                    />
                </Form.Group> */}
                <div className="detailsOrderChange">
                    <div className="productNameorder">
                        <Form.Group className={`mb-3 formGroup ${!subProducts && planDataError.product_id ? "errorFields" : ""}`}>
                            <Form.Label>Product</Form.Label>
                            <Dropdown
                                className={"customDropdown"}
                            >
                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic" disabled={edit ? true : false}>
                                    {productName}
                                </Dropdown.Toggle>

                                <Dropdown.Menu className={"dropdownList"}>
                                    {products && products.map(
                                        product =>
                                            <Dropdown.Item eventKey={product.product_key} onClick={() => handleChange(product)} >{product.product_name}</Dropdown.Item>
                                    )
                                    }
                                </Dropdown.Menu>
                                {!subProducts &&
                                    <span className="d-flex subErors">
                                        {planDataError.product_id}
                                    </span>
                                }
                            </Dropdown>
                        </Form.Group>
                        {subProducts &&
                            <Form.Group className={`mb-3 formGroup ${planDataError.product_id ? "errorFields" : ""}`}>
                                <Form.Label>Select Sub Product</Form.Label>
                                <Dropdown
                                    className={"customDropdown"}
                                >
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        {subProductName}
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        {subProducts && subProducts.map(
                                            subProduct =>
                                                <Dropdown.Item eventKey={subProduct.product_key} onClick={() => handleChangeSubProduct(subProduct)} >{subProduct.product_name}</Dropdown.Item>
                                        )
                                        }
                                    </Dropdown.Menu>
                                    <span className="d-flex subErors">
                                        {planDataError.product_id && "Select sub product"}
                                    </span>
                                </Dropdown>
                            </Form.Group>
                        }
                    </div>
                    <div className="modeOrder">
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>
                                {/* Mode of Plan */}
                                Package Category
                            </Form.Label>
                            {/* <span className="modeName">Normal</span>
                    <Form.Check
                        type="switch"
                        id="customize_option"
                        className="modeSwitch"
                        value={planData.customize_option}
                        onChange={(e) => handleFreetext(e)}
                        checked={planData.customize_option}
                        disabled={disabled}
                    /> <span className="modeName">Contact us</span> */}

                            <div class={`can-toggle demo-rebrand-2 ${disabled && "toggleDisable"}`}>
                                <input
                                    type="checkbox"
                                    id="customize_option"
                                    className={`modeSwitch`}
                                    value={planData.customize_option}
                                    // onChange={(e) => handleFreetext(e)}
                                    checked={planData.customize_option}
                                    disabled={disabled}
                                />
                                <label for="customize_option">
                                    <div class="can-toggle__switch" data-checked="Contact us" data-unchecked="Normal"></div>
                                </label>
                            </div>
                            {/* <Form.Check
                        className="displayContent"
                        type={"checkbox"}
                        label={"Normal"}
                        value={planData.normal_option}
                        checked={planData.customize_option ? "" : "checked"}
                        onChange={planData.customize_option ? "" : "checked"}
                    disabled={disabled}
                    name="planMode"
                    />
                    <Form.Check
                        className="displayContent"
                        type={"checkbox"} id="customize_option"
                        value={planData.customize_option}
                        onChange={(e) => handleFreetext(e)}
                        checked={planData.customize_option}
                        label={"Contact Us"}
                        disabled={disabled}
                        name="planMode"

                    /> */}
                            {/* <Form.Text className="d-flex subErors">
                        {planDataError.customize_option}
                    </Form.Text> */}
                        </Form.Group>
                    </div>
                </div>
                {/* <Form.Group className="mb-3">
                    <Form.Label>
                        Mode of Plan
                    </Form.Label>
                    <Form.Check
                        className="displayContent"
                        type={"checkbox"} id="customize_option"
                        value={planData.customize_option}
                        onChange={(e) => handleFreetext(e)}
                        checked={planData.customize_option}
                        label={"Enterprise Plan which customer will contact One Platform"}
                        disabled={disabled}
                    />
                </Form.Group> */}
                <Form.Group className={`mb-3 formGroup ${planDataError.plan_name ? "errorFields" : ""}`}>
                    <Form.Label>
                        <span>Package Name</span>
                    </Form.Label>
                    <div className="rightField">
                        <Form.Control type="text" value={planData.plan_name} placeholder={"Enter Plan Name"} id='plan_name' onChange={(e) => handleFreetext(e)} disabled={disabled} />
                        <Form.Text className="d-flex subErors">
                            {planDataError.plan_name}
                        </Form.Text>
                    </div>
                </Form.Group>
                <Form.Group className={`mb-3 formGroup ${planDataError.plan_description ? "errorFields" : ""}`}>
                    <Form.Label>
                        <span>Plan Info</span>
                    </Form.Label>
                    <div className="rightField">
                        <Form.Control type="text"
                            value={planData.plan_description}
                            placeholder={"Enter Plan Info"}
                            id='plan_description'
                            onChange={(e) => handleFreetext(e)}
                            disabled={disabled}
                        />
                        <Form.Text className="d-flex subErors">
                            {planDataError.plan_description}
                        </Form.Text>
                    </div>
                </Form.Group>
                {/* <Form.Group className={`mb-3 formGroup ${planDataError.plan_description ? "errorFields" : ""}`}>
                    <Form.Label className="startLabel">
                        <span>Plan Description</span>
                    </Form.Label>
                    <div className="rightField">
                        <Form.Control as="textarea"
                            rows={5}
                            value={planData.plan_description}
                            placeholder={"Enter Plan Subscription"}
                            id='plan_description'
                            maxLength={350}
                            onChange={(e) => handleFreetext(e)}
                            disabled={disabled}
                        />
                        <Form.Text className="d-flex subErors">
                            {planDataError.plan_description}
                        </Form.Text>
                    </div>
                </Form.Group> */}
                <Form.Group className={`mb-3 formGroup ${planDataError.order_number ? "errorFields" : ""}`}>
                    <Form.Label>
                        {/* <span>Plan Display no</span> */}
                        <span>Package Display Code</span>
                    </Form.Label>
                    <div className="rightField viewNumber">
                        <Form.Control type="number" value={planData.order_number} id='order_number' onChange={(e) => handleFreetext(e)} disabled={disabled} />
                        <div className="hintWrapper">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                            </svg>
                            <span className="hintText">Display order number for customer portal.</span>
                        </div>
                        <Form.Text className="d-flex subErors">
                            {planDataError.order_number}
                        </Form.Text>
                    </div>
                </Form.Group>
                {/* {(edit || disabled) &&
                    <Form.Group className="mb-3 toggleWithText" controlId="exampleForm.ControlInput1">
                        <Form.Label>
                            <span>Status</span>
                        </Form.Label>
                        <label class="toggle">
                            <input
                                type={"checkbox"}
                                id="published"
                                value={planDiscounts.published}
                                onChange={(e) => handleTermFreetext(e)}
                                checked={planDiscounts.published}
                                disabled={disabled}
                            />
                            <span class={`slider ${disabled && "disableSmToggle"}`}></span>
                            <span class="labels" data-on="Active" data-off="Inactive"></span>
                        </label>
                        <Form.Text className="d-flex subErors">
                            {planDataError.published}
                        </Form.Text>
                    </Form.Group>
                } */}
                <Form.Group className="mb-3 basicBtnWrap">
                    <Form.Label>
                        <span>&nbsp;</span>
                    </Form.Label>
                    <Link to="/SubscriptionLists" className="secondaryBtn">Back</Link>
                    <Button className="primaryBtn" onClick={() => handleCheckNext("config", "next")}>
                        {/* {edit ? "Update" : "Next"} */}
                        Next
                    </Button>
                </Form.Group>
            </Form>
        </div>
    )
}
export default BasicDetails