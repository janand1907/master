import React, { useState, useEffect } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from "react-router-dom";

const PlanfeatureConfig = ({ show, edit, addOn, handleClose, handleShow, planData, features, handleChangeFeatures,
    featureValue, handleCheckNext, handleFreetextGrid, gridArray, handleAddfeature, featureDetail, handleChangeProfile,
    featuresProfile, featuresProfileName, planDataError, handleDelete, handleEditFeature, popData, handleDeletePop, handleAddPopGrid,
    user_slot, handleClosePopGrid, disabled, handleUpdateGridValue, handleFreetext, customFeatures, handleUpdateCusGridValue,
    handleSavePlan, handleTermFreetext, planDiscounts, serverMainError, ...props }) => {

    return (
        <div>
            <div className='row'>
                <div className='col-md-12'>
                    <div className='card op_card'>
                        <div className='card-body'>
                            {!planData.customize_option && <Form className="col-md-12 featureDropdown">
                                <Form.Group className={`mb-3 my-auto formGroup inlineFormFeature ${planDataError.profile_id ? "errorFields" : ""}`}>
                                    <Form.Label className="withInfoIcon me-3">
                                        {/* <span>Select Feature Group</span> */}
                                        <span>Select Feature Category</span>
                                    </Form.Label>
                                    <div className="withInfoIcon">
                                        <Dropdown
                                            className={"customDropdown groupDropdown"}
                                        >
                                            <Dropdown.Toggle className={"form-control"} id="dropdown-basic" disabled={edit ? true : false}>
                                                {featuresProfileName}
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu className={"dropdownList"}>
                                                {featuresProfile && featuresProfile.length > 0 && featuresProfile.map(
                                                    profile =>
                                                        <Dropdown.Item eventKey={profile.profile_id} onClick={() => handleChangeProfile(profile)} >{profile.profile}</Dropdown.Item>
                                                )
                                                }
                                            </Dropdown.Menu>
                                        </Dropdown>
                                        <div className="labelInfo">
                                            <span>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                                    <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                                </svg>
                                            </span>
                                            <span className="infoContent">
                                                Select the created feature group to create plan.
                                            </span>
                                        </div>
                                        <Form.Text className="d-flex subErors">
                                            {planDataError.profile_id}
                                        </Form.Text>
                                    </div>

                                </Form.Group>
                            </Form>}
                            {planData.customize_option ?
                                // <table className="table planCreationTable manageuser_grid customisePlanTable mb-0">
                                //     <thead>
                                //         <tr className='px-3 py-4'>
                                //             <th scope="col" className='px-3'>Feature Name<span className='mx-2' style={{ fontSize: '13px' }}></span></th>
                                //             <th scope="col">Feature Description <span className='mx-2' style={{ fontSize: '13px' }}></span></th>
                                //         </tr>
                                //     </thead>
                                //     <tbody className='border-top-0'>
                                //         {customFeatures.length <= 0 ?
                                //             <tr>
                                //                 <td className="text-center" colspan="5">No Records Found</td>
                                //             </tr>
                                //             :
                                //             customFeatures.map(
                                //                 (data, index) =>
                                //                     <tr>
                                //                         <td className='px-3'>{data.feature_name}</td>
                                //                         <td>
                                //                             <Form.Group className={`formGroup ${planDataError.feature_value && data.short_description === "" ? "errorFields" : ""}`}>
                                //                                 <Form.Control className='valueInputDesc' type="text" value={data.short_description} id='short_description' onChange={(e) => handleUpdateCusGridValue(e, index, data)} disabled={disabled} />
                                //                                 <Form.Text className="d-flex subErors">
                                //                                     {planDataError.feature_value && data.short_description === ""}
                                //                                 </Form.Text>
                                //                             </Form.Group>
                                //                         </td>
                                //                     </tr>
                                //             )
                                //         }
                                //     </tbody>
                                // </table>

                                <div className={"customFeatureList"}>
                                    <h3 className="title">Choose a Feature</h3>
                                    <ul>
                                        {customFeatures.map((data, index) =>
                                            <li>
                                                <Form.Group className="mb-4" controlId="exampleForm.ControlInput1">
                                                    <Form.Check
                                                        className="displayContent"
                                                        type={"checkbox"}
                                                        value={data.short_description}
                                                        onChange={(e) => handleUpdateCusGridValue(e, index, data)}
                                                        checked={data.short_description}
                                                        label={data.feature_name}
                                                        disabled={disabled}
                                                    />
                                                    <Form.Control
                                                        className='valueInput'
                                                        type="number"
                                                        value={data.value}
                                                        id='feature_value'
                                                        onChange={(e) => handleUpdateGridValue(e, index, data)}
                                                        // disabled={disabled ? disabled : data.choosen ? false : true}
                                                    />
                                                    <Form.Text className="d-flex subErors">
                                                        {planDataError.feature_value}
                                                    </Form.Text>
                                                </Form.Group>
                                            </li>
                                        )}
                                    </ul>
                                </div>

                                :
                                <table className="table planCreationTable manageuser_grid mb-0">
                                    <thead>
                                        <tr className='px-3 py-4'>
                                            <th>
                                                <label class="CheckBox">
                                                    <input type="checkbox" checked="checked" />
                                                    <span class="checkmark"></span>
                                                </label>
                                            </th>
                                            <th scope="col" className='px-3'>Feature<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col" style={{ width: "150px" }}>Min Value <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col" style={{ width: "150px" }}>Max Value <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col" style={{ width: "175px" }}>Value <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col" style={{ width: "150px" }}>Price<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        </tr>
                                    </thead>
                                    <tbody className='border-top-0'>
                                        {gridArray.length <= 0 ?
                                            <tr>
                                                <td className="text-center" colspan="5">No Records Found</td>
                                            </tr>
                                            :
                                            gridArray.map(
                                                (data, index) =>
                                                    <tr>
                                                        <td>
                                                            <label className="CheckBox">
                                                                <input
                                                                    type="checkbox"
                                                                    checked={data.choosen}
                                                                    onChange={(e) => handleUpdateGridValue(e, index, data)}
                                                                    id='feature_choose'
                                                                    disabled={disabled}
                                                                />
                                                                <span className="checkmark"></span>
                                                            </label>
                                                        </td>
                                                        <td className='px-3'>{data.feature_name}</td>
                                                        <td className='px-3'>{data.min_value}</td>
                                                        <td className='px-3'>{data.max_value}</td>
                                                        <td>
                                                            <Form.Group className={`formGroup ${data.error ? "errorFields" : ""}`}>
                                                                <Form.Control
                                                                    className='valueInput'
                                                                    type="number"
                                                                    value={data.value}
                                                                    min={data.min_value}
                                                                    max={data.max_value}
                                                                    id='feature_value'
                                                                    onChange={(e) => handleUpdateGridValue(e, index, data)}
                                                                    disabled={disabled ? disabled : data.choosen ? false : true}
                                                                />
                                                                <Form.Text className="d-flex subErors">
                                                                    {data.error}
                                                                </Form.Text>
                                                            </Form.Group>
                                                        </td>
                                                        <td>{data.price === "-" ? "-" : `$ ${data.price}`}</td>
                                                    </tr>
                                            )
                                        }
                                    </tbody>
                                </table>

                            }
                            {planData.customize_option &&
                                <>
                                    {edit ?

                                        <></>

                                        : disabled ?

                                            <></>

                                            :
                                            <Form.Group className="mb-3 customiseClick" controlId="exampleForm.ControlInput1">
                                                <Form.Check
                                                    className="displayContent"
                                                    type={"checkbox"} id="published" value={planDiscounts.published}
                                                    onChange={(e) => handleTermFreetext(e)}
                                                    checked={planDiscounts.published}
                                                    label={"When click the checkbox, plan will display in customer portal."}
                                                    disabled={disabled}
                                                />
                                                <Form.Text className="d-flex subErors">
                                                    {planDataError.published}
                                                </Form.Text>
                                            </Form.Group>
                                    }
                                </>
                            }
                            <div className="btnWrapper my-5 configBtnWrap">
                                <Button className="secondaryBtn" onClick={() => handleCheckNext("basic", "prev")}>Back</Button>
                                {planData.customize_option ?
                                    <>
                                        {disabled ?
                                            <Link to="/SubscriptionLists" className="primaryBtn" >Close</Link>
                                            :
                                            <>
                                                <Button className="primaryBtn" onClick={() => handleSavePlan()}>{edit ? "Update" : "Save"}</Button>
                                                <span className="customiseCenterError">
                                                    {serverMainError}
                                                </span>
                                            </>
                                        }
                                    </>
                                    :
                                    <>
                                        <Button className="primaryBtn" onClick={() => handleCheckNext("termed", "next")}>Next</Button>
                                        <Form.Text className="d-flex subErors serverError">
                                            {planDataError.mainError}
                                        </Form.Text>
                                    </>
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default PlanfeatureConfig