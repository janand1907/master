import React, { useState, useEffect } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from "react-router-dom";

const TermedDiscount = ({ edit, termedDuration, subCondition, handleCheckNext, termedDurationName,
    subConditionName, handleTermChange, planDataError, handleSubChange, planDiscounts, handleTermFreetext,
    handleSavePlan, serverMainError, handleCalculatePrice, planDiscountDetails, disabled, ...props }) => {

    const [derivedPop, setDerivedPop] = useState(false)

    const haandleDerived = () => {
        setDerivedPop(!derivedPop)
    }

    return (
        <div className="box-wrapper">
            <Form className={"inlineForm termedForm"}>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>
                        <span>Plan Price</span>
                    </Form.Label>
                    <div className="withtagline">
                        <div className="rightField">
                            <span className="priceFont">${planDiscounts.price === 0 ? " " : planDiscounts.price}</span>
                        </div>
                    </div>
                    <div className="manualChoose withInfoIcon">

                    </div>
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>
                        <span>Specified Period</span>
                    </Form.Label>
                    <div class={`can-toggle demo-rebrand-2 ${disabled && "toggleDisable"}`}>
                        <input
                            type="checkbox"
                            id='duration'
                            checked={planDiscounts.duration}
                            disabled={disabled}
                            onChange={(e) => handleTermFreetext(e)}
                        />
                        <label for="duration">
                            <div class="can-toggle__switch" data-checked="Annually" data-unchecked="Monthly"></div>
                        </label>
                    </div>
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>
                        <span>Discount(%)</span>
                    </Form.Label>
                    <div className="rightField">
                        <Form.Control type="text" placeholder='Enter Discount (%)' value={planDiscounts.discount === 0 ? null : planDiscounts.discount} id='discount' onChange={(e) => handleTermFreetext(e)} disabled={disabled} />
                        <Form.Text className="d-flex subErors">
                            {planDataError.discount}
                        </Form.Text>
                    </div>
                </Form.Group>
                {/* <Form.Group className="mb-3 customiseClick" controlId="exampleForm.ControlInput1">
                    <Form.Check
                        className="displayContent"
                        type={"checkbox"} id="published" value={planDiscounts.published}
                        onChange={(e) => handleTermFreetext(e)}
                        checked={planDiscounts.published}
                        label={"When click the checkbox, plan will display in customer portal."}
                        disabled={disabled}
                    />
                    <Form.Text className="d-flex subErors">
                        {planDataError.published}
                    </Form.Text>
                </Form.Group> */}
                <Form.Group className="mb-3 toggleWithText" controlId="exampleForm.ControlInput1">
                    <Form.Label>
                        <span>Status</span>
                    </Form.Label>
                    <label class="toggle">
                        <input
                            type={"checkbox"}
                            id="published"
                            value={planDiscounts.published}
                            onChange={(e) => handleTermFreetext(e)}
                            checked={planDiscounts.published}
                            disabled={disabled}
                        />
                        <span class={`slider ${disabled && "disableSmToggle"}`}></span>
                        <span class="labels" data-on="Active" data-off="Inactive"></span>
                    </label>
                    <Form.Text className="d-flex subErors">
                        {planDataError.published}
                    </Form.Text>
                </Form.Group>
                {/* {edit ?
                    <></>
                : disabled ?
                    <></>
                :
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>
                            <span>&nbsp;</span>
                        </Form.Label>
                        <Form.Check
                            className="displayContent"
                            type={"checkbox"} id="published" value={planDiscounts.published}
                            onChange={(e) => handleTermFreetext(e)}
                            checked={planDiscounts.published}
                            label={"When click the checkbox, plan will display in customer portal."}
                            disabled={disabled}
                        />
                        <Form.Text className="d-flex subErors">
                            {planDataError.published}
                        </Form.Text>
                    </Form.Group>
                } */}
                <Form.Group className="mb-3 finalSubmit" controlId="exampleForm.ControlInput1">
                    <Form.Label>
                        <span>&nbsp;</span>
                    </Form.Label>
                    <Button className="secondaryBtn" onClick={() => handleCheckNext("config", "prev")}>Back</Button>
                    {disabled ?
                        <Link to="/SubscriptionLists" className="primaryBtn" >Close</Link>
                        : edit ?
                            <Button className="primaryBtn" onClick={() => handleSavePlan()}>{edit ? "Update" : "Save"}</Button>
                            :
                            <Button className="primaryBtn" onClick={() => handleSavePlan()}>{edit ? "Update" : "Save"}</Button>
                    }
                    <Form.Text className="d-flex subErors">
                        {serverMainError}
                    </Form.Text>
                </Form.Group>
            </Form>
        </div>
    )
}
export default TermedDiscount