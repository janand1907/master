import React, { useState, useEffect } from 'react';
import './platformadmin.scss';
import { Form, Modal, Tab, Tabs, Dropdown, Popover, Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
import paypal from '../../assets/images/payment/paypal.png';
import stripe from '../../assets/images/payment/stripe.png';
import { setPaymentOptions, getPaymentOptions } from "../../endpoints/subscription/payment";
import { toast } from 'react-toastify';

const ProductDiscount = () => {

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Product Discount</div>
                    </div>
                </div>
            </div>
            <div className="box-wrapper">
                <Form className={"py-4 inlineForm termedForm"}>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label># of Prodcuts</Form.Label>
                        <Dropdown
                            className={"customDropdown"}
                        >
                            <Dropdown.Toggle className={"form-control"} id="dropdown-basic" >
                                {}
                            </Dropdown.Toggle>

                            <Dropdown.Menu className={"dropdownList"}>
                                {/* {subCondition && subCondition.map(
                                    sub =>
                                        <Dropdown.Item eventKey={sub.id} onClick={() => handleSubChange(sub)}>{sub.condition}</Dropdown.Item>
                                )
                                } */}
                            </Dropdown.Menu>
                            <span className="d-flex subErors">
                                {}
                            </span>
                        </Dropdown>
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Subscription Condition</Form.Label>
                        <Dropdown
                            className={"customDropdown"}
                        >
                            <Dropdown.Toggle className={"form-control"} id="dropdown-basic" >
                                {}
                            </Dropdown.Toggle>

                            <Dropdown.Menu className={"dropdownList"}>
                                {/* {termedDuration && termedDuration.map(
                                    term =>
                                        <Dropdown.Item eventKey={term.id} onClick={() => handleTermChange(term)}>{term.duration}</Dropdown.Item>
                                )
                                } */}
                            </Dropdown.Menu>
                            <span className="d-flex subErors">
                                {}
                            </span>
                        </Dropdown>
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>
                            <span>Subscription Discount(%)</span>
                        </Form.Label>
                        <div className="rightField">
                            <Form.Control type="text" placeholder='Enter Discount (%)' id='discount' />
                            <Form.Text className="d-flex subErors">
                                {}
                            </Form.Text>
                        </div>
                    </Form.Group>
                    <div className="btnWrapper">
                        <Button className="primaryBtn" >Add</Button>
                        <Form.Text className="d-flex subErors">
                            {}
                        </Form.Text>
                    </div>
                </Form>
            </div>
            <div className="customTabContainer">
                <div className='card op_card'>
                    <div className='card-body px-0 pb-0'>
                        <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                            <div className='heading_approval'>Product Plan Discount</div>
                        </div>
                        <table className="table manageuser_grid mb-0">
                            <thead>
                                <tr className='px-3 py-4'>
                                    <th scope="col" className='px-3'>SI.No <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col"># of Product<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col"># of Product Discount<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Action<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                </tr>
                            </thead>
                            <tbody className='border-top-0'>
                                <tr>
                                    <td colspan="4" className="text-center">No Records Found</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default ProductDiscount;
