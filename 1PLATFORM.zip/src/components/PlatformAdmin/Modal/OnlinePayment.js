import React, { useState, useEffect } from 'react';
import './Plandetail.scss';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
import Spinner from 'react-bootstrap/Spinner'
import paypal from '../../../assets/images/paypal.png'
import stripe from '../../../assets/images/stripe.png'
import productLogo from '../../../assets/images/stripe.png'

const OnlinePayment = ({ show, handleClose, paymentOption, setGatewayID, handleSubmitRequest, pending, planDetailsErr,
    chargeDetails, gateway_name, gateway_id, setGatewayName, productName, productLogo, ...props }) => {

    return (
        <div>
            <Modal show={show} onHide={handleClose} centered backdrop="static" keyboard={false} className='warningModal paymentConfirmModal'>
                <Modal.Header className='border-0  m-0' closeButton>
                    <span className="productLogo">
                        <img src={productLogo} alt="" />
                    </span>
                    <h3 className={"modal-title"}>1TX - {productName}</h3>
                </Modal.Header>
                <Modal.Body>
                    {paymentOption && paymentOption.payment_mode[1] === "Online" &&
                        <div className='card-body px-0 pb-0 gatewayWrapper'>
                            <section>
                                <ul className="gateWayNames">
                                    {paymentOption && paymentOption.gateway_list.map(
                                        payment =>
                                            <li>
                                                <span>{payment.gateway_name}</span>
                                                <span>,&nbsp;</span>
                                            </li>
                                    )}
                                </ul>
                                <ul className="gatewayTypes">
                                    {paymentOption && paymentOption.gateway_list.map(
                                        payment => payment.gateway_name === "Paypal" ?
                                            <li onClick={() => { setGatewayID(payment.gateway_id); setGatewayName(payment.gateway_name) }}>
                                                <div className="gatewayNameWrap">
                                                    <input type="radio" name="gateway" checked={gateway_id === payment.gateway_id ? true : false} />
                                                    <div className="gatewayName">
                                                        <img src={paypal} alt="" />
                                                    </div>
                                                </div>
                                            </li>
                                            :
                                            <li onClick={() => { setGatewayID(payment.gateway_id); setGatewayName(payment.gateway_name) }}>
                                                <div className="gatewayNameWrap">
                                                    <input type="radio" name="gateway" checked={gateway_id === payment.gateway_id ? true : false} />
                                                    <div className="gatewayName">
                                                        <img src={stripe} alt="" />
                                                    </div>
                                                </div>
                                            </li>
                                    )
                                    }
                                </ul>
                            </section>

                        </div>
                    }
                </Modal.Body>
                <Modal.Footer>
                    <div className="payDetails">
                        <h5>${(chargeDetails?.final_price)?.toLocaleString("en-US")}</h5>
                    </div>
                    <div className="btnWrapper autoBtnWidth my-3">
                        <Button className="primaryBtn payButton"
                            disabled={pending}
                            onClick={() => handleSubmitRequest()}>

                            {pending ?
                                <span>
                                    <Spinner
                                        as="span"
                                        animation="border" variant="light"
                                        size="sm"
                                        role="status"
                                        aria-hidden="true"
                                    /> Pay with {gateway_name}</span> : <>Pay with {gateway_name}</>
                            }
                        </Button>
                        <Form.Text className="d-flex subErors popError">
                            {planDetailsErr.server}
                        </Form.Text>
                    </div>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default OnlinePayment;