import React, { useState, useEffect } from 'react';
import './Plandetail.scss';
import { Form, Modal } from 'react-bootstrap';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
import successIcon from '../../../assets/images/succeed.png'

const ManualPayment = ({ show, handleClose, handleLoadMain, planDetailsErr, ...props }) => {

    return (
        <div>
            <Modal show={show} onHide={handleClose} backdrop="static" keyboard={false} className='warningModal manualPopWrap'>
                <Modal.Header className='border-0  m-0'>
                    <h3 className={"modal-title"}>{planDetailsErr?.server ? "Notification" : "Subscription Request"}</h3>
                </Modal.Header>
                <Modal.Body>
                    <div className={"customeSearch"}>
                        {planDetailsErr?.server ?
                            <p>{planDetailsErr?.server}</p>
                            :
                            <div className="manuallSuccesWrap">
                                <div className="successIcon">
                                    <img src={successIcon} alt="" />
                                </div>
                                <div className="rightModalCnt">
                                    <p>Your request has been submitted to the <strong>sales team.</strong> You will get a response within 1 business day.</p>
                                    <button className='btn btn_primary px-3 mx-2' onClick={handleLoadMain}>OK</button>
                                </div>
                            </div>
                        }
                    </div>
                </Modal.Body>
                {/* <Modal.Footer className='justify-content-center border-0 pt-2 pb-3'>
                    <button className='btn btn_primary px-3 mx-2' onClick={handleLoadMain}>Ok</button>
                </Modal.Footer> */}
            </Modal>
        </div>
    )
}

export default ManualPayment;