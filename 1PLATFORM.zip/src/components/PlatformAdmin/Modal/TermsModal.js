import React, { useState, useEffect } from 'react';
import './Plandetail.scss';
import { Form, Modal } from 'react-bootstrap';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';

const TermsModal = ({ terms, show, handleClose, ...props }) => {

    return (
        <div>
            <Modal show={show} onHide={handleClose} centered backdrop="static" keyboard={false} className='warningModal termsPlanModel'>
                <Modal.Header className='border-0  m-0' closeButton>
                    <h3 className={"modal-title"}>Terms of Service</h3>
                </Modal.Header>
                <Modal.Body>
                    <div className={"customeSearch CustomeTerms"}>

                        <p><ReactMarkdown rehypePlugins={[rehypeRaw]} children={terms} /></p>

                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center border-0 pt-2 pb-3'>
                    <button className='btn btn_primary px-3 mx-2' onClick={handleClose}>Close</button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default TermsModal;