import React, { useState, useEffect } from 'react'
import './platformadmin.scss'
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button } from 'react-bootstrap'
import BasicDetails from './createsubtabs/BasicDetails'
import PlanfeatureConfig from './createsubtabs/PlanfeatureConfig'
import TermedDiscount from './createsubtabs/TermedDiscount';
import { getProducts, getSubProducts, getDiscountDuration, getDiscountCondition, getPlanDuration, getFeatures } from "../../endpoints/subscription/lookup";
import {
    createPlan, getPlanDetails, getPlanFeature, getPlanList, getUserSlot,
    getFeatureProfile, getPlanFeatureDetails, getPlanDelete, getPlanUpdate,
    planUpdate, planUpdatable, checkOrderNumberExist
} from "../../endpoints/subscription/plan";
import { toast } from 'react-toastify';
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";

const CreateSubscriptionPlan = (props) => {
    const history = useHistory();
    const [show, setShow] = useState(false);
    const [_show, setShow1] = useState(false);
    const [addOn, setAddOn] = useState(false);
    const [confirmUpdate, setConfirmUpdate] = useState(null);
    const [comfMessage, setComfMessage] = useState(false);
    const [edit, setEdit] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = (feature) => {

        setShow(true);
        setFeature({
            "feature_id": feature.feature_id,
            "price": feature.feature_id,
            "feature_name": "Select Feature Name",
            "feature_type": feature.feature_type,
            "min_value": feature.min_value,
            "max_value": feature.max_value
        });
    };
    const _handleClose = () => setShow1(false);
    const [disabled, setDisabled] = useState(false);
    const [planData, setPlanData] = useState({
        "published": false,
        "product_id": 0,
        "profile_id": 0,
        "plan_name": "",
        "plan_description": "",
        "order_number": 0,
        "plan_feature_config": null,
        "customize_option": true,
        "discount": 0,
        "plan_duration": 0,
    });

    const [planDiscounts, setPlanDiscounts] = useState({
        "duration": false,
        "condition": 0,
        "discount": 0,
        "published": false,
        "price": 0,
        "contact_option": false,
        "plan_duration": 1
    });

    const [planDiscountDetails, setPlanDiscountDetails] = useState({
        "discount": 0,
        "discountAmt": 0,
        "price": 0,
        "total": 0
    });

    const [planDataError, setPlanDataError] = useState({
        "product_id": null,
        "profile_id": null,
        "plan_name": null,
        "plan_description": null,
        "order_number": null,
        "plan_feature_config": null,
        "mainError": null,
        "mainError_1": null,
        "duration": null,
        "condition": null,
        "discount": null,
        "published": null,
        "price": null,
        "index": null,
        "feature_value": null
    });

    const [featureDetail, setFeature] = useState({
        "feature_id": 0,
        "price": 0,
        "feature_name": "Select Feature Name",
        "feature_type": "custom",
        "min_value": 0,
        "max_value": 0
    });

    const [featureConfig, setFeatureConfig] = useState([]);

    const [tabActive, setTabActive] = useState("basic");

    const [products, setProducts] = useState(null);
    const [productName, setProductName] = useState("Select Product Name");

    const [subProducts, setSubProducts] = useState(null);
    const [subProductName, setSubProductName] = useState("Select Sub Product Name");

    const [features, setFeatures] = useState(null);
    const [featuresProfile, setFeaturesProfile] = useState(null);
    const [featuresProfileName, setFeaturesProfileName] = useState("Select Profile Name");


    const [termedDuration, setTermedDuration] = useState(null);
    const [termedDurationName, setTermedDurationName] = useState("Select duration");

    const [subCondition, setSubConditions] = useState(null);
    const [subConditionName, setSubConditionName] = useState("Select condition");

    const [featureValue, setFeatureValue] = useState({
        feature_value: 0
    });
    const [gridArray, serGridArray] = useState([]);

    const [popData, setPopGridData] = useState([]);

    const [user_slot, setuserSlot] = useState(0);

    const [serverMainError, setServerMainError] = useState(null);

    const [userSlot, setUserSlot] = useState(null);

    const [planDuration, setPlanDuration] = useState(null);

    const [customFeatures, setCustomFeatures] = useState(null);

    useEffect(() => {
        getProductsName();
        getTermedDuration();
        getSubDuration();
        getPlanDurations();

        if (props.location.state) {

            var _plan_id = props.location.state.plan_id;
            let disable = props.location.state.type;
            setDisabled(disable);
            getPlanDetail(_plan_id);
        }

    }, []);

    const getPlanDurations = async () => {

        let response = await getPlanDuration("json");

        if (response.status === 200) {
            setPlanDuration(response.data);
        }
    }

    const getCustomeFeatures = async (product_id) => {

        let response = await getFeatures(product_id, "json");

        if (response.status === 200) {
            var array = [];
            for (var a = 0; a < response.data.length; a++) {

                var json = {
                    "feature_id": response.data[a].feature_id,
                    "feature_name": response.data[a].feature_name,
                    "short_description": true,
                    "value": 0,
                    error: "Enter value"
                }
                array.push(json);
            }
            setCustomFeatures(array);
        }
    }

    const getPlanDetail = async (_plan_id) => {

        let response = await getPlanDetails(_plan_id);
        if (response.status === 200) {
            //setSubProducts(response.data);

            setEdit(true);
            var data = response.data;
            debugger;
            if (data.customize_option) {
                setPlanData({
                    ...planData,
                    "published": data.published,
                    "product_id": data.product_id,
                    "profile_id": 0,
                    "plan_name": data.plan_name,
                    "plan_description": data.plan_description,
                    "order_number": data.order_number,
                    "plan_feature_config": null,
                    "customize_option": data.customize_option,
                    "discount": data.discount,
                    "plan_duration": data.plan_duration
                })
                setProductName(data.product_name);
                var array = [];
                var feature_config = data.plan_feature_config;
                for (var a = 0; a < feature_config.length; a++) {

                    var json = {
                        "feature_id": feature_config[a].feature_id,
                        "feature_name": feature_config[a].feature_name,
                        "short_description": feature_config[a].short_description ? true : false,
                        "value": feature_config[a].feature_value
                    }
                    array.push(json);
                }
                setCustomFeatures(array);
                setPlanDiscounts({
                    ...planDiscounts,
                    "duration": 0,
                    "condition": 0,
                    "discount": data.discount,
                    "published": data.published,
                    "price": data.monthly_price,
                    "plan_duration": 0
                });
            } else {
                //getProfileFeatures(data.profile[0]);
                setFeatures(data.plan_feature_config);
                setPlanData({
                    ...planData,
                    "published": data.published,
                    "product_id": data.product_id,
                    "profile_id": data.profile[0],
                    "plan_name": data.plan_name,
                    "plan_description": data.plan_description,
                    "order_number": data.order_number,
                    "plan_feature_config": null,
                    "customize_option": data.customize_option,
                    "discount": data.discount,
                    "plan_duration": data.plan_duration,
                    "price": data.monthly_price
                })
                getCustomeFeatures(data.product_id);
                setProductName(data.product_name);
                setFeaturesProfileName(data.profile[1]);
                //serGridArray(data.plan_feature_config);
                var array = [];
                var feature_config = data.plan_feature_config;
                for (var a = 0; a < feature_config.length; a++) {

                    var json = {
                        feature_name: feature_config[a].feature_name,
                        feature_id: feature_config[a].feature_id,
                        priceOrg: feature_config[a].price,
                        feature_type: feature_config[a].feature_type,
                        min_value: feature_config[a].min_value,
                        max_value: feature_config[a].max_value,
                        value: feature_config[a].feature_value,
                        price: feature_config[a].price,
                        choosen: true
                    }
                    array.push(json);
                    if (feature_config[a].feature_type === "default") {
                        setFeature({
                            ...featureDetail,
                            "feature_id": feature_config[a].feature_id,
                            "price": feature_config[a].price,
                            "feature_name": "Select Feature Name",
                            "feature_type": feature_config[a].feature_type,
                            "min_value": feature_config[a].min_value,
                            "max_value": feature_config[a].max_value
                        });
                    }
                }
                serGridArray(array);
                //getUserSlots(_plan_id, data.plan_feature_config);
                //setTermedDurationName(data.plan_discounts.duration[1]);
                //setSubConditionName(data.plan_discounts.condition[1]);

                setPlanDiscounts({
                    ...planDiscounts,
                    "duration": data.plan_duration[0] === 1 ? false : true,
                    "condition": 0,
                    "discount": data.discount,
                    "published": data.published,
                    "price": data.monthly_price,
                    "plan_duration": data.plan_duration[0]
                });
                // handleCalculatePrice({
                //     "duration": data.plan_duration[0] === 1 ? false : true,
                //     "condition": 0,
                //     "discount": data.discount,
                //     "published": data.published,
                //     "price": 0,
                //     "plan_duration": data.plan_duration[0]
                // }, data.plan_feature_config);
            }
        }
    }

    const handleChange = (item) => {

        setProductName(item.product_name);

        if (item.is_sub_product) {
            setPlanData({ ...planData, product_id: null });
            getAllSubProducts(item.product_key);
            handleClearAll(0);
        } else {
            setSubProducts(null);
            setPlanData({ ...planData, product_id: item.product_key });
            getPlanFeatureProfile(item.product_key);
            handleClearAll(item.product_key);
            getCustomeFeatures(item.product_key);
        }
    }

    const handleClear = (product_id) => {
        setFeature({
            ...featureDetail,
            "feature_id": 0,
            "price": 0,
            "feature_name": "Select Feature Name",
            "feature_type": "custom",
            "min_value": 0,
            "max_value": 0
        });

        serGridArray([]);
        setPopGridData([]);
        setFeaturesProfileName("Select Profile Name");
        setTermedDurationName("Select duration");
        setSubConditionName("Select condition");
    }

    const handleClearAll = (product_id) => {

        setPlanData({
            ...planData,
            "published": false,
            "product_id": product_id,
            "profile_id": 0,
            "plan_name": "",
            "plan_description": "",
            "order_number": 0,
            "plan_feature_config": null,
            "customize_option": true,
            "discount": 0,
            "plan_duration": 0
        });

        setPlanDataError({
            ...planDataError,
            "product_id": null,
            "profile_id": null,
            "plan_name": null,
            "plan_description": null,
            "order_number": null,
            "plan_feature_config": null,
            "mainError": null,
            "mainError_1": null,
            "duration": null,
            "condition": null,
            "discount": null,
            "published": null,
            "price": null,
        });

        setFeature({
            ...featureDetail,
            "feature_id": 0,
            "price": 0,
            "feature_name": "Select Feature Name",
            "feature_type": "custom",
            "min_value": 0,
            "max_value": 0
        });

        //setSubProducts(null);
        serGridArray([]);
        setPopGridData([]);
        // setProductName("Select Product Name");
        // setSubProductName("Select Sub Product Name");
        setFeaturesProfileName("Select Profile Name");
        setTermedDurationName("Select duration");
        setSubConditionName("Select condition");
    }

    const getAllSubProducts = async (_product_key) => {

        let response = await getSubProducts(_product_key, "json");
        if (response.status === 200) {
            setSubProducts(response.data);
        }
    }

    const handleChangeSubProduct = (item) => {

        setSubProductName(item.product_name);
        if (item.product_key) {
            setPlanData({ ...planData, product_id: item.product_key });
            getPlanFeatureProfile(item.product_key);
            getCustomeFeatures(item.product_key);
            setPlanDataError({ ...planDataError, product_id: null });
        }
    }

    const getProductsName = async () => {
        let response = await getProducts("json");
        if (response.status === 200) {
            setProducts(response.data);
        }
    }

    const getProfileFeatures = async (profile_id) => {
        let response = await getPlanFeature(profile_id);
        if (response.status === 200) {
            setFeatures(response.data);
            var data = response.data;

            var array = [];
            for (var a = 0; a < data.length; a++) {
                var json = {
                    feature_name: data[a].feature_name,
                    feature_id: data[a].feature_id,
                    priceOrg: data[a].price,
                    feature_type: data[a].feature_type,
                    min_value: data[a].min_value,
                    max_value: data[a].max_value,
                    value: "",
                    price: (data[a].min_value) * (data[a].price),
                    error: "Enter value",
                    choosen: true
                }
                array.push(json);
                if (data[a].feature_type === "default") {
                    setFeature({
                        "feature_id": data[a].feature_name,
                        "price": data[a].price,
                        "feature_name": data[a].feature_name,
                        "feature_type": data[a].feature_type,
                        "min_value": data[a].min_value,
                        "max_value": data[a].max_value
                    });
                }
            }
            serGridArray(array);
            setShow(true);
        }
    }

    const getUserSlots = async (plan_id, plan_config) => {

        let response = await getUserSlot(plan_id);
        if (response.status === 200) {
            setUserSlot(response.data);
            var arr = [];
            var popGrid = [];
            for (var a = 0; a < response.data.length; a++) {
                arr.push(response.data[a].slot);
                let popData = {
                    user_slot: parseInt(response.data[a].slot)
                }
                popGrid.push(popData);
            }
            // var grid = [...gridArray];
            for (var b = 0; b < plan_config.length; b++) {
                if (plan_config[b].feature_type === "default") {
                    plan_config[b].feature_value = arr;
                }
            }

            //serGridArray(plan_config);
            setShow(true);
            setPopGridData(popGrid);
        }
    }

    const getPlanFeatureProfile = async (_product_id) => {

        let response = await getFeatureProfile(_product_id, "json");
        if (response.status === 200) {
            setFeaturesProfile(response.data);
        }
    }

    const handleChangeProfile = (item) => {

        setFeaturesProfileName(item.profile);

        setPlanData({ ...planData, profile_id: item.profile_id });
        serGridArray([]);
        setFeature({
            "feature_id": 0,
            "price": 10,
            "feature_name": "Select Feature Name",
            "feature_type": "custom",
            "min_value": 0,
            "max_value": 0
        });
        setFeatureValue({
            feature_value: 0
        });
        setPlanDataError({
            "product_id": null,
            "profile_id": null,
            "plan_name": null,
            "plan_description": null,
            "order_number": null,
            "plan_feature_config": null,
            "duration": null,
            "condition": null,
            "discount": null,
            "published": null,
            "price": null,
            "mainError": null,
            "mainError_1": null
        });
        if (item.profile) {
            getProfileFeatures(item.profile_id);
        }
    }

    const handleFreetext = (e) => {

        let name = e.target.id;

        if (name === "customize_option") {
            setPlanData({ ...planData, [name]: e.target.checked });
        } else {
            let value = e.target.value;
            setPlanData({ ...planData, [name]: value });
        }

        setPlanDataError({ ...planDataError, [name]: null });
    }

    const handleChangeFeatures = (item) => {

        if (item.feature_type === "default") {
            var grid = [...gridArray];
            for (var zz = 0; zz < grid.length; zz++) {
                if (grid[zz].feature_name === item.feature_name) {
                    setAddOn(true);
                }
            }
            setFeature({
                ...featureDetail, "feature_id": item.feature_id,
                "price": item.price,
                "feature_name": item.feature_name,
                "feature_type": item.feature_type,
                "min_value": item.min_value,
                "max_value": item.max_value
            });
            setPlanDataError({ ...planDataError, feature_id: null });
        } else {
            setPlanDataError({ ...planDataError, feature_id: null });
            setFeature({
                ...featureDetail, "feature_id": item.feature_id,
                "price": item.price,
                "feature_name": item.feature_name,
                "feature_type": item.feature_type,
                "min_value": item.min_value,
                "max_value": item.max_value
            });
        }






        //setPlanData({ ...planData, plan_feature_config: plan_feature_config });

    }

    const handleCheckNext = async (screen, act) => {

        if (screen === "config" && act === "next") {

            if (planData) {
                var error = {
                    product_id: planData.product_id === 0 ? "Choose product" : null,
                    plan_name: (planData.plan_name === "" || planData.plan_name === null) ? "Enter plan name" : null,
                    plan_description: (planData.plan_description === "" || planData.plan_description === null) ? "Enter plan info" : null,
                    order_number: (planData.order_number === 0 || planData.order_number < 0) ? "Enter order no" : null
                }
                if (error.product_id || error.plan_name || error.plan_description || error.order_number) {
                    setPlanDataError(
                        {
                            ...planDataError,
                            product_id: error.product_id,
                            plan_name: error.plan_name,
                            plan_description: error.plan_description,
                            order_number: error.order_number
                        }
                    );
                    return;
                } else {

                    if (planData.order_number) {
                        //checkOrderNumberExist
                        let response = await checkOrderNumberExist(planData.product_id, planData.order_number, props.location.state ? props.location.state?.plan_id : -1);
                        if (response.status === 200) {

                            if (response.data.order_number_exist) {
                                setPlanDataError({
                                    ...planDataError, product_id: null, plan_name: null, plan_description: null,
                                    order_number: "Order no already exits", profile_id: null
                                });
                                return;
                            }
                        }
                    }
                    setPlanDataError({
                        ...planDataError, product_id: null, plan_name: null, plan_description: null,
                        order_number: null, profile_id: null
                    });
                    setTabActive(tabActive => tabActive = screen);
                }
            }
            // if (planData.product_id === 0) {
            //     setPlanDataError({ ...planDataError, product_id: "Choose product" });
            //     return;
            // } else if (planData.plan_name === "" || planData.plan_name === null) {
            //     setPlanDataError({ ...planDataError, product_id: null, plan_name: "Enter plan name" });
            //     return;
            // } else if (planData.plan_description === "" || planData.plan_description === null) {
            //     setPlanDataError({ ...planDataError, product_id: null, plan_name: null, plan_description: "Enter plan description" });
            //     return;
            // } else if (planData.order_number === 0 || planData.order_number < 0) {
            //     setPlanDataError({ ...planDataError, product_id: null, plan_name: null, plan_description: null, order_number: "Enter order no" });
            //     return;
            // } 
            // else {
            //     setPlanDataError({
            //         ...planDataError, product_id: null, plan_name: null, plan_description: null,
            //         order_number: null, profile_id: null
            //     });
            //     setTabActive(tabActive => tabActive = screen);
            // }
        } else if (screen === "termed" && act === "next") {
            let arr = [...gridArray];
            if (planData.profile_id === 0) {
                setPlanDataError({ ...planDataError, profile_id: "Choose profile" });
                return;
            } else if (arr.length === 0) {
                setPlanDataError({ ...planDataError, mainError: "Complete plan with all features" });
                return;
            } else if (arr.length !== features.length) {
                setPlanDataError({ ...planDataError, mainError: "Complete plan with all features" });
                return;
            } else if (gridArray.length > 0) {
                var size = 0;
                for (var zz = 0; zz < gridArray.length; zz++) {
                    if(gridArray[zz].choosen){
                        if ((gridArray[zz].value === "" || gridArray[zz].value === null)) {
                            setPlanDataError({ ...planDataError, feature_value: "Enter value", index: zz });
                            return;
                        } else if (gridArray[zz].value < gridArray[zz].min_value) {
                            setPlanDataError({ ...planDataError, feature_value: "Enter value higher than " + gridArray[zz].min_value, index: zz });
                            return;
                        } else if (gridArray[zz].value > gridArray[zz].max_value) {
                            setPlanDataError({ ...planDataError, feature_value: "Enter value less than " + gridArray[zz].max_value, index: zz });
                            return;
                        }
                        
                    }else{
                        size++;
                    }
                }

                if(size === gridArray.length){
                    setPlanDataError({ ...planDataError, mainError: "choose atleast one feature" });
                    return;
                }

            }

            setPlanDataError({
                ...planDataError, profile_id: null, mainError: null, feature_value: null, index: null
            });

            let feature_config = [];
            var grid = [...gridArray];

            for (var zz = 0; zz < grid.length; zz++) {

                let _plan_feature_config = {
                    "feature_id": 0,
                    "feature_value": 0,
                    "short_description": "",
                    "value": 0
                };

                if(grid[zz].choosen){
                    if (_plan_feature_config.feature_id === 0) {
                        _plan_feature_config.feature_id = grid[zz].feature_id;
                    }
    
                    if (grid[zz].feature_type === "custom") {
    
                        _plan_feature_config.feature_value = parseInt(grid[zz].value);
    
                    } else {
                        _plan_feature_config.feature_value = parseInt(grid[zz].value);
                    }
                    feature_config.push(_plan_feature_config);
                }
                
            }

            setFeatureConfig(feature_config);
            setServerMainError(null);

            handleCalculatePrice(planDiscounts, [...gridArray]);
            setTabActive(tabActive => tabActive = screen);

        } else {
            setTabActive(tabActive => tabActive = screen);
        }

    }

    const handleFreetextGrid = (e) => {
        let name = e.target.id;
        let value = e.target.value;

        setFeatureValue({ ...featureValue, [name]: value });
        setPlanDataError({ ...planDataError, [name]: null });
        if (name === "user_slot") {
            setuserSlot(value);
        }
    }

    const handleAddfeature = () => {

        setPlanDataError({
            ...planDataError, product_id: null, plan_name: null, plan_description: null,
            order_number: null, profile_id: null
        });
        if (planData.profile_id === 0) {
            setPlanDataError({ ...planDataError, profile_id: "Choose profile" });
            return;
        } else if (featureDetail.feature_id === 0) {
            setPlanDataError({ ...planDataError, profile_id: null, feature_id: "Choose feature" });
            return;
        } else if (featureValue.feature_value === 0 || featureValue.feature_value < 0) {
            setPlanDataError({ ...planDataError, profile_id: null, feature_id: null, feature_value: "Enter feature value" });
            return;
        } else if (featureValue.feature_value < featureDetail.min_value) {
            setPlanDataError({ ...planDataError, profile_id: null, feature_id: null, feature_value: "Value must be greater than " + featureDetail.min_value });
            return;
        } else if (featureValue.feature_value > featureDetail.max_value) {
            setPlanDataError({ ...planDataError, profile_id: null, feature_id: null, feature_value: "Value must be lesser than " + featureDetail.max_value });
            return;
        }
        setPlanDataError({ ...planDataError, profile_id: null, feature_id: null, feature_value: null, mainError: null, mainError_1: null });

        let arr = [...gridArray];
        for (var a = 0; a < arr.length; a++) {

            if (arr[a].feature_id === featureDetail.feature_id) {
                setPlanDataError({ ...planDataError, profile_id: null, feature_id: null, feature_value: null, mainError: null, feature_id: "Feature already added" });
                return;
            }
        }

        let data = {
            feature_id: featureDetail.feature_id,
            feature_name: featureDetail.feature_name,
            feature_value: featureValue.feature_value,
            price: (featureValue.feature_value) * (featureDetail.price)
        }

        arr.push(data);

        serGridArray(arr);
        setFeature({
            "feature_id": 0,
            "price": 10,
            "feature_name": "Select Feature Name",
            "feature_type": "custom",
            "min_value": 0,
            "max_value": 0
        });
        setFeatureValue({
            feature_value: 0
        });

    }

    const handleEditFeature = (data) => {

        setFeature({
            ...featureDetail,
            feature_id: data.feature_id,
            feature_name: data.feature_name,
            min_value: data.min_value,
            max_value: data.max_value,
            price: data.price,
        });
        setFeatureValue({
            feature_value: 0
        });
    }

    const handleDelete = (item) => {

        var grid = [...gridArray];
        grid.splice(grid.findIndex(a => a.feature_id === item.feature_id), 1)
        serGridArray(grid);

        if (item.feature_type === "default") {
            setPopGridData([]);
        }

    }

    const handleAddPopGrid = () => {

        var grid = [...popData];

        if (parseInt(user_slot) === 0 || parseInt(user_slot) < 0) {
            setPlanDataError({ ...planDataError, user_slot: "Enter user slot" });
            return;
        } else if (parseInt(user_slot) < featureDetail.min_value) {
            setPlanDataError({ ...planDataError, user_slot: "Enter value must be greater than " + featureDetail.min_value });
            return;
        } else if (parseInt(user_slot) > featureDetail.max_value) {
            setPlanDataError({ ...planDataError, user_slot: "Enter value must be less than " + featureDetail.max_value });
            return;
        }

        setPlanDataError({ ...planDataError, user_slot: null });

        if (grid.length === 0) {
            let data = {
                user_slot: parseInt(user_slot)
            }

            grid.push(data);
        } else {

            for (var b = 0; b < grid.length; b++) {
                if (parseInt(user_slot) <= parseInt(grid[b].user_slot)) {
                    setPlanDataError({ ...planDataError, user_slot: "Enter value must be greater than previous entry" });
                    return;
                }
            }

            let data = {
                user_slot: parseInt(user_slot)
            }

            grid.push(data);

        }

        setPopGridData(grid);
        setuserSlot(0);
    }

    const handleDeletePop = (item) => {
        var grid = [...popData];
        grid.splice(grid.findIndex(a => a.user_slot === item.user_slot), 1)
        setPopGridData(grid);
    }

    const handleClosePopGrid = () => {

        var grid = [...popData];
        if (grid.length === 0) {

            setPlanDataError({ ...planDataError, mainError_2: "User Slots are not added yet" });

        } else {
            setPlanDataError({ ...planDataError, mainError_2: null });
            var array = [];
            for (var z = 0; z < grid.length; z++) {
                array.push(grid[z].user_slot);
            }

            let arr = [...gridArray];
            for (var a = 0; a < arr.length; a++) {

                if (arr[a].feature_id === featureDetail.feature_id) {
                    setPlanDataError({ ...planDataError, feature_id: "Feature already added" });
                    return;
                }
            }

            let data = {
                feature_id: featureDetail.feature_id,
                feature_name: featureDetail.feature_name,
                feature_value: array,
                price: "-"
            }

            arr.push(data);

            serGridArray(arr);
            setFeature({
                "feature_id": 0,
                "price": 10,
                "feature_name": "Select Feature Name",
                "feature_type": "custom",
                "min_value": 0,
                "max_value": 0
            });
            setFeatureValue({
                feature_value: 0
            });
            //setPopGridData([]);
            handleClose();
        }

    }

    const getTermedDuration = async () => {

        let response = await getDiscountDuration("json");
        if (response.status === 200) {
            setTermedDuration(response.data);
        }
    }

    const getSubDuration = async () => {

        let response = await getDiscountCondition("json");
        if (response.status === 200) {
            setSubConditions(response.data);
        }
    }

    const handleTermChange = (item) => {
        setTermedDurationName(item.duration);
        setPlanDiscounts({ ...planDiscounts, duration: item.id });
        setPlanDataError({ ...planDataError, duration: null });
        handleCalculatePrice({ ...planDiscounts, duration: item.id }, [...gridArray]);
    }

    const handleSubChange = (item) => {
        setSubConditionName(item.condition);
        setPlanDiscounts({ ...planDiscounts, condition: item.id });
        setPlanDataError({ ...planDataError, condition: null });
        handleCalculatePrice({ ...planDiscounts, condition: item.id }, [...gridArray]);
    }

    const handleTermFreetext = (e) => {

        let name = e.target.id;

        if (name === "published") {
            setPlanDiscounts({ ...planDiscounts, [name]: e.target.checked });
        } else if (name === "duration") {

            if (e.target.checked) {
                setPlanDiscounts({ ...planDiscounts, [name]: e.target.checked, "plan_duration": planDuration[1].id });
                handleCalculatePrice({ ...planDiscounts, [name]: e.target.checked, "plan_duration": planDuration[1].id }, [...gridArray]);
            } else {
                setPlanDiscounts({ ...planDiscounts, [name]: e.target.checked, "plan_duration": planDuration[0].id });
                handleCalculatePrice({ ...planDiscounts, [name]: e.target.checked, "plan_duration": planDuration[0].id }, [...gridArray]);
            }

        } else {
            let value = e.target.value;
            if (name === "discount" && value < 0 || value > 100) {
                setPlanDataError({ ...planDataError, [name]: "Enter value between 0 - 100" });
                return;
            }
            handleCalculatePrice({ ...planDiscounts, [name]: value }, [...gridArray]);
            setPlanDiscounts({ ...planDiscounts, [name]: value });
            setPlanDataError({ ...planDataError, [name]: null });
        }

    }

    const handleSavePlan = async () => {

        setPlanDataError({ ...planDataError, duration: null, condition: null, discount: null });

        var payload = planData;

        payload.published = planDiscounts.published;
        payload.discount = planDiscounts.discount;
        payload.plan_duration = planDiscounts.plan_duration;

        if (payload.customize_option) {
            var featureArr = [];
            var size = 0;
            for (var c = 0; c < customFeatures.length; c++) {

                if (customFeatures[c].short_description) {
                    var json = {
                        "feature_id": customFeatures[c].feature_id,
                        "feature_value": customFeatures[c].value,
                        "short_description": customFeatures[c].feature_name
                    };
                    featureArr.push(json);
                } else {
                    size++;
                    //setPlanDataError({ ...planDataError, feature_value: "Enter value", index: c });
                    //return;
                }

            }
            if(customFeatures.length === size){
                setServerMainError("choose atleast one feature");
                return;
            }
            payload.plan_feature_config = featureArr;

        } else {
            var featureArr = [];
            for (var c = 0; c < featureConfig.length; c++) {

                var json = {
                    "feature_id": featureConfig[c].feature_id,
                    "feature_value": featureConfig[c].feature_value,
                    "short_description": ""
                };
                featureArr.push(json);
            }
            payload.plan_feature_config = featureArr;

        }

        let response = null;

        if (props.location.state) {

            delete payload["product_id"];
            delete payload["plan_discounts"];
            delete payload["price"];
            var _plan_id = props.location.state.plan_id;

            let _response = await planUpdatable(payload, _plan_id);

            if (_response.status === 200 || _response.status === 201) {

                if (!_response.data.updateable) {

                    setShow1(true);
                    setComfMessage(_response.data.message);
                    setConfirmUpdate(payload);

                } else {

                    response = await planUpdate(payload, _plan_id);

                    if (response.status === 200 || response.status === 201) {
                        setServerMainError(null);
                        toast.success(response.data.message);
                        history.push({
                            pathname: "/SubscriptionLists"
                        });

                    } else {

                        if (response.Error.response.data !== "") {
                            setServerMainError(response.Error.response.data.errors[0].message);

                        } else {
                            setServerMainError("Error in request");
                        }
                    }
                }

            } else {
                if (response.Error.response.data !== "") {
                    setServerMainError(response.Error.response.data.errors[0].message);

                } else {
                    setServerMainError("Error in request");
                }
            }

        } else {
            delete payload["plan_discounts"];
            delete payload["price"];
            response = await createPlan(payload);

            if (response.status === 200 || response.status === 201) {
                setServerMainError(null);
                toast.success(response.data.message);
                history.push({
                    pathname: "/SubscriptionLists"
                });

            } else {

                if (response.Error.response.data !== "") {
                    setServerMainError(response.Error.response.data.errors[0].message);

                } else {
                    setServerMainError("Error in request");
                }
            }

        }

    }

    const handleUpdatePlan = async () => {

        let response = await planUpdate(confirmUpdate, props.location.state.plan_id);

        if (response.status === 200 || response.status === 201) {
            setServerMainError(null);
            _handleClose();
            toast.success(response.data.message);
            history.push({
                pathname: "/SubscriptionLists"
            });

        } else {

            if (response.Error.response.data !== "") {
                setServerMainError(response.Error.response.data.errors[0].message);

            } else {
                setServerMainError("Error in request");
            }
        }

    }

    const handleCalculatePrice = (planDiscount, arr) => {
       
        if (true) {
            let price = 0;
            var userslot = 0;
            for (var a = 0; a < arr.length; a++) {
                if(arr[a].choosen){
                    price = parseFloat(price) + parseFloat(arr[a].price);
                }
            }

            planDiscount.price = (price * (planDiscount.plan_duration === 1 ? 1 : 12) + userslot);
            setPlanDiscountDetails({ ...planDiscountDetails, price: price, total: price, discountAmt: 0 });
            setPlanDiscounts(planDiscount);
        }
    }

    const handleUpdateGridValue = (e, index, featureDetail) => {

        let arr = [...gridArray];
        var feature_value = e.target.value;
        var id = e.target.id;
debugger;
        if(id === "feature_choose"){

            if(e.target.checked){
                featureDetail.error = "Enter value";
                featureDetail.choosen = e.target.checked;
                featureDetail.value = "";
                arr[index] = featureDetail;
                serGridArray(arr);
            }else{
                featureDetail.error = null;
                featureDetail.choosen = e.target.checked;
                featureDetail.value = "";
                arr[index] = featureDetail;
                serGridArray(arr);
            }

        }else{
            debugger;
            if(featureDetail.priceOrg){
                if (featureDetail.feature_value === 0 || featureDetail.feature_value < 0) {
                    featureDetail.error = "Enter value"
        
                } else if (feature_value < featureDetail.min_value) {
                    featureDetail.error = "Value must be greater than " + featureDetail.min_value
        
                } else if (feature_value > featureDetail.max_value) {
                    featureDetail.error = "Value must be lesser than " + featureDetail.max_value
        
                } else {
                    if(featureDetail.priceOrg){
                        let price = (feature_value) * (featureDetail.priceOrg);
                        featureDetail.price = price.toFixed(1);
                        featureDetail.error = null;
                    }                
                }
                featureDetail.value = feature_value;
            }else{
                featureDetail.value = feature_value;
            }
            
            arr[index] = featureDetail;
            serGridArray(arr);
        }
    }

    const handleUpdateCusGridValue = (e, index, featureDetail) => {

        //var short_description = e.target.value;
        var short_description = e.target.checked;
        setPlanDataError({ ...planDataError, profile_id: null, feature_value: null, index: null });
        featureDetail.short_description = short_description;
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>{disabled ? "View" : edit ? "Edit" : "Create"} Plan</div>
                    </div>
                    {/* <div className="d-flex gap-3">
                        <Link to="/CreatePlanFeature" className="primaryBtn">+ Create Features</Link>
                    </div> */}
                </div>
            </div>
            <div className="customTabContainer">
                {!_show &&
                    <Tab.Container id="left-tabs-example" defaultActiveKey={tabActive} unmountOnExit={true}>
                        <div className='wrapperNewTabDesign'>
                            <div className='leftTab'>
                                <Nav>
                                    <Nav.Item><Nav.Link className={tabActive === "basic" ? "active" : ""} onClick={() => handleCheckNext("basic", "next")}><span></span>Details</Nav.Link></Nav.Item>
                                    <Nav.Item><Nav.Link className={tabActive === "config" ? "active" : ""} onClick={() => handleCheckNext("config", "next")}><span></span>Package Setup</Nav.Link></Nav.Item>
                                    {!planData.customize_option && <Nav.Item><Nav.Link className={tabActive === "termed" ? "active" : ""} onClick={() => handleCheckNext("termed", "next")}><span></span>Discount</Nav.Link></Nav.Item>}
                                </Nav>
                            </div>
                            <div className='RightContent'>
                                <Tab.Content>
                                    <Tab.Pane eventKey="basic">
                                        {tabActive === "basic" ?
                                            <BasicDetails
                                                edit={edit}
                                                productName={productName}
                                                products={products}
                                                planData={planData}
                                                subProducts={subProducts}
                                                subProductName={subProductName}
                                                handleChange={handleChange}
                                                handleChangeSubProduct={handleChangeSubProduct}
                                                handleFreetext={handleFreetext}
                                                handleCheckNext={handleCheckNext}
                                                planDataError={planDataError}
                                                disabled={disabled}
                                                planDiscounts={planDiscounts}
                                                handleTermFreetext={handleTermFreetext}
                                            />
                                            : tabActive === "config" ?
                                                <PlanfeatureConfig
                                                    show={show}
                                                    edit={edit}
                                                    addOn={addOn}
                                                    handleShow={handleShow}
                                                    handleClose={handleClose}
                                                    planData={planData}
                                                    features={features}
                                                    handleChangeFeatures={handleChangeFeatures}
                                                    featureValue={featureValue}
                                                    handleCheckNext={handleCheckNext}
                                                    featureDetail={featureDetail}
                                                    handleFreetextGrid={handleFreetextGrid}
                                                    gridArray={gridArray}
                                                    handleAddfeature={handleAddfeature}
                                                    handleChangeProfile={handleChangeProfile}
                                                    featuresProfile={featuresProfile}
                                                    featuresProfileName={featuresProfileName}
                                                    planDataError={planDataError}
                                                    handleEditFeature={handleEditFeature}
                                                    handleDelete={handleDelete}
                                                    popData={popData}
                                                    handleAddPopGrid={handleAddPopGrid}
                                                    handleDeletePop={handleDeletePop}
                                                    user_slot={user_slot}
                                                    handleClosePopGrid={handleClosePopGrid}
                                                    disabled={disabled}
                                                    handleUpdateGridValue={handleUpdateGridValue}
                                                    handleFreetext={handleFreetext}
                                                    customFeatures={customFeatures}
                                                    handleUpdateCusGridValue={handleUpdateCusGridValue}
                                                    handleTermFreetext={handleTermFreetext}
                                                    handleSavePlan={handleSavePlan}
                                                    planDiscounts={planDiscounts}
                                                    serverMainError={serverMainError}
                                                />
                                                :
                                                <TermedDiscount
                                                    edit={edit}
                                                    termedDuration={termedDuration}
                                                    subCondition={subCondition}
                                                    termedDurationName={termedDurationName}
                                                    subConditionName={subConditionName}
                                                    planDataError={planDataError}
                                                    planDiscounts={planDiscounts}
                                                    handleCheckNext={handleCheckNext}
                                                    handleTermChange={handleTermChange}
                                                    handleSubChange={handleSubChange}
                                                    handleTermFreetext={handleTermFreetext}
                                                    handleSavePlan={handleSavePlan}
                                                    serverMainError={serverMainError}
                                                    handleCalculatePrice={handleCalculatePrice}
                                                    planDiscountDetails={planDiscountDetails}
                                                    disabled={disabled}
                                                />
                                        }
                                    </Tab.Pane>
                                </Tab.Content>
                            </div>
                        </div>



                    </Tab.Container>
                }
            </div>
            <Modal
                show={_show}
                size="md"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className="subscriptionModal"
                onHide={_handleClose}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Confirm Request
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p className="text-center">{comfMessage}</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button className="secondaryBtn" onClick={_handleClose}>Cancel</Button>
                    <Button className="primaryBtn" onClick={() => handleUpdatePlan()}>OK</Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default CreateSubscriptionPlan