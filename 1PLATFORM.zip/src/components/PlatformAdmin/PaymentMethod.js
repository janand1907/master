import React, { useState, useEffect } from 'react';
import './platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Popover, Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
import paypal from '../../assets/images/payment/paypal.png';
import stripe from '../../assets/images/payment/stripe.png';
import { setPaymentOptions, getPaymentOptions } from "../../endpoints/subscription/payment";
import { saveTerms, getTerms } from "../../endpoints/subscription/terms";
import { toast } from 'react-toastify';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import OnlinePayment from './OnlinePayment';

const PaymentMethod = () => { 
    const [tabActive, setTabActive] = useState("basic");
    const [ckEditorData, setCKEditorData] = useState("<p>Hello from CKEditor&nbsp;5!</p>");
    const [serverMainError, setServerMainError] = useState(null);

    const [payment, setPayment] = useState({
        "payment_mode": 0,
        "payment_options": [
            0
        ]
    });

    const [selected, setPaymentOptionSeleted] = useState(0);
    const [paymentOptions, setPaymentOption] = useState(null);

    useEffect(() => {
        getPaymentOption();
        getTermsData();
    }, []);

    const getTermsData = async () => {

        let response = await getTerms();

        if (response.status === 200) {

            setCKEditorData(response.data.term);
        }

    }

    const getPaymentOption = async () => {

        let response = await getPaymentOptions();

        if (response.status === 200) {

            var arr = [];
            for (var a = 0; a < response.data._payment_options.length; a++) {
                if (response.data._payment_options[a].selected) {
                    arr.push(response.data._payment_options[a].payment_option_id);
                }
            }
            setPayment({ ...payment, payment_mode: response.data.payment_mode.selected, payment_options: arr });
            setPaymentOption(response.data);
            setPaymentOptionSeleted(response.data.payment_mode.selected);
            // setTimeout(() => {
            //     document.getElementById(response.data.payment_mode.selected).checked = true;
            // }, 2000);
        }

    }

    const handleChange = (e) => {
        var id = e.target.id;
        setPaymentOptionSeleted(id);
        setPayment({ ...payment, payment_mode: parseInt(id) });

        var data = { ...paymentOptions }

        var check = data.payment_mode;

        check.selected = parseInt(id);

        setPaymentOption({ ...paymentOptions, payment_mode: check })

        // if(id=== "1"){
        //     document.getElementById("1").checked = true;
        //     document.getElementById("2").checked = false;
        // }else{
        //     document.getElementById("1").checked = false;
        //     document.getElementById("2").checked = true;
        // }

    }

    const handleOnlineChange = (e) => {
        
        var id = e.target.id;
        var name = e.target.name;
        var check = e.target.checked;

        var data = { ...paymentOptions };

        var _payment_options = data._payment_options;

        for (var a = 0; a < _payment_options.length; a++) {

            if (parseInt(id) === _payment_options[a].payment_option_id) {
                _payment_options[a].selected = check;
            }

        }

        setPaymentOption({ ...paymentOptions, _payment_options: _payment_options });
    }

    const handleSave = async () => {
        setServerMainError(null);
        var payload = { ...payment };
        var arr = [];
        var data = { ...paymentOptions };
        var _payment_options = data._payment_options;
        if (payload.payment_mode === 1) {
            for (var a = 0; a < _payment_options.length; a++) {

                if (_payment_options[a].selected) {
                    arr.push(_payment_options[a].payment_option_id);
                }

            }
        }
        payload.payment_options = arr;

        let response = await setPaymentOptions(payload);
        if (response.status === 200 || response.status === 201) {
            setServerMainError(null);
            toast.success(response.data.message);
        } else {

            if (response.Error.response.data !== "") {
                setServerMainError(response.Error.response.data.errors[0].message);

            } else {
                setServerMainError("Error in request");
            }
        }

    }

    const handleSaveTerms = async () => {
        setServerMainError(null);
        var payload = {
            term: ckEditorData
        }

        let response = await saveTerms(payload);
        if (response.status === 200 || response.status === 201) {
            setServerMainError(null);
            toast.success(response.data.message);
        } else {

            if (response.Error.response.data !== "") {
                setServerMainError(response.Error.response.data.errors[0].message);

            } else {
                setServerMainError("Error in request");
            }
        }

    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Terms of Payment</div>
                    </div>
                </div>
            </div>
            <div className="customTabContainer paymentTab">

                <Tab.Container id="left-tabs-example" defaultActiveKey={tabActive} unmountOnExit={true}>
                    <Nav>
                        <Nav.Item><Nav.Link eventKey="basic">Mode of Payment</Nav.Link></Nav.Item>
                        <Nav.Item><Nav.Link eventKey="config">Terms of Service</Nav.Link></Nav.Item>
                    </Nav>
                    <Tab.Content>

                        <Tab.Pane eventKey="basic">
                            {paymentOptions &&
                                <div className='row my-3'>
                                    <div className='col-md-3 paymentType'>
                                        <Form className="paymentForm">
                                            {paymentOptions.payment_mode.modes.map(
                                                paymentMode =>
                                                    <Form.Check
                                                        type={'radio'}
                                                        label={paymentMode.mode + " " + "Payment"}
                                                        id={paymentMode.id}
                                                        name={paymentMode.mode}
                                                        checked={paymentOptions.payment_mode.selected === paymentMode.id ? true : false}
                                                        onChange={(e) => handleChange(e)}
                                                    />
                                            )
                                            }
                                        </Form>
                                    </div>
                                    {payment.payment_mode === 1 &&
                                        <OnlinePayment
                                            paymentOptions={paymentOptions}
                                            handleOnlineChange={handleOnlineChange}
                                        />
                                    }
                                    <div className={`cardBtnWrapper ${payment.payment_mode !== 1 && "wrapperStart"}`}>
                                        <Button className="secondaryBtn">Cancel</Button>
                                        <Button className="primaryBtn" onClick={() => handleSave()}>Save</Button>
                                    </div>
                                </div>
                            }
                        </Tab.Pane>
                        <Tab.Pane eventKey="config">
                            <div className="box-wrapper">
                                <Form >
                                    <CKEditor
                                        editor={ClassicEditor}
                                        data={ckEditorData}
                                        onReady={editor => {
                                            // You can store the "editor" and use when it is needed.
                                            console.log('Editor is ready to use!', editor);
                                            setCKEditorData(editor.getData())
                                        }}
                                        onChange={(event, editor) => {
                                            const data = editor.getData();
                                            setCKEditorData(data)
                                            console.log({ event, editor, data });
                                        }}
                                        config={{
                                            toolbar: {
                                                items: [
                                                    'heading', 
                                                    '|', 'bold', 'italic', 'strikethrough', 'subscript', 'superscript', 'code',
                                                    '|', 'fontfamily', 'fontsize', 'fontColor', 'fontBackgroundColor',
                                                    '|', 'link', 'uploadImage', 'blockQuote', 'codeBlock', 'mediaEmbed',
                                                    '|', 'alignment', 
                                                    '|', 'bulletedList', 'numberedList', 'todoList', 'outdent', 'indent',
                                                    '|', 'insertTable', 'tableColumn', 'tableRow', 'mergeTableCells',
                                                    '|', 'undo', 'redo'
                                                ],
                                                shouldNotGroupWhenFull: true
                                            }
                                            }
                                        }
                                    />
                                    <div className="btnWrapper">
                                        {/* <Button className="secondaryBtn">Cancel</Button> */}
                                        <Button className="primaryBtn" onClick={() => handleSaveTerms()}>Save</Button>
                                        <Form.Text className="d-flex termsError">
                                            {serverMainError}
                                        </Form.Text>
                                    </div>
                                </Form>
                            </div>
                        </Tab.Pane>
                    </Tab.Content>
                </Tab.Container>
            </div>
        </div>
    )
}
export default PaymentMethod;
