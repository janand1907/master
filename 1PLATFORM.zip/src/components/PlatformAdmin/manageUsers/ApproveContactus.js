import React, { useState, useEffect } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { requestPlanDetails, setPlanRequestAction } from "../../../endpoints/subscription/manageuser";
import { getFeatures } from "../../../endpoints/subscription/lookup";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import { toast } from 'react-toastify';

const ApproveContactus = (props) => {
    const history = useHistory();
    const [disabled, setDisabled] = useState(false);
    const [requestPlanDetail, setRequestPlanDetail] = useState(null);
    const [serverMainError, setServerMainError] = useState(null);
    const [customFeatures, setCustomFeatures] = useState([]);
    const [searchOpen, setSearchOpen] = useState(false);
    const [request_id, setRequestId] = useState(0);
    const animateSearch = () => {
        setSearchOpen(!searchOpen);
    }
    const [planDataError, setPlanDataError] = useState({
        index: null,
        feature_value: null,
        approve: null,
        required_month: null,
    });

    const [featureDetail, setFeature] = useState({
        "feature_id": 0,
        "feature_name": "Select Feature Name",
        "feature_value": null
    });

    const [planData, setPlanData] = useState({
        "approve": true,
        "comments": "",
        "set_custom_plan": null
    });

    const [durationName, setDurationName] = useState("Select Plan Duration");
    const [required_month, setrequiredMonth] = useState(0);
    const [durations, setDurations] = useState(
        [{
            "id": "1",
            "name": "Monthly"
        },
        {
            "id": "2",
            "name": "Annually"
        }]
    );

    useEffect(() => {
        if (props.location.state) {
            setRequestId(props.location.state.request_id);
            handleRequestPlanDetails(props.location.state.request_id);
            //getCustomeFeatures(props.location.state.request.product_id);
        }
    }, []);

    const handleBack = () => {
        history.goBack();
    }

    const handleRequestPlanDetails = async (request_id) => {

        let response = await requestPlanDetails(request_id);
        if (response.status === 200) {

            setDisabled(!response.data.customize_plan);
            setRequestPlanDetail(response.data);
            setrequiredMonth(response.data.request_duration === 12 ? 2 : response.data.request_duration);
            setDurationName(response.data.request_duration === 1 ? "Monthly" : "Annually");
            if (response.data.request_type === "Upgrade Addon") {
                setCustomFeatures(response.data.current_plan_features);
            } else {
                setCustomFeatures(response.data.current_plan_features);
            }

        }
    }

    const getCustomeFeatures = async (product_id) => {

        let response = await getFeatures(product_id, "json");

        if (response.status === 200) {
            var array = [];
            for (var a = 0; a < response.data.length; a++) {

                var json = {
                    "feature_id": response.data[a].feature_id,
                    "feature_name": response.data[a].feature_name,
                    "feature_value": ""
                }
                array.push(json);
            }
            setCustomFeatures(array);
        }
    }

    const handleUpdateCusGridValue = (e, index, featureDetail) => {

        var feature_value = e.target.value;
        setPlanDataError({ ...planDataError, feature_value: null, index: null });
        featureDetail.feature_value = feature_value;

    }

    const handleChange = (item) => {
        setDurationName(item.name);
        setrequiredMonth(item.id);
        if (item.id !== 0) {
            setPlanDataError({ ...planDataError, required_month: null });
        }
    }

    const handleApprovePlan = async () => {
        
        if (required_month === 0) {
            setPlanDataError({ ...planDataError, required_month: "Duration Required", feature_value: null, index: 0 });
            return;
        }

        if (!planData.approve) {
            setPlanDataError({ ...planDataError, approve: "Required", required_month: null, feature_value: null, index: 0 });
            return;
        }

        var featureArr = [];
        for (var c = 0; c < customFeatures.length; c++) {

            if (customFeatures[c].feature_value) {
                var json = {
                    "feature_id": customFeatures[c].feature_id,
                    "value": customFeatures[c].feature_value,
                };
                featureArr.push(json);
            } else {
                setPlanDataError({ ...planDataError, feature_value: "Enter value", index: c });
                return;
            }
        }
        setPlanDataError({ ...planDataError, approve: null, required_month: null, feature_value: null, index: 0 });
        let set_custom_plan = {
            "required_month": required_month,
            "set_features": featureArr
        }

        var payload = {
            "approve": planData.approve,
            "comments": "",
            "set_custom_plan": set_custom_plan
        }

        setPlanData({ ...planData, set_custom_plan: set_custom_plan });

        let response = await setPlanRequestAction(payload, props.location.state.request_id);

        if (response.status === 200) {
            setServerMainError(null);
            toast.success(response.data.message);
            history.push({
                pathname: "/dashboard-admin",
            });
        } else {

            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);
            } else {
                toast.error("Error in request");
            }
        }
        
    }

    const handleTermFreetext = (e) => {
        let name = e.target.id;
        if (name === "approve") {
            setPlanData({ ...planData, [name]: e.target.checked });
        }
    }

    const handleApproveRequest = async (requestType) => {

        var payload = {
            "approve": requestType,
            "comments": ""
        }

        let response = await setPlanRequestAction(payload, request_id);
        if (response.status === 200) {
            toast.success(response.data.message);
            history.push({
                pathname: "/dashboard-admin",
            });
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);

            } else {
                toast.error("Error in request");
            }
        }
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <button className="btn btn_light" onClick={() => handleBack()}>{backBtnIcon}</button>
                        <div className='h3'>License Approval Request</div>
                    </div>
                </div>
            </div>

            <div className='row g-3 my-1'>
                <div className='col-md-12'>
                    <div className='card p_card paymentCardwrap'>
                        {requestPlanDetail &&
                            <div className='card-body px-0 py-0'>
                                <div className="addonwrapper mt-0">
                                    <h5 className="addonTitle">Product Details</h5>
                                    <div class="editSubscriptionForm approvalLabelWrap">
                                        <div className="formWrapper">
                                            <Form className={"inlineForm fullWidth"}>
                                                <Form.Group controlId="exampleForm.ControlInput1">
                                                    <Form.Label>
                                                        <span>Product</span>
                                                    </Form.Label>
                                                    <Form.Label className="viewLabel">
                                                        <span>{requestPlanDetail.product_name}</span>
                                                    </Form.Label>
                                                </Form.Group>
                                                <Form.Group controlId="exampleForm.ControlInput1">
                                                    <Form.Label>
                                                        <span>Package Name</span>
                                                    </Form.Label>
                                                    <Form.Label className="viewLabel">
                                                        <span>{requestPlanDetail.plan_name}</span>
                                                    </Form.Label>
                                                </Form.Group>
                                                <Form.Group controlId="exampleForm.ControlInput1">
                                                    <Form.Label>
                                                        <span>Requested On</span>
                                                    </Form.Label>
                                                    <Form.Label className="viewLabel">
                                                        <span>{requestPlanDetail.requested_on}</span>
                                                    </Form.Label>
                                                </Form.Group>
                                            </Form>
                                        </div>
                                        <div className="formWrapper">
                                            <Form className={"inlineForm fullWidth"}>
                                                {disabled ?
                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                        <Form.Label>
                                                            <span>Plan Duration</span>
                                                        </Form.Label>
                                                        <Form.Label className="viewLabel">
                                                            <span>{requestPlanDetail.request_plan_duration}</span>
                                                        </Form.Label>
                                                    </Form.Group>
                                                    :
                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                        <Form.Label>
                                                            <span>Plan Duration</span>
                                                        </Form.Label>
                                                        <Dropdown className={"customDropdown durationDropdown"} >
                                                            <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                                                {durationName}
                                                            </Dropdown.Toggle>
                                                            <Dropdown.Menu className={"dropdownList"}>
                                                                {durations && durations.map(
                                                                    dur =>
                                                                        <Dropdown.Item eventKey={dur.id} onClick={() => handleChange(dur)} >{dur.name}</Dropdown.Item>
                                                                )
                                                                }
                                                            </Dropdown.Menu>
                                                            <span className="d-flex subErors">
                                                                {planDataError.required_month}
                                                            </span>
                                                        </Dropdown>
                                                    </Form.Group>
                                                }
                                                <Form.Group controlId="exampleForm.ControlInput1">
                                                    <Form.Label>
                                                        <span>Category</span>
                                                    </Form.Label>
                                                    <Form.Label className="viewLabel">
                                                        <span>{requestPlanDetail.request_type}</span>
                                                    </Form.Label>
                                                </Form.Group>
                                                {/* <Form.Group controlId="exampleForm.ControlInput1">
                                                    <Form.Label>
                                                        <span>Plan Expire On</span>
                                                    </Form.Label>
                                                    <Form.Label className="viewLabel">
                                                        <span>{requestPlanDetail.current_plan_expire_on ? requestPlanDetail.current_plan_expire_on : "-"}</span>
                                                    </Form.Label>
                                                </Form.Group> */}
                                            </Form>
                                        </div>
                                    </div>
                                </div>
                                <div className="addonwrapper mt-0">
                                    <h5 className="addonTitle">Customer Details</h5>
                                    <div class="editSubscriptionForm approvalLabelWrap">
                                        <div className="formWrapper">
                                            <Form className={"inlineForm fullWidth"}>
                                                <Form.Group controlId="exampleForm.ControlInput1">
                                                    <Form.Label>
                                                        <span>Inquired By</span>
                                                    </Form.Label>
                                                    <Form.Label className="viewLabel">
                                                        <span>{requestPlanDetail.name}</span>
                                                    </Form.Label>
                                                </Form.Group>
                                                {/* <Form.Group controlId="exampleForm.ControlInput1">
                                                    <Form.Label>
                                                        <span>Company</span>
                                                    </Form.Label>
                                                    <Form.Label className="viewLabel">
                                                        <span>{"-"}</span>
                                                    </Form.Label>
                                                </Form.Group> */}
                                            </Form>
                                        </div>
                                        <div className="formWrapper">
                                            <Form className={"inlineForm fullWidth"}>
                                                <Form.Group controlId="exampleForm.ControlInput1">
                                                    <Form.Label>
                                                        <span>Email</span>
                                                    </Form.Label>
                                                    <Form.Label className="viewLabel">
                                                        <span className="approveEmail">{requestPlanDetail.email}</span>
                                                    </Form.Label>
                                                </Form.Group>
                                            </Form>
                                        </div>
                                    </div>
                                    <div className="licenceApprovalGrid">
                                        <table className="table my-3">
                                            <thead>
                                                <tr className='px-3 py-4'>
                                                    <th scope="col" className='px-3'>Features<span className='mx-2' style={{ fontSize: '13px' }}></span></th>
                                                    <th scope="col" className="licenceValue px-3">Value <span className='mx-2' style={{ fontSize: '13px' }}></span></th>
                                                </tr>
                                            </thead>
                                            <tbody className='border-top-0'>
                                                {customFeatures.length <= 0 ?
                                                    <tr>
                                                        <td className="text-center" colspan="5">No Records Found</td>
                                                    </tr>
                                                    :
                                                    customFeatures.map(
                                                        (data, index) =>
                                                            <tr>
                                                                <td className='px-3'>{data.feature_name}</td>
                                                                <td className='px-3'>
                                                                    <Form.Group className={`formGroup ${planDataError.index === index && planDataError.feature_value ? "errorFields" : ""}`}>
                                                                        <Form.Control className='valueInputDesc' type="number" value={data.feature_value > 0 && data.feature_value} placeholder="0" id='feature_value' onChange={(e) => handleUpdateCusGridValue(e, index, data)} disabled={disabled} />
                                                                        <Form.Text className="d-flex subErors">
                                                                            {planDataError.index === index && planDataError.feature_value}
                                                                        </Form.Text>
                                                                    </Form.Group>
                                                                </td>
                                                            </tr>
                                                    )
                                                }
                                            </tbody>
                                        </table>
                                    </div>
                                    {/* <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                        <Form.Label>
                                            <span>&nbsp;</span>
                                        </Form.Label>
                                        <Form.Check
                                            className="displayContent"
                                            type={"checkbox"} id="approve" value={planData.approve}
                                            onChange={(e) => handleTermFreetext(e)}
                                            checked={planData.approve}
                                            label={"Approve user request"}
                                            disabled={disabled}
                                        />
                                        <Form.Text className="d-flex subErors">
                                            {planDataError.approve}
                                        </Form.Text>
                                    </Form.Group> */}
                                    <Form className={"py-4"}>
                                        <div className="btnWrapper approveplanBtn">
                                            <Button className="secondaryBtn" onClick={() => handleBack()}>Cancel</Button>
                                            {disabled ?
                                                <Button className="primaryBtn" onClick={() => handleApproveRequest(true)}>Approve</Button>
                                                :
                                                <Button className="primaryBtn" onClick={() => handleApprovePlan()}>Approve</Button>
                                            }
                                            <Form.Text className="d-flex subErors">
                                                {serverMainError}
                                            </Form.Text>
                                        </div>
                                    </Form>
                                </div>
                            </div>
                        }
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ApproveContactus;