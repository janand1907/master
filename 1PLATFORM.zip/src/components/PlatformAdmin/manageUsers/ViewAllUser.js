import React, { useState, useEffect, useMemo } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { getSlotUsers } from "../../../endpoints/subscription/manageuser";
import { useHistory } from "react-router-dom";
import { backBtnIcon } from '../../../Icons/icons';
import { TablePagination, Pagination } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Search from '../../Common/Search/Search';
import icon1 from '../../../assets/images/dashboard/5.png'
import icon2 from '../../../assets/images/dashboard/3.png'
import icon3 from '../../../assets/images/dashboard/4.png'

const ViewAllUser = (props) => {
    const history = useHistory();
    const [searchOpen, setSearchOpen] = useState(false);
    const animateSearch = () => {
        setSearchOpen(!searchOpen);
    }

    const [allUsers, setAllUsers] = useState(null);

    const [allLicense, setAllLicense] = useState(0);
    const [activeLicense, setActiveLicense] = useState(0);
    const [inactiveLicense, setInactiveLicense] = useState(0);

    useEffect(() => {
        if (props.location.state) {
            setAllLicense(props.location.state.plan_user_slots_purchased);
            setActiveLicense(props.location.state.plan_active_users);
            setInactiveLicense(props.location.state.plan_inactive_users);
            getSunscribedUsersList(props.location.state.subscribed_id);
        }
    }, []);

    const getSunscribedUsersList = async (subscribed_id) => {

        let response = await getSlotUsers(subscribed_id);
        if (response.status === 200) {
            setAllUsers(response.data);
        }

    }

    const handleBack = () => {
        history.goBack();
    }

    const theme = createTheme({
        palette: {
            neutral: {
                main: '#bae6f3',
                contrastText: '#0e699c',
            },
        },
    });

    /*pagination with search */
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");

    const ITEMS_PER_PAGE = 10;

    const allUsersFilter = useMemo(() => {
        if (allUsers === null) {
            return allUsers;
        }
        let computedviewDomain = allUsers;
        
        if (search) {
            computedviewDomain = computedviewDomain.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(search.toLowerCase())
                    || viewDomain.first_name.toLowerCase().includes(search.toLowerCase())
                    || viewDomain.last_name.toLowerCase().includes(search.toLowerCase())
            );
        }
        setTotalItems(computedviewDomain.length);

        return computedviewDomain.slice(
            (currentPage - 1) * ITEMS_PER_PAGE,
            (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [allUsers, currentPage, search]);

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <button className="btn btn_light" onClick={() => handleBack()}>{backBtnIcon}</button>
                        <div className='h3'>Subscription User Details</div>
                    </div>
                </div>
            </div>
            <section className="usersStatuswrap">
                <ul className="statusLists">
                    <li>
                        <div className="cardWrap">
                            <div className="countWthcircle">
                                <div className="circle">
                                    <img src={icon1} alt="" />
                                </div>
                                <h1 className="usersCount">{allLicense}</h1>
                            </div>
                            <div className="userLabel"># of Licence</div>
                        </div>
                    </li>
                    <li>
                        <div className="cardWrap">
                            <div className="countWthcircle">
                                <div className="circle">
                                    <img src={icon2} alt="" />
                                </div>
                                <h1 className="usersCount">{activeLicense}</h1>
                            </div>
                            <div className="userLabel">Active License</div>
                        </div>
                    </li>
                    <li>
                        <div className="cardWrap">
                            <div className="countWthcircle">
                                <div className="circle">
                                    <img src={icon3} alt="" />
                                </div>
                                <h1 className="usersCount">{inactiveLicense}</h1>
                            </div>
                            <div className="userLabel">Inactive License</div>
                        </div>
                    </li>
                </ul>
            </section>
            <div className="customTabContainer">
                <div className='card op_card'>
                    <div className='card-body px-0 pb-0'>
                        <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                            <div className='heading_approval'>List of Users</div>
                            <Search
                                className='searchinput'
                                searchOpen={searchOpen}
                                animateSearch={animateSearch}
                                onSearch={value => {
                                    setSearch(value);
                                    setCurrentPage(1);
                                }}
                            />
                        </div>
                        <table className="table manageuser_grid mb-0">
                            <thead>
                                <tr className='px-3 py-4'>
                                    <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Email ID <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Company Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Products Name<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Role<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Added Date<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                    <th scope="col">Status<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                </tr>
                            </thead>
                            <tbody className='border-top-0'>
                                {allUsersFilter && allUsersFilter.map(
                                    user =>
                                        <tr>
                                            <td>{user.first_name} {user.last_name}</td>
                                            <td>{user.email}</td>
                                            <td>{user.company_name}</td>
                                            <td>{user.product_name}</td>
                                            <td>{user.role}</td>
                                            <td>{user.created_on}</td>
                                            <td>{user.status ? "Active" : "In Active"}</td>
                                        </tr>
                                )}
                            </tbody>
                        </table>
                        <div className='my-3 pe-3 paginationBlock'>
                            <ThemeProvider theme={theme}>
                                <Pagination
                                    count={Math.ceil(totalItems / ITEMS_PER_PAGE)}
                                    onChange={(page, i) => setCurrentPage(i)}
                                    shape="rounded"
                                    variant="outlined"
                                    style={{ float: 'right' }}
                                />
                            </ThemeProvider>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ViewAllUser;