import React, { useState, useEffect } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom/cjs/react-router-dom';
import { getAllproducts, getUserProductPlan, getBillings } from "../../../endpoints/subscription/manageuser";
import { useHistory } from "react-router-dom";

const ViewSubscribedUser = (props) => {
    const history = useHistory();
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [userAllProduct, setUserAllProduct] = useState(null);
    const [billingDetail, setBillingDetail] = useState(null);

    const UserhandleShow = () => UsersetShow(true);
    const [Usershow, UsersetShow] = useState(false);
    const UserhandleClose = () => UsersetShow(false);

    useEffect(() => {
        if (props.location.state) {
            if (props.location.state.planId) {
                getUserForPlan(props.location.state.email, props.location.state.planId);
            } else {
                getUserAllproducts(props.location.state.email);
            }
        }
    }, []);

    const getUserAllproducts = async (email) => {
        let response = await getAllproducts(email);
        if (response.status === 200) {
            setUserAllProduct(response.data);
        }
    }

    const getUserForPlan = async (email, planId) => {
        let response = await getUserProductPlan(email, planId);
        if (response.status === 200) {
            setUserAllProduct(response.data);
        }
    }

    const getBillingDetails = async (subscribed_id) => {
        let response = await getBillings(subscribed_id);
        if (response.status === 200) {
            handleShow();
            setBillingDetail(response.data);
        }
    }

    const handleBack = () => {
        history.push({
            pathname: "/SubscribedUsersList"
        });
    }

    const handleViewUsers = (innertabCnt) => {
        history.push({
            pathname: "/allusers",
            state: {
                subscribed_id: innertabCnt.subscription_id,
                plan_user_slots_purchased: innertabCnt.plan_user_slots_purchased,
                plan_active_users: innertabCnt.plan_active_users,
                plan_inactive_users: innertabCnt.plan_inactive_users
            }
        });
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>View License Products</div>
                    </div>
                    <div className="d-flex gap-3">
                        {/* <button className="secondaryBtn" onClick={handleShow}>
                            <span>Billing Details</span>
                        </button> */}
                        <Modal
                            show={show}
                            size="md"
                            aria-labelledby="contained-modal-title-vcenter"
                            centered
                            className="subscriptionModal"
                            onHide={handleClose}
                        >
                            <Modal.Header closeButton>
                                <Modal.Title id="contained-modal-title-vcenter">
                                    Subscription Billing Details
                                </Modal.Title>
                            </Modal.Header>
                            <Modal.Body>
                                {billingDetail && billingDetail.price_details &&
                                    <>
                                        <div className="planCostDetails">
                                            <span className="subPlanName">Subscribe to Pro-unlimited-annual</span>
                                            <h1 className="planPrice">
                                                <strong>$ {billingDetail.price_details.final_price}</strong>
                                                <span>Every {billingDetail.price_details.required_month} months</span>
                                            </h1>
                                        </div>
                                        <ul className="priceSplited">
                                            <li>
                                                <div className="leftLabels">
                                                    <strong>Payment Mode</strong>
                                                </div>
                                                <div className="priceDetails">{billingDetail.payment_mode}</div>
                                            </li>
                                            <li>
                                                <div className="leftLabels">
                                                    <strong>Amount</strong>
                                                </div>
                                                <div className="priceDetails">{billingDetail.price_details.required_month} </div>
                                                <div className="priceDetails">*</div>
                                                <div className="priceDetails">$ {billingDetail.price_details.monthly_price}</div>
                                            </li>
                                            <li>
                                                <div className="leftLabels">
                                                    <strong>Pro-unlimited-annual</strong>
                                                    <span className="tagLine">Billed every {billingDetail.price_details.required_month} months</span>
                                                </div>
                                                <div className="priceDetails">$ {(billingDetail.price_details.required_month * billingDetail.price_details.monthly_price)}</div>
                                            </li>
                                            {/* <li>
                                            <div className="leftLabels">
                                                <strong>Subtotal</strong>
                                            </div>
                                            <div className="priceDetails">$ {billingDetail.price_details.total_price}</div>
                                        </li> */}
                                            <li>
                                                <div className="leftLabels">
                                                    <strong>Discount</strong>
                                                </div>
                                                <div className="priceDetails">{billingDetail.price_details.plan_discount.discount_percent} %</div>
                                                <div className="priceDetails">$ (- {billingDetail.price_details.plan_discount.discount_amount})</div>
                                            </li>
                                            <li>
                                                <div className="leftLabels">
                                                    <strong>User Slot Price</strong>
                                                </div>
                                                <div className="priceDetails">$ {billingDetail.price_details.total_user_slot_price}</div>
                                            </li>
                                            <li className="grantTotal">
                                                <div className="leftLabels">
                                                    <strong>Total</strong>
                                                </div>
                                                <div className="priceDetails">$ {billingDetail.price_details.final_price}</div>
                                            </li>
                                        </ul>
                                    </>
                                }
                            </Modal.Body>
                            <Modal.Footer>
                                <Button className="secondaryBtn" onClick={handleClose}>Cancel</Button>
                                <Button className="primaryBtn" onClick={handleClose}>OK</Button>
                            </Modal.Footer>
                        </Modal>
                    </div>
                </div>
            </div>
            <div className="customTabContainer ManageUserTab">
                {userAllProduct && userAllProduct.products?.length > 0 &&
                    <Tab.Container id="left-tabs-example" defaultActiveKey={userAllProduct.products[0].main_product_name} unmountOnExit={true}>
                        <div className='wrapperNewTabDesign'>
                            <div className='leftTab'>
                                <Nav>
                                    {userAllProduct.products.map((product, i) => (
                                        <Nav.Item key={`main-key-${i}`}><Nav.Link eventKey={product.main_product_name}><span></span>{product.main_product_name}{product.product_plan_details.length > 1 && <span className="count">{product.product_plan_details && product.product_plan_details.length}</span>}</Nav.Link></Nav.Item>
                                    ))}
                                </Nav>
                            </div>
                            <div className='RightContent'>
                                <Tab.Content>
                                    {userAllProduct.products.map((product, i) => (
                                        <Tab.Pane key={`inner-key-${i}`} eventKey={product.main_product_name} className={`box-wrapper ${product.sub_product ? "innerTabContainer" : ""}`}>
                                            {product.sub_product ?
                                                <Tab.Container id="left-tabs-example" defaultActiveKey={product.product_plan_details[0].product_name} unmountOnExit={true}>
                                                    <Nav className="innerTabList">
                                                        {product.product_plan_details.map((innertabslist, i) => (
                                                            <Nav.Item key={i}><Nav.Link eventKey={innertabslist.product_name}>{innertabslist.product_name}</Nav.Link></Nav.Item>
                                                        ))}
                                                    </Nav>
                                                    <Tab.Content>
                                                        {product.product_plan_details.map((innertabCnt, i) => (
                                                            <Tab.Pane key={`inner-tab-key-${i}`} eventKey={innertabCnt.product_name}>
                                                                
                                                                <div className="editSubscriptionForm">
                                                                    {/* <div className="subscriptionBtnWrapper">
                                                                        <Button className="secondaryBtn" onClick={() => getBillingDetails(innertabCnt.subscription_id)} >Billing Details</Button>
                                                                    </div> */}
                                                                    <div className="formWrapper">
                                                                        <Form className={"py-4 inlineForm fullWidth"}>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>First Name</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{userAllProduct.first_name}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Email ID</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{userAllProduct.email}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Product Name</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{innertabCnt.product_name}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>License Start Date</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{innertabCnt.plan_starts_on}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span># of User Slots</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span onClick={() => handleViewUsers(innertabCnt)}>{innertabCnt.plan_user_slots_purchased}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span># of Inactive Users</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{innertabCnt.plan_inactive_users}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                        </Form>
                                                                    </div>
                                                                    <div className="formWrapper">
                                                                        <Form className={"py-4 inlineForm fullWidth"}>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Last Name</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{userAllProduct.last_name}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Company Name</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{userAllProduct.company_name}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Plan Duration</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{innertabCnt.plan_duration} Months</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>License End Date</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{innertabCnt.plan_ends_on}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span># of Active Users</span>
                                                                                </Form.Label>
                                                                                <Form.Label className="viewLabel">
                                                                                    <span>{innertabCnt.plan_active_users}</span>
                                                                                </Form.Label>
                                                                            </Form.Group>
                                                                            <Form.Group controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Status</span>
                                                                                </Form.Label>
                                                                                <Form.Check
                                                                                    type="switch"
                                                                                    id="custom-switch"
                                                                                    checked={innertabCnt.status}
                                                                                />
                                                                            </Form.Group>
                                                                        </Form>
                                                                    </div>
                                                                    {props.location.state && props.location.state.planId ?
                                                                        <div className="subscriptionBtnWrapper">
                                                                            <Button className="secondaryBtn" onClick={() => history.goBack()}>Back</Button>
                                                                            <Button className="primaryBtn" onClick={() => history.goBack()}>Ok</Button>
                                                                        </div>
                                                                        :
                                                                        <div className="subscriptionBtnWrapper">
                                                                            <Button className="secondaryBtn" onClick={() => handleBack()}>Back</Button>
                                                                            <Button className="primaryBtn" onClick={() => handleBack()}>Ok</Button>
                                                                        </div>
                                                                    }
                                                                </div>
                                                            </Tab.Pane>
                                                        ))}
                                                    </Tab.Content>
                                                </Tab.Container>
                                                :
                                                <div className="editSubscriptionForm">
                                                    {product.product_plan_details.map((innertabCnt, i) => (
                                                        <>
                                                            <div className="formWrapper">
                                                               
                                                                {/* <div className="subscriptionBtnWrapper">
                                                                    <Button className="secondaryBtn" onClick={() => getBillingDetails(innertabCnt.subscription_id)} >Billing Details</Button>
                                                                </div> */}
                                                                <Form className={"py-4 inlineForm fullWidth"}>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>First Name</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{userAllProduct.first_name}</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>Email ID</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{userAllProduct.email}</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>Product</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{innertabCnt.product_name}</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>Active Users Count</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel text-theme-medium" >
                                                                            <span onClick={() => handleViewUsers(innertabCnt)}>{innertabCnt.plan_user_slots_purchased}</span>
                                                                            <span className="userIcon">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                                                                                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4Zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10Z" />
                                                                                </svg>
                                                                            </span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>Status</span>
                                                                        </Form.Label>
                                                                        <Form.Check
                                                                            type="switch"
                                                                            id="custom-switch"
                                                                            checked={innertabCnt.status}
                                                                        />
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>Comment</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                </Form>
                                                            </div>
                                                            <div className="formWrapper">
                                                                <Form className={"py-4 inlineForm fullWidth"}>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>Last Name</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{userAllProduct.last_name}</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>Company Name</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{userAllProduct.company_name}</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>Plan Duration</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{innertabCnt.plan_duration} Months</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>License Start Date</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{innertabCnt.plan_starts_on}</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span>License End Date</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{innertabCnt.plan_ends_on}</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    {/* <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span># of Active Users</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{innertabCnt.plan_active_users}</span>
                                                                        </Form.Label>
                                                                    </Form.Group>
                                                                    <Form.Group controlId="exampleForm.ControlInput1">
                                                                        <Form.Label>
                                                                            <span># of Inactive Users</span>
                                                                        </Form.Label>
                                                                        <Form.Label className="viewLabel">
                                                                            <span>{(innertabCnt.plan_inactive_users)}</span>
                                                                        </Form.Label>
                                                                    </Form.Group> */}
                                                                </Form>
                                                            </div>
                                                            {props.location.state && props.location.state.planId ?
                                                                <div className="subscriptionBtnWrapper">
                                                                    <Button className="secondaryBtn" onClick={() => history.goBack()}>Back</Button>
                                                                    <Button className="primaryBtn" onClick={() => history.goBack()}>Ok</Button>
                                                                </div>
                                                                :
                                                                <div className="subscriptionBtnWrapper">
                                                                    <Button className="secondaryBtn" onClick={() => handleBack()}>Back</Button>
                                                                    <Button className="primaryBtn" onClick={() => handleBack()}>Ok</Button>
                                                                </div>
                                                            }
                                                        </>
                                                    ))
                                                    }
                                                </div>
                                            }
                                        </Tab.Pane>
                                    ))
                                    }
                                </Tab.Content>
                            </div>
                        </div>
                    </Tab.Container>
                }
            </div>
            <div className={""}>
                <Modal
                    show={Usershow}
                    size="md"
                    aria-labelledby=""
                    centered
                    className="subscriptionModal CreateUser"
                    onHide={UserhandleClose}
                >
                    <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">
                            Create User
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form>
                            <Form.Group className='mb-3'>
                                <Form.Label>
                                    <span>First Name</span>
                                </Form.Label>
                                <Form.Control type="text" placholder="Enter first name"/>
                            </Form.Group>
                            <Form.Group className='mb-3'>
                                <Form.Label>
                                    <span>Last Name</span>
                                </Form.Label>
                                <Form.Control type="text" placholder="Enter last name"/>
                            </Form.Group>
                            <Form.Group className='mb-3'>
                                <Form.Label>
                                    <span>Email</span>
                                </Form.Label>
                                <Form.Control type="text" placholder="Enter email address"/>
                            </Form.Group>
                            <Form.Group>
                                <Form.Label>
                                    <span>Product Name</span>
                                </Form.Label>
                                <Dropdown
                                    className={"customDropdown"}
                                >
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        
                                    </Dropdown.Toggle>
                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item eventKey="0"  >All</Dropdown.Item>
                                        <Dropdown.Item eventKey="0"  >All</Dropdown.Item>
                                        <Dropdown.Item eventKey="0" >All</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </Form.Group>
                        </Form>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button className="secondaryBtn" onClick={UserhandleClose}>Cancel</Button>
                        <Button className="primaryBtn">Create</Button>
                    </Modal.Footer>
                </Modal> 
            </div>
        </div>
    )
}

export default ViewSubscribedUser