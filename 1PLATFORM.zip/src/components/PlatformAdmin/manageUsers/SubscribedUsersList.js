import React, { useState, useEffect, useMemo } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button, Popover } from 'react-bootstrap';
import { Link } from 'react-router-dom/cjs/react-router-dom';
import { getBoardView, getAllUsers, getActionDetails, setPlanRequestAction, requestPlanDetails, setAction } from "../../../endpoints/subscription/manageuser";
import { useHistory } from "react-router-dom";
import icon1 from '../../../assets/images/dashboard/5.png'
import icon2 from '../../../assets/images/dashboard/3.png'
import icon3 from '../../../assets/images/dashboard/4.png'
import { toast } from 'react-toastify';
import { TablePagination, Pagination } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Search from '../../Common/Search/Search';

const SubscribedUsersList = () => {
    const history = useHistory();
    const [show, setShow] = useState(false);
    const [showTwo, setShowTwo] = useState(false);
    const [showThree, setShowThree] = useState(false);
    const [gridAction, setGridAction] = useState(false);
    const [statusName, setStatusName] = useState("All");

    const handleGridAction = (index) => {
        setGridAction(false);
        setGridAction(prevAction => ({
            ...prevAction,
            [index]: !gridAction[index]
        }));
    }
    const handleClose = () => {
        setShow(false);
        setRequestType(null);
        setComments(null);
        setCommentsErr(null);
        setRequestId(0);
    };
    const handleCloseTwo = () => {
        setRequestPlanDetail(null);
        setShowTwo(false);
    };
    const handleCloseThree = () => {
        setShowThree(false);
    };
    const handleShow = () => setShow(true);
    const handleShowTwo = () => setShowTwo(true);
    const handleShowThree = () => setShowThree(true);
    const [showPopover, setShowPopover] = useState(false);
    const [showPopoverId, setShowPopoverId] = useState(0);
    const [searchOpen, setSearchOpen] = useState(false);
    const animateSearch = () => {
        setSearchOpen(!searchOpen);
    }

    const [boardViewData, setBoardViewData] = useState(null);
    const [allUsers, setAllUsers] = useState(null);
    const [pendingUsers, setPendingUsers] = useState(null);
    const [rejectedUsers, setRejectedUsers] = useState(null);
    const [message, setMessage] = useState(null);
    const [requestType, setRequestType] = useState(null);
    const [request_id, setRequestId] = useState(0);
    const [comments, setComments] = useState(null);
    const [commentsErr, setCommentsErr] = useState(null);
    const [requestPlanDetail, setRequestPlanDetail] = useState(null);

    const [userData, setUserData] = useState({
        "products": 0,
        "email": null,
        "firstname": null,
        "lastname": null,
        "companyname": null,
        "status": false
    });
    const [filter, setFileter] = useState("All");

    useEffect(() => {
        // getAllBoardView();
        getSunscribedUsersList();
        // getPendingUsersList();
        // getRejectedUsersList();
    }, []);

    const getAllBoardView = async () => {
        let response = await getBoardView("json");
        if (response.status === 200) {
            setBoardViewData(response.data);
        }
    }

    const getSunscribedUsersList = async () => {
        let response = await getAllUsers("subscribed_users");
        if (response.status === 200) {
            setAllUsers(response.data);
        }
    }

    const getPendingUsersList = async () => {
        let response = await getAllUsers("pending_approvals");
        if (response.status === 200) {
            setPendingUsers(response.data);
        }
    }

    const getRejectedUsersList = async () => {
        let response = await getAllUsers("rejected_users");
        if (response.status === 200) {
            setRejectedUsers(response.data);
        }
    }

    const viewDetails = (type, email) => {
        //updateplan
        if (type === 0) {
            history.push({
                pathname: "/EditSubscribedUser",
                state: {
                    email
                }
            });
        } else {
            history.push({
                pathname: "/ViewSubscribedUser",
                state: {
                    email
                }
            });
        }

    }

    const getCommentDetails = async (request_id) => {
        let response = await getActionDetails(request_id);
        if (response.status === 200) {
            setMessage(response.data);
        }
    }

    const getCommentDetailsView = async (request_id) => {
        let response = await getActionDetails(request_id);
        if (response.status === 200) {
            return response.data;
        } else {
            return "No reason";
        }
    }

    const handleApprovePopUp = (request_id) => {
        handleShow(); setRequestType(true);
        setRequestId(request_id);
    }

    const handleRejectPopUp = (request_id) => {
        handleShow(); setRequestType(false);
        setRequestId(request_id);
    }

    const handleApproveRequest = async () => {

        if (comments === "") {
            setCommentsErr("Enter Comments");
            return;
        }
        setCommentsErr(null);

        var payload = {
            "approve": requestType,
            "comments": comments
        }

        let response = await setPlanRequestAction(payload, request_id);
        if (response.status === 200) {
            handleClose();
            getSunscribedUsersList();
            getPendingUsersList();
            getRejectedUsersList();
            toast.success(response.data.message);
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);

            } else {
                toast.error("Error in request");
            }
        }
    }

    const handleRejectRequest = async () => {

        if (comments === "") {
            setCommentsErr("Enter Comments");
            return;
        }
        setCommentsErr(null);
        var payload = {
            "approve": requestType,
            "comments": comments
        }

        let response = await setPlanRequestAction(payload, request_id);
        if (response.status === 200) {
            handleClose();
            getSunscribedUsersList();
            getPendingUsersList();
            getRejectedUsersList();
            toast.success(response.data.message);
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);

            } else {
                toast.error("Error in request");
            }
        }
    }

    const handleFreetext = (e) => {
        let name = e.target.id;
        let value = e.target.value;
        setComments(value);
    }

    const handleRequestPlanDetails = async (request_id) => {

        let response = await requestPlanDetails(request_id);
        if (response.status === 200) {
            setRequestPlanDetail(response.data);
            handleShowTwo();
        }
    }


    const handlePopUpUser = (item) => {
        setUserData({
            ...userData,
            "products": item.products,
            "email": item.email,
            "firstname": item.firstname,
            "lastname": item.lastname,
            "companyname": item.companyname,
            "status": item.status,
        });
        handleShowThree();

    }

    const handleStaheStatus = (e) => {

        let value = e.target.checked;

        setUserData({ ...userData, status: value })
    }

    const handleUpdasteUserStatus = async () => {

        var payload = {
            "email": userData.email,
            "status": userData.status
        }

        let response = await setAction(payload);
        if (response.status === 200) {
            getAllBoardView();
            getSunscribedUsersList();
            setShowThree(false);
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);
            } else {
                toast.error("Error in request");
            }
        }

    }

    const handleApprovePending = (request_id, request) => {
        history.push({
            pathname: "/approve-contact",
            state: {
                request_id,
                request
            }
        });
    }

    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const handleChangePagination = (event, value) => {
        setPage(value);
    };

    const theme = createTheme({
        palette: {
            neutral: {
                main: '#bae6f3',
                contrastText: '#0e699c',
            },
        },
    });

    /*pagination with search */
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");

    const [p_totalItems, setPTotalItems] = useState(0);
    const [p_currentPage, setPCurrentPage] = useState(1);
    const [p_search, setPSearch] = useState("");

    const [r_totalItems, setRTotalItems] = useState(0);
    const [r_currentPage, setRCurrentPage] = useState(1);
    const [r_search, setRSearch] = useState("");

    const ITEMS_PER_PAGE = 10;

    const allUsersFilter = useMemo(() => {
        if (allUsers === null || allUsers?.length === 0) {
            setTotalItems(0);
            return allUsers;
        }
        let computedviewDomain = allUsers;
        if (search) {
            computedviewDomain = computedviewDomain.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(search.toLowerCase())
            );
        }
        if (filter) {
            if (filter === "Active") {
                computedviewDomain = computedviewDomain.filter(
                    viewDomain =>
                        viewDomain.status === true
                );
            } else if (filter === "Inactive") {
                computedviewDomain = computedviewDomain.filter(
                    viewDomain =>
                        viewDomain.status === false
                );
            } else {
                computedviewDomain = computedviewDomain;
            }
        }
        setTotalItems(computedviewDomain.length);

        return computedviewDomain.slice(
            (currentPage - 1) * ITEMS_PER_PAGE,
            (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [allUsers, currentPage, search, filter]);

    const pendingUsersFilter = useMemo(() => {
        if (pendingUsers === null) {
            return pendingUsers;
        }
        let computedviewDomain = pendingUsers;
        if (p_search) {
            computedviewDomain = computedviewDomain.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(p_search.toLowerCase())
            );
        }
        setTotalItems(computedviewDomain.length);

        return computedviewDomain.slice(
            (p_currentPage - 1) * ITEMS_PER_PAGE,
            (p_currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [pendingUsers, p_currentPage, p_search]);

    const rejectedUsersFilter = useMemo(() => {
        if (rejectedUsers === null) {
            return rejectedUsers;
        }
        let computedviewDomain = rejectedUsers;
        if (r_search) {
            computedviewDomain = computedviewDomain.filter(
                viewDomain =>
                    viewDomain.email.toLowerCase().includes(r_search.toLowerCase())
            );
        }
        setRTotalItems(computedviewDomain.length);

        return computedviewDomain.slice(
            (r_currentPage - 1) * ITEMS_PER_PAGE,
            (r_currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [rejectedUsers, r_currentPage, r_search]);


    /*pagination with search */

    const handleStatusChange = (status, status_1) => {
        setFileter(status_1);
        setCurrentPage(1);
    }

    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Manage User</div>
                    </div>
                </div>
            </div>
            <div className="customTabContainer">
                <div className='ManageUser'>
                    <div className='heading_approval'>User List</div>
                    <div className='wrapSearchSelect'>
                        <Search
                            className='searchinput'
                            searchOpen={searchOpen}
                            animateSearch={animateSearch}
                            placeholder={"Search by email"}
                            onSearch={value => {
                                setSearch(value);
                                setCurrentPage(1);
                            }}
                        />
                        <div className='SelectStatus'>
                            <label>Status</label>
                            <Dropdown className={"customDropdown"} >
                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                    {filter}
                                </Dropdown.Toggle>
                                <Dropdown.Menu className={"dropdownList"}>
                                    <Dropdown.Item eventKey="All" onClick={() => handleStatusChange("all", "All")}>All</Dropdown.Item>
                                    <Dropdown.Item eventKey="Active" onClick={() => handleStatusChange("active", "Active")}>Active</Dropdown.Item>
                                    <Dropdown.Item eventKey="Inactive" onClick={() => handleStatusChange("inactive", "Inactive")}>Inactive</Dropdown.Item>
                                </Dropdown.Menu>
                            </Dropdown>
                        </div>
                    </div>
                </div>
                <Tab.Container id="left-tabs-example" defaultActiveKey="subUser" unmountOnExit={true}>
                    <Tab.Content>
                        <Tab.Pane eventKey="subUser">
                            <div className='card op_card'>
                                <table className="table manageuser_grid mb-0">
                                    <thead>
                                        <tr className='px-3 py-4'>
                                            <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col">Email ID <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col">Company <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col" className='text-center'>Product Count <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col">Status<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                            <th scope="col" className='text-center'>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody className='border-top-0'>
                                        {allUsersFilter && allUsersFilter?.length > 0 && allUsersFilter.map((user, index) => {
                                            return (
                                                <tr>
                                                    <td className='px-3'>{user.firstname} {user.lastname}</td>
                                                    <td>{user.email}</td>
                                                    <td>{user.companyname}</td>
                                                    <td className='text-center text-theme-medium fontSemiBold'>{user.products}</td>
                                                    <td className='text-theme-medium fontSemiBold cursorActive' onClick={() => handlePopUpUser(user)}>{user.status ? "Active" : "In Active"}</td>
                                                    <td className='text-center'>
                                                        <div className="actionDropDown">
                                                            <span className="hamburIcon" onClick={() => handleGridAction(index)}>
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                                </svg>
                                                            </span>
                                                            {/* {gridAction[index] && */}
                                                            <ul className="actionPopup">
                                                                <li onClick={() => viewDetails(1, user.email)}>
                                                                    <span className={""}>
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="15.047" height="10.388" viewBox="0 0 15.047 10.388">
                                                                            <path id="Union_19" data-name="Union 19" d="M21347.029-5141.024a8.59,8.59,0,0,1-2.986-3.683l-.043-.1.043-.1a8.653,8.653,0,0,1,2.986-3.683,7.66,7.66,0,0,1,4.492-1.41,7.663,7.663,0,0,1,4.5,1.41,8.653,8.653,0,0,1,2.986,3.683l.043.1-.043.1a8.59,8.59,0,0,1-2.986,3.683,7.668,7.668,0,0,1-4.5,1.415A7.665,7.665,0,0,1,21347.029-5141.024Zm.965-6.449a6.862,6.862,0,0,0-2.418,2.669,6.882,6.882,0,0,0,2.418,2.665,6.386,6.386,0,0,0,3.527,1.04,6.389,6.389,0,0,0,3.531-1.04,6.725,6.725,0,0,0,2.4-2.665,6.706,6.706,0,0,0-2.4-2.669,6.433,6.433,0,0,0-3.531-1.04A6.43,6.43,0,0,0,21347.994-5147.473Zm1.367,4.83a2.959,2.959,0,0,1-.891-2.161,2.962,2.962,0,0,1,.891-2.166,2.959,2.959,0,0,1,2.16-.89,2.966,2.966,0,0,1,2.166.89,2.96,2.96,0,0,1,.889,2.166,2.957,2.957,0,0,1-.889,2.161,2.966,2.966,0,0,1-2.166.89A2.959,2.959,0,0,1,21349.361-5142.643Zm1.029-3.3a1.529,1.529,0,0,0-.461,1.136,1.526,1.526,0,0,0,.461,1.131,1.521,1.521,0,0,0,1.131.461,1.531,1.531,0,0,0,1.137-.461,1.526,1.526,0,0,0,.461-1.131,1.529,1.529,0,0,0-.461-1.136,1.531,1.531,0,0,0-1.137-.461A1.521,1.521,0,0,0,21350.391-5145.94Z" transform="translate(-21344 5149.998)" fill="#333" />
                                                                        </svg>
                                                                    </span>
                                                                    View
                                                                </li>
                                                                <li onClick={() => viewDetails(0, user.email)}>
                                                                    <span className={""}>
                                                                        <svg id="edit_black_24dp" xmlns="http://www.w3.org/2000/svg" width="17.577" height="17.577" viewBox="0 0 17.577 17.577">
                                                                            <path id="Path_14389" data-name="Path 14389" d="M0,0H17.577V17.577H0Z" fill="none" />
                                                                            <path id="Path_14390" data-name="Path 14390" d="M11.1,7.409l.674.674L5.139,14.718H4.465v-.674L11.1,7.409M13.737,3a.733.733,0,0,0-.513.212l-1.34,1.34L14.63,7.3l1.34-1.34a.729.729,0,0,0,0-1.033L14.257,3.212A.719.719,0,0,0,13.737,3ZM11.1,5.336,3,13.436v2.746H5.746l8.1-8.1L11.1,5.336Z" transform="translate(-0.803 -0.803)" />
                                                                        </svg>
                                                                    </span>
                                                                    Edit
                                                                </li>
                                                            </ul>
                                                            {/* } */}
                                                        </div>
                                                    </td>
                                                </tr>
                                            )
                                        }
                                        )}
                                    </tbody>
                                </table>
                                <div className='my-3 pe-3 paginationBlock'>
                                    <ThemeProvider theme={theme}>
                                        <Pagination
                                            count={Math.ceil(totalItems / ITEMS_PER_PAGE)}
                                            onChange={(page, i) => setCurrentPage(i)}
                                            shape="rounded"
                                            variant="outlined"
                                            style={{ float: 'right' }}
                                        />
                                    </ThemeProvider>
                                </div>
                            </div>
                        </Tab.Pane>
                        <Tab.Pane eventKey="pending">
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                        <div className='heading_approval headBold'>No. of License Pending Approvals</div>
                                        <Search
                                            className='searchinput'
                                            searchOpen={searchOpen}
                                            animateSearch={animateSearch}
                                            placeholder={"Search by"}
                                            onSearch={value => {
                                                setPSearch(value);
                                                setPCurrentPage(1);
                                            }}
                                        />
                                    </div>
                                    <table className="table manageuser_grid mb-0">
                                        <thead>
                                            <tr className='px-3 py-4'>
                                                <th scope="col">Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Email ID <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Product Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Plan Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Plan Duration <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Request Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col" className='text-center'>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody className='border-top-0'>
                                            {pendingUsersFilter && pendingUsersFilter?.length > 0 && pendingUsersFilter.map(
                                                (user, index) =>
                                                    <tr>
                                                        <td>{user.first_name} {user.last_name}</td>
                                                        <td>{user.email}</td>
                                                        <td className='text-theme-medium'>{user.product_name} {user.sub_product !== '-' && "- " + user.sub_product}</td>
                                                        <td className='text-theme-medium' onClick={() => handleRequestPlanDetails(user.request_id)}>{user.plan_name}</td>
                                                        <td>{user.plan_duration}</td>
                                                        <td>{user.request_type}</td>
                                                        <td className='text-center'>
                                                            <div className="actionDropDown">
                                                                <span className="hamburIcon" onClick={() => handleGridAction(index)}>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                                                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                                                    </svg>
                                                                </span>
                                                                {gridAction[index] &&
                                                                    <ul className="actionPopup pendingDroppop" onClick={() => handleGridAction(index)}>
                                                                        {user.customize_plan ?
                                                                            <li onClick={() => handleApprovePending(user.request_id, user)}>
                                                                                View & Issue License
                                                                            </li>
                                                                            :
                                                                            <li onClick={() => handleApprovePopUp(user.request_id)}>
                                                                                Approve
                                                                            </li>
                                                                        }

                                                                        <li onClick={() => handleRejectPopUp(user.request_id)}>
                                                                            Reject
                                                                        </li>
                                                                    </ul>
                                                                }
                                                            </div>
                                                        </td>
                                                    </tr>
                                            )}
                                        </tbody>
                                    </table>
                                    <div className='my-3 pe-3 paginationBlock'>
                                        <ThemeProvider theme={theme}>
                                            <Pagination
                                                count={Math.ceil(p_totalItems / ITEMS_PER_PAGE)}
                                                onChange={(page, i) => setPCurrentPage(i)}
                                                shape="rounded"
                                                variant="outlined"
                                                style={{ float: 'right' }}
                                            />
                                        </ThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </Tab.Pane>
                        <Tab.Pane eventKey="rejected" >
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                        <div className='heading_approval headBold'># of License Rejected Users</div>
                                        <Search
                                            className='searchinput'
                                            searchOpen={searchOpen}
                                            animateSearch={animateSearch}
                                            placeholder={"Search by"}
                                            onSearch={value => {
                                                setRSearch(value);
                                                setRCurrentPage(1);
                                            }}
                                        />
                                    </div>
                                    <table className="table manageuser_grid mb-0">
                                        <thead>
                                            <tr className='px-3 py-4'>
                                                <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Email ID <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Product Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Request Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Rejected Message</th>
                                            </tr>
                                        </thead>
                                        <tbody className='border-top-0'>
                                            {rejectedUsersFilter && rejectedUsersFilter?.length > 0 && rejectedUsersFilter?.map(
                                                (user, index) =>
                                                    <tr>
                                                        <td>{user.first_name} {user.last_name}</td>
                                                        <td>{user.email}</td>
                                                        <td className='text-theme-medium'>{user.product_name} {user.sub_product !== '-' && "- " + user.sub_product}</td>
                                                        <td>{user.request_type}</td>
                                                        <td>
                                                            <div className="planFeature"
                                                                onClick={() => { getCommentDetails(user.request_id); setShowPopover(!showPopover); setShowPopoverId(index) }}
                                                            >
                                                                <span>{"View"}</span>
                                                                {showPopoverId === index && showPopover &&
                                                                    <Popover id="popover-basic" className="featuresPop">
                                                                        <Popover.Header as="h3">
                                                                            <span>Reject Comments</span>
                                                                            <span onClick={() => (setShowPopover(false))}>
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                                                                                    <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                                                                </svg>
                                                                            </span>
                                                                        </Popover.Header>
                                                                        <Popover.Body>
                                                                            <ul className="featuresListinpop">
                                                                                {message &&
                                                                                    <span>{message.action_reason}</span>
                                                                                }
                                                                            </ul>
                                                                        </Popover.Body>
                                                                    </Popover>
                                                                }
                                                            </div>
                                                        </td>
                                                    </tr>
                                            )}
                                        </tbody>
                                    </table>
                                    <div className='my-3 pe-3 paginationBlock'>
                                        <ThemeProvider theme={theme}>
                                            <Pagination
                                                count={Math.ceil(r_totalItems / ITEMS_PER_PAGE)}
                                                onChange={(page, i) => setRCurrentPage(i)}
                                                shape="rounded"
                                                variant="outlined"
                                                style={{ float: 'right' }}
                                            />
                                        </ThemeProvider>
                                    </div>
                                </div>
                            </div>
                        </Tab.Pane>
                    </Tab.Content>
                </Tab.Container>
            </div>
            <Modal
                show={show}
                size="md"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className="subscriptionModal pendingApprovalModal"
                onHide={handleClose}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        {requestType ? "Confirm Request" : "Rejection Note"}
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {requestType &&
                        <p className="text-center">Are you sure, you want to approve</p>
                    }
                    <Form.Group className="my-3" controlId="exampleForm.ControlInput1">
                        <Form.Label className="startLabel">
                            {requestType ?
                                <span>Comments</span>
                                :
                                <span>Reject Reason</span>
                            }
                        </Form.Label>
                        <Form.Control as="textarea" rows={2} value={comments} id='comments' onChange={(e) => handleFreetext(e)} />
                        <Form.Text className="d-flex subErors">
                            {commentsErr}
                        </Form.Text>
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                    <Button className="secondaryBtn" onClick={handleClose}>Cancel</Button>
                    {requestType ?
                        <Button className="primaryBtn" onClick={() => handleApproveRequest()}>Approve</Button>
                        :
                        <Button className="primaryBtn" onClick={() => handleRejectRequest()}>Reject</Button>
                    }
                </Modal.Footer>
            </Modal>
            <Modal
                show={showTwo}
                size="md"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className="subscriptionModal"
                onHide={handleCloseTwo}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Plan Details
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {requestPlanDetail &&
                        <>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Plan Name: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{requestPlanDetail.plan_name}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span># of Users: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{requestPlanDetail.user_slot}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Duration: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{requestPlanDetail.plan_duration}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Plan Discount: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{requestPlanDetail.plan_discount}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Total Price: </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>$ {requestPlanDetail.total_price}</span>
                                </Form.Label>
                            </Form.Group>
                        </>
                    }
                </Modal.Body>
                <Modal.Footer>
                    <Button className="primaryBtn" onClick={handleCloseTwo}>Ok</Button>
                </Modal.Footer>
            </Modal>
            <Modal
                show={showThree}
                size="md"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className="subscriptionModal"
                onHide={handleCloseThree}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        User Details
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {userData &&
                        <>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>First Name </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{userData.firstname}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Last name </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{userData.lastname}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Email ID </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <span>{userData.email}</span>
                                </Form.Label>
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>
                                    <span>Status </span>
                                </Form.Label>
                                <Form.Label className="viewLabel">
                                    <Form.Check
                                        type="switch"
                                        id="status"
                                        checked={userData.status}
                                        onClick={(e) => handleStaheStatus(e)}
                                    />
                                </Form.Label>
                            </Form.Group>
                        </>
                    }
                </Modal.Body>
                <Modal.Footer>
                    <Button className="secondaryBtn" onClick={handleCloseThree}>Cancel</Button>
                    <Button className="primaryBtn" onClick={() => handleUpdasteUserStatus()}>Update</Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default SubscribedUsersList;