import React, { useState, useEffect } from 'react';
import '../platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom/cjs/react-router-dom';
import { getAllproducts, changeOwnership, setProductAction, getUserProductPlan } from "../../../endpoints/subscription/manageuser";
import { toast } from 'react-toastify';
import { useHistory } from "react-router-dom";

const EditSubscribedUser = (props) => {
    const history = useHistory();
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const UserhandleShow = () => UsersetShow(true);
    const [Usershow, UsersetShow] = useState(false);
    const UserhandleClose = () => UsersetShow(false);

    const [userAllProduct, setUserAllProduct] = useState(null);
    const [changeOwner, setChangeOwner] = useState({
        current_owner: "",
        new_owner: ""
    })

    const [changeOwnerError, setChangeOwnerError] = useState({
        current_owner: null,
        new_owner: null
    })

    const [changeSubRequest, setChangeSubRequest] = useState({
        "status": null,
        "comments": ""
    })

    const [changeSubRequestErr, setChangeSubRequestErr] = useState({
        "status": null,
        "comments": null
    })

    useEffect(() => {
        if (props.location.state) {
            if (props.location.state.planId) {
                getUserForPlan(props.location.state.email, props.location.state.planId);
            } else {
                getUserAllproducts(props.location.state.email);
            }

        }
    }, []);

    const getUserAllproducts = async (email) => {
        let response = await getAllproducts(email);
        if (response.status === 200) {
            setUserAllProduct(response.data);
            setChangeOwner({ ...changeOwner, current_owner: response.data.email });
            setChangeSubRequest({ ...changeSubRequest, status: response.data.products[0].product_plan_details[0].status });
        }
    }

    const getUserForPlan = async (email, planId) => {
        let response = await getUserProductPlan(email, planId);
        if (response.status === 200) {
            setUserAllProduct(response.data);
            setChangeOwner({ ...changeOwner, current_owner: response.data.email });
            setChangeSubRequest({ ...changeSubRequest, status: response.data.products[0].product_plan_details[0].status });
        }
    }

    const handleChangeOwner = async (email) => {

        if (changeOwner.current_owner === "") {
            setChangeOwnerError({ ...changeOwnerError, current_owner: "Current Owner Email is Required" });
            return;
        } else if (changeOwner.new_owner === "") {
            setChangeOwnerError({ ...changeOwnerError, current_owner: null, new_owner: "New Owner Email is Required" });
            return;
        }

        setChangeOwnerError({ ...changeOwnerError, current_owner: null, new_owner: null });
        let response = await changeOwnership(changeOwner);
        if (response.status === 200) {
            handleBack();
            toast.success(response.data.message);
            handleClose();
        } else {

            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);

            } else {
                toast.error("Error in request");
            }
        }
    }

    const handleFreetext = (e) => {

        let name = e.target.id;
        let value = e.target.value;

        setChangeOwner({ ...changeOwner, [name]: value });
    }

    const handleSetStatus = (status) => {

        setChangeSubRequest({ ...changeSubRequest, "status": status, "comments": "" });
    }

    const handleChangePlanStatus = (e) => {
        let name = e.target.id;
        let value = e.target.value;

        if (name === "status") {
            setChangeSubRequest({ ...changeSubRequest, status: e.target.checked });
        } else {
            setChangeSubRequest({ ...changeSubRequest, comments: value });
        }
    }

    const handleSavePlanStatus = async (subscribed_id) => {

        if (changeSubRequest.comments === "") {
            setChangeSubRequestErr({ ...changeSubRequestErr, comments: "Enter Comment" });
            return;
        }
        setChangeSubRequestErr({ ...changeSubRequestErr, comments: null });
        let response = await setProductAction(changeSubRequest, subscribed_id);
        if (response.status === 200) {
            
            if (props.location.state.planId) {
                history.goBack();
            } else {
                getUserAllproducts(props.location.state.email);
            }
            toast.success(response.data.message);
        } else {
            if (response.Error.response.data !== "") {
                toast.error(response.Error.response.data.errors[0].message);
            } else {
                toast.error("Error in request");
            }
        }
    }

    const handleBack = () => {
        history.push({
            pathname: "/SubscribedUsersList"
        });
    }


    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Edit License Products</div>
                    </div>
                    <div className="d-flex gap-3">
                        <button className="secondaryBtn" onClick={handleShow}>
                            <span>Change Subscription Owner</span>
                        </button>
                        <Modal
                            show={show}
                            size="md"
                            aria-labelledby="contained-modal-title-vcenter"
                            centered
                            className="subscriptionModal"
                            onHide={handleClose}
                        >
                            <Modal.Header closeButton>
                                <Modal.Title id="contained-modal-title-vcenter">
                                    Change Subscription Ownership
                                </Modal.Title>
                            </Modal.Header>
                            <Modal.Body>
                                <Form>
                                    <Form.Group className="changeOwnerEmail">
                                        <Form.Control type="email" value={changeOwner.current_owner} id='current_owner' placeholder='Current Owner' disabled />
                                        <Form.Text className="d-flex subErors">
                                            {changeOwnerError.current_owner}
                                        </Form.Text>
                                    </Form.Group>
                                    <Form.Group className="changeOwnerEmail">
                                        <Form.Control type="email" value={changeOwner.new_owner} id='new_owner' onChange={(e) => handleFreetext(e)} placeholder='Enter New Owner Email ID' />
                                        <Form.Text className="d-flex subErors">
                                            {changeOwnerError.new_owner}
                                        </Form.Text>
                                    </Form.Group>
                                </Form>
                            </Modal.Body>
                            <Modal.Footer>
                                <Button className="secondaryBtn" onClick={handleClose}>Cancel</Button>
                                <Button className="primaryBtn" onClick={() => handleChangeOwner()}>Update</Button>
                            </Modal.Footer>
                        </Modal>
                    </div>
                </div>
            </div>
            <div className="customTabContainer">
                {userAllProduct && userAllProduct.products?.length > 0 &&
                    <Tab.Container id="left-tabs-example" defaultActiveKey={userAllProduct && userAllProduct.products[0].main_product_name} unmountOnExit={true}>
                        <div className='wrapperNewTabDesign'>
                            <div className='leftTab'>
                                <Nav>
                                    {userAllProduct.products.map((product, i) => (
                                        <Nav.Item key={`main-key-${i}`}>
                                            <Nav.Link eventKey={product.main_product_name} onClick={() => handleSetStatus(product.product_plan_details[0].status)}>{product.main_product_name} {product.product_plan_details.length > 1 && <span className="count">{product.product_plan_details && product.product_plan_details.length}</span>}</Nav.Link>
                                        </Nav.Item>
                                    ))}
                                </Nav>
                            </div>
                            <div className='RightContent'>
                                <Tab.Content>
                                    {userAllProduct.products.map((product, i) => (
                                        <Tab.Pane key={`inner-key-${i}`} eventKey={product.main_product_name} className={`box-wrapper ${product.sub_product ? "innerTabContainer" : ""}`}>
                                            {product.sub_product ?
                                                <Tab.Container id="left-tabs-example" defaultActiveKey={product.product_plan_details[0].product_name} unmountOnExit={true}>
                                                    <Nav className="innerTabList">
                                                        {product.product_plan_details.map((innertabslist, i) => (
                                                            <Nav.Item key={i}>
                                                                <Nav.Link eventKey={innertabslist.product_name} onClick={() => handleSetStatus(innertabslist.status)}>{innertabslist.product_name}</Nav.Link>
                                                            </Nav.Item>
                                                        ))}
                                                    </Nav>
                                                    <Tab.Content>
                                                        {product.product_plan_details.map((innertabCnt, i) => (
                                                            <Tab.Pane eventKey={innertabCnt.product_name}>
                                                                <div className="editSubscriptionForm">
                                                                    <div className="formWrapper">
                                                                        <Form className={"py-4 inlineForm fullWidth"}>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>First Name</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={userAllProduct.first_name} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Email ID</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={userAllProduct.email} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Product Name</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={innertabCnt.product_name} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span># of Users</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={innertabCnt.plan_user_slots_purchased} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>License End Date</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={innertabCnt.plan_ends_on} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Comment</span>
                                                                                </Form.Label>
                                                                                <div className="commentError">
                                                                                    <Form.Control type="text" id="comments" value={changeSubRequest.comments} onChange={(e) => handleChangePlanStatus(e)} />
                                                                                    <Form.Text className="d-flex subErors">
                                                                                        {changeSubRequestErr.comments}
                                                                                    </Form.Text>
                                                                                </div>
                                                                            </Form.Group>
                                                                        </Form>
                                                                    </div>
                                                                    <div className="formWrapper">
                                                                        <Form className={"py-4 inlineForm fullWidth"}>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Last Name</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={userAllProduct.last_name} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Company Name</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={userAllProduct.company_name} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Plan Duration</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={innertabCnt.plan_duration + " Months"} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>License Start Date</span>
                                                                                </Form.Label>
                                                                                <Form.Control type="text" value={innertabCnt.plan_starts_on} disabled />
                                                                            </Form.Group>
                                                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                                <Form.Label>
                                                                                    <span>Status</span>
                                                                                </Form.Label>
                                                                                <Form.Check
                                                                                    type="switch"
                                                                                    id="status"
                                                                                    checked={changeSubRequest.status}
                                                                                    onClick={(e) => handleChangePlanStatus(e)}
                                                                                />
                                                                            </Form.Group>

                                                                        </Form>
                                                                    </div>
                                                                    {props.location.state && props.location.state.planId ?
                                                                        <div className="subscriptionBtnWrapper">
                                                                            <Button className="secondaryBtn" onClick={() => history.goBack()}>Back</Button>
                                                                            <Button className="primaryBtn" onClick={() => handleSavePlanStatus(innertabCnt.subscription_id)}>Ok</Button>
                                                                        </div>
                                                                        :
                                                                        <div className="subscriptionBtnWrapper">
                                                                            <Button className="secondaryBtn" onClick={() => handleBack()} >Cancel</Button>
                                                                            <Button className="primaryBtn" onClick={() => handleSavePlanStatus(innertabCnt.subscription_id)}>Update</Button>
                                                                        </div>
                                                                    }
                                                                </div>
                                                            </Tab.Pane>
                                                        ))}
                                                    </Tab.Content>
                                                </Tab.Container>
                                                :
                                                <div>
                                                    {/* <div className="ChooseAdmin">
                                                        <a onClick={UserhandleShow} className="">Change Product Admin</a>
                                                    </div> */}
                                                    <div className="editSubscriptionForm">
                                                        {product.product_plan_details.map((innertabCnt, i) => (
                                                            <>
                                                                <div className="formWrapper">
                                                                    <Form className={"py-4 inlineForm fullWidth"}>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>First Name</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={userAllProduct.first_name} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>Email ID</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={userAllProduct.email} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>Product Name</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={innertabCnt.product_name} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span># of Users</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={innertabCnt.plan_user_slots_purchased} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>License End Date</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={innertabCnt.plan_ends_on} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>Comment</span>
                                                                            </Form.Label>
                                                                            <div className="commentError">
                                                                                <Form.Control type="text" id="comments" value={changeSubRequest.comments} onChange={(e) => handleChangePlanStatus(e)} />
                                                                                <Form.Text className="d-flex subErors">
                                                                                    {changeSubRequestErr.comments}
                                                                                </Form.Text>
                                                                            </div>
                                                                        </Form.Group>
                                                                    </Form>
                                                                </div>
                                                                <div className="formWrapper">
                                                                    <Form className={"py-4 inlineForm fullWidth"}>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>Last Name</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={userAllProduct.last_name} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>Company Name</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={userAllProduct.company_name} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>Plan Duration</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={innertabCnt.plan_duration + " Months"} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>License Start Date</span>
                                                                            </Form.Label>
                                                                            <Form.Control type="text" value={innertabCnt.plan_starts_on} disabled />
                                                                        </Form.Group>
                                                                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                                            <Form.Label>
                                                                                <span>Status</span>
                                                                            </Form.Label>
                                                                            <Form.Check
                                                                                type="switch"
                                                                                id="status"
                                                                                checked={changeSubRequest.status}
                                                                                onClick={(e) => handleChangePlanStatus(e)}
                                                                            />
                                                                        </Form.Group>
                                                                    </Form>
                                                                </div>
                                                                {props.location.state && props.location.state.planId ?
                                                                    <div className="subscriptionBtnWrapper">
                                                                        <Button className="secondaryBtn" onClick={() => history.goBack()}>Back</Button>
                                                                        <Button className="primaryBtn" onClick={() => handleSavePlanStatus(innertabCnt.subscription_id)}>Update</Button>
                                                                    </div>
                                                                    :
                                                                    <div className="subscriptionBtnWrapper">
                                                                        <Button className="secondaryBtn" onClick={() => handleBack()} >Cancel</Button>
                                                                        <Button className="primaryBtn" onClick={() => handleSavePlanStatus(innertabCnt.subscription_id)}>Update</Button>
                                                                    </div>
                                                                }
                                                            </>
                                                        )
                                                        )}
                                                    </div>
                                                </div> 
                                            }
                                        </Tab.Pane>
                                    ))
                                    }
                                </Tab.Content>
                            </div>
                        </div> 
                    </Tab.Container>
                }
            </div>
            {/* <div className={""}>
                <Modal
                    show={Usershow}
                    size="md"
                    aria-labelledby=""
                    centered
                    className="subscriptionModal CreateUser"
                    onHide={UserhandleClose}
                >
                    <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">
                            Change Product Admin
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form>
                            <Form.Group className='mb-3'>
                                <Form.Label>
                                    <span>First Name</span>
                                </Form.Label>
                                <Form.Control type="text" placholder="Enter first name"/>
                            </Form.Group>
                            <Form.Group className='mb-3'>
                                <Form.Label>
                                    <span>Last Name</span>
                                </Form.Label>
                                <Form.Control type="text" placholder="Enter last name"/>
                            </Form.Group>
                            <Form.Group className='mb-3'>
                                <Form.Label>
                                    <span>Email</span>
                                </Form.Label>
                                <Form.Control type="text" placholder="Enter email address"/>
                            </Form.Group>
                            <Form.Group>
                                <Form.Label>
                                    <span>Comment</span>
                                </Form.Label>
                                <Form.Control as="textarea" rows={3} />
                            </Form.Group>
                        </Form>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button className="secondaryBtn" onClick={UserhandleClose}>Cancel</Button>
                        <Button className="primaryBtn">Update</Button>
                    </Modal.Footer>
                </Modal> 
            </div> */}
        </div>
    )
}

export default EditSubscribedUser