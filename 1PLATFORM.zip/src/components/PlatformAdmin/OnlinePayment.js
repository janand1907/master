import React, { useState, useEffect } from 'react';
import './platformadmin.scss';
import { Form, Modal, Tab, Nav, Tabs, Dropdown, Popover, Button } from 'react-bootstrap';

const OnlinePayment = ({ paymentOptions, handleOnlineChange, ...props }) => {

    return (
        <div className='col-md-9 paymentLists'>
            <div className="paymentcard">
                <h3 className="payTitle">Online Payment</h3>
                <Form>
                    <ul className="paymentTypes">
                        {paymentOptions._payment_options.map((type) =>
                            <li>
                                <Form.Check
                                    type={'checkbox'}
                                    label={""}
                                    id={type.payment_option_id}
                                    name={type.payment_option}
                                    checked={type.selected}
                                    onChange={(e) => handleOnlineChange(e)}
                                />
                                <span>{type.payment_option}</span>
                            </li>
                        )}
                    </ul>
                </Form>
            </div>
        </div>
    )
}
export default OnlinePayment;