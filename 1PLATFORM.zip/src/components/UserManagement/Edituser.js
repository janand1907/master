import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import './Edituser.scss';
import profilePicture from '../../assets/images/usermanagement/profilepicture.png'
import btnEdit from '../../assets/images/btnEdit.svg'
import { useForm, Controller } from "react-hook-form";
import Select from 'react-select'
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import { getUsersInOrg, getRoles, getOnePlatformProducts, activeLicense, getSearchUser, getLicenseValidation } from '../../endpoints/gateway';
import { validateIcon } from '../../Icons/icons';
import moment from 'moment';

const Edituser = ({ selectedUser, Toggle, role }) => {

    let CompanyList = [
        { value: 'Qassure', label: 'Qassure' },
        { value: 'Proov', label: 'Proov' },
        { value: 'Flatworld', label: 'Flatworld' }
    ]

    const [allroles, setallroles] = useState([])
    const [allproducts, setallproducts] = useState([])

    const [userEmail, setuserEmail] = useState()
    //const userDetails = useSelector(state => state.user.userInfo.allInfo);
    const personalSchema = Yup.object().shape({
        productId: Yup.string()
            .required('Product is required'),
    });

    useEffect(() => {
        //fetchroles()
        // fetchproducts()

        if (selectedUser != 0) {

            const fields = ['userEmail', 'productId'];
            fields.forEach(field => setValue(field, selectedUser[field]));
        }
        else {
            //fetchUsers()
        }


    }, [])

    const [licenseKey, setLicenseKey] = useState("");
    const [licenseMsg, setLicenseMsg] = useState("");
    const [companyName, setCompanyName] = useState("");
    const [companyId, setCompanyId] = useState("");
    const [companyDetails, setCompanydetails] = useState([]);
    const [userName, setUserName] = useState("");
    const [userId, setUserId] = useState("");
    const [userDetails, setUserDetails] = useState([]);
    const [startDate, setStartDate] = useState("");
    const [endDate, setEndDate] = useState("");
    const [companyMsg, setCompanyMsg] = useState("");
    const [userMsg, setUserMsg] = useState("");

    const handleLicenseKey = async () => {
        if (licenseKey === "") {
            setLicenseMsg("License key is required");
        } else {
            setLicenseMsg("");
            let response = await getLicenseValidation(1, licenseKey);
            if (response.data) {
                let date = response.data;
                setStartDate(date.created + "000");
                setEndDate(date.expires + "000");
            }
        }
    }
    const fetchUsers = async () => {
        let response = await getUsersInOrg(userDetails.userEmail)
        setuserEmail(response.data)

    }

    const fetchroles = async () => {
        let response = await getRoles()
        if (role == 'productadmin') {
            let responsedata = response.data.filter(val => val.roleName == 'Member')
            setallroles(responsedata)
        }
        else {
            setallroles(response.data)
        }


    }
    const fetchproducts = async (id) => {
        let response = await getOnePlatformProducts()
        setallproducts(response.data)

    }
    const { register,
        handleSubmit, setValue,
        formState: { errors, isValid }, control, reset } = useForm({
            resolver: yupResolver(personalSchema), mode: 'onChange'
        });


    const handleGetCompany = async (value) => {
        setCompanyName(value);
        if (value === "") {
            setCompanydetails([]);
        } else {
            let response = await getSearchUser(value)
            setCompanydetails(response.data);
        }
    }

    // const handleGetUser = async (value) => {
    //     setUserName(value);
    //     if (value === "") {
    //         setUserDetails([]);
    //     } else {
    //         let response = await getSubscriptionUserDetails(`/getAllUsers/${companyId}/${value}`)
    //         setUserDetails(response.data);
    //     }
    // }

    const onSubmit = async (data) => {
        if (companyId === "") {
            setCompanyMsg("Company is required");
            return;
        } else if (licenseKey === "") {
            setLicenseMsg("License key is required");
            return;
        }

        

        let payload = {
            product_id: data.productId ,
            license: licenseKey,
            email: companyId
        }

        let response = await activeLicense(payload)
        toast.success(response.data.message)

        Toggle()
    }
    return (
        <div className='custom_modalContainer'>
            <div className="envHealthCheck_modal card">
                <div className="modal_header card-header m-0">
                    <div className="modal_header-title">{selectedUser == 0 ? 'Add ' : 'Edit '} User Subscription</div>
                    <button className="close" onClick={() => Toggle()}><i class="bi bi-x"></i></button>
                </div>
                <div className='modal_body card-body'>
                    <div className='editUser'>
                        <form className="profile_update" onSubmit={handleSubmit(onSubmit)}>
                            <div className='row mx-4'>
                                <div className='col-md-4 text-center'>
                                    <div className='profilePicture_panel my-4'>
                                        <img className='profile_picture' src={profilePicture} alt='profileImage' />
                                    </div>
                                </div>
                                <div className='col-md-8'>
                                    <div className="editUser_input">
                                        <label htmlFor="text" className="col-md-4 text-end">Email Id</label>
                                        <div className='op_input_block my-1 w-100'>
                                            <input type="text" className='form-control' value={companyName} onChange={(e) => { handleGetCompany(e.target.value) }} placeholder='Search by user name / email'/>
                                            {companyDetails.length > 0 &&
                                                <ul className='company_dropdown shadow'>
                                                    {companyDetails?.map((company, index) => {
                                                        return (
                                                            <li onClick={() => { setCompanyId(company.email); setCompanyName(company.email); setCompanydetails([]); fetchproducts(company.email); setCompanyMsg(""); }}>{company.email}</li>
                                                        )
                                                    })}
                                                </ul>
                                            }            
                                            <span className="input_error_msg">{companyMsg !== "" && <span>{companyMsg}</span>}</span>
                                        </div>
                                    </div>
                                    <div className="editUser_input">
                                        <label htmlFor="text" className="col-md-4 text-end">Products</label>
                                        <div className='op_input_block my-1 w-100'>
                                            <Controller
                                                name="productId"
                                                control={control}
                                                render={({ field: { onChange, value } }) => <Select
                                                    value={allproducts.find((c) => c.product_id === value)}
                                                    onChange={(val) => { onChange(val.product_id) }}
                                                    options={allproducts}
                                                    getOptionLabel={(option) => option.product_name}
                                                    getOptionValue={(option) => option.product_id}
                                                    style={{ width: "100%" }}
                                                    className='form-select p-0 border-0'
                                                />}
                                                rules={{ required: true }}
                                            />
                                            <span className="input_error_msg">{errors.productId && <span>{errors.productId?.message}</span>}</span>
                                        </div>
                                    </div>
                                    <div className="editUser_input">
                                        <label htmlFor="text" className="col-md-4 text-end">License Key</label>
                                        <div className='col d-flex align-items-center gap-1'>
                                            <div className='op_input_block my-1 w-100'>
                                                <input type="text" className='form-control' value={licenseKey} onChange={(e) => setLicenseKey(e.target.value)} />
                                                <span className="input_error_msg">{licenseMsg !== "" && <span>{licenseMsg}</span>}</span>
                                            </div>
                                            <a className='btn validate_btn' onClick={() => { handleLicenseKey() }}>{validateIcon}</a>
                                        </div>
                                    </div>
                                    <div className="editUser_input">
                                        <label htmlFor="text" className="col-md-4 text-end">Valid upto</label>
                                        <div className='col d-flex align-items-center gap-1'>
                                            <div className='op_input_block my-1 w-100'>
                                                <input type='text' className='form-control' value={moment(parseInt(startDate)).format("DD/MM/YYYY hh:mm:ss")} disabled />
                                            </div>
                                            <div className='op_input_block my-1 w-100'>
                                                <input type='text' className='form-control' value={moment(parseInt(endDate)).format("DD/MM/YYYY hh:mm:ss")} disabled />
                                            </div>
                                        </div>
                                    </div>
                                    {/* <div className="editUser_input">
                                        <label htmlFor="text" className="col-md-4 text-end ">Account Status</label>
                                        <div className="form-check form-switch">
                                            <input className="form-check-input" {...register("status")} type="checkbox" id="flexSwitchCheckChecked" />
                                            <label className="form-check-label" htmlFor="flexSwitchCheckChecked">Active</label>
                                        </div>
                                    </div> */}
                                </div>
                                <div className='col-md-12 text-center'>
                                    {/* <button className='btn btn_update' onClick={() => Toggle()}>Cancel</button> */}
                                    <button className='btn btn_update' type="submit">{selectedUser == 0 ? 'Add user subscription' : 'Update subscribed user'}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default Edituser