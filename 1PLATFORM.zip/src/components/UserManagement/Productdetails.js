import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useLocation } from "react-router-dom";
import './Productdetails.scss';
import { useSelector } from 'react-redux';
import quantifyLogo from '../../assets/images/products/quantify.png';
import userGroup from '../../assets/images/usermanagement/usergroup.png'
import user1 from '../../assets/images/usermanagement/users/user1.png';
import { backBtnIcon } from '../../Icons/icons';
import { getMappedUsers, getOnePlatformProducts, subscriptionPendingDetails } from '../../endpoints/gateway';
import moment from 'moment';

const Productdetails = (props) => {

    const dateIcon = <svg id="today_black_24dp" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
        <path id="Path_13531" data-name="Path 13531" d="M0,0H20V20H0Z" fill="none" />
        <path id="Path_13532" data-name="Path 13532" d="M17.885,2.783h-.93V1H15.094V2.783H7.652V1H5.791V2.783h-.93A1.823,1.823,0,0,0,3,4.566V17.048a1.823,1.823,0,0,0,1.861,1.783H17.885a1.828,1.828,0,0,0,1.861-1.783V4.566A1.828,1.828,0,0,0,17.885,2.783Zm0,14.265H4.861V8.132H17.885Zm0-10.7H4.861V4.566H17.885ZM6.721,9.915h4.652v4.458H6.721Z" transform="translate(-1.373 -0.458)" fill='#757575' />
    </svg>

    const eye = <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#0E699C" class="bi bi-eye" viewBox="0 0 16 16">
        <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z" />
        <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z" />
    </svg>

    const edit = <svg xmlns="http://www.w3.org/2000/svg" width="13.512" height="14.771" viewBox="0 0 13.512 14.771">
        <path id="border_color_FILL0_wght400_GRAD0_opsz48" d="M4,19.045V17H17.512v2.044Zm1.385-3.834V12.964l6.3-6.3,2.246,2.246-6.3,6.3ZM6.4,14.2h.76l5.32-5.32-.76-.76L6.4,13.437Zm8.276-6.03L12.428,5.921,13.847,4.5a.573.573,0,0,1,.422-.228.646.646,0,0,1,.473.228L16.059,5.82a.654.654,0,0,1,.22.464.709.709,0,0,1-.186.464ZM6.4,14.2Z" transform="translate(-4 -4.274)" fill="#0e699c" />
    </svg>

    const del = <svg xmlns="http://www.w3.org/2000/svg" width="12.537" height="14.52" viewBox="0 0 12.537 14.52">
        <g id="Component_100_22" data-name="Component 100 – 22" transform="translate(0.25 0.25)">
            <path id="Path_14027" data-name="Path 14027" d="M601.222,838.493c-.992,0-1.985.005-2.977,0a1.3,1.3,0,0,1-1.408-1.352q-.352-4.734-.707-9.468c-.025-.343-.041-.621-.512-.569a.39.39,0,0,1-.423-.453c.02-.3.222-.423.515-.421.843.006,1.687-.009,2.53.009.291.006.395-.055.4-.382a1.263,1.263,0,0,1,1.373-1.371c.81-.008,1.621-.011,2.431,0a1.258,1.258,0,0,1,1.339,1.353c0,.364.141.4.433.4.81-.015,1.621,0,2.431-.008.328,0,.586.1.583.455,0,.325-.255.468-.556.431-.37-.046-.347.208-.365.439q-.218,2.87-.433,5.741c-.1,1.309-.194,2.619-.3,3.928a1.279,1.279,0,0,1-1.332,1.272C603.24,838.5,602.231,838.493,601.222,838.493Zm-.008-11.377c-1.29,0-2.579.006-3.869,0-.276,0-.413.024-.385.377q.381,4.73.721,9.463c.037.525.259.688.753.683,1.785-.019,3.571-.008,5.357-.008.875,0,.9-.018.969-.925.233-3.054.458-6.108.7-9.161.025-.321-.032-.438-.377-.432C603.793,827.128,602.5,827.116,601.213,827.116Zm-.011-.885c.446,0,.894-.027,1.337.008.359.028.414-.135.384-.436-.034-.343-.238-.454-.539-.454h-1.437c-.33,0-.661-.013-.991.005-.391.022-.466.289-.459.635.008.407.3.222.466.232C600.375,826.248,600.789,826.231,601.2,826.231Z" transform="translate(-595.194 -824.476)" fill="#0e699c" stroke="#0e699c" stroke-width="0.5" />
            <path id="Path_2435" data-name="Path 2435" d="M639.29,862.35c0,.878,0,1.756,0,2.633,0,.227-.014.46-.416.456s-.406-.239-.405-.465q0-2.616,0-5.231c0-.232.03-.46.419-.457s.406.238.4.466C639.287,860.618,639.29,861.484,639.29,862.35Z" transform="translate(-633.911 -853.789)" fill="#0e699c" stroke="#0e699c" stroke-width="0.5" />
            <path id="Path_2436" data-name="Path 2436" d="M665.261,862.4c0,.866,0,1.732,0,2.6,0,.23-.019.459-.418.454s-.406-.241-.406-.465q0-2.616,0-5.232c0-.232.032-.46.422-.455s.4.239.4.467C665.257,860.645,665.261,861.523,665.261,862.4Z" transform="translate(-657.784 -853.803)" fill="#0e699c" stroke="#0e699c" stroke-width="0.5" />
        </g>
    </svg>



    
    const [productDetails, setproductDetails] = useState();
    const [expiryOn, setexpiryOn] = useState();
    const [allMemebers, setallMembers] = useState()
    const userDetails = useSelector(state => state.user.userInfo.allInfo);
    useEffect(() => {
        fetchSpecficproduct();
        //fetchallMemebers();
        fetchMappedUsers();
    }, [])


    const fetchMappedUsers = async () => {    
        let response = await subscriptionPendingDetails(2);
        setallMembers(response.data)
        //setfilterData(response.data)
    }

    const fetchSpecficproduct = async () => {
        let response = await getOnePlatformProducts()

        //props.match.params.productId
        if(response.data[0].product_id == props.match.params.productId){
            setproductDetails(response.data[0])
            calculateDateDifference(response.data[0])
        }else{
            setproductDetails(response.data[1])
            calculateDateDifference(response.data[1])
        }
        
    }

    const fetchallMemebers = async () => {
        let response = await getMappedUsers(userDetails.userEmail)
        setallMembers(response.data)

    }

    const calculateDateDifference = (data) => {
        
        const date1 = new Date()
        const date2 = new Date(parseInt(data.expires+"000"));
        const diffTime = Math.abs(date2 - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        setexpiryOn(diffDays);

    }


    return (
        <div className='productDetails'>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <Link to="/platformadmin" className='btn btn_light'>{backBtnIcon} </Link>
                        <div className='h3'>Product Details</div>
                    </div>
                    {/* <div className='d-flex align-items-center gap-3'>
                        <Link to='/inviteuser' className='btn btn_outline'>Invite Users</Link>
                        <Link to='/manageuser' className='btn btn_primary'>Manage Users</Link>
                    </div> */}
                </div>
            </div>
            <div className='row g-3 my-1'>
                <div className='col-lg-5 col-md-12'>

                    <div className='card p_card'>
                        <div className='card-header p_card_header'>
                            <div className='d-flex align-items-center gap-1'>
                                <div className='productlogoPannel'>
                                    <img src={`${productDetails?.product_logo}`} alt="product-thumbnail" className="product_thumbnail" />
                                </div>
                                <div className='product_name'>{productDetails?.product_name}</div>
                            </div>
                            <div className='d-flex align-items-center gap-2'>
                                <div className='d_icon'>{dateIcon}</div>
                                <div className='subscribedon_panel'>
                                    <label>Subscribed on</label>
                                    <div className='date'>{moment(parseInt(productDetails?.created+"000")).format("DD/MM/YYYY")}</div>
                                </div>
                            </div>
                        </div>
                        <div className='card-body p_card_body pb-3'>
                            <div className='d-flex align-items-center justify-content-between'>
                                <div className='description_label'>Description</div>
                                {/* <img className="user_group" src={userGroup} alt='usergroup' /> */}
                            </div>
                            <div className='description my-3'>
                                <p className='m-0'>{productDetails?.product_desc}</p>
                            </div>
                            <div className='progress_block w-75 py-3'>
                                <div className="progress mb-2" style={{ height: '3px' }}>
                                    <div className="progress-bar" style={{ background: "#18A834", width: "75%", borderRadius: '4px' }} role="progressbar" aria-valuenow={75} aria-valuemin={0} aria-valuemax={100} />
                                </div>
                                <p className='progress_label'>Subscription will Expire {expiryOn} days</p>
                            </div>
                            {
                                expiryOn < 10 &&
                                <div className='text-center'>
                                    <button className='btn px-4 my-4 btn_primary'>Send Renew Notification</button>
                                </div>
                            }

                        </div>
                    </div>

                </div>
                <div className='col-lg-7 col-md-12'>
                    <div className='card p_card'>
                        <div className='card-header p_card_header py-3'>
                            <div className='user_detail'>User Details</div>
                            <div className='d-flex align-items-center gap-2'>
                                <input type='text' className="form-control" placeholder='Enter user name' />
                                <button className='btn btn_outline_primary btn-sm px-3'>Invite User</button>
                            </div>
                        </div>
                        <div className='card-body px-0 p_body_scrollable my-2'>
                            <div className='list-group px-2'>
                                {allMemebers?.map((val, index) => val.product_id === parseInt(props.match.params.productId) && (
                                    <>
                                        <div className='list-group-item ' key={index}>

                                            <div className='d-flex justify-content-between align-items-end'>

                                                <div className='d-flex align-items-center gap-2'>
                                                    {
                                                        val.userProfile ?
                                                            // <img src={`https://dtlehta1thuw9.cloudfront.net/testcasemgmt/api/attachment/views/${val?.userProfile}`} alt="users" className="Profile_picture" />
                                                            <img src={user1} alt="users" className="Profile_picture" />
                                                            :
                                                            <img src={user1} alt="users" className="Profile_picture" />
                                                    }

                                                    <div className='user_details'>
                                                        <div className='user_name'>{val.first_name} {val.last_name}</div>
                                                        {/* <div className='user_contact'>+91 87654 56432</div> */}
                                                        <div className='user_email'>{val.email}</div>
                                                    </div>
                                                </div>
                                                {/* <div className='action_btns px-2'>
                                                    <button className='btn p-0'>{eye} </button>
                                                    <button className='btn p-0'>{edit} </button>
                                                    <button className='btn p-0'>{del} </button>
                                                </div> */}
                                            </div>
                                        </div>
                                        {index < allMemebers.length - 1 && <hr className='my-1 userdetail_seperator' key={index} />}
                                    </>

                                ))}

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Productdetails