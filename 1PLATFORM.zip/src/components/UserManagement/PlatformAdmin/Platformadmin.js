import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Link, useHistory } from "react-router-dom";
import './Platformadmin.scss';
import addUser from '../../../assets/images/addUser.svg'
import { getAllProducts } from '../../../endpoints/gateway';
import nodata from '../../../assets/images/nodata.svg';
import moment from 'moment';
import Spinner from 'react-bootstrap/Spinner';
import { backBtnIcon } from '../../../Icons/icons';

const Platformadmin = () => {
    const history = useHistory();
    const userDetails = useSelector(state => state.user.userInfo.allInfo);
    const [allProducts, setallProducts] = useState([])

    useEffect(() => {
        fetchProducts()
    }, [])

    const fetchProducts = async () => {
        let response = await getAllProducts(userDetails.userId)
        setallProducts(response.data)

    }
    const dateIcon = <svg id="today_black_24dp" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 20 20">
        <path id="Path_13531" data-name="Path 13531" d="M0,0H20V20H0Z" fill="none" />
        <path id="Path_13532" data-name="Path 13532" d="M17.885,2.783h-.93V1H15.094V2.783H7.652V1H5.791V2.783h-.93A1.823,1.823,0,0,0,3,4.566V17.048a1.823,1.823,0,0,0,1.861,1.783H17.885a1.828,1.828,0,0,0,1.861-1.783V4.566A1.828,1.828,0,0,0,17.885,2.783Zm0,14.265H4.861V8.132H17.885Zm0-10.7H4.861V4.566H17.885ZM6.721,9.915h4.652v4.458H6.721Z" transform="translate(-1.373 -0.458)" fill='#757575' />
    </svg>
    return (
        <div className='Productsubscribe'>
            <div className="mt-2 custom-head-card">
                <div className="d-flex justify-content-between align-items-center">
                    <div className='d-flex align-items-center gap-2'>
                        <button type="button" onClick={() => history.goBack()} className="btn btn_light"> {backBtnIcon} </button>
                        <div className='h3'>Product Subscription</div>
                    </div>
                </div>
            </div>
            <div className='row my-3'>
                <div className='col-md-12'>
                    <div className='filter_dropdown float-end'>
                        {/* <div className="dropdown_label">Sort by</div>
                        <select className="form-select" aria-label="Default select example">
                            <option selected>All</option>
                            <option value={1}>Trial/freeware</option>
                            <option value={2}>Latest</option>
                            <option value={3}>A to Z</option>
                        </select> */}
                    </div>
                </div>
            </div>
            <div className='row g-3'>
                {
                    allProducts?.length === 0 &&
                    <>
                        {/* <div className="col-sm-12 text-center emptyscreenBlock">
                            <div className='container'>
                                <img src={nodata} alt="nodata" className="img-fluid" />
                                <p className="nodata-msg mt-3">You don’t seem to have any Products.</p>
                            </div>
                        </div> */}
                        <div className='col-md-12'>
                            <div className='d-flex justify-content-center align-items-center' style={{ height: '50vh' }}>
                                <Spinner animation="border" variant="primary" />
                            </div>
                        </div>
                    </>
                }
                {
                    allProducts?.map((val, index) => (
                        <div className="col-md-6 col-lg-3" key={index}>
                            <div className="card op_card" style={{ height: "350px" }}>
                                <div className="card-body">
                                    <div className="d-flex justify-content-between align-items-center">
                                        <div className="d-flex align-items-center">
                                            <div className='productlogoPannel'>
                                                <img src={val?.product_logo} alt="product-thumbnail" className="product_thumbnail" />
                                            </div>
                                            <div className="product_title ms-2">{val.product_name}</div>
                                        </div>
                                        {val.subscribed && <div className='subscribed'>Subscribed</div>}
                                    </div>
                                    <div className="product_desc my-4"><p>{val.product_desc}</p></div>
                                </div>
                                {val.license_id ?

                                    <div className="card-footer bg-transparent border-0 mx-3 p-0">
                                        {/* <Link to='/inviteuser' className='btn add_user'><img src={addUser} alt="addUsers" width="30"/></Link> */}
                                        <div className="d-flex align-items-center justify-content-center border-bottom">
                                            <Link to={`/productdetails/${val.product_id}`} className=' btn btn-sm btn_outline px-4 my-3'>View Details</Link>
                                        </div>
                                        <div className='d-flex align-items-center gap-2 justify-content-between mt-3 mb-4'>
                                            <div className='d-flex'>
                                                <div>{dateIcon}</div>
                                                <div className='footer_block ms-1'>
                                                    <div className='footer_label'>Subscribed on</div>
                                                    <div className='footer_content'>{moment(parseInt((val.created + "000"))).format("DD/MM/YYYY")}</div>
                                                </div>
                                            </div>
                                            <div className='footer_block text-end'>
                                                <div className='footer_label'>valid Untill</div>
                                                <div className='footer_content'>{moment(parseInt((val.expires + "000"))).format("DD/MM/YYYY")}</div>
                                            </div>
                                        </div>
                                    </div>
                                    :
                                    <div className="card-footer bg-transparent mx-3 px-0 py-0">
                                        <div className='d-flex align-items-center gap-2 my-1 justify-content-end'>
                                            {/* <button className="btn btn-sm btn_secondary px-4">Try</button> */}
                                            {/* <button className="btn btn-sm btn_primary" onClick={}>Subscribe</button> */}
                                            {val.product_name === "OIP" ?
                                                <Link to={{ pathname: "/billing", state: { data: 4, type: val.product_id } }} className='btn_primary btn btn-sm px-4 my-3'>Subscribe</Link>
                                                :
                                                <Link to={`subscription/${val.product_id}`} className='btn_primary btn btn-sm px-4 my-3'>Subscribe</Link>
                                            }

                                        </div>
                                    </div>

                                }

                            </div>
                            <div className='col-md-12 d-none'>
                                <div className='d-flex justify-content-center align-items-center' style={{ height: '50vh' }}>
                                    <Spinner animation="border" variant="primary" />
                                </div>
                            </div>
                        </div>
                    ))
                }

            </div>
        </div>
    )
}

export default Platformadmin