import React, { useState, useEffect } from 'react';
import { Link, useHistory } from "react-router-dom";

import { useSelector } from 'react-redux';
import Selectdropdown from '../../Common/Dropdownselect/Selectdropdown';
import './Inviteuser.scss'
import { useForm, Controller } from "react-hook-form";
import Select from 'react-select'
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import { sendPlatformInvite } from '../../../endpoints/gateway';
const Inviteuser = () => {
  const history = useHistory();
  const [productselected, setProductSelected] = useState("Select a Product");
  const userDetails = useSelector(state => state.user.userInfo.allInfo);
  const [allProducts, setallProducts] = useState()


  const personalSchema = Yup.object().shape({
    email: Yup.string()
      .email('Email is required')
      .required('Email is required')
      .matches(/^[a-zA-Z0-9._%+-]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)(?!yahoo.co.in)(?!aol.com)(?!live.com)(?!outlook.com)[a-zA-Z0-9_-]+.[a-zA-Z0-9-.]{2,61}$/,
        "Only Business emails are accepted"),

  });

  const { register,
    handleSubmit, setValue,
    formState: { errors, isValid }, control, reset } = useForm({
      resolver: yupResolver(personalSchema), mode: 'onChange'
    });



  const onSubmit = async (e) => {
    
    let response = await sendPlatformInvite(e.email)
    toast.success(response.data.message)
  }
  return (
    <div className='inviteUser'>
      <div className="mt-2 custom-head-card">
        <div className="d-flex justify-content-between align-items-center">
          <div className='d-flex align-items-center gap-2'>
            <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
            <div className='h3'>Invite User</div>
          </div>
          <Link to='/manageuser' className='btn btn_primary'>Manage Users</Link>
        </div>
      </div>
      <div className='row my-2 g-3'>
        <div className='col-md-12'>
          <div className='card op_card'>

            <form className='inviteUserForm' onSubmit={handleSubmit(onSubmit)}>
              <div className="form-group my-3">
                {/* <label for="exampleFormControlInput1" class="form-label">Email ID <span className='text-danger'>*</span></label> */}
                <input type="text" {...register("email", { required: true })} className={`form-control ${errors.email ? 'invalid' : ''}`} id="email" aria-describedby="email" placeholder="Email" />
                <span className="error">{errors.email && <span>{errors.email?.message}</span>}</span>
              </div>

              <div className='text-center'>
                <button type="submit" className="btn btn_primary mt-4" style={{ width: '267px' }}>Invite User</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Inviteuser