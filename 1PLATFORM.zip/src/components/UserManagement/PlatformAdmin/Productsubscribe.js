import React from 'react'
import {Link} from "react-router-dom";
import './Productsubscribe.scss';
import addUser from  '../../../assets/images/addUser.svg'
import QuantumLogo from "../../../assets/images/products/quantum.png";
import QuantifyLogo from "../../../assets/images/products/quantify.png";
import ProovLogo from "../../../assets/images/products/proov.png";

const Productsubscribe = () => {
    const dateIcon = <svg id="today_black_24dp" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 20 20">
    <path id="Path_13531" data-name="Path 13531" d="M0,0H20V20H0Z" fill="none"/>
    <path id="Path_13532" data-name="Path 13532" d="M17.885,2.783h-.93V1H15.094V2.783H7.652V1H5.791V2.783h-.93A1.823,1.823,0,0,0,3,4.566V17.048a1.823,1.823,0,0,0,1.861,1.783H17.885a1.828,1.828,0,0,0,1.861-1.783V4.566A1.828,1.828,0,0,0,17.885,2.783Zm0,14.265H4.861V8.132H17.885Zm0-10.7H4.861V4.566H17.885ZM6.721,9.915h4.652v4.458H6.721Z" transform="translate(-1.373 -0.458)" fill='#757575'/>
    </svg>    
  return (
    <div className='Productsubscribe'>
        <div className="mt-2 custom-head-card">
            <div className="d-flex justify-content-between align-items-center">
                <div className='h3'>Product Subscription</div>
                <div className='d-flex align-items-center gap-3'>
                    <Link to='/inviteuser' className='btn btn_outline'>Invite Users</Link>
                    <Link to='/manageuser' className='btn btn_primary'>Manage Users</Link>
                </div>
            </div>
        </div>        
        {/* <div className='row my-3'>
            <div className='col-md-12'>
                <div className='filter_dropdown float-end'>
                    <div className="dropdown_label">Sort by</div>
                    <select className="form-select" aria-label="Default select example">
                        <option selected>All</option>
                        <option value={1}>Trial/freeware</option>
                        <option value={2}>Latest</option>
                        <option value={3}>A to Z</option>
                    </select>                        
                </div>
            </div>                                             
        </div> */}
        <div className='row g-3'>
            <div className="col-md-6 col-lg-3">
                <div className="card op_card" style={{height:"350px"}}>
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center">
                            <div className="d-flex align-items-center">
                                <div className='productlogoPannel'>
                                    <img src={QuantifyLogo} alt="product-thumbnail" className="product_thumbnail" />
                                </div>
                                <div className="product_title ms-2">Quantify</div>
                            </div>                           
                        </div>
                        <div className="product_desc my-4">Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</div>
                    </div>
                    <div className="card-footer bg-transparent mx-3 px-0 py-0">
                        <div className='d-flex align-items-center gap-2 mt-3 mb-4 justify-content-end'>
                            <button className="btn btn-sm btn_try px-4">Try</button>
                            <button className="btn btn-sm btn_subscribe">Subscribe</button>                            
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-6 col-lg-3">
                <div className="card op_card" style={{height:"350px"}}>
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center">
                            <div className="d-flex align-items-center">
                                <div className='productlogoPannel'>
                                    <img src={QuantumLogo} alt="product-thumbnail" className="product_thumbnail" />
                                </div>
                                <div className="product_title ms-2">Quantum</div>
                            </div>
                            <div className='subscribed'>Subscribed</div>                            
                        </div>
                        <div className="product_desc my-4">Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</div>
                    </div>
                    <div className="card-footer bg-transparent border-0 mx-3 p-0">
                        <Link to='/inviteuser' className='productSubCard_btn btn add_user'><img src={addUser} alt="addUsers" style={{width:'30px'}}/></Link>
                        <div className="d-flex align-items-center justify-content-center border-bottom">
                            <Link to="/productdetails" className='productSubCard_btn btn btn-sm btn_view_details my-3'>View Details</Link>
                        </div>                        
                        <div className='d-flex align-items-center gap-2 justify-content-between mt-3 mb-4'>
                            <div className='d-flex'>
                                <div>{dateIcon}</div>
                                <div className='footer_block ms-1'>
                                    <div className='footer_label'>Subscribed on</div>
                                    <div className='footer_content'>May 13, 2022</div>
                                </div> 
                            </div> 
                            <div className='footer_block text-end'>
                                <div className='footer_label'>Subscribe type</div>
                                <div className='footer_content' style={{color:"#0E699C",fontWeight:'600'}}>Yearly</div>
                            </div>                                                    
                        </div>
                    </div>
                </div>
            </div>  
            <div className="col-md-6 col-lg-3">
                <div className="card op_card" style={{height:"350px"}}>
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center">
                            <div className="d-flex align-items-center">
                                <div className='productlogoPannel'>
                                    <img src={ProovLogo} alt="product-thumbnail" className="product_thumbnail" />
                                </div>
                                <div className="product_title ms-2">Proov</div> 
                            </div>   
                            <div className='subscribed'>Subscribed</div>                                                    
                        </div>
                        <div className="product_desc my-4">Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</div>                      
                    </div>
                    <div className="card-footer bg-transparent border-0 mx-3 p-0">
                        <Link to='/inviteuser' className='productSubCard_btn btn add_user'><img src={addUser} alt="addUsers" style={{width:'30px'}}/></Link>
                        <div className="d-flex align-items-center justify-content-center border-bottom">
                            <Link to="/productdetails" className='productSubCard_btn btn btn-sm btn_view_details my-3'>View Details</Link>
                        </div>                        
                        <div className='d-flex align-items-center gap-2 justify-content-between mt-3 mb-4'>
                            <div className='d-flex'>
                                <div>{dateIcon}</div>
                                <div className='footer_block ms-1'>
                                    <div className='footer_label'>Subscribed on</div>
                                    <div className='footer_content'>May 13, 2022</div>
                                </div> 
                            </div> 
                            <div className='footer_block text-end'>
                                <div className='footer_label'>Subscribe type</div>
                                <div className='footer_content' style={{color:"#0E699C",fontWeight:'600'}}>Yearly</div>
                            </div>                                                    
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-6 col-lg-3">
                <div className="card op_card" style={{height:"350px"}}>
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center">
                            <div className="d-flex align-items-center">
                                <div className='productlogoPannel'>
                                    <img src={QuantifyLogo} alt="product-thumbnail" className="product_thumbnail" />
                                </div>
                                <div className="product_title ms-2">Quantify</div>
                            </div>                          
                        </div>
                        <div className="product_desc my-4">Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</div>
                    </div>
                    <div className="card-footer bg-transparent mx-3 p-0">
                        <div className='d-flex align-items-center gap-2 mt-3 mb-4 justify-content-end'>
                            <button className="btn btn-sm btn_try px-4">Try</button>
                            <button className="btn btn-sm btn_subscribe">Subscribe</button>                            
                        </div>
                    </div>
                </div>
            </div> 
            <div className="col-md-6 col-lg-3">
                <div className="card op_card" style={{height:"350px"}}>
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center">
                            <div className="d-flex align-items-center">
                                <div className='productlogoPannel'>
                                    <img src={QuantumLogo} alt="product-thumbnail" className="product_thumbnail" />
                                </div>
                                <div className="product_title ms-2">Product 01</div>
                            </div>                           
                        </div>
                        <div className="product_desc my-4">Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</div>
                    </div>
                    <div className="card-footer bg-transparent mx-3 px-0 py-4">
                        <div className='d-flex align-items-center gap-2 justify-content-end'>
                            <button className="btn btn-sm btn_subscribe">Subscribe</button>
                            <button className='btn p-0 ms-3' style={{fontSize:"19px"}}><i class="bi bi-three-dots"></i></button>                            
                        </div>
                    </div>
                </div>
            </div>  
            <div className="col-md-6 col-lg-3">
                <div className="card op_card" style={{height:"350px"}}>
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center">
                            <div className="d-flex align-items-center">
                                <div className='productlogoPannel'>
                                    <img src={ProovLogo} alt="product-thumbnail" className="product_thumbnail" />
                                </div>
                                <div className="product_title ms-2">Proov</div>
                            </div>
                            <div className='try_version'>Try version</div>                            
                        </div>
                        <div className="product_desc my-4">Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</div>                      
                    </div>
                    <div className="card-footer bg-transparent mx-3 border-0 px-0 py-4">
                        <div className='progress_block my-1'>
                            <div className="progress mb-1" style={{height:'5px'}}>
                                <div className="progress-bar bg-success" style={{width:"75%",borderRadius:'4px'}} role="progressbar" aria-valuenow={75} aria-valuemin={0} aria-valuemax={100} />
                            </div>
                            <p className='progress_label'>Trial will Expire 6 days</p>                            
                        </div>                        
                        <div className='d-flex align-items-center gap-2 justify-content-end'>
                            <Link to="/productdetails" className="btn btn-sm btn_try ">View Details</Link>
                            <button className="btn btn-sm btn_subscribe">Subscribe</button>                            
                        </div>
                    </div>
                </div>
            </div>            
        </div>
    </div> 
  )
}

export default Productsubscribe