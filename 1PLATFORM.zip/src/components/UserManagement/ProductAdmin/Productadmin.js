import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Link, useHistory } from "react-router-dom";
import '../PlatformAdmin/Platformadmin.scss';
import addUser from '../../../assets/images/addUser.svg'
import { getOrgProductMemebr } from '../../../endpoints/gateway';
import nodata from '../../../assets/images/nodata.svg';
const Productadmin = () => {
    const history = useHistory();
    const userDetails = useSelector(state => state.user.userInfo.allInfo);
    const [allProducts, setallProducts] = useState([])   
    useEffect(() => {
        fetchProducts()
    }, [])

    const fetchProducts = async () => {
        let response = await getOrgProductMemebr(userDetails.companyId)
        setallProducts(response.data)
        
    }
    const dateIcon = <svg id="today_black_24dp" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 20 20">
        <path id="Path_13531" data-name="Path 13531" d="M0,0H20V20H0Z" fill="none" />
        <path id="Path_13532" data-name="Path 13532" d="M17.885,2.783h-.93V1H15.094V2.783H7.652V1H5.791V2.783h-.93A1.823,1.823,0,0,0,3,4.566V17.048a1.823,1.823,0,0,0,1.861,1.783H17.885a1.828,1.828,0,0,0,1.861-1.783V4.566A1.828,1.828,0,0,0,17.885,2.783Zm0,14.265H4.861V8.132H17.885Zm0-10.7H4.861V4.566H17.885ZM6.721,9.915h4.652v4.458H6.721Z" transform="translate(-1.373 -0.458)" fill='#757575' />
    </svg>
    return (
        <div className='Productsubscribe'>
            <div className="mt-2 custom-head-card">
                <div className="d-flex justify-content-between align-items-center">
                    <div className='d-flex align-items-center gap-2'>
                        <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
                        <div className='h3'>Subscribed Products</div>
                    </div>
                    <div className='d-flex align-items-center gap-3'>
                        {/* <Link to='/inviteuser' className='btn btn_outline'>Invite Users</Link> */}
                        <Link to='/manageuser' className='btn btn_primary'>Manage Users</Link>
                    </div>
                </div>
            </div>
            <div className='row my-3'>
                <div className='col-md-12'>
                    <div className='filter_dropdown float-end'>
                        <div className="dropdown_label">Sort by</div>
                        <select className="form-select" aria-label="Default select example">
                            <option selected>All</option>
                            <option value={1}>Trial/freeware</option>
                            <option value={2}>Latest</option>
                            <option value={3}>A to Z</option>
                        </select>
                    </div>
                </div>
            </div>
            <div className='row g-3'>
                {
                    allProducts?.length < 0 ? 
                    <>
                        {
                            allProducts?.map((val, index) => (
                                <div className="col-md-6 col-lg-3" key={index}>
                                    <div className="card op_card" style={{ height: "350px" }}>
                                        <div className="card-body">
                                            <div className="d-flex justify-content-between align-items-center">
                                                <div className="d-flex align-items-center">
                                                    <div className='productlogoPannel'>
                                                        <img src={`https://dtlehta1thuw9.cloudfront.net/testcasemgmt/api/attachment/views/${val?.productProfile}`} alt="product-thumbnail" className="product_thumbnail" />
                                                    </div>
                                                    <div className="product_title ms-2">{val.productName}</div>
                                                </div>
                                                {val.subscribed && <div className='subscribed'>Subscribed</div>}
                                            </div>
                                            <div className="product_desc my-4"><p>{val.description}</p></div>
                                        </div>
                                        {val.subscribed ?

                                            <div className="card-footer bg-transparent border-0 mx-3 p-0">
                                                <Link to={`/inviteuseradmin/${val.id}`} className='btn add_user'><img src={addUser} alt="addUsers" width="30"/></Link>
                                                <div className="d-flex align-items-center justify-content-center border-bottom">
                                                    <Link to={`/productdetails/${userDetails.userId}/${val.id}`} className='productSubCard_btn btn btn-sm btn_view_details my-3'>View Details</Link>
                                                </div>
                                                <div className='d-flex align-items-center gap-2 justify-content-between mt-3 mb-4'>
                                                    <div className='d-flex'>
                                                        <div>{dateIcon}</div>
                                                        <div className='footer_block ms-1'>
                                                            <div className='footer_label'>Subscribed on</div>
                                                            <div className='footer_content'>{val.subscribeOn.split('T')[0]}</div>
                                                        </div>
                                                    </div>
                                                    <div className='footer_block text-end'>
                                                        <div className='footer_label'>Subscribe type</div>
                                                        <div className='footer_content' style={{ color: "#0E699C", fontWeight: '600',textTransform:'capitalize' }}>{val.subscribeType}</div>
                                                    </div>
                                                </div>
                                            </div>
                                            :
                                            <div className="card-footer bg-transparent mx-3 px-0 py-0">
                                                <div className='d-flex align-items-center gap-2 mt-3 mb-4 justify-content-end'>
                                                    <button className="btn btn-sm btn_try px-4">Try</button>
                                                    <button className="btn btn-sm btn_primary">Subscribe</button>
                                                </div>
                                            </div>

                                        }

                                    </div>
                                </div>
                            ))
                        }                    
                    </>
                    :
                    <>
                        <div className="col-sm-12 text-center emptyscreenBlock">
                            <div className='container'>
                                <img src={nodata} alt="nodata" className="img-fluid" />
                                <p className="nodata-msg mt-3">You don’t seem to have any Products. Please contact your admin</p>
                            </div>
                        </div>                        
                    </>
                }
                
            </div>
        </div>
    )
}

export default Productadmin