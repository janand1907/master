import React, { useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import './DashboardAdmin.scss'
import dropDownIcon from '../../../assets/images/dropIcon.svg'
import user1 from '../../../assets/images/usermanagement/users/user1.png';
import user2 from '../../../assets/images/usermanagement/users/user2.png';
import user3 from '../../../assets/images/usermanagement/users/user3.png';
import user4 from '../../../assets/images/usermanagement/users/user4.png';
import user5 from '../../../assets/images/usermanagement/users/user5.png';
import deleteModal from '../../../assets/images/del.png';
import nodata from '../../../assets/images/nodata.svg';
import { useSelector } from 'react-redux';
import usericon from '../../../assets/images/userSingle.svg';
import usersicon from '../../../assets/images/users.svg';
import basket from '../../../assets/images/basket.svg'
import Selectdropdown from '../../Common/Dropdownselect/Selectdropdown';
import Edituser from '../Edituser';
import DeleteModal from '../../Common/Deletemodal/DeleteModal';
import { toast } from 'react-toastify';

import { getProducts,getProductsCounts,getMappedUsers,deleteMapperUser } from '../../../endpoints/gateway';
const DashboardAdmin = () => {
  let delIcon = <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 17.565 20.019">
    <g id="Component_100_3" data-name="Component 100 – 3" transform="translate(0.25 0.25)">
      <path id="Path_14027" data-name="Path 14027" d="M603.74,843.991c-1.407,0-2.814.007-4.22,0a1.828,1.828,0,0,1-2-1.883q-.5-6.591-1-13.182c-.036-.478-.059-.865-.726-.793a.548.548,0,0,1-.6-.631c.029-.417.314-.59.73-.587,1.2.008,2.392-.013,3.587.013.412.009.56-.077.567-.532a1.775,1.775,0,0,1,1.946-1.909c1.149-.012,2.3-.015,3.447,0a1.767,1.767,0,0,1,1.9,1.884c0,.507.2.56.614.552,1.148-.021,2.3,0,3.446-.012.465-.006.831.138.827.634,0,.453-.362.651-.788.6-.524-.064-.493.29-.517.611q-.309,4-.614,7.993c-.14,1.823-.276,3.646-.422,5.468a1.8,1.8,0,0,1-1.888,1.771C606.6,844,605.17,843.992,603.74,843.991Zm-.012-15.84c-1.828,0-3.657.008-5.485-.006-.391,0-.586.034-.545.525q.54,6.585,1.022,13.176c.053.731.367.958,1.068.951,2.531-.027,5.063-.01,7.594-.011,1.241,0,1.275-.025,1.374-1.288.331-4.252.649-8.5.991-12.755.036-.448-.046-.609-.534-.6C607.385,828.168,605.556,828.151,603.728,828.152Zm-.016-1.232c.632,0,1.267-.037,1.9.012.51.04.587-.187.545-.607-.048-.477-.337-.632-.764-.633q-1.019,0-2.037,0c-.468,0-.938-.018-1.4.007-.554.03-.66.4-.651.884.011.567.425.309.661.324C602.54,826.944,603.127,826.92,603.712,826.92Z" transform="translate(-595.194 -824.476)" fill="#363636" stroke="#363636" stroke-width="0.5" />
      <path id="Path_2435" data-name="Path 2435" d="M639.29,863.41c0,1.182,0,2.363,0,3.545,0,.305-.014.62-.416.614s-.406-.322-.405-.626q0-3.521,0-7.042c0-.313.03-.62.419-.616s.406.321.4.628C639.287,861.079,639.29,862.245,639.29,863.41Z" transform="translate(-631.868 -852.691)" fill="#363636" stroke="#363636" stroke-width="0.5" />
      <path id="Path_2436" data-name="Path 2436" d="M665.261,863.474c0,1.166,0,2.331,0,3.5,0,.31-.019.617-.418.611s-.406-.325-.406-.626q0-3.521,0-7.042c0-.312.032-.619.422-.613s.4.322.4.628C665.257,861.11,665.261,862.292,665.261,863.474Z" transform="translate(-654.799 -852.704)" fill="#363636" stroke="#363636" stroke-width="0.5" />
    </g>
  </svg>

  let editIcon = <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-pen-fill" viewBox="0 0 16 16">
    <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001z" />
  </svg>

  let productIcon = <svg id="Component_108_1_2" data-name="Component 108 – 1 2" xmlns="http://www.w3.org/2000/svg" width="26.745" height="27.044" viewBox="0 0 26.745 27.044">
    <g id="Path_14033" data-name="Path 14033" transform="translate(0.003 0)">
      <path id="Path_11" data-name="Path 11" d="M164.887-106.254l13.5-6.28,13.245,6.159L178.454-100.7Z" transform="translate(-164.887 112.534)" fill="none" />
      <path id="Path_12" data-name="Path 12" d="M178.445-101.712l10.894-4.7L178.383-111.5l-11.16,5.193,11.222,4.6m.009,1.015-13.567-5.557,13.5-6.28,13.246,6.159Z" transform="translate(-164.887 112.534)" fill="#757575" />
    </g>
    <g id="Path_14034" data-name="Path 14034" transform="translate(0 6.278)">
      <path id="Path_13" data-name="Path 13" d="M21.838-296.23,35.7-290.572l-.238,15.091-13.607-6.55Z" transform="translate(-21.838 296.23)" fill="none" />
      <path id="Path_14" data-name="Path 14" d="M22.776-294.837l.011,12.217,11.759,5.66.2-12.987-11.974-4.889m-.937-1.394L35.7-290.572l-.238,15.091-13.607-6.55Z" transform="translate(-21.838 296.23)" fill="#757575" />
    </g>
    <g id="Path_14035" data-name="Path 14035" transform="translate(13.605 6.162)">
      <path id="Path_15" data-name="Path 15" d="M-323.477-83.6l13.128-5.616-.025,14.237-13.092,6.646Z" transform="translate(323.477 89.211)" fill="none" />
      <path id="Path_16" data-name="Path 16" d="M-311.288-87.791l-11.252,4.814.009,13.125,11.222-5.7.021-12.242m.939-1.42-.025,14.237-13.092,6.646-.011-15.267Z" transform="translate(323.477 89.211)" fill="#757575" />
    </g>
    <path id="Path_14036" data-name="Path 14036" d="M2619.259-632.079l12.272,5.392v6.751l3.469-1.818v-6.571l-12-5.529Z" transform="translate(-2613.091 636.526)" fill="#757575" />
  </svg>

  // Edit User Modal
  const [modal, setModal] = useState(false);

  // End of Edit User Modal
  const [delModal, setdelModal] = useState(false);

  const userDetails = useSelector(state => state.user.userInfo.allInfo);
  const [roleSelected, setRoleselected] = useState('Select Role');
  const [status, setStatus] = useState("Select Status")
  const [productselected, setProductSelected] = useState("Select Product");
  const [filterData, setfilterData] = useState()
  useEffect(() => {
    // fetchroles()
    fetchProducts()
    fetchProductsDetails()
    fetchMappedUsers()
  }, [])
  /*roles*/
  // const [allroles, setallroles] = useState()
  const [allproducts, setallproducts] = useState()
  const [ProductsDetails, setProductsDetails] = useState()
  const [mappedUsers, setmappedUsers] = useState()

  const fetchProducts = async () => {
      let response = await getProducts()
      setallproducts(response.data)
  }

  const fetchProductsDetails = async () => {
      let response = await getProductsCounts(userDetails.userEmail)
      setProductsDetails(response.data)
  }

  const fetchMappedUsers = async () => {
    let response = await getMappedUsers(userDetails.userEmail)    
    setmappedUsers(response.data.filter(val=>val.roleName!=='Product Admin'))
    setfilterData(response.data.filter(val=>val.roleName!=='Product Admin'))
   
  }

  const [selectedUser, setselectedUser] = useState()
  const Toggle = (id) => {
    if(id!=='add'){
      let selectUser = filterData.find((val) => {
        return val.id == id
      })
     setselectedUser(selectUser)
     setModal(!modal)
    }
    else{
      setselectedUser(0)
      setModal(!modal)
    }
  };
  const delToggle = (id) => {
    let selectUser = filterData.find((val) => {
      return val.id == id
    })

    setselectedUser(selectUser)
    setdelModal(!delModal)
  }

  const deleteContent=async(id)=>{
    let response = await deleteMapperUser(id)
    toast.success(response.data.message)
    fetchMappedUsers()
  
  }

  const filterwithStatus = (value)=>{
    
    let statusValue;
    if(value == 'Active'){
      statusValue = true
    }
    else{
      statusValue = false
    }
    let newResult = filterData.filter((val) => {
      return val.status == statusValue
    }
    )

    setmappedUsers(newResult)
  }

  const filterUser = (filterValue) => {    
    let newResult = filterData.filter((val) => {
      return val.productName == filterValue
    }
    )

    setmappedUsers(newResult)
  }
  return (
    <div className='admin_dashboard'>
      <div className="mt-2 custom-head-card">
        <div className="d-flex justify-content-between align-items-center">
          <div className='h3'>Dashboard</div>
          <Link to="/productadmin" className='btn btn_primary px-4'>Products</Link>
        </div>
      </div>
      <div className='row g-3 mt-1'>
        {/* <div className='col-md-3'>
                <div className='mb-1 DashboardLabel'>Select a Product</div>
                <Selectdropdown dataSelected={productselected} setDataSelected={setProductSelected} options={allproducts} getSelectValue="productId" getSelectLabel="productName" />
            </div>           */}
        <div className='col-md-6'>
          <div className='card p-3'>
            <div className='d-flex align-items-center gap-3'>
              <div className='icon'><img src={basket} alt='basket' /> </div>
              <div className='content_panel'>
                <div className='value'>{ProductsDetails?.project_count}</div>
                <div className='label'>Projects</div>
              </div>
            </div>
          </div>
        </div>
        <div className='col-md-6'>
          <div className='card p-3'>
            <div className='d-flex align-items-center gap-3'>
              <div className='icon'><img src={usericon} alt='usericon' /> </div>
              <div className='content_panel'>
                <div className='value'>{ProductsDetails?.user_count}</div>
                <div className='label'>Users</div>
              </div>
            </div>
          </div>
        </div>
        {/* <div className='col-md-4'>
          <div className='card p-3'>
            <div className='d-flex align-items-center gap-3'>
              <div className='icon'><img src={usersicon} alt='userIcon' /> </div>
              <div className='content_panel'>
                <div className='value'>{ProductsDetails?.user_group}</div>
                <div className='label'>User Groups</div>
              </div>
            </div>
          </div>
        </div> */}
      </div>
      <div className='d-flex justify-content-between align-items-end mb-2 mt-3'>
        <div className='user_label ms-1'>Users</div>
        <div className='d-flex align-items-center gap-4'>
          <div className='filter_dropdown'>
            <div className="dropdown_label">Products</div>
            <div style={{ width: '200px' }}>
              <Selectdropdown dataSelected={productselected} setDataSelected={setProductSelected} options={allproducts} getSelectValue="productId" getSelectLabel="productName" filterSelect={(e) => { filterUser(e) }}/>
              {/* <Selectdropdown dataSelected={roleSelected} setDataSelected={setRoleselected} options={allroles} getSelectValue="roleId" getSelectLabel="roleName" />                           */}
            </div>
          </div>
          <div className='filter_dropdown'>
            <div className="dropdown_label">Status</div>
            <div style={{ width: '200px' }}>
              <Selectdropdown dataSelected={status} setDataSelected={setStatus} options={['Active', 'In Active']} getSelectLabel={0} filterSelect={(e) => { filterwithStatus(e) }} />
            </div>
          </div>
          <button className='btn btn_primary px-4'  onClick={() => Toggle('add')}><i class="bi bi-plus-lg"></i> Add User</button>
        </div>
      </div>
      <div className='row'>
        <div className='col-md-12'>
          <table className="table manageuser_grid">
            <thead>
              <tr>
                <th className="px-4" scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Products</th>
                <th scope="col">Role</th>
                <th scope="col">Created Date</th>
                <th scope="col">status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody className='border-top-0'>
              {mappedUsers?.length === 0 ? 
              <>
                <tr>
                  <td colSpan={8}>
                    <div className="col-sm-12 text-center py-2">
                        <img src={nodata} alt="nodata" className="gridImg" />
                        <p className="nodata-msg mt-3">No users added !  please add the users by clicking<span className='batchAddUser mx-1'>+ Add User</span>button</p>
                    </div>
                  </td>
                </tr>
              </>
              :
              <>
              {mappedUsers?.map((val, index) => (
                <tr key={index}>
                  <td>
                    <div className='d-flex align-items-center gap-2'>
                      {
                        val.userProfile !== null ?
                          <img src={`https://dtlehta1thuw9.cloudfront.net/testcasemgmt/api/attachment/views/${val?.userProfile}`} className="user_icon" alt="userimg" />
                          :
                          <img src={user1} className="user_icon" alt="userimg" />
                      }
                      {/* <img src={user1} className="user_icon" alt="userimg" /> */}
                      <div>{val.firstName} {val.lastName}</div>
                    </div>
                  </td>
                  <td>{val.userEmail}</td>

                  <td>{val.productName}</td>
                  <td><span className='role admin'>{val.roleName}</span></td>
                  <td>{val.createdOn.split('T')[0]}</td>
                  <td>{val.status ? "Active" : "Inactive"}</td>
                  <td>
                    <div className='d-flex align-items-center gap-2'>
                      <button className='btn action_btns' onClick={() => Toggle(val.id)}>{editIcon}</button>
                      <button className='btn action_btns' onClick={() => delToggle(val.id)}>{delIcon}</button>
                    </div>
                  </td>
                </tr>
              ))}
              </>

              }
              

            </tbody>
          </table>
          <div className='table_pagination'>
            <nav aria-label="Page navigation example">
              <ul className="pagination">
                <li className="page-item"><Link className="page-link" href="#"><i class="bi bi-chevron-left"></i></Link></li>
                <li className="page-item"><Link className="page-link active" href="#">1</Link></li>
                <li className="page-item"><Link className="page-link" href="#">2</Link></li>
                <li className="page-item"><Link className="page-link" href="#">3</Link></li>
                <li className="page-item"><Link className="page-link" href="#"><i class="bi bi-chevron-right"></i></Link></li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
      {modal && <Edituser selectedUser={selectedUser} Toggle={Toggle} role="productadmin"/>}  
      {
         delModal &&  <DeleteModal customHeading="Delete Member" customMessage="This action will delete all assigned product and user" delToggle={() => delToggle()} deleteContent={()=>deleteContent(selectedUser.id)} />
      }
    </div>
  )
}

export default DashboardAdmin