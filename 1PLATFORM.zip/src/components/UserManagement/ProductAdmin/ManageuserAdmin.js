import React,{useState} from 'react'
import {Link, useHistory} from "react-router-dom";
import '../PlatformAdmin/Manageuser.scss'
import user1 from '../../../assets/images/usermanagement/users/user1.png';
import user2 from '../../../assets/images/usermanagement/users/user2.png';
import user3 from '../../../assets/images/usermanagement/users/user3.png';
import user4 from '../../../assets/images/usermanagement/users/user4.png';
import user5 from '../../../assets/images/usermanagement/users/user5.png';
import deleteModal from '../../../assets/images/del.png';

import Edituser from '../Edituser';
import Selectdropdown from '../../Common/Dropdownselect/Selectdropdown';

const ManageuserAdmin = () => {
  const history = useHistory();

    let listIcon = <svg id="Component_89_3" data-name="Component 89 – 3" xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g id="Rectangle_2590" data-name="Rectangle 2590" fill="#ebf2fe" stroke="#d6e6fe" stroke-width="0.5">
      <rect width="30" height="30" rx="2" stroke="none"/>
      <rect x="0.25" y="0.25" width="29.5" height="29.5" rx="1.75" fill="none"/>
    </g>
    <path id="Path_14342" data-name="Path 14342" d="M-27.777,110.844h-8.371c-.68,0-.9-.215-.9-.887q0-7.752,0-15.5c0-.676.219-.9.892-.9h16.746c.671,0,.907.229.908.891q0,7.753,0,15.506c0,.66-.239.894-.9.894Zm2.641-5.316c1.65,0,3.3-.006,4.949.006.273,0,.36-.069.352-.349-.02-.67-.016-1.34,0-2.01.005-.243-.069-.312-.31-.312q-4.988.011-9.976,0c-.237,0-.32.064-.314.31.015.67.019,1.34,0,2.01-.008.28.081.352.353.35C-28.436,105.522-26.786,105.528-25.137,105.528Zm-.021-7.974c1.664,0,3.328-.005,4.991.005.257,0,.337-.07.33-.331q-.027-.985,0-1.972c.008-.276-.076-.365-.353-.364q-4.972.011-9.943,0c-.251,0-.308.089-.3.321.013.657.02,1.315,0,1.972-.01.293.069.379.368.377C-28.433,97.546-26.8,97.554-25.157,97.554Zm.049,1.333c-1.664,0-3.329,0-4.993-.005-.249,0-.344.053-.336.324.02.67.014,1.341,0,2.012,0,.227.045.326.3.326q4.993-.011,9.986,0c.24,0,.316-.069.311-.311-.015-.657-.026-1.316,0-1.972.015-.332-.11-.381-.4-.379C-21.859,98.894-23.484,98.887-25.109,98.887Zm-.074,10.624c1.664,0,3.328-.006,4.992.006.269,0,.364-.065.355-.349-.021-.67-.014-1.341,0-2.012,0-.211-.038-.3-.276-.3q-5.012.011-10.023,0c-.257,0-.3.094-.3.322.013.657.021,1.316,0,1.972-.011.308.1.37.381.367C-28.432,109.5-26.808,109.511-25.183,109.511Zm-8.576-3.983c.576,0,1.151-.01,1.726,0,.229.006.291-.075.287-.293q-.016-1.043,0-2.087c0-.225-.073-.291-.294-.289q-1.707.014-3.414,0c-.23,0-.287.078-.284.3.012.7.013,1.392,0,2.087,0,.227.07.292.29.287C-34.884,105.519-34.321,105.528-33.759,105.528Zm.043-7.974c.549,0,1.1-.009,1.648,0,.225.006.331-.036.325-.3-.017-.7-.014-1.392,0-2.088,0-.235-.089-.283-.3-.281q-1.668.013-3.336,0c-.245,0-.358.069-.354.333.011.683.012,1.366,0,2.048,0,.231.077.288.294.284C-34.868,97.546-34.292,97.554-33.716,97.554Zm-.032,1.333c-.575,0-1.151.009-1.726,0-.21,0-.264.065-.261.268q.017,1.063,0,2.126c0,.208.067.267.27.266,1.138-.008,2.276-.011,3.413,0,.248,0,.31-.082.306-.316-.013-.682-.017-1.365,0-2.047.007-.258-.088-.3-.316-.3C-32.623,98.9-33.186,98.887-33.748,98.887Zm0,10.623c.576,0,1.152-.007,1.728,0,.2,0,.278-.056.275-.266-.01-.709-.007-1.419,0-2.129,0-.17-.023-.264-.23-.263q-1.767.013-3.535,0c-.174,0-.222.06-.221.228.008.71.01,1.419,0,2.129,0,.254.109.306.334.3C-34.85,109.5-34.3,109.511-33.75,109.511Z" transform="translate(43.046 -87.553)" fill="#0e699c"/>
    </svg>
  
    let gridIcon = <svg id="Component_88_3" data-name="Component 88 – 3" xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
    <g id="Rectangle_2589" data-name="Rectangle 2589" fill="#ebf2ff" stroke="#d6e6ff" stroke-width="0.5" opacity="0">
      <rect width="30" height="30" rx="2" stroke="none"/>
      <rect x="0.25" y="0.25" width="29.5" height="29.5" rx="1.75" fill="none"/>
    </g>
    <path id="grid_view_FILL0_wght400_GRAD0_opsz48" d="M6,13.684V6h7.684v7.684Zm0,9.081V15.081h7.684v7.684Zm9.081-9.081V6h7.684v7.684Zm0,9.081V15.081h7.684v7.684ZM7.4,12.287h4.89V7.4H7.4Zm9.081,0h4.89V7.4h-4.89Zm0,9.081h4.89v-4.89h-4.89Zm-9.081,0h4.89v-4.89H7.4ZM16.478,12.287ZM16.478,16.478ZM12.287,16.478ZM12.287,12.287Z" transform="translate(1 1)" fill="#d1d1d1"/>
  </svg>
  
  let delIcon = <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 17.565 20.019">
  <g id="Component_100_3" data-name="Component 100 – 3" transform="translate(0.25 0.25)">
    <path id="Path_14027" data-name="Path 14027" d="M603.74,843.991c-1.407,0-2.814.007-4.22,0a1.828,1.828,0,0,1-2-1.883q-.5-6.591-1-13.182c-.036-.478-.059-.865-.726-.793a.548.548,0,0,1-.6-.631c.029-.417.314-.59.73-.587,1.2.008,2.392-.013,3.587.013.412.009.56-.077.567-.532a1.775,1.775,0,0,1,1.946-1.909c1.149-.012,2.3-.015,3.447,0a1.767,1.767,0,0,1,1.9,1.884c0,.507.2.56.614.552,1.148-.021,2.3,0,3.446-.012.465-.006.831.138.827.634,0,.453-.362.651-.788.6-.524-.064-.493.29-.517.611q-.309,4-.614,7.993c-.14,1.823-.276,3.646-.422,5.468a1.8,1.8,0,0,1-1.888,1.771C606.6,844,605.17,843.992,603.74,843.991Zm-.012-15.84c-1.828,0-3.657.008-5.485-.006-.391,0-.586.034-.545.525q.54,6.585,1.022,13.176c.053.731.367.958,1.068.951,2.531-.027,5.063-.01,7.594-.011,1.241,0,1.275-.025,1.374-1.288.331-4.252.649-8.5.991-12.755.036-.448-.046-.609-.534-.6C607.385,828.168,605.556,828.151,603.728,828.152Zm-.016-1.232c.632,0,1.267-.037,1.9.012.51.04.587-.187.545-.607-.048-.477-.337-.632-.764-.633q-1.019,0-2.037,0c-.468,0-.938-.018-1.4.007-.554.03-.66.4-.651.884.011.567.425.309.661.324C602.54,826.944,603.127,826.92,603.712,826.92Z" transform="translate(-595.194 -824.476)" fill="#363636" stroke="#363636" stroke-width="0.5"/>
    <path id="Path_2435" data-name="Path 2435" d="M639.29,863.41c0,1.182,0,2.363,0,3.545,0,.305-.014.62-.416.614s-.406-.322-.405-.626q0-3.521,0-7.042c0-.313.03-.62.419-.616s.406.321.4.628C639.287,861.079,639.29,862.245,639.29,863.41Z" transform="translate(-631.868 -852.691)" fill="#363636" stroke="#363636" stroke-width="0.5"/>
    <path id="Path_2436" data-name="Path 2436" d="M665.261,863.474c0,1.166,0,2.331,0,3.5,0,.31-.019.617-.418.611s-.406-.325-.406-.626q0-3.521,0-7.042c0-.312.032-.619.422-.613s.4.322.4.628C665.257,861.11,665.261,862.292,665.261,863.474Z" transform="translate(-654.799 -852.704)" fill="#363636" stroke="#363636" stroke-width="0.5"/>
  </g>
  </svg>
  let editIcon = <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-pen-fill" viewBox="0 0 16 16">
  <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001z"/>
  </svg> 
const [modal, setModal] = useState(false);
const Toggle = () => setModal(!modal); 
const Modal = ({ show, close }) => {
  return (
    <>
     {
     show ?
        <div className='custom_modalContainer'>
          <div className="envHealthCheck_modal card" style={{width:"70vw"}} >
              <div className="modal_header card-header m-0">
                <div className="modal_header-title">Edit Profile</div>
                <button className="close" onClick={() => close()}><i class="bi bi-x"></i></button>
              </div>
              <div className='modal_body card-body'>
                <Edituser />
              </div>
          </div>
        </div>
      : null
     }
    </>
  );
}; 

const [delModal, setdelModal] = useState(false);
const delToggle = () => setdelModal(!delModal);
const DeleteModal = ({ show, close }) => {
    return (
      <>
       {
       show ?
       
       <div className="custom_modalContainer">
          <div className="envHealthCheck_modal card" style={{width:'50vw'}} >
            <div className="modal_header card-header m-0">
              <div className="modal_header-title p-2">Delete Users</div>
              <button className="close" onClick={() => close()}><i class="bi bi-x"></i></button>
            </div>
            <div className='modal_body card-body'>
                <div className='text-center py-2'>
                    <img src={deleteModal} alt='imagedelete'  />
                    <div className='deleteModalContent my-3'>Are you sure you want to delete?</div>
                </div>
                
                <div className='text-center my-2'>
                    <button className='btn btn-sm btn_primary mx-2 px-5'>yes</button>
                </div>                    
            </div>
          </div>
        </div>
        : null
       }
      </>
    );
};
  
const[rSelected, setRselected] = useState('Select Role');
const[status , setStatus] = useState("select Status");
  return (
    <div className='manageuser'>
        <div className="mt-2 custom-head-card">
            <div className="d-flex gap-2 align-items-center">
                <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
                <div className='h3'>Manage User</div>
            </div>
        </div> 
        <div className='row my-2'>
          <div className='col-md-12'>
                <div className='d-flex justify-content-end align-items-center gap-4'>
                  <div className='filter_dropdown'>
                    <div className="dropdown_label">Role</div>
                    <div style={{width:'200px'}}>
                      <Selectdropdown dataSelected={rSelected} setDataSelected={setRselected} options={['All', 'Prodct Admin', 'Member']} />                          
                    </div>
                  </div>                  
                  <div className='filter_dropdown'>
                      <div className="dropdown_label">Status</div>
                      <div style={{width:'200px'}}>
                        <Selectdropdown dataSelected={status} setDataSelected={setStatus} options={['All', 'Active', 'In Active']} />                          
                      </div>                        
                  </div>
                    <button className='btn btn_primary px-4'><i class="bi bi-plus-lg"></i> Add User</button>    
                    <div className='d-flex align-items-center gap-1'>
                      <button className='btn p-1'>{listIcon}</button>
                      <button className='btn p-1'>{gridIcon}</button>
                    </div>                                                      
                </div>
          </div>          
        </div>        
        <div className='row g-3'>
            <div className='col-md-12'>
                <table className="table manageuser_grid">
                  <thead>
                    <tr>
                      <th className="px-4" scope="col">Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Products</th>
                      <th scope="col">Role</th>
                      <th scope="col">Created Date</th>
                      <th scope="col">status</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody className='border-top-0'>
                    <tr>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <img src={user1} className="user_icon" alt="userimg"/>
                          <div>Ashok Kumar</div>
                        </div>
                      </td>
                      <td>ashok.kumar@qassure.com</td>
                      <td>Quantify, Proov</td>
                      <td><span className='role member'>Member</span></td>
                      <td>23/05/2021</td>
                      <td>Active</td>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <button className='btn action_btns' onClick={() => Toggle()}>{editIcon}</button>
                          <button className='btn action_btns' onClick={() => delToggle()}>{delIcon}</button>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <img src={user2} className="user_icon" alt="userimg"/>
                          <div>Sathish Kumar</div>
                        </div>
                      </td>
                      <td>sathish.k@qassure.com</td>
                      <td>Quantify, Quantum</td>
                      <td><span className='role member'>Member</span></td>
                      <td>23/05/2021</td>
                      <td>Active</td>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <button className='btn action_btns'>{editIcon}</button>
                          <button className='btn action_btns'>{delIcon}</button>
                        </div>
                      </td>
                    </tr>  
                    <tr>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <img src={user3} className="user_icon" alt="userimg"/>
                          <div>Manikandan Nagendran</div>
                        </div>
                      </td>
                      <td>manikandan.nagendran@qassure.com</td>
                      <td>Quantify</td>
                      <td><span className='role member'>Member</span></td>
                      <td>23/05/2021</td>
                      <td>Active</td>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <button className='btn action_btns'>{editIcon}</button>
                          <button className='btn action_btns'>{delIcon}</button>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <img src={user4} className="user_icon" alt="userimg"/>
                          <div>Adiyaman Annathurai</div>
                        </div>
                      </td>
                      <td>adiyaman.annathurai@qassure.com</td>
                      <td>Quantify, Quantum</td>
                      <td><span className='role member'>Member</span></td>
                      <td>23/05/2021</td>
                      <td>Active</td>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <button className='btn action_btns'>{editIcon}</button>
                          <button className='btn action_btns'>{delIcon}</button>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <img src={user5} className="user_icon" alt="userimg"/>
                          <div>Rajesh Kumar</div>
                        </div>
                      </td>
                      <td>rajesh.kumar@qassure.com</td>
                      <td>Proov</td>
                      <td><span className='role member'>Member</span></td>
                      <td>23/05/2021</td>
                      <td>Active</td>
                      <td>
                        <div className='d-flex align-items-center gap-2'>
                          <button className='btn action_btns'>{editIcon}</button>
                          <button className='btn action_btns'>{delIcon}</button>
                        </div>
                      </td>
                    </tr>                                                                               
                  </tbody>
                </table>
                <div className='table_pagination'>
                    <nav aria-label="Page navigation example">
                      <ul className="pagination">
                        <li className="page-item"><Link className="page-link" href="#"><i class="bi bi-chevron-left"></i></Link></li>
                        <li className="page-item"><Link className="page-link active" href="#">1</Link></li>
                        <li className="page-item"><Link className="page-link" href="#">2</Link></li>
                        <li className="page-item"><Link className="page-link" href="#">3</Link></li>
                        <li className="page-item"><Link className="page-link" href="#"><i class="bi bi-chevron-right"></i></Link></li>
                      </ul>
                    </nav>
                </div>              
            </div>
        </div> 
        <Modal show={modal} close={Toggle}/>    
        <DeleteModal show={delModal} close={delToggle}/>
    </div>
  )
}

export default ManageuserAdmin