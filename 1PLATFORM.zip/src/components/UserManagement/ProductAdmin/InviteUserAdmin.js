import React,{useState,useEffect} from 'react'
import {Link, useHistory} from "react-router-dom";
import { useSelector } from 'react-redux';
import '../PlatformAdmin/Inviteuser.scss';
import { useForm, Controller } from "react-hook-form";
import Select from 'react-select'
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import { getUsersInOrg,inviteProductMemebr } from '../../../endpoints/gateway';
const InviteUserAdmin = (props) => {
  const history = useHistory();
  
  const userDetails = useSelector(state => state.user.userInfo.allInfo);
  const [userEmail,setuserEmail]=useState([])
  useEffect(()=>{
    fetchUsers();
  },[])

  const personalSchema = Yup.object().shape({
    userId: Yup.string()        
        .required('User Email is required')
  });

  const { register,
    handleSubmit, setValue,
    formState: { errors, isValid }, control, reset } = useForm({
      resolver: yupResolver(personalSchema),mode: 'onChange'
    });

  const fetchUsers=async()=>{
    let response = await getUsersInOrg(userDetails.userEmail)
    setuserEmail(response.data)
    

  }

  const onSubmit =async(data)=>{
    data.productId = props.match.params.productId
    let response = await inviteProductMemebr(data)
    toast.success(response.data.message)
  }
  return (
    <div className='inviteUser'>
        <div className="mt-2 custom-head-card">
            <div className="d-flex justify-content-between align-items-center">
              <div className='d-flex align-items-center gap-2'>
                  <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
                  <div className='h3'>Invite User</div>
              </div>
                <Link to="/manageuseradmin" className="btn btn_primary px-3">Manage Users</Link>
            </div>
        </div>
        <div className='row my-2 g-3'>
            <div className='col-md-12 '>
               
              <form className='inviteUserForm' onSubmit={handleSubmit(onSubmit)}>
                    
                    <div className="form-group my-3">
                      <Controller
                            name="userId"
                            control={control}
                            render={({ field:{value, onChange}  }) => <Select                                
                                // value={allProducts?.find((c) => c.productId === value)}
                                onChange={(val) => onChange(val.userId)}
                                options={userEmail}
                                getOptionLabel={(option) => option.userEmail}
                                getOptionValue={(option) => option.userId}
                            />}
                            rules={{ required: true }}
                        />
                         <span className="error">{errors.userId && <span>{errors.userId?.message}</span>}</span>
                    
                    </div>
                    <div className='text-center'>
                      <button type="submit" className="btn btn_inviteUser  mt-4">Invite User</button>
                    </div>
                </form>          
            </div>
        </div>       
    </div>
  )
}

export default InviteUserAdmin