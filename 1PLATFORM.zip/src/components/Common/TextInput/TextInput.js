import React from 'react'
import './Textinput.scss'

const TextInput = ({ fieldName, value, register, errors, placeHolder, isDisabled, isRequired, maximLength, minimLength, pattern, patternMessage, setValue }) => {

    return (
        <>
            <div class="op_input_block">
                <label htmlFor={fieldName} className="form-label">{placeHolder} <span className='text-danger'>*</span> </label>
                <input
                    type="text"
                    disabled={isDisabled}
                    {...register(fieldName, {
                        required: {
                            value: isRequired,
                            message: `${placeHolder} is required`
                        },
                        maxLength: {
                            value: maximLength,
                            message: `${placeHolder} must not exceed   ${maximLength} character`,
                        },
                        minLength: {
                            value: minimLength,
                            message: `${placeHolder} should be greater than ${minimLength} character`,
                        },
                        pattern: {
                            value: pattern,
                            message: patternMessage
                        }
                    }
                    )}
                    className={`form-control ${errors?.[fieldName] ? 'invalid' : ''}`}
                    id={fieldName}
                    aria-describedby={fieldName} />
                <span className="input_error_msg">{errors?.[fieldName] && errors?.[fieldName]?.message}</span>
            </div>
        </>
    )
}

export default TextInput 