import * as React from 'react';

export default function Cell({
    content,
    header,
}) {

    const cellMarkup = header ? (
        <th scope="col">
            {content}
            <span className="float-end">
                <i className="fa fa-play" aria-hidden="true"></i>
            </span>
        </th>
    ) : (
        <td scope="row">
            
                {content}
            
        </td>
    );

    return (cellMarkup);
}