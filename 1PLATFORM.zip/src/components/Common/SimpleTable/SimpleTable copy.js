import React from "react";
import './SimpleTable.scss';

class SimpleTable extends React.Component {
    constructor(props) {
       super(props)
       this.state = {
          students: [
             { id: 1, name: 'Wasif', age: 21, email: 'wasif@email.com' },
             { id: 2, name: 'Ali', age: 19, email: 'ali@email.com' },
             { id: 3, name: 'Saad', age: 16, email: 'saad@email.com' },
             { id: 4, name: 'Asad', age: 25, email: 'asad@email.com' }
          ]
       }
    }
 
    renderTableHeader() {
       let header = Object.keys(this.state.students[0])
       return header.map((key, index) => {
          return <th key={index}>{key.toUpperCase()}</th>
       })
    }
 
    renderTableData() {
       return this.state.students.map((student, index) => {
          const { id, name, age, email } = student //destructuring
          return (
             <tr key={id}>
                <td>{id}</td>
                <td>{name}</td>
                <td>{age}</td>
                <td>{email}</td>
             </tr>
          )
       })
    }
 
    render() {
       return ( 
           <>
            <div className="card-header">Analysis Summary</div>
            <div className="card-body">
                <table className="table table-bordered">
                    <thead className="table-dark">
                        <tr>
                            <th scope="col">Testcase 
                                <span className="float-end text-white">
                                    <i className="fa fa-book" aria-hidden="true"></i>
                                </span>
                            </th>
                            <th scope="col">Start Time
                                <span className="float-end">
                                    <i className="fa fa-play" aria-hidden="true"></i>                                                    
                                </span>
                            </th>
                            <th scope="col">End Time
                                <span className="float-end">
                                    <i className="fa fa-stop" aria-hidden="true"></i>
                                </span>
                            </th>
                            <th scope="col">Duration
                                <span className="float-end">
                                    <i className="fa fa-clock-o" aria-hidden="true"></i>                                                    
                                </span>
                            </th>
                            <th scope="col">Status
                                <span className="float-end">
                                    <i className="fa fa-check" aria-hidden="true"></i>                                                  
                                </span>
                            </th> 
                            <th scope="col">Action</th>                                                                                       
                          </tr>
                    </thead>
                    <tbody>
                        <tr>
                          <th scope="row">Demo_pipoint_auto_JMX_JMX</th>
                          <td>12/03/2020 9:31:54 PM	</td>
                          <td>12/03/2020 9:32:54 PM	</td>
                          <td>00:11:00</td>
                          <td>
                              <span className="progress m-0">
                                <div className="progress-bar bg-success" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"> 
                                  <strong>94.57 %</strong>
                                </div>
                              </span>                     
                          </td>
                          <td className="d-flex">
                              <a href="#" className="mt-0 mb-0 m-1">
                                  <span className="text-primary font-bold"><i className="fa fa-refresh" aria-hidden="true"></i></span>
                              </a>
                              <a href="#" className="mt-0 mb-0 m-1">
                                  <span className="text-danger font-bold"><i className="fa  fa-stop-circle" aria-hidden="true"></i> </span>
                              </a>                                                
                          </td>
                        </tr>
                      </tbody>
                  </table>                
            </div>
           </>
        //   <div>
        //      <h1 id='title'>React Dynamic Table</h1>
        //      <table id='students'>
        //         <tbody>
        //            <tr>{this.renderTableHeader()}</tr>
        //            {this.renderTableData()}
        //         </tbody>
        //      </table>
        //   </div>
       )
    }
 }
 
 export default SimpleTable