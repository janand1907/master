import axios from "axios";

export default axios.create({
  baseURL: "https://dtlehta1thuw9.cloudfront.net/testcasemgmt",
  headers: {
    "Content-type": "application/json",
  },
});
