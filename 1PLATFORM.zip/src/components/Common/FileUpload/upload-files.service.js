import http from "./http-common";

class UploadFilesService {
  upload(file, onUploadProgress) {
    let formData2 = new FormData();

    formData2.append("files", file);

    return http.post("/api/attachment/uploadfiles", 
      formData2, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
      onUploadProgress,
    });
  }

  getFiles() {
    return http.get("/api/attachment/readfiles");
  }
}

export default new UploadFilesService();
