import React from "react";
import './Cards.scss';
import ProgressBar from 'react-bootstrap/ProgressBar';
import graph from '../../../assets/images/img.png';

const Cards = ({ completed, pocName, boxNumber, handleDrag, handleDrop }) => {
    return (
        <div
            draggable={true}
            onDragOver={(ev) => ev.preventDefault()}
            onDragStart={handleDrag}
            onDrop={handleDrop}
            id={boxNumber}
            className="col-sm-3"
        >
            <div className="card">
                <div className="card-body">
                    <div className="cardHeaderBlock">
                        <h5 className="card-title">PoC's {pocName}</h5>
                        <span className="float-right">
                            <i className="bi bi-ui-checks-grid"></i>
                        </span>
                    </div>
                    <ProgressBar animated now={completed} />
                    some description on the PoC's that should remind us what we are testing and monitoring...
                    <div className="cFooter">
                        <div className="leftCFooter mb-2">
                            3 Vendors <span className="ms-2">
                                <i className="bi bi-people-fill"></i>
                            </span>
                        </div>
                        <div className="rightCFooter">
                            <img className="cfooterImage" src={graph} alt="image" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Cards;