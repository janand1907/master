import React, { useEffect, useState, useMemo } from "react";
import Pagination from "react-bootstrap/Pagination";

const PaginationComponent = ({
    total = 1,
    itemsPerPage = 10,
    currentPage = 1,
    onPageChange,
    show=true
}) => {
    const [totalPages, setTotalPages] = useState(0);

    useEffect(() => {
        
/**
 * 
 * var numberOfPages = Math.floor((totalItemsCount + numberOfItemsPerPage - 1) / numberOfItemsPerPage);
var start = (page * numberOfItemsPerPage) - (numberOfItemsPerPage - 1);
var end = Math.min(start + numberOfItemsPerPage - 1, totalItemsCount);

 */

        if (total > 0 && itemsPerPage > 0)
            setTotalPages(Math.floor((total + itemsPerPage - 1) / itemsPerPage));
    }, [total, itemsPerPage]);

    const paginationItems = useMemo(() => {
        const pages = [];
       if (totalPages < 10) {
        for (let i = 1; i <= totalPages; i++) {
            
            pages.push(
                <Pagination.Item
                    key={i}
                    active={i === currentPage}
                    onClick={() => onPageChange(i)}
                >
                    {i}
                </Pagination.Item>
            );
            
        }
       } else {
        for (let i = 1; i <= 10; i++) {
            
            pages.push(
                <Pagination.Item
                    key={i}
                    active={i === currentPage}
                    onClick={() => onPageChange(i)}
                >
                    {i}
                </Pagination.Item>
            );
            
        }
       }
        

        return pages;
    }, [totalPages, currentPage]);
    
    if (totalPages === 0 || !show) return null;
    if (totalPages < 10) {
        return (
       
            <Pagination >
                <Pagination.Prev
                    onClick={() => onPageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                />
                {paginationItems}
                <Pagination.Next
                    onClick={() => onPageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                />
            </Pagination>
        );
    } else {
        return (
       
            <Pagination >
                <Pagination.Prev
                    onClick={() => onPageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                />
                {paginationItems}
                <Pagination.Ellipsis />
                <Pagination.Item onClick={() => onPageChange(totalPages)}>{totalPages}</Pagination.Item>
                <Pagination.Next
                    onClick={() => onPageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                />
            </Pagination>
        );
    }
    
};

export default PaginationComponent;