import React, {useState} from 'react'
import './Selectdropdown.scss'
import dropDownIcon from '../../../assets/images/dropIcon.svg'

const Selectdropdown = (props) => {
    const[isActive, setIsActive] = useState(false);
  return (
    <div className='dropDown_panel'>
    <div className='op_dropdown' onClick={(e)=>setIsActive(!isActive)}>
      <div className='dropdown_btn'>{props.dataSelected} <span className='dropDownIcon'> <img src={dropDownIcon} alt='dropdownicon' /> </span></div>
      {isActive && (
        <div className='dropdown_content'>
            {props.options?.map((d)=>(
            <>
               {props.getSelectLabel !=0 ? 
                  <div
                 className='dropdown_item'
                    onClick={(e)=>{
                        props.setDataSelected(d[props.getSelectLabel]);
                        props.filterSelect(d[props.getSelectLabel])
                        setIsActive(false);
                    }}
                 >{d[props.getSelectLabel]}
                 </div>
                  :
                  <>
                    <div
                      className='dropdown_item'
                          onClick={(e)=>{
                              props.setDataSelected(d);
                              props.filterSelect(d)
                              setIsActive(false);
                          }}
                      >{d}
                 </div>
                  </>
                 }
            </>
                 
                
            ))}
        </div>
      )}
    </div>
  </div>
  )
}


// {Object.keys(props.options).map((d)=>(

// ))}

// {props.options.map((d)=>(
//   <div
//    className='dropdown_item'
//       onClick={(e)=>{
//           props.setDataSelected(d.roleName);
//           props.filterSelect(d.roleName)
//           setIsActive(false);
//       }}
//    >{d.roleName}
//    </div>
// ))}

export default Selectdropdown