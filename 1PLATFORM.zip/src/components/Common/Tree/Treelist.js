import React from "react";

import Tree from "./Tree";


const treeData = [
  {
    key: "0",
    label: "Documents",
    icon: "bi-folder",
    title: "Documents Folder",
    children: [
      {
        key: "0-0",
        label: "Document 1-1",
        icon: "bi-folder",
        title: "Documents Folder",
        children: [
          {
            key: "0-1-1",
            label: "Document-0-1.doc",
            icon: "bi-file-text",
            title: "Documents Folder",
          },
          {
            key: "0-1-2",
            label: "Document-0-2.doc",
            icon: "bi-file-text",
            title: "Documents Folder",
          },
          {
            key: "0-1-3",
            label: "Document-0-3.doc",
            icon: "bi-file-text",
            title: "Documents Folder",
          },
          {
            key: "0-1-4",
            label: "Document-0-4.doc",
            icon: "bi-file-text",
            title: "Documents Folder",
          },
        ],
      },
    ],
  },
  {
    key: "1",
    label: "Desktop",
    icon: "bi-pc",
    title: "Desktop Folder",
    children: [
      {
        key: "1-0",
        label: "document1.doc",
        icon: "bi-file-text",
        title: "Documents Folder",
      },
      {
        key: "0-0",
        label: "documennt-2.doc",
        icon: "bi-file-text",
        title: "Documents Folder",
      },
    ],
  },
  {
    key: "2",
    label: "Downloads",
    icon: "bi-download",
    title: "Downloads Folder",
    children: [],
  },
];

const Treelist = () => {
  return (
    <>
      <div className="row">
        <div className="col">
           <Tree data={treeData} />
        </div>
      </div>
    </>
  );
};

export default Treelist;