import React from 'react';
import { useForm } from 'react-hook-form';
import { Col, FloatingLabel, Form,Button } from 'react-bootstrap';
import './OPForm.scss'

// Reusable Form Component
function OPForm({ template, onSubmit }) {
    let { register, handleSubmit, formState: { errors, ...formState } } = useForm();
    let { title, fields } = template;
    const renderFields = (fields) => {
        return fields.map(field => {
            let { title, type, name, validationProps, dynamic } = field;
            switch (type) {
                case 'text':
                    return (
                        <Col sm={12} key={name}>
                            <FloatingLabel controlId={name} label={title}>
                                <Form.Control type="text" {...register(name, validationProps)} />
                            </FloatingLabel>

                            {
                                errors?.[name]?.['type'] === 'required' && <span className="red-text">{title} is Required</span>

                            }
                            {

                                errors?.[name]?.['type'] === 'pattern' && <span className="red-text">{errors?.[name]?.['message']}</span>
                            }
                            {

                                errors?.[name]?.['type'] === 'maxLength' && <span className="red-text">{errors?.[name]?.['message']}</span>
                            }
                            {

                                errors?.[name]?.['type'] === 'minLength' && <span className="red-text">{errors?.[name]?.['message']}</span>
                            }

                        </Col>
                    )


                case 'textarea':
                    return (
                        <Col sm={12} key={name}>
                            <FloatingLabel controlId={name} label={title}>
                                <Form.Control as="textarea" {...register(name, validationProps)} />
                            </FloatingLabel>
                            {
                                errors?.[name]?.['type'] === 'required' && <span className="red-text">{title} is Required</span>

                            }

                        </Col>
                    )

                default:
                    return (
                        <div key={name}>
                            <span className="red-text">Invalid Field</span>
                        </div>
                    )
            }


        })
    }

    return (
        <>
            <form onSubmit={handleSubmit(onSubmit)} className="custom-form"> 
                {renderFields(fields)}
                <br />
                <Col sm={12} className="text-center">
                     <button className="btn btn_primary" type="submit">Create</button>
                </Col>
            </form>
        </>
    );
}

export default OPForm;