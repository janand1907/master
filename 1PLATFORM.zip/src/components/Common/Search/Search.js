import React, { useState } from "react";

const Search = ({ searchOpen, animateSearch, onSearch, placeholder }) => {
    const [search, setSearch] = useState("");

    const onInputChange = value => {
        setSearch(value);
        onSearch(value);
    };
    return (
        // <div className='searchinput'>
        //     <input
        //         type="text"
        //         className="form_control"
        //         style={{ width: "20rem" }}
        //         placeholder="Search"
        //         value={search}
        //         onChange={e => onInputChange(e.target.value)}
        //     />
        //     <span className='search_icon'><i className="bi bi-search"></i></span>
        // </div>
        <div className="subTblFilter">
            <div className="filterSearchWrapper">
                {/* <div className={`filterSearch ${searchOpen ? "open" : ""}`}> */}
                <div className={"filterSearch"}>
                    <span className="searchIcon" onClick={animateSearch}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22">
                            <path id="search_FILL0_wght400_GRAD0_opsz24" d="M140.289-818l-7.7-7.7a7.282,7.282,0,0,1-2.108,1.161,7.449,7.449,0,0,1-2.536.428,7.669,7.669,0,0,1-5.637-2.307A7.669,7.669,0,0,1,120-832.056a7.669,7.669,0,0,1,2.307-5.638A7.669,7.669,0,0,1,127.944-840a7.669,7.669,0,0,1,5.637,2.307,7.669,7.669,0,0,1,2.307,5.638,7.449,7.449,0,0,1-.428,2.536,7.285,7.285,0,0,1-1.161,2.108l7.7,7.7Zm-12.344-8.556a5.3,5.3,0,0,0,3.9-1.6,5.3,5.3,0,0,0,1.6-3.9,5.3,5.3,0,0,0-1.6-3.9,5.3,5.3,0,0,0-3.9-1.6,5.3,5.3,0,0,0-3.9,1.6,5.3,5.3,0,0,0-1.6,3.9,5.3,5.3,0,0,0,1.6,3.9A5.3,5.3,0,0,0,127.944-826.556Z" transform="translate(-120 840)" fill="#9c9c9c" />
                        </svg>
                    </span>
                    <input
                        type="text"
                        // className="form_control"
                        // style={{ width: "20rem" }}
                        placeholder={placeholder ? placeholder : "Search"}
                        value={search}
                        onChange={e => onInputChange(e.target.value)}
                    />
                    {/* <span className="searchIcon" onClick={animateSearch}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                        </svg>
                    </span> */}
                    {/* <span className="closeIcon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
                            <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z" />
                        </svg>
                    </span> */}
                </div>
            </div>
        </div>
    );
};

export default Search;