import React from 'react';
import styled from 'styled-components';
import logo from '../../../assets/images/op_public/logo.png';

const LOGO = styled.img`width:15.625rem;`;
const Logo = () => {
  return (
    <a href='/home'>
        <LOGO src={logo} />
    </a>
  )
}

export default Logo