import React from 'react';
import './Textarea.scss';

const TextArea = ({ fieldName, register, errors, placeHolder, isRequired,isDisabled, maximLength, minimLength,pattern,patternMessage}) => {
    
    return (
        <>
            <div class="op_input_block">
                <label htmlFor={fieldName} className="form-label">{placeHolder} <span className='text-danger'>*</span> </label>                
                <textarea
                    disabled={isDisabled} 
                    
                    {...register(fieldName, { 
                        required: {
                            value: isRequired,
                            message: `${placeHolder} is required`
                        },
                        maxLength: {
                            value: maximLength,
                            message: `${placeHolder} should be less than  ${maximLength} character`,
                        },
                        minLength: {
                            value: minimLength,
                            message: `${placeHolder} shlould be greater than ${minimLength} character`,
                        },
                        pattern: {
                            value: pattern,
                            message: patternMessage
                        }
                    }                    
                    )} 
                    className={`form-control ${errors?.[fieldName] ? 'invalid' : ''}`} 
                    id={fieldName} 
                    aria-describedby={fieldName} 
                    style={{height: '100px'}}
                    />
                <span className="input_error_msg">{errors?.[fieldName] && errors?.[fieldName]?.message}</span>
            </div>
        </>
        
    )
}

export default TextArea 