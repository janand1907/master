import React, { useState, useEffect } from 'react'
import './Plandetail.scss'
import nodata from '../../assets/images/nodata.svg';
import { backBtnIcon } from '../../Icons/icons';
import card1 from '../../assets/images/usermanagement/34.png';
import card2 from '../../assets/images/usermanagement/35.png';
import card3 from '../../assets/images/usermanagement/36.png';
import { Form, Modal } from 'react-bootstrap'
import { useHistory } from 'react-router-dom';
const ManageSubscribedUsers = () => {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const history = useHistory();
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex gap-2 align-items-center'>
                    <button type="button" onClick={() => history.goBack()} className="btn btn_light">{backBtnIcon}</button>
                    <div className='h3'>Edit User Details</div>
                </div>
            </div>
            <div className={"box-wrapper"}>
                <div className={"inlineformcontainer"}>
                    <div className={"centerform"}>
                        <div className={"fieldContainer"}>
                            <label className={"labelText"}>First Name <span className={"astericColor"}>*</span></label>
                            <input type="text" value="Ashok" className={"form-control centerforminputs"} disabled />
                            {/* <Error name="" className={"errormsg"} /> */}
                        </div>
                        <div className={"fieldContainer"}>
                            <label className={"labelText"}>Last Name<span className={"astericColor"}>*</span></label>
                            <input type="text" value="Kumar" className={"form-control centerforminputs"} disabled />
                            {/* <Error name="" className={"errormsg"} /> */}
                        </div>
                        <div className={"fieldContainer"}>
                            <label className={"labelText"}>Email ID <span className={"astericColor"}>*</span></label>
                            <input type="text" value="ashok.kumar@wellsfargo.com" className={"form-control centerforminputs"} disabled />
                            {/* <Error name="company_type" className={"errormsg"} /> */}
                        </div>
                        <div className={"fieldContainer"}>
                            <label className={"labelText"}>Contact Number <span className={"astericColor"}>*</span></label>
                            <input type="text" value="+91 9006734414" className={"form-control centerforminputs"} disabled />
                            {/* <Error name="company_type" className={"errormsg"} /> */}
                        </div>
                        <div className={"fieldContainer"}>
                            <label className={"labelText"}>Role <span className={"astericColor"}>*</span></label>
                            <input type="text" value="Member" className={"form-control centerforminputs"} disabled />
                            {/* <Error name="company_type" className={"errormsg"} /> */}
                        </div>
                        <div className={"fieldContainer"}>
                            <label className={"labelText"}>Subscribed Product <span className={"astericColor"}>*</span></label>
                            <input type="text" value="OIP - Open Innovation Platform" className={"form-control centerforminputs"} disabled />
                            {/* <Error name="company_type" className={"errormsg"} /> */}
                        </div>
                        <div className={"fieldContainer togglemargin"}>
                            <label className={"labelText"}>Account Status <span className={"astericColor"}>*</span></label>
                            <div className={"centerforminputs togglewrapper"}>
                                <label class="switch">
                                    <input type="checkbox" />
                                    <span class="slider round"></span>
                                </label>
                                <span className={"toggleLabel"}>Active</span>
                            </div>
                        </div>
                    </div>
                    <div className={"btnWrapper"}>
                        <button className={"secondaryBtn"}>
                            <span>Cancel</span>
                        </button>
                        <button className={"primaryBtn"}>
                            <span>Update</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ManageSubscribedUsers