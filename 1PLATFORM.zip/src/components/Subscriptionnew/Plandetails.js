import React from 'react'
import './Plandetail.scss'
import nodata from '../../assets/images/nodata.svg';
import { backBtnIcon } from '../../Icons/icons';
import { NavLink } from 'react-router-dom';

const Plandetails = (props) => {


    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className="d-flex gap-2 align-items-center">
                    <button type="button" className="btn btn_light">{backBtnIcon}</button>
                    <div className='h3'>Subscription Plan Details</div>
                </div>
            </div>
            <div className="box-wrapper">
                <div className={"pricingCardwrap"}>
                    <ul>
                        <li>
                            <div className={"pricingCard"}>
                                <div className={"popularBand"}>
                                    <span>Most Popular</span>
                                </div>
                                <div className={"planDetailsTop"}>
                                    <h4 className={"planName"}>
                                        <strong>Premium - Pro</strong>
                                        <span>Yearly</span>
                                    </h4>
                                    <div className={"offerPrice"}>
                                        <h4 className={"existPrice"}>$ 719.88</h4>
                                        <h1 className={"planPrice"}>
                                            <strong>$611.88</strong>
                                            <span>(Plan Price)</span>
                                        </h1>
                                    </div>
                                </div>
                                <ul className={"planFeaturs"}>
                                    <li>Single License</li>
                                    <li>Create a Challenges</li>
                                    <li>Post a Solutions</li>
                                    <li>Create a PoC</li>
                                    <li>24/7 Customer Support</li>
                                </ul>
                                <div className={"subscribeBtnWrap"}>
                                    <button className={"primaryBtn"}>Subscribe</button>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    )
}

export default Plandetails;