import React, { useState, useEffect } from 'react'
import './Plandetail.scss'
import nodata from '../../assets/images/nodata.svg';
import { backBtnIcon } from '../../Icons/icons';
import card1 from '../../assets/images/usermanagement/34.png';
import card2 from '../../assets/images/usermanagement/35.png';
import card3 from '../../assets/images/usermanagement/36.png';
import { Form, Modal } from 'react-bootstrap'
import { NavLink } from 'react-router-dom';
import { useHistory } from 'react-router-dom';
const ManageSubscribedUsers = () => {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const history = useHistory();
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <button type="button" onClick={() => history.goBack()} className="btn btn_light">{backBtnIcon}</button>
                        <div className='h3'>Manage Users</div>
                    </div>
                    <div className='d-flex align-items-center gap-3'>
                        <a className='btn btn_primary' onClick={handleShow}>Invite User</a>
                    </div>
                </div>
            </div>
            <ul className={"licenceCard"}>
                <li>
                    <div className={"card"}>
                        <div className={"cardDetails"}>
                            <span className={"icon"}>
                                <img src={card1} alt="" />
                            </span>
                            <h2 className={"count"}>
                                <strong>25</strong>
                                <span>Total License</span>
                            </h2>
                        </div>
                    </div>
                </li>
                <li>
                    <div className={"card"}>
                        <div className={"cardDetails"}>
                            <span className={"icon"}>
                                <img src={card2} alt="" />
                            </span>
                            <h2 className={"count"}>
                                <strong>13</strong>
                                <span>Used License</span>
                            </h2>
                        </div>
                    </div>
                </li>
                <li>
                    <div className={"card"}>
                        <div className={"cardDetails"}>
                            <span className={"icon"}>
                                <img src={card3} alt="" />
                            </span>
                            <h2 className={"count"}>
                                <strong>12</strong>
                                <span>Unused License</span>
                            </h2>
                        </div>
                    </div>
                </li>
            </ul>
            <div className='row my-3'>
                <div className='col-md-12'>
                    <div className='card op_card'>
                        <div className='card-body px-0 pb-0'>
                            <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                <div className='heading_approval'>Product Pending Details</div>
                            </div>
                            <table className="table manageuser_grid mb-0">
                                <thead>
                                    <tr className='px-3 py-4'>
                                        <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Email<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Product Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Role <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Created Date <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Status <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col" className='text-center'>Action</th>
                                    </tr>
                                </thead>
                                <tbody className='border-top-0'>
                                    <tr>
                                        <td className='px-3'>Manikandan Nagendran</td>
                                        <td>manikandan.n@wellsfargo.com</td>
                                        <td>OIP - Open Innovation Platform</td>
                                        <td>
                                            <span className={"memberRole"}>Member</span>
                                        </td>
                                        <td>07/11/2022</td>
                                        <td>Active</td>
                                        <td className='text-center'>
                                            <div className={"middleAlign"}>
                                                <span className={"actionIcons"}>
                                                    <NavLink to="/subUserDetails" activeClassName="active">
                                                        <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="EditIcon"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path></svg>
                                                    </NavLink>
                                                </span>
                                                <span className={"actionIcons"}>
                                                    <NavLink to="/subUserDetails" activeClassName="active">
                                                        <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="RemoveRedEyeOutlinedIcon"><path d="M12 6.5c3.79 0 7.17 2.13 8.82 5.5-1.65 3.37-5.02 5.5-8.82 5.5S4.83 15.37 3.18 12C4.83 8.63 8.21 6.5 12 6.5m0-2C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zm0 5c1.38 0 2.5 1.12 2.5 2.5s-1.12 2.5-2.5 2.5-2.5-1.12-2.5-2.5 1.12-2.5 2.5-2.5m0-2c-2.48 0-4.5 2.02-4.5 4.5s2.02 4.5 4.5 4.5 4.5-2.02 4.5-4.5-2.02-4.5-4.5-4.5z"></path></svg>
                                                    </NavLink>
                                                </span>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <Modal show={show} onHide={handleClose} centered backdrop="static" keyboard={false} className='warningModal'>
                <Modal.Header className='border-0  m-0' closeButton>
                    <h3 className={"modal-title"}>Invite User</h3>
                </Modal.Header>
                <Modal.Body>
                    <div className={"customeSearch"}>
                        <input type="text" placeholder="Search by User name" />
                        <ul className={"customdrop slimscroll"} style={{ display: "none" }}>
                            <li>
                                <p title={"ashok.kumar@wellsfargo.com"}>ashok.kumar@wellsfargo.com</p>
                            </li>
                            <li>
                                <p title={"ashok.kumar@wellsfargo.com"}>ashok.kumar@wellsfargo.com</p>
                            </li>
                            <li>
                                <p title={"ashok.kumar@wellsfargo.com"}>ashok.kumar@wellsfargo.com</p>
                            </li>
                        </ul>
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </span>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center border-0 pt-2 pb-3'>
                    <button className='btn btn_primary px-3 mx-2' onClick={""}>Invite User</button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default ManageSubscribedUsers