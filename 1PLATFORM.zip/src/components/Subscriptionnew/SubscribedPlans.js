import React from 'react'
import './Plandetail.scss'
import nodata from '../../assets/images/nodata.svg';
import { backBtnIcon } from '../../Icons/icons';
import { NavLink } from 'react-router-dom';
const SubscribedPlans = () => {
    return (
        <div>
            <div className="mt-2 custom-head-card">
                {/* <div className="d-flex gap-2 align-items-center">
                    <div className='h3'>Subscription Management</div>
                </div> */}
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        {/* <button type="button" onClick={() => history.goBack()} className="btn btn_light">{backBtnIcon}</button> */}
                        <div className='h3'>Subscription Management</div>
                    </div>
                    <div className='d-flex align-items-center gap-3'>
                        <NavLink to="/plandetails" className="primaryBtn" activeClassName="active">
                            Change Plan
                        </NavLink>
                        <NavLink to="/newsubdetails" className="primaryBtn ml-3" activeClassName="active">
                            Upgrade Users/Add ons
                        </NavLink>
                    </div>
                </div>
            </div>
            <div className="box-wrapper">
                <div className={"subscribedProducts"}>
                    <ul className={"subscribedlist"}>
                        <li>
                            <div className={"card"}>
                                <div className={"productDetails"}>
                                    <div className={"productName"}>OIP</div>
                                    <div className={"planName"}>Premium-pro</div>
                                </div>
                                <div className={"productDescription"}>
                                    <p>Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</p>
                                    {/* <NavLink to="/manageSubscribedUsers" className="view" activeClassName="active">View Details</NavLink> */}
                                    {/* <a className={"view"}>View Details</a> */}
                                    <NavLink to="/newsubdetails" className="renew" activeClassName="active">Renew your Plan</NavLink>
                                    {/* <a className={"renew"}>Renew your Plan</a> */}
                                </div>
                                <div className={"expiryDetails"}>
                                    <div className={"from"}>
                                        <span>
                                            <svg id="today_black_24dp" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 20 20"><path id="Path_13531" data-name="Path 13531" d="M0,0H20V20H0Z" fill="none"></path><path id="Path_13532" data-name="Path 13532" d="M17.885,2.783h-.93V1H15.094V2.783H7.652V1H5.791V2.783h-.93A1.823,1.823,0,0,0,3,4.566V17.048a1.823,1.823,0,0,0,1.861,1.783H17.885a1.828,1.828,0,0,0,1.861-1.783V4.566A1.828,1.828,0,0,0,17.885,2.783Zm0,14.265H4.861V8.132H17.885Zm0-10.7H4.861V4.566H17.885ZM6.721,9.915h4.652v4.458H6.721Z" transform="translate(-1.373 -0.458)" fill="#757575"></path></svg>
                                        </span>
                                        <div className={"dates"}>
                                            <span>Subscribed On</span>
                                            <label>Oct 23, 2022</label>
                                        </div>
                                    </div>
                                    <div className={"from"}>
                                        <span>
                                            <svg id="today_black_24dp" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 20 20"><path id="Path_13531" data-name="Path 13531" d="M0,0H20V20H0Z" fill="none"></path><path id="Path_13532" data-name="Path 13532" d="M17.885,2.783h-.93V1H15.094V2.783H7.652V1H5.791V2.783h-.93A1.823,1.823,0,0,0,3,4.566V17.048a1.823,1.823,0,0,0,1.861,1.783H17.885a1.828,1.828,0,0,0,1.861-1.783V4.566A1.828,1.828,0,0,0,17.885,2.783Zm0,14.265H4.861V8.132H17.885Zm0-10.7H4.861V4.566H17.885ZM6.721,9.915h4.652v4.458H6.721Z" transform="translate(-1.373 -0.458)" fill="#757575"></path></svg>
                                        </span>
                                        <div className={"dates"}>
                                            <span>Validity Period</span>
                                            <label>Oct 22, 2023</label>
                                        </div>
                                    </div>
                                </div>
                                <div className={"expiryDetails"}>
                                    <div className={"from"}>
                                        <div className={"dates"}>
                                            <span>Remaining Days</span>
                                            <label>11 Months</label>
                                        </div>
                                    </div>
                                    <div className={"from"}>
                                        <div className={"dates"}>
                                            <span>Subscribe Type</span>
                                            <label>Yearly</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    )
}

export default SubscribedPlans