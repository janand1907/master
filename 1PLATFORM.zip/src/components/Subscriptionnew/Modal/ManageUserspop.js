import React, { useState, useEffect } from 'react'
import '../Plandetail.scss'
import { Form, Modal } from 'react-bootstrap'
const ManageUserspop = () => {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return (
        <div>
            <Modal show={show} onHide={handleClose} centered backdrop="static" keyboard={false} className='warningModal'>
                <Modal.Header className='border-0  m-0' closeButton>
                    <h3 className={"modal-title"}>Invite User</h3>
                </Modal.Header>
                <Modal.Body>
                    <div className={"customeSearch"}>
                        <input type="text" placeholder="Search by User name" />
                        <ul className={"customdrop slimscroll"} style={{ display: "none" }}>
                            <li>
                                <p title={"ashok.kumar@wellsfargo.com"}>ashok.kumar@wellsfargo.com</p>
                            </li>
                            <li>
                                <p title={"ashok.kumar@wellsfargo.com"}>ashok.kumar@wellsfargo.com</p>
                            </li>
                            <li>
                                <p title={"ashok.kumar@wellsfargo.com"}>ashok.kumar@wellsfargo.com</p>
                            </li>
                        </ul>
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </span>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center border-0 pt-2 pb-3'>
                    <button className='btn btn_primary px-3 mx-2' onClick={""}>Invite User</button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default ManageUserspop