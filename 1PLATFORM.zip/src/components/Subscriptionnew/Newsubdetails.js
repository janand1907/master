import React from 'react'
import './Plandetail.scss'
import nodata from '../../assets/images/nodata.svg';
import { backBtnIcon } from '../../Icons/icons';
import { useHistory } from 'react-router-dom';
import { NavLink } from 'react-router-dom';
const Newsubdetails = () => {
    const history = useHistory();
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className="d-flex gap-2 align-items-center">
                    <button type="button" onClick={() => history.goBack()} className="btn btn_light">{backBtnIcon}</button>
                    <div className='h3'>Billing Address</div>
                </div>
            </div>
            <div className="box-wrapper">
                <div className={"twoColumn"}>
                    <div className={"colHalf"}>
                        <div className={"formWrap"}>
                            <div className={"formrow"}>
                                <div>
                                    <label>Company Name</label>
                                    <input type="text" value="Wellsfargo" className={"form-control"} disabled />
                                </div>
                            </div>
                            <div className={"formrow"}>
                                <div className={"fieldWrapper"}>
                                    <label>First Name</label>
                                    <input type="text" value="Gopi" className={"form-control"} disabled />
                                </div>
                                <div className={"fieldWrapper"}>
                                    <label>Last Name</label>
                                    <input type="text" value="Kuppuswamy" className={"form-control"} disabled />
                                </div>
                            </div>
                            <div className={"formrow"}>
                                <div>
                                    <label>Country</label>
                                    <input type="text" value="Singapore" className={"form-control"} disabled />
                                </div>
                                <div>
                                    <label>Email</label>
                                    <input type="text" value="Gopi.kuppuswamy@wellsfargo.com" className={"form-control"} disabled />
                                </div>
                            </div>
                            <div className={"formrow"}>
                                <div>
                                    <label># of License Required</label>
                                    <input type="text" className={"form-control"} />
                                </div>
                                <div>
                                    &nbsp;
                                </div>
                            </div>
                            <div className={"buttonWrapper"}>
                                <button className={"secondaryBtn"}>Cancel</button>
                                <NavLink to="/subscribedPlans" className="primaryBtn" activeClassName="active">Pay</NavLink>
                                {/* <button className={"primaryBtn"}>Pay</button> */}
                            </div>
                        </div>
                    </div>
                    <div className={"col25"}>
                        <div className={"priceDetails"}>
                            <div className={"totalPrize"}>
                                <p>Subscribe to Basic-Monthly</p>
                                <h2>
                                    <strong>$15297.00</strong>
                                    <span>Every 12 months</span>
                                </h2>
                            </div>
                            <ul className={"splitedPricelist"}>
                                <li>
                                    <label className={"splittedLabel"}>
                                        <strong>Pro-unlimited-annual</strong>
                                        <span>Billed every 12 months</span>
                                    </label>
                                    <h5 className={"splittedPrize"}>$15297.00</h5>
                                </li>
                                <li>
                                    <label className={"splittedLabel"}>
                                        <strong>Subtotal</strong>
                                    </label>
                                    <h5 className={"splittedPrize"}>$15297.00</h5>
                                </li>
                                <li className={"seperator"}></li>
                                <li>
                                    <label className={"splittedLabel"}>
                                        <span>Tax (18%)</span>
                                    </label>
                                    <span className={"splittedPrize"}>$2753.46</span>
                                </li>
                                <li className={"seperator"}></li>
                                <li>
                                    <label className={"splittedLabel"}>
                                        <strong>Total</strong>
                                    </label>
                                    <h5 className={"splittedPrize"}>$18015.46</h5>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Newsubdetails