import React from 'react'
import './Plandetail.scss'
import nodata from '../../assets/images/nodata.svg';
import { backBtnIcon } from '../../Icons/icons';
import { NavLink } from 'react-router-dom';
const ProductSubList = () => {
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className="d-flex gap-2 align-items-center">
                    {/* <button type="button" className="btn btn_light">{backBtnIcon}</button> */}
                    <div className='h3'>Plan details</div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-6 col-lg-3">
                    <div class="card op_card" style={{ height: "350px" }}>
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-center">
                                <div className="d-flex align-items-center">
                                    <div className='productlogoPannel'>
                                        {/* <img src={""} alt="product-thumbnail" className="product_thumbnail" /> */}
                                    </div>
                                    <div className="product_title ms-2">Quantify</div>
                                </div>

                            </div>
                            <div className="product_desc my-4">
                                <p>Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</p>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent mx-3 px-0 py-0">
                            <div class="d-flex align-items-center gap-2 my-1 justify-content-center">
                                <NavLink to="/plandetails" className="primaryBtn px-4 my-3" activeClassName="active">View Plan</NavLink>
                                {/* <a class="btn_primary btn btn-sm px-4 my-3" href="/subscription/1">View Plan</a> */}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card op_card" style={{ height: "350px" }}>
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-center">
                                <div className="d-flex align-items-center">
                                    <div className='productlogoPannel'>
                                        {/* <img src={""} alt="product-thumbnail" className="product_thumbnail" /> */}
                                    </div>
                                    <div className="product_title ms-2">OIP</div>
                                </div>

                            </div>
                            <div className="product_desc my-4">
                                <p>Smart Many desktop publishing packages and web page editors now use Lorem Ipsum as their default</p>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent mx-3 px-0 py-0">
                            <div class="d-flex align-items-center gap-2 my-1 justify-content-center">
                                <NavLink to="/subscribedPlans" className="secondaryBtn px-4 my-3" activeClassName="active">View Details</NavLink>
                                {/* <a class="btn_primary btn btn-sm px-4 my-3" href="/subscription/1">View Details</a> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ProductSubList