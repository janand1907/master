import React, { useState, useEffect } from 'react'
import '../Plandetail.scss'
import { Form, Modal, Tab, Tabs } from 'react-bootstrap'
import Dropdown from 'react-bootstrap/Dropdown';
import { NavLink } from 'react-router-dom';
const ManageSubscribedUsers = () => {
    const [key, setKey] = useState('licenseUsers');
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [show2, setShow2] = useState(false);
    const handleShow2 = () => setShow2(true);
    const handleClose2 = () => setShow2(false);

    const [show3, setShow3] = useState(false);
    const handleShow3 = () => setShow3(true);
    const handleClose3 = () => setShow3(false);

    const [show4, setShow4] = useState(false);
    const handleShow4 = () => setShow4(true);
    const handleClose4 = () => setShow4(false);

    const [show5, setShow5] = useState(false);
    const handleShow5 = () => setShow5(true);
    const handleClose5 = () => setShow5(false);
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Subscribe management details</div>
                    </div>
                    <div className='d-flex align-items-center gap-3'>
                        <a className='btn btn_primary' onClick={handleShow}>Manage User</a>
                    </div>
                </div>
            </div>
            <Tabs
                id="controlled-tab-example"
                activeKey={key}
                onSelect={(k) => setKey(k)}
                className="manageSubscription"
            >
                <Tab
                    eventKey="licenseUsers"
                    title={
                        <>
                            <span>All Purchases</span>
                        </>
                    }>
                    <div className='row my-3'>
                        <div className='col-md-12'>
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                        <div className='heading_approval'># of Users - 150</div>
                                    </div>
                                    <table className="table manageuser_grid mb-0">
                                        <thead>
                                            <tr className='px-3 py-4'>
                                                <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Email<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">ID Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Company Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col"># of Products <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">License Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col" className='text-center'>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody className='border-top-0'>
                                            <tr>
                                                <td className='px-3'>Manikandan Nagendran</td>
                                                <td>manikandan.n@wellsfargo.com</td>
                                                <td>Individual ID</td>
                                                <td>HCL Technologies</td>
                                                <td>4</td>
                                                <td>Enterprise</td>
                                                <td className='text-center'>
                                                    <div className={"middleAlign"}>
                                                        <span className={"actionIcons"}>
                                                            <NavLink to="/editSubscriptiondetails" className="" activeClassName="active">
                                                                <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="EditIcon"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path></svg>
                                                            </NavLink>
                                                        </span>
                                                        <span className={"actionIcons"}>
                                                            <NavLink to="/editSubscriptiondetails" className="" activeClassName="active">
                                                                <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="RemoveRedEyeOutlinedIcon"><path d="M12 6.5c3.79 0 7.17 2.13 8.82 5.5-1.65 3.37-5.02 5.5-8.82 5.5S4.83 15.37 3.18 12C4.83 8.63 8.21 6.5 12 6.5m0-2C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zm0 5c1.38 0 2.5 1.12 2.5 2.5s-1.12 2.5-2.5 2.5-2.5-1.12-2.5-2.5 1.12-2.5 2.5-2.5m0-2c-2.48 0-4.5 2.02-4.5 4.5s2.02 4.5 4.5 4.5 4.5-2.02 4.5-4.5-2.02-4.5-4.5-4.5z"></path></svg>
                                                            </NavLink>
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </Tab>
                <Tab
                    eventKey="pendingUsera"
                    title={
                        <>
                            <span>Pending Approvals - (14)</span>
                        </>
                    }>
                    <div className='row my-3'>
                        <div className='col-md-12'>
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                        <div className='heading_approval'># of License Requested - 14</div>
                                    </div>
                                    <table className="table manageuser_grid mb-0">
                                        <thead>
                                            <tr className='px-3 py-4'>
                                                <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Email<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Product Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Subscribe Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Request Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col" className='text-center'>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody className='border-top-0'>
                                            <tr>
                                                <td className='px-3'>Manikandan Nagendran</td>
                                                <td>manikandan.n@wellsfargo.com</td>
                                                <td>Cyber Predictor</td>
                                                <td>Monthly</td>
                                                <td>Change Plan</td>
                                                <td className='text-center'>
                                                    <div className={"middleAlign"}>
                                                        <span className={"approve"} onClick={handleShow2}>
                                                            View & Approve
                                                        </span>
                                                        <span className={"reject"} onClick={handleShow4}>
                                                            Reject
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </Tab>
                <Tab
                    eventKey="rejectedusers"
                    title={
                        <>
                            <span>Rejected - (14)</span>
                        </>
                    }>
                    <div className='row my-3'>
                        <div className='col-md-12'>
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                        <div className='heading_approval'># of License Requested - 14</div>
                                    </div>
                                    <table className="table manageuser_grid mb-0">
                                        <thead>
                                            <tr className='px-3 py-4'>
                                                <th scope="col" className='px-3'>Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Email<span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Product Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Request Type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Rejected On <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                <th scope="col">Reason <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                                {/* <th scope="col" className='text-center'>Action</th> */}
                                            </tr>
                                        </thead>
                                        <tbody className='border-top-0'>
                                            <tr>
                                                <td className='px-3'>Manikandan Nagendran</td>
                                                <td>manikandan.n@wellsfargo.com</td>
                                                <td>Quantify</td>
                                                <td>Plan Change</td>
                                                <td>07/11/2022</td>
                                                <td>Payment not completed</td>
                                                {/* <td className='text-center'>
                                                    <div className={"middleAlign"}>
                                                        <span className={"approve"} onClick={handleShow2}>
                                                            Resend
                                                        </span>
                                                    </div>
                                                </td> */}
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </Tab>
            </Tabs>
            <Modal className='' size='lg' show={show} onHide={handleClose} backdrop="static" keyboard={false} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Manage User</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className={"inlineformcontainer"}>
                        <div className={"centerform"}>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Email ID <span className={"astericColor"}>*</span></label>
                                <input type="text" className={"form-control centerforminputs"} />
                                {/* <Error name="" className={"errormsg"} /> */}
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>First Name <span className={"astericColor"}>*</span></label>
                                <input type="text" className={"form-control centerforminputs"} />
                                {/* <Error name="" className={"errormsg"} /> */}
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Last Name<span className={"astericColor"}>*</span></label>
                                <input type="text" className={"form-control centerforminputs"} />
                                {/* <Error name="" className={"errormsg"} /> */}
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Product Name<span className={"astericColor"}>*</span></label>
                                <Dropdown className={"customDropdown centerforminputs"}>
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        Quantify
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item href="#/action-1">Quantify</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">OIP</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">One Platform</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Plan<span className={"astericColor"}>*</span></label>
                                <Dropdown className={"customDropdown centerforminputs"}>
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        Enterprises
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item href="#/action-1">Quantify</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">OIP</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">One Platform</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>

                            <div className={"fieldContainer"}>
                                <label className={"labelText"}># of Days<span className={"astericColor"}>*</span></label>
                                <input type="text" className={"form-control centerforminputs"} />
                                {/* <Error name="" className={"errormsg"} /> */}
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Status<span className={"astericColor"}>*</span></label>
                                <div className={"centerforminputs togglewrapper"}>
                                    <label class="switch">
                                        <input type="checkbox" />
                                        <span class="slider round"></span>
                                    </label>
                                    <span className={"toggleLabel"}>Active</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <button className='btn btn_outline mx-2' onClick={handleClose}>
                        Cancel
                    </button>

                    <button className='btn btn_primary mx-2'>
                        Submit
                    </button>
                </Modal.Footer>
            </Modal>

            <Modal className='' size='lg' show={show2} onHide={handleClose2} backdrop="static" keyboard={false} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Subscription Approval</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="d-flex justify-content-end">
                        <button className="secondaryBtn my-3 smallBtn" onClick={handleShow5}>Billing Details</button>
                    </div>
                    <div className={"labelListWrap"}>
                        <ul className={"labelList"}>
                            <li>
                                <label className={"label"}>Name</label>
                                <label className={"content"}>Ashok Kumar</label>
                            </li>
                            <li>
                                <label className={"label"}>Company Name</label>
                                <label className={"content"}>Infosys Inc</label>
                            </li>
                            <li>
                                <label className={"label"}>License Type</label>
                                <label className={"content"}>Enterprise</label>
                            </li>
                            <li>
                                <label className={"label"}>Mode of License</label>
                                <label className={"content"}>New</label>
                            </li>
                            <li>
                                <label className={"label"}>License Plan</label>
                                <label className={"content"}>Premium-Pro</label>
                            </li>
                        </ul>
                        <ul className={"labelList"}>
                            <li>
                                <label className={"label"}>Email</label>
                                <label className={"content"}>ashok.kumar@qassure.com</label>
                            </li>
                            <li>
                                <label className={"label"}># of License</label>
                                <label className={"content"}>50</label>
                            </li>
                            <li>
                                <label className={"label"}>Requested on</label>
                                <label className={"content"}>09/11/2022</label>
                            </li>
                            <li>
                                <label className={"label"}>Subscribe Type</label>
                                <label className={"content"}>Yearly</label>
                            </li>
                        </ul>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <button className='btn btn_outline mx-2' onClick={handleClose2}>
                        Cancel
                    </button>

                    <button className='btn btn_primary mx-2'>
                        Approve
                    </button>
                </Modal.Footer>
            </Modal>

            <Modal className='' size='lg' show={show3} onHide={handleClose3} backdrop="static" keyboard={false} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Subscription Approval</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className={"labelListWrap"}>
                        <ul className={"labelList disableForm"}>
                            <li>
                                <label className={"label"}>Name</label>
                                <input type="text" className="form-control content" value="Ashok kumar" disabled />
                            </li>
                            <li>
                                <label className={"label"}>Email</label>
                                <input type="text" className="form-control content" value="manikandan.n@wellsfargo.com" disabled />
                            </li>
                            <li>
                                <label className={"label"}>Company Name	</label>
                                <input type="text" className="form-control content" value="HCL Technologies" disabled />
                            </li>
                            <li>
                                <label className={"label"}># of License</label>
                                <input type="text" className="form-control content" value="100" disabled />
                            </li>
                            <li>
                                <label className={"label"}>License Type</label>
                                <input type="text" className="form-control content" value="Requested license" disabled />
                            </li>
                            <li>
                                <label className={"label"}>Mode of Payment</label>
                                <input type="text" className="form-control content" value="Online" disabled />
                            </li>
                            <li>
                                <label className={"label"}>Created Date</label>
                                <input type="text" className="form-control content" value="07/11/2022" disabled />
                            </li>
                            <li>
                                <label className={"label"}>Status</label>
                                <div className={"content togglewrapper"}>
                                    <label class="switch">
                                        <input type="checkbox" />
                                        <span class="slider round"></span>
                                    </label>
                                    <span className={"toggleLabel"}>Active</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <button className='btn btn_outline mx-2' onClick={handleClose3}>
                        Cancel
                    </button>
                </Modal.Footer>
            </Modal>

            <Modal className='' size='md' show={show4} onHide={handleClose4} backdrop="static" keyboard={false} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Rejection Note</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className={"rejectPop"}>
                        <label className={"label align-flex-start"}>Reason</label>
                        <textarea className="form-control content"></textarea>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <button className='btn btn_outline mx-2' onClick={handleClose4}>
                        Cancel
                    </button>

                    <button className='btn btn_primary mx-2'>
                        Reject
                    </button>
                </Modal.Footer>
            </Modal>

            <Modal className='' size='md' show={show5} onHide={handleClose5} backdrop="static" keyboard={false} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Subscription Billing Status</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className={"priceDetails"}>
                        <div className={"totalPrize"}>
                            <p>Subscribe to Basic-Monthly</p>
                            <h2>
                                <strong>$15297.00</strong>
                                <span>Every 12 months</span>
                            </h2>
                        </div>
                        <ul className={"splitedPricelist"}>
                            <li>
                                <label className={"splittedLabel"}>
                                    <strong>Pro-unlimited-annual</strong>
                                    <span>Billed every 12 months</span>
                                </label>
                                <h5 className={"splittedPrize"}>$15297.00</h5>
                            </li>
                            <li>
                                <label className={"splittedLabel"}>
                                    <strong>Subtotal</strong>
                                </label>
                                <h5 className={"splittedPrize"}>$15297.00</h5>
                            </li>
                            <li className={"seperator"}></li>
                            <li>
                                <label className={"splittedLabel"}>
                                    <span>Tax (18%)</span>
                                </label>
                                <span className={"splittedPrize"}>$2753.46</span>
                            </li>
                            <li className={"seperator"}></li>
                            <li>
                                <label className={"splittedLabel"}>
                                    <strong>Total</strong>
                                </label>
                                <h5 className={"splittedPrize"}>$18015.46</h5>
                            </li>
                        </ul>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <button className='btn btn_outline mx-2' onClick={handleClose5}>
                        Cancel
                    </button>

                    <button className='btn btn_primary mx-2'>
                        Ok
                    </button>
                </Modal.Footer>
            </Modal>
        </div >
    )
}

export default ManageSubscribedUsers