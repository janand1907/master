import React, { useState, useEffect } from 'react'
import '../Plandetail.scss'
import { Form, Modal, Tab, Tabs } from 'react-bootstrap'
const SubscriptionEntry = () => {
    const [show, setShow] = useState(false);
    const [key, setKey] = useState('licenseUsers');
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [show2, setShow2] = useState(false);
    const handleShow2 = () => setShow2(true);
    const handleClose2 = () => setShow2(false);
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Subscription Entry</div>
                    </div>
                </div>
            </div>
            <div className={"box-wrapper"}>
                <div className={"createForm"}>
                    <div className={"productName"}>
                        <input type="text" className={"form-control"} placeholder="Product Name" />
                    </div>
                    <ul>
                        <li>
                            <div className={"createKey"}>
                                <input type="text" className={"form-control"} placeholder="Plan Name" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="# of users" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="$0.00" />
                            </div>
                        </li>
                        <li>
                            <div className={"createKey"}>
                                <input type="text" className={"form-control"} placeholder="Load Generator" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="# of users" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="$0.00" />
                            </div>
                        </li>
                        <li>
                            <div className={"createKey"}>
                                <input type="text" className={"form-control"} placeholder="Virtual User Hours" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="# of users" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="$0.00" />
                            </div>
                        </li>
                        <li>
                            <div className={"createKey"}>
                                <input type="text" className={"form-control"} placeholder="Max Test Duration" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="# of users" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="$0.00" />
                            </div>
                        </li>
                        <li>
                            <div className={"createKey"}>
                                <input type="text" className={"form-control"} placeholder="APM Monitoring" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="# of users" />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} placeholder="$0.00" />

                            </div>
                            <span className={"addIcon"}>
                                <svg fill={"currentColor"} class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="AddCircleOutlineOutlinedIcon"><path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"></path></svg>
                            </span>
                        </li>
                    </ul>
                    <div className={"btnWrapper"}>
                        <button className={"secondaryBtn"}>
                            <span>Cancel</span>
                        </button>
                        <button className={"primaryBtn"}>
                            <span>Update</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SubscriptionEntry