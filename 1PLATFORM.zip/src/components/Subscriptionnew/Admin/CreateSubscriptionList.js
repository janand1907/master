import React, { useState, useEffect } from 'react'
import '../Plandetail.scss'
import { Form, Modal, Tab, Tabs } from 'react-bootstrap'
import Dropdown from 'react-bootstrap/Dropdown';
const CreateSubscriptionList = () => {
    const [show, setShow] = useState(false);
    const [key, setKey] = useState('licenseUsers');
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [show2, setShow2] = useState(false);
    const handleShow2 = () => setShow2(true);
    const handleClose2 = () => setShow2(false);
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>List of Subscription Details</div>
                    </div>
                </div>
            </div>
            <div className={"box-wrapper"}>
                <div className={"createForm"}>
                    <div className={"productName"}>
                        {/* <select className={"form-control"}>
                            <option value="">Quantify</option>
                        </select> */}
                        <Dropdown className={"customDropdown"}>
                            <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                Quantify
                            </Dropdown.Toggle>

                            <Dropdown.Menu className={"dropdownList"}>
                                <Dropdown.Item href="#/action-1">Quantify</Dropdown.Item>
                                <Dropdown.Item href="#/action-2">OIP</Dropdown.Item>
                                <Dropdown.Item href="#/action-3">One Platform</Dropdown.Item>
                            </Dropdown.Menu>
                        </Dropdown>
                    </div>
                    <ul>
                        <li>
                            <div className={"createKey"}>
                                <Dropdown className={"customDropdown"}>
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        Basic
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} />
                            </div>
                        </li>
                        <li>
                            <div className={"createKey"}>
                                <Dropdown className={"customDropdown"}>
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        Concurrent Users
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} />
                            </div>
                        </li>
                        <li>
                            <div className={"createKey"}>
                                <Dropdown className={"customDropdown"}>
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        Max Test Duration
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} />
                            </div>
                        </li>
                        <li>
                            <div className={"createKey"}>
                                <Dropdown className={"customDropdown"}>
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        APM Monitoring
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} />
                            </div>
                            <div className={"createValue"}>
                                <input type="text" className={"form-control"} />
                            </div>
                            <span className={"addIcon"}>
                                <svg fill={"currentColor"} class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="AddCircleOutlineOutlinedIcon"><path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"></path></svg>
                            </span>
                        </li>
                    </ul>
                    <div className={"btnWrapper"}>
                        <button className={"secondaryBtn"}>
                            <span>Cancel</span>
                        </button>
                        <button className={"primaryBtn"}>
                            <span>Update</span>
                        </button>
                    </div>
                </div>
            </div>

            <div className='row my-3'>
                <div className='col-md-12'>
                    <div className='card op_card'>
                        <div className='card-body px-0 pb-0'>
                            <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                <div className='heading_approval'>Product Pending Details</div>
                            </div>
                            <table className="table manageuser_grid mb-0">
                                <thead>
                                    <tr className='px-3 py-4'>
                                        <th scope="col" className='px-3'>Sl. No <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Product Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Plan Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Subscribe Plan <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Plan Price <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Created on <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col">Plan Status <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                                        <th scope="col" className='text-center'>Action</th>
                                    </tr>
                                </thead>
                                <tbody className='border-top-0'>
                                    <tr>
                                        <td className='px-3'>Manikandan Nagendran</td>
                                        <td>OIP - Open Innovation Platform</td>
                                        <td>Premium-Pro</td>
                                        <td>Monthly</td>
                                        <td>$49.99</td>
                                        <td>09/11/2022</td>
                                        <td>Published</td>
                                        <td className='text-center'>
                                            <div className={"middleAlign"}>
                                                <span className={"actionIcons"}>
                                                    <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="EditIcon"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path></svg>
                                                </span>
                                                <span className={"actionIcons"}>
                                                    <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-1om0hkc" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="DeleteOutlineOutlinedIcon"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9zm7.5-5-1-1h-5l-1 1H5v2h14V4h-3.5z"></path></svg>
                                                </span>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default CreateSubscriptionList