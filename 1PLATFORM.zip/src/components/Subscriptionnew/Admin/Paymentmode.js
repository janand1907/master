import React, { useState, useEffect } from 'react'
import '../Plandetail.scss'
import { Form, Modal, Tab, Tabs } from 'react-bootstrap'
import Dropdown from 'react-bootstrap/Dropdown';
const Paymentmode = () => {
    const [show, setShow] = useState(false);
    const [key, setKey] = useState('licenseUsers');
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [show2, setShow2] = useState(false);
    const handleShow2 = () => setShow2(true);
    const handleClose2 = () => setShow2(false);
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Payment Option</div>
                    </div>
                </div>
            </div>
            <div className={"box-wrapper"}>
                <div className={"createForm paymentwrap"}>
                    <div className={"productName"}>
                        {/* <select className={"form-control"}>
                            <option value="">Quantify</option>
                        </select> */}
                        <div className="field-container">
                            <label className="label-text">Payment Method</label>
                            <Dropdown className={"customDropdown"}>
                                <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                    Online
                                </Dropdown.Toggle>

                                <Dropdown.Menu className={"dropdownList"}>
                                    <Dropdown.Item href="#/action-1">Online</Dropdown.Item>
                                    <Dropdown.Item href="#/action-2">Offline</Dropdown.Item>
                                </Dropdown.Menu>
                            </Dropdown>
                        </div>
                    </div>
                    <div className={"btnWrapper"}>
                        <button className={"secondaryBtn"}>
                            <span>Cancel</span>
                        </button>
                        <button className={"primaryBtn"}>
                            <span>Update</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Paymentmode