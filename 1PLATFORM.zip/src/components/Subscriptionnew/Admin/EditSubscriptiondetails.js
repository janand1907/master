import React, { useState, useEffect } from 'react'
import '../Plandetail.scss'
import { Form, Modal, Tab, Tabs } from 'react-bootstrap'
import Dropdown from 'react-bootstrap/Dropdown';
const EditSubscriptiondetails = () => {
    const [key, setKey] = useState('Quantify');
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [show2, setShow2] = useState(false);
    const handleShow2 = () => setShow2(true);
    const handleClose2 = () => setShow2(false);
    const [show3, setShow3] = useState(false);
    const handleShow3 = () => setShow3(true);
    const handleClose3 = () => setShow3(false);
    return (
        <div>
            <div className="mt-2 custom-head-card">
                <div className='d-flex align-items-center justify-content-between'>
                    <div className="d-flex gap-2 align-items-center">
                        <div className='h3'>Subscribe management details</div>
                    </div>
                    <div className='d-flex align-items-center gap-3'>
                        <a className='btn btn_primary' onClick={handleShow}>Manage User</a>
                    </div>
                </div>
            </div>
            <Tabs
                id="controlled-tab-example"
                activeKey={key}
                onSelect={(k) => setKey(k)}
                className="manageSubscription"
            >
                <Tab
                    eventKey="Quantify"
                    title={
                        <>
                            <span>Quantify</span>
                        </>
                    }>
                    <div className='row'>
                        <div className='col-md-12'>
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-end my-4 mx-3'>
                                        {/* <button className="secondaryBtn" onClick={handleShow2}>Billing Details</button> */}
                                        <button className="secondaryBtn ml-1" onClick={handleShow3}>Change Subscription Owner</button>
                                    </div>
                                    <div className={"labelListWrap editSubscription"}>
                                        <ul className={"labelList"}>
                                            <li>
                                                <label className={"label"}>First Name</label>
                                                <input type="text" className="form-control content" value="Ashok kumar" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Email ID</label>
                                                <input type="text" className="form-control content" value="manikandan.n@wellsfargo.com" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Company Name	</label>
                                                <input type="text" className="form-control content" value="HCL Technologies" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}># of Users</label>
                                                <input type="text" className="form-control content" value="25" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Start Date</label>
                                                <input type="text" className="form-control content" value="20/10/2022" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Product Name</label>
                                                <input type="text" className="form-control content" value="Quantify" disabled />
                                            </li>
                                        </ul>
                                        <ul className={"labelList"}>
                                            <li>
                                                <label className={"label"}>Last Name</label>
                                                <input type="text" className="form-control content" value="Ramamurthy" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>ID Type</label>
                                                <input type="text" className="form-control content" value="Business ID" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Type</label>
                                                <input type="text" className="form-control content" value="Enterprises" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Subscription Type</label>
                                                <input type="text" className="form-control content" value="Yearly" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Start Date</label>
                                                <input type="text" className="form-control content" value="07/11/2022" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Status</label>
                                                <div className={"content togglewrapper"}>
                                                    <label class="switch">
                                                        <input type="checkbox" />
                                                        <span class="slider round"></span>
                                                    </label>
                                                    <span className={"toggleLabel"}>Active</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className='btnWrapper'>
                                        <button className='btn btn_outline mx-2' onClick={handleClose}>
                                            Cancel
                                        </button>

                                        <button className='btn btn_primary mx-2'>
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Tab>
                <Tab
                    eventKey="oip"
                    title={
                        <>
                            <span>OIP (Open Innovation Platform)</span>
                        </>
                    }>
                    <div className='row'>
                        <div className='col-md-12'>
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                        <div className='heading_approval'># of Users - 150</div>
                                    </div>
                                    <div className={"labelListWrap editSubscription"}>
                                        <ul className={"labelList"}>
                                            <li>
                                                <label className={"label"}>First Name</label>
                                                <input type="text" className="form-control content" value="Ashok kumar" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Email ID</label>
                                                <input type="text" className="form-control content" value="manikandan.n@wellsfargo.com" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Company Name	</label>
                                                <input type="text" className="form-control content" value="HCL Technologies" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}># of Users</label>
                                                <input type="text" className="form-control content" value="25" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Start Date</label>
                                                <input type="text" className="form-control content" value="20/10/2022" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Product Name</label>
                                                <input type="text" className="form-control content" value="Quantify" disabled />
                                            </li>
                                        </ul>
                                        <ul className={"labelList"}>
                                            <li>
                                                <label className={"label"}>Last Name</label>
                                                <input type="text" className="form-control content" value="Ramamurthy" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>ID Type</label>
                                                <input type="text" className="form-control content" value="Business ID" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Type</label>
                                                <input type="text" className="form-control content" value="Enterprises" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Subscription Type</label>
                                                <input type="text" className="form-control content" value="Yearly" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Start Date</label>
                                                <input type="text" className="form-control content" value="07/11/2022" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Status</label>
                                                <div className={"content togglewrapper"}>
                                                    <label class="switch">
                                                        <input type="checkbox" />
                                                        <span class="slider round"></span>
                                                    </label>
                                                    <span className={"toggleLabel"}>Active</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className='btnWrapper'>
                                        <button className='btn btn_outline mx-2' onClick={handleClose}>
                                            Cancel
                                        </button>

                                        <button className='btn btn_primary mx-2'>
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Tab>
                <Tab
                    eventKey="Cyber Predictor"
                    title={
                        <>
                            <span>Cyber Predictor</span>
                        </>
                    }>
                    <div className='row'>
                        <div className='col-md-12'>
                            <div className='card op_card'>
                                <div className='card-body px-0 pb-0'>
                                    <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                                        <div className='heading_approval'># of Users - 150</div>
                                    </div>
                                    <div className={"labelListWrap editSubscription"}>
                                        <ul className={"labelList"}>
                                            <li>
                                                <label className={"label"}>First Name</label>
                                                <input type="text" className="form-control content" value="Ashok kumar" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Email ID</label>
                                                <input type="text" className="form-control content" value="manikandan.n@wellsfargo.com" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Company Name	</label>
                                                <input type="text" className="form-control content" value="HCL Technologies" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}># of Users</label>
                                                <input type="text" className="form-control content" value="25" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Start Date</label>
                                                <input type="text" className="form-control content" value="20/10/2022" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Product Name</label>
                                                <input type="text" className="form-control content" value="Quantify" disabled />
                                            </li>
                                        </ul>
                                        <ul className={"labelList"}>
                                            <li>
                                                <label className={"label"}>Last Name</label>
                                                <input type="text" className="form-control content" value="Ramamurthy" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>ID Type</label>
                                                <input type="text" className="form-control content" value="Business ID" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Type</label>
                                                <input type="text" className="form-control content" value="Enterprises" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Subscription Type</label>
                                                <input type="text" className="form-control content" value="Yearly" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>License Start Date</label>
                                                <input type="text" className="form-control content" value="07/11/2022" disabled />
                                            </li>
                                            <li>
                                                <label className={"label"}>Status</label>
                                                <div className={"content togglewrapper"}>
                                                    <label class="switch">
                                                        <input type="checkbox" />
                                                        <span class="slider round"></span>
                                                    </label>
                                                    <span className={"toggleLabel"}>Active</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className='btnWrapper'>
                                        <button className='btn btn_outline mx-2' onClick={handleClose}>
                                            Cancel
                                        </button>

                                        <button className='btn btn_primary mx-2'>
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Tab>
            </Tabs>
            <Modal className='' size='lg' show={show} onHide={handleClose} backdrop="static" keyboard={false} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Manage User</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className={"inlineformcontainer"}>
                        <div className={"centerform"}>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Email ID <span className={"astericColor"}>*</span></label>
                                <input type="text" className={"form-control centerforminputs"} />
                                {/* <Error name="" className={"errormsg"} /> */}
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>First Name <span className={"astericColor"}>*</span></label>
                                <input type="text" className={"form-control centerforminputs"} />
                                {/* <Error name="" className={"errormsg"} /> */}
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Last Name<span className={"astericColor"}>*</span></label>
                                <input type="text" className={"form-control centerforminputs"} />
                                {/* <Error name="" className={"errormsg"} /> */}
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Product Name<span className={"astericColor"}>*</span></label>
                                <Dropdown className={"customDropdown centerforminputs"}>
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        Quantify
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item href="#/action-1">Quantify</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">OIP</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">One Platform</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Plan<span className={"astericColor"}>*</span></label>
                                <Dropdown className={"customDropdown centerforminputs"}>
                                    <Dropdown.Toggle className={"form-control"} id="dropdown-basic">
                                        Enterprises
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu className={"dropdownList"}>
                                        <Dropdown.Item href="#/action-1">Quantify</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">OIP</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">One Platform</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>

                            <div className={"fieldContainer"}>
                                <label className={"labelText"}># of Days<span className={"astericColor"}>*</span></label>
                                <input type="text" className={"form-control centerforminputs"} />
                                {/* <Error name="" className={"errormsg"} /> */}
                            </div>
                            <div className={"fieldContainer"}>
                                <label className={"labelText"}>Status<span className={"astericColor"}>*</span></label>
                                <div className={"centerforminputs togglewrapper"}>
                                    <label class="switch">
                                        <input type="checkbox" />
                                        <span class="slider round"></span>
                                    </label>
                                    <span className={"toggleLabel"}>Active</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <button className='btn btn_outline mx-2' onClick={handleClose}>
                        Cancel
                    </button>

                    <button className='btn btn_primary mx-2'>
                        Submit
                    </button>
                </Modal.Footer>
            </Modal>
            <Modal className='' size='md' show={show2} onHide={handleClose2} backdrop="static" keyboard={false} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Subscription Billing Status</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className={"priceDetails"}>
                        <div className={"totalPrize"}>
                            <p>Subscribe to Basic-Monthly</p>
                            <h2>
                                <strong>$15297.00</strong>
                                <span>Every 12 months</span>
                            </h2>
                        </div>
                        <ul className={"splitedPricelist"}>
                            <li>
                                <label className={"splittedLabel"}>
                                    <strong>Pro-unlimited-annual</strong>
                                    <span>Billed every 12 months</span>
                                </label>
                                <h5 className={"splittedPrize"}>$15297.00</h5>
                            </li>
                            <li>
                                <label className={"splittedLabel"}>
                                    <strong>Subtotal</strong>
                                </label>
                                <h5 className={"splittedPrize"}>$15297.00</h5>
                            </li>
                            <li className={"seperator"}></li>
                            <li>
                                <label className={"splittedLabel"}>
                                    <span>Tax (18%)</span>
                                </label>
                                <span className={"splittedPrize"}>$2753.46</span>
                            </li>
                            <li className={"seperator"}></li>
                            <li>
                                <label className={"splittedLabel"}>
                                    <strong>Total</strong>
                                </label>
                                <h5 className={"splittedPrize"}>$18015.46</h5>
                            </li>
                        </ul>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <button className='btn btn_outline mx-2' onClick={handleClose2}>
                        Cancel
                    </button>

                    <button className='btn btn_primary mx-2'>
                        Ok
                    </button>
                </Modal.Footer>
            </Modal>
            <Modal className='' size='md' show={show3} onHide={handleClose3} backdrop="static" keyboard={false} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Change Subscription Ownership</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div>
                        <input type="text" className={"form-control centerforminputs"} placeholder="Enter Email ID" />
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <button className='btn btn_outline mx-2' onClick={handleClose3}>
                        Cancel
                    </button>

                    <button className='btn btn_primary mx-2'>
                        Update
                    </button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default EditSubscriptiondetails