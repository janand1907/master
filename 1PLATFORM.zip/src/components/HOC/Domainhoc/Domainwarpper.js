import React, { useState, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getDomain } from '../../../ducks/domain/getdomain/actions';
// import { domainCreate } from '../../../ducks/domain/createdomain/actions';
import { domainclear } from '../../../ducks/domain/createdomain/actions';
import { toast } from 'react-toastify';
import { debounce } from "lodash";
import {deleteData} from '../../../endpoints/gateway';
import {tokenExpiry} from '../../../endpoints/gateway';
import { Link,useHistory } from 'react-router-dom';
import {logout } from '../../../ducks/gateway/login/actions';
import Timeout from '../../Common/Timeout/Timeout';
import {domainCreate} from  '../../../endpoints/gateway';

const Domainwrapper = WrappedComponent => {
    const Wrapper = () => {
        const dispatch = useDispatch();
        const history = useHistory();
        const userDetails = useSelector(state => state.user);
        const userallDetails = useSelector(state => state.user.userInfo.allInfo);
        const getDomainDetails = useSelector(state => state.getdomain);
        const domainState = useSelector(state => state.domaincreate);
        const [filterDomain, setfilterDomain] = useState(getDomainDetails?.domainDetails);
        const [tokenExpired,settokenExpired] = useState(false)
        const [show, setShow] = useState(false);
       
        const handleClose = () => setShow(false);
       

        const handleShow=()=>{
            
            setShow(true)
        }

        const AllDomain = (userId) => {
            let payload = {
                userId
            }
            let Expiry = tokenExpiry();
            
            if(Expiry){
                    settokenExpired(true)
            }
            else{
                settokenExpired(false)
                dispatch(getDomain(payload));
            }
            
        }


        useEffect(() => {
            getDomainDetails?.domainDetails.sort(function (a, b) {
                return new Date(b.createdOn) - new Date(a.createdOn);
            });
            setfilterDomain(getDomainDetails?.domainDetails)
        }, [getDomainDetails])

        // useEffect(() => {
        //     AllDomain(userDetails.userInfo.userId)
        //     if (domainState?.isSuccess) {
        //         domainallclear()
        //         toast.success(`${domainState?.message?.domainInfo?.message}`)
        //     }
        //     if (domainState?.isDuplicate) {
        //         domainallclear()
        //         toast.error(`${domainState?.message?.domainInfo?.message}`)
        //     }
        // }, [domainState.isSuccess, domainState.isDuplicate])

        useEffect(() => {
            AllDomain(userDetails.userInfo.userId)
            // if (domainState?.isSuccess) {
            //     domainallclear()
            //     toast.success(`${domainState?.message?.domainInfo?.message}`)
            // }
            // if (domainState?.isDuplicate) {
            //     domainallclear()
            //     toast.error(`${domainState?.message?.domainInfo?.message}`)
            // }
        }, [])

        useEffect(() => {

            return () => {
                domainallclear()
            }
        }, [])


        const domainallclear = () => {
            dispatch(domainclear())
        }

        const handleSearch = (event) => {           
            let datas = getDomainDetails.domainDetails.filter((domainvalue, index) => {
                return domainvalue.domainName.includes(event.target.value)
            })
            setfilterDomain(datas)
        }

        const onSubmit = async(data,req) => {
            
            handleClose()
            data.userId = userDetails.userInfo.userId;
            data.createdBy = userDetails.userInfo.firstname + " " + userDetails.userInfo.lastname;
            // dispatch(domainCreate(data,req));
            let response = await domainCreate(data,req)
            
            if(response.data.dulpicate){               
                toast.error(response.data.message);
            }
            else{
                toast.success(response.data.message);
                AllDomain(userDetails.userInfo.userId)
            }
           

        }

        const completedstep = () => {
            dispatch({ type: 'NEXT', payload: 1 });
        }

        const deleteDomain = async (domainId) => {    
                   
            let response = await deleteData(domainId,'/api/domain/delete')
            toast.success(response.data.message);
            AllDomain(userDetails.userInfo.userId)
        }
        return (
            <WrappedComponent
                handleSearch={handleSearch}
                filterDomain={filterDomain}
                onSubmit={onSubmit}
                show={show}
                deleteDomain={deleteDomain}
                handleShow={handleShow}
                handleClose={handleClose}
                completedstep={completedstep}
                tokenExpired={tokenExpired}
            />
        )

    }
    return Wrapper;
}
export default Domainwrapper;