import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
// import { projectCreate } from '../../../ducks/domain/createproject/actions';
import { projectclear } from '../../../ducks/domain/createproject/actions';
import { getProject } from '../../../ducks/domain/getproject/actions';
import { toast } from 'react-toastify';
import {deleteData} from '../../../endpoints/gateway'
import {projectCreate} from '../../../endpoints/gateway'
const Projectwrapper = WrappedComponent => {
    const Wrapper = (props) => {
        const dispatch = useDispatch();
        const userDetails = useSelector(state => state.user);
        const userallDetails = useSelector(state => state.user.userInfo.allInfo);
        const projectState = useSelector(state => state.projectcreate);
        const allDetails = useSelector(state => state.manage);
        const getProjectDetails = useSelector(state => state.getproject);
        const [Length,setLength] = useState(0)
        const [filterProject, setfilterProject] = useState(getProjectDetails?.projectDetails);        
        const [show, setShow] = useState(false);
        const handleClose = () => setShow(false);
        const handleShow = () => setShow(true);
        const allProjects = () => {            
            let projectDets           
            if(props.match){
                setLength(Object.keys(props?.match?.params).length)
                if(Object.keys(props?.match?.params).length === 0){
                    projectDets = {
                        "doaminId": allDetails.domainId,
                        "isNav":false
                    }
                }
                else{
                    projectDets = {
                        "userId": userDetails.userInfo.userId,
                        "isNav":true
                    }
                }
            }
            else{
                setLength(0)
                projectDets = {
                    "doaminId": allDetails.domainId,
                    "isNav":false
                }
            }
            dispatch(getProject(projectDets))
        }
       
        useEffect(() => { 
            getProjectDetails?.projectDetails.sort(function(a,b){              
            return new Date(b.createdOn) - new Date(a.createdOn);
            });            
            setfilterProject( getProjectDetails?.projectDetails) 
        }, [getProjectDetails])

        // useEffect(() => {            
        //     allProjects()
        //     if (projectState.isSuccess) {
        //         toast.success("Project Created Successfully")
        //         projectallclear()
        //     }
        //     if (projectState.isDuplicate) {
        //         toast.error("Project Name Already Exist")
        //         projectallclear()
        //     }
    
        // },[projectState.isSuccess, projectState.isDuplicate])

        useEffect(() => {            
            allProjects()
    
        },[])

        useEffect(() => {            
            return () => {               
                projectallclear()
            }
        }, [])

        const projectallclear = () => {
            dispatch(projectclear())
        }

        const handleSearch = (event) => {
            let datas = getProjectDetails?.projectDetails.filter((projectvalue, index) => {
                return projectvalue.projectName.includes(event.target.value)
            })
            setfilterProject(datas)
        }

        const onSubmit = async(data,req) => {       
            data.userId = userDetails.userInfo.userId;
            data.userId = userDetails.userInfo.userId
            data.domainId = allDetails.domainId
            data.createdBy = userDetails.userInfo.firstname + " " + userDetails.userInfo.lastname;          
            // dispatch(projectCreate(data,req));
            let response = await projectCreate(data,req)
            handleClose()
            if(response.data.dulpicate){
                toast.error(response.data.message);
            }
            else{
                toast.success(response.data.message);
                allProjects()
            }
            // allProjects()
        }
        const completedstep = ()=>{           
            dispatch({ type: 'NEXT', payload: 2 });
        }

        const previousStep=()=>{
            
            dispatch({ type: 'BACK', payload: 0 });
        }

        const deleteProject = async (projectId) => { 
            let response = await deleteData(projectId,'/api/project/delete')
            toast.success(response.data.message);
            allProjects() 
        }
        return (
            <WrappedComponent
                handleSearch={handleSearch}
                filterProject={filterProject}
                onSubmit={onSubmit}
                show={show}
                handleShow={handleShow}
                handleClose={handleClose}
                allDetails={allDetails}
                deleteProject={deleteProject}
                completedstep={completedstep} 
                previousStep={previousStep}
                paramLength={Length}
            />

        )
    }
    return Wrapper
}

export default Projectwrapper