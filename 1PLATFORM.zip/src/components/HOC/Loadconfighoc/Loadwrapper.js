import React, { useState, useEffect,useCallback  } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Highcharts from 'highcharts';
import Charts from '../../Common/Charts/Charts';
import { useHistory } from 'react-router-dom';
import { getThread } from '../../../ducks/testcase/gettestcase/actions';
import { addScenario, getAllregion, evnautoCalculation, getCSVSplitDetails } from "../../../endpoints/gateway";
import {runLoadCommands} from '../../../endpoints/gateway'
const Loadwrapper = WrappedComponent => {
    const Wrapper = () => {
        const dispatch = useDispatch();
        let history = useHistory();
        const [iteration,setIteration]=useState(false)
        const [runErrorDetails,setRunErrorDetails]=useState(null)
        const [scenarioError,setScenarioError]=useState("Scenario Name is required")
        const [startRun,setStartRun]=useState(true)
        const getthreadGroup = useSelector(state => state.getthread);
        const allDetails = useSelector(state => state.manage);
        const [configValue, setconfigValue] = useState({
            vusers: parseInt(getthreadGroup?.thread?.userCount),
            rampup: parseInt(getthreadGroup?.thread?.rampUp),
            duration: parseInt(getthreadGroup?.thread?.duration),
            runname: '',
            region: '',
            iteration: parseInt(getthreadGroup?.thread?.loopCount)
        })
        const [validation, setValidation] = useState({
            vusers:false,
            rampup: false,
            duration: false,
            runname: false,
            region: false,
            iteration: false
        });
        const [startDisabled, setstartDisabled] = useState(false)
        const [getautoCalculation, setautoCalculation] = useState({})
        const [getRegion, setRegion] = useState()
        const [threadGroup, setthreadGroup] = useState([
            [0, 0], 
            [parseInt(configValue.rampup), parseInt(configValue.vusers)], 
            [parseInt(configValue.duration), parseInt(configValue.vusers)]
        ])

        useEffect(() => {
            let testcaseId = {
                "testcaseId": allDetails.testcaseId
            }
            dispatch(getThread(testcaseId));
            fetchRegion()
        },[])

        useEffect(() => {
            setconfigValue({
                vusers: parseInt(getthreadGroup?.thread?.userCount),
                rampup: parseInt(getthreadGroup?.thread?.rampUp),
                duration: parseInt(getthreadGroup?.thread?.duration),
                runname: '',
                region: '',
                iteration: parseInt(getthreadGroup?.thread?.loopCount)
            })
        }, [getthreadGroup]) 
        
        useEffect(() => {
            setthreadGroup([[0, 0], [parseInt(configValue.rampup), parseInt(configValue.vusers)], [parseInt(configValue.duration), parseInt(configValue.vusers)]])
            if (configValue.region != '' && configValue.rampup != '' && configValue.vusers != '' && configValue.duration != '' && configValue.rampup != 0 && configValue.vusers != 0 && configValue.duration != 0 && configValue.runname != '') {
                setstartDisabled(false);
            }
            if (configValue.vusers != '' && configValue.vusers != 0)
                autoCalculation()
        },[configValue]) 
        useEffect(() => {            
                checkValidation()           
        }, [configValue]);

        const handleLoadConfig = (event) => {

            const name = event.target.name;
            const value = event.target.value;
            setconfigValue(values => ({ ...values, [name]: value }))
            
            if( name === "iteration" && (value === -1 || value === 0 || value === "0" || value === "-1") ){
                setIteration(false);
                checkValidation();
            }
        }

        const autoCalculation = async () => {
            let autoCalculationValue = await evnautoCalculation(configValue.vusers);
            setautoCalculation(autoCalculationValue.data)
        }
       
        const fetchRegion = async () => {
            let allRegion = await getAllregion()
            setRegion(allRegion.data)
        }

        const cycleData = {
            chart: {
                type: 'area',
                height: 180
            },
            credits: {
                enabled: false
            },
            exporting: {
                enabled: false
            },
            title: false,
            xAxis: {
                allowDecimals: false,
                title: {
                    text: 'Duration (sec)',
                    enabled: true,
                    style: {
                        color: Highcharts.getOptions().colors[0]
                    }
                },
            },
            yAxis: {
                title: {
                    text: 'VUser Count'
                }
            },
            tooltip: {
                crosshairs: true,
                shared: true,
            },
            series: [{
                name: "Users",
                data: threadGroup,
                color: Highcharts.getOptions().colors[0],
                fillOpacity: 1,
                zIndex: 0,
                showInLegend: false,
                marker: {
                    fillColor: 'blue',
                    lineWidth: 2,
                    lineColor: Highcharts.getOptions().colors[0]
                }
            }]

        }
        const checkValidation = () => {
            
            let errors = validation;            
            if (configValue.runname.length<3) {  
                setScenarioError("Scenario Name should be greater than 3 character");              
                errors.runname = true
            }else if (configValue.runname.length > 30) { 
                setScenarioError("Scenario Name should be less than 30 character");               
                errors.runname = true
            }else {

                var pattern =/^[A-Za-z0-9_]+$/;

                if(!pattern.test(configValue.runname)){
                    errors.runname = true;
                    setScenarioError("Accept Only Alpha Numeric and Underscore");
                }else{
                    
                    setScenarioError(null);
                    errors.runname =false;
                }
            }

            if(!configValue.region.trim()){
                errors.region=true
            }
            else{
                errors.region=false
            }
            if(parseInt(configValue.vusers) <= 0 || configValue.vusers==''){
                errors.vusers=true
            }
            else{
                errors.vusers=false
            }
            var rampup = parseInt(configValue.rampup);
            if(rampup < 0 ){
                errors.rampup=true
            }
            else{
                errors.rampup=false
            }
           
            if(parseInt(configValue.duration) <= 0){
                errors.duration=true
            }else if(configValue.duration === '' ){
                if(parseInt(configValue.iteration) === -1){
                    errors.duration=true
                }
            }else{
                errors.duration=false
            }
            if(parseInt(configValue.iteration) === 0 || configValue.iteration==''){
                errors.iteration=true
            }
            else{
                errors.iteration=false
            }
            setValidation(errors);
            if(!validation.vusers && !validation.rampup && !validation.iteration     && !validation.duration && !validation.region && !validation.runname){
                return true
            }
            return false

            // return true
            
          };

        const submitValue = async (receivedFrom) => {
            
            //  await checkValidation();
            if(true){
                setstartDisabled(true);
                setStartRun(false);
                if(checkValidation()){
                    let payload = {
                        noOfSlave: getautoCalculation.noLg,
                        scenariaName: configValue.runname,
                        region: configValue.region,
                        core: getautoCalculation.core,
                        memory: getautoCalculation.lgRam,
                        clusterName: "QuantifySaas",
                        duration: configValue.duration,
                        currrentDateTime: new Date().getTime()
                    }
                    let testScenario = {
                        "userCount": getautoCalculation.jmeterUserPerEngine,
                        "rampUp": configValue.rampup,
                        "loopCount": configValue.iteration,
                        "duration": configValue.duration,
                        "scenarioName": allDetails.testcaseName,
                        "testcaseId": allDetails.testcaseId,
                        "enableDuration": true
                    }

                    

                    var par = {
                        noOfSlave: getautoCalculation.noLg,
                        testcaseId: allDetails.testcaseId,
                        userCount: getautoCalculation.jmeterUserPerEngine
                    }

                    let csvSplitDetails = await getCSVSplitDetails(par)

                    if(csvSplitDetails.data){
                        
                        for(var a = 0; a < csvSplitDetails.data.length; a++ ){
                            if(csvSplitDetails.data[a].message === "Not able to split equally"){
                                setRunErrorDetails(csvSplitDetails.data[a].file + ": " + csvSplitDetails.data[a].message);
                                setstartDisabled(false);
                                return;
                            }
                        }
                        
                        let result = await addScenario(testScenario)
                        if (result.data.message === 'Thread Group updated successfully') {
                            dispatch({ type: 'Loadstate', payload: payload });
                            if (receivedFrom == 'wizard') {                    
                                completedstep()
                            }
                            else {

                                let payload = {
                                    "testcaseId": allDetails.testcaseId,
                                    "noOfSlave": getautoCalculation.noLg,
                                    "scenariaName": configValue.runname,
                                    "region": configValue.region,
                                    "core": getautoCalculation.core,
                                    "memory": getautoCalculation.lgRam,
                                    "clusterName": "QuantifySaas",
                                    "userId": allDetails.userId,
                                    "duration": configValue.duration,
                                    "currrentDateTime": new Date().getTime()
                                }

                                let response = await runLoadCommands(payload)   
                            
                                if(response.status === 200){
                                    completedstepBegin();
                                    history.push({ 
                                        pathname: '/runtest',
                                        state:{
                                            runId: response?.data?.Exid
                                        }
                                    })

                                }else{
                                    setRunErrorDetails(response?.data?.message);
                                    setstartDisabled(false);
                                }
                                
                            }
            
                        }else{
                            setRunErrorDetails(result.data.message);
                            setstartDisabled(false);
                        }
                    }
                }
                else{
                    
                    
                }
            }
            setstartDisabled(false);
        }

        const completedstepBegin = () => {
            dispatch({ type: 'BACK', payload: 0 });
        }

        const completedstep = () => {
            dispatch({ type: 'NEXT', payload: 4 });
        }

        const previousStep = () => {
            dispatch({ type: 'BACK', payload: 2 });
        }

        const onMouseIteration = (value) =>{
            
            if(value === -1 || value === "-1"){
              setIteration(true);
            }
        }

        const onMouseLeftIteration = (value) =>{
            
            if(value === -1 || value === "-1"){
              setIteration(false);
            }
        }

        return (
            <WrappedComponent
                configValue={configValue}
                handleLoadConfig={handleLoadConfig}
                cycleData={cycleData}
                getautoCalculation={getautoCalculation}
                getRegion={getRegion}
                startDisabled={startDisabled}
                submitValue={submitValue}
                previousStep={previousStep}
                validation={validation}
                onMouseIteration={onMouseIteration}
                onMouseLeftIteration={onMouseLeftIteration}
                iteration={iteration}
                scenarioError={scenarioError}
                runErrorDetails={runErrorDetails}
            />
        )

    }
    return Wrapper;
}
export default Loadwrapper;