import React, { useState, useEffect } from 'react'
import './ActiveProductDetail.scss'
import logo from '../../assets/images/logo_main.png'
import { useHistory } from 'react-router-dom';
import viewBtn from '../../assets/images/other/eyebtn.png';
import { allProductSubscriptionDetail } from '../../endpoints/gateway';
import { useDispatch } from 'react-redux';
import nodata from '../../assets/images/nodata.svg';

const ActiveProductDetail = (props) => {
  
  const history = useHistory();
  const dispatch = useDispatch();

  useEffect(() => {
    fetchallProductSubscriptionDetail()
  }, [])

  const [productDetails, setproductDetails] = useState([])
  const fetchallProductSubscriptionDetail = async () => {
    let response = await allProductSubscriptionDetail(`/getAllProductSubscriptionDetail/${props.match.params.productId}`)
    setproductDetails(response.data)

  }


  const viewDetails = (data) => {
    
    dispatch({ type: 'ADD', payload: data });
    history.push(`/productplandetail/${data.subscriptionPlanId}`)
  }
  return (
    <div className='ActiveProductDetail'>
      <div className="mt-2 custom-head-card">
        <div className="d-flex gap-2 align-items-center">
          <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
          <div className='h3'>Product Subscription Detail</div>
        </div>
      </div>
      <div className='row my-3'>
        <div className='col-md-12'>
          <div className='card op_card '>
            <div className='card-body px-0 pb-0'>
              {/* <div className='d-flex justify-content-end align-items-center gap-3 py-2'>
                      <div className='d-flex align-items-center gap-3' style={{width:'25%'}}>
                          <div className='status'>Status</div>
                          <Selectdropdown dataSelected={statusSelected} setDataSelected={setStatusselected} options={status}/>
                      </div>
                      <div className='btn_layout ms-2'>
                        <button className='btn btn_primary px-3 '>
                          <span className='me-2'><i class="bi bi-download"></i></span>
                          Report
                        </button>                              
                      </div>
                      <div className='table_pagination'>
                          <nav aria-label="Page navigation example">
                            <ul className="pagination">
                              <li className="page-item"><Link className="page-link" href="#"><i class="bi bi-chevron-left"></i></Link></li>
                              <li className="page-item"><Link className="page-link active" href="#">1</Link></li>
                              <li className="page-item"><Link className="page-link" href="#">2</Link></li>
                              <li className="page-item"><Link className="page-link" href="#">3</Link></li>
                              <li className="page-item"><Link className="page-link" href="#"><i class="bi bi-chevron-right"></i></Link></li>
                            </ul>
                          </nav>
                      </div>                             
                    </div>  */}
              <div className='table-responsive'>
                <table className="table manageuser_grid mb-0">
                  <thead>
                    <tr className='px-3'>
                      <th scope="col" className='px-3'>Company Name <span className='mx-1' style={{ fontSize: '13px' }}><i class="bi bi-chevron-down"></i></span></th>
                      <th scope="col">User Name <span className='mx-1' style={{ fontSize: '13px' }}><i class="bi bi-chevron-down"></i></span></th>
                      <th scope="col">Email ID</th>
                      <th scope="col">Subscribed Plan <span className='mx-1' style={{ fontSize: '13px' }}><i class="bi bi-chevron-down"></i></span></th>
                      <th scope="col">Plan type <span className='mx-1' style={{ fontSize: '13px' }}><i class="bi bi-chevron-down"></i></span></th>
                      <th scope="col">Status</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody className='border-top-0'>
                    {
                      productDetails.length > 0 ?
                        productDetails.map((data, index) => (
                          <tr key={index}>
                            <td className='px-3'>
                              <div className='d-flex align-items-center gap-2'>
                                <img src={`https://dtlehta1thuw9.cloudfront.net/testcasemgmt/api/attachment/views/${data?.companyLogo}`} className='companyLogo' alt='logoProduct' width={49} height={24} />
                                <div>{data.companyName}</div>
                              </div>
                            </td>
                            <td>{data.firstName}</td>
                            <td>{data.userEmail}</td>
                            <td>{data.subscriptionName}</td>
                            <td>{data.subscriptionModeName}</td>
                            <td>{data.status}</td>
                            <td>
                              <span className="view-icon" onClick={() => viewDetails(data)}>
                                <img src={viewBtn} className="product_button mx-2" alt='eyebtn' />
                              </span>
                            </td>
                          </tr>
                        ))
                        :
                        <tr>
                          <td colspan="8">
                            <div className="col-sm-12 text-center py-2">
                              <img src={nodata} alt="nodata" className="gridImg" />
                              <p className="nodata-msg mt-3">No Datails available </p>
                            </div>
                          </td>
                        </tr>


                    }
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <div className='col-md-12 mt-5'>
          <div className='footerPanel d-flex align-items-center justify-content-end gap-2 mx-4'>
            <p className='content mb-0'>Powered by</p>
            <div className='logoLayout'><img className='w-100' src={logo} alt='logo' /></div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ActiveProductDetail