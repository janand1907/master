import React,{useEffect,useState} from 'react'
import { Link, useHistory } from 'react-router-dom';
import moment from 'moment';
import nodata from '../../assets/images/nodata.svg';


import './SubscriptionDetails.scss';
import {subscriptionPlanDetails} from '../../endpoints/gateway'
import { useSelector, useDispatch } from 'react-redux'; 
const SubscriptionDetails = () => {
    const history = useHistory();
    const dispatch = useDispatch();
   const [plan,setPlan]=useState([])
    useEffect(()=>{
        planDetails();
    },[])

    const planDetails=async()=>{
        let response = await subscriptionPlanDetails(`/getProductSubscriptionDetails/1`)
        setPlan(response.data)
       
    }
   const  subscriptionUsage=(data)=>{
       dispatch({ type: 'ADD',payload:data });
       history.push('/subscriptionUsage')
   }
  
  return (
    <div className='subscriptionDetails'>
        <div className="mt-2 custom-head-card">
            <div className="d-flex gap-2 align-items-center">
                <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
                <div className='h3'>List of Product Subscription Details</div>
            </div>
        </div>
        <div className='row my-3'>
            <div className='col-md-12'>
                <div className='card op_card'>
                <table className="table manageuser_grid mb-0">
                    <thead>
                        <tr className='px-3'>
                        <th scope="col" className='px-3'>Plan Name <span className='mx-1' style={{fontSize:'13px'}}><i class="bi bi-chevron-down"></i></span></th>
                        <th scope="col">Plan Detail </th>
                        {/* <th scope="col">Product Name</th> */}
                        <th scope="col">Plan subscription</th>
                        <th scope="col">Created On </th>
                        <th scope="col">Start Date </th>
                        <th scope="col">End Date </th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody className='border-top-0'>
                        {
                            plan.length < 0?
                            <>
                            {
                                plan.map((val,index)=>(
                                    <tr key={index}>
                            <td className='px-3' style={{width:'180px'}}>{val.subscriptionName}</td>
                            <td style={{width:'250px'}}>
                                <ul className='m-0 p-0'>
                                    <li><b>{val.concurrentUsers}</b> Concurrent Users</li>
                                    <li><b>{val.loadGenerator}</b> Load Generator</li>
                                    <li><b>{val.maxTestDuration}h</b> Max Test Duration</li>
                                    <li><b>{val.apmMonitoring}</b>APM Monitoring </li>
                                    <li><b>{val.virtualUserHours}</b> Virtual User Hours </li>
                                    <li>
                                    <b>{val.apiCalls}</b> API Calls
                                    </li>
                                </ul>
                            </td>
                            {/* <td>{val.productName}</td> */}
                            <td>{val.subscriptionModeName}</td>
                            <td>{moment(new Date(val.createdOn)).format('DD-MM-YYYY')}</td>
                            <td>23/01/2022</td>
                            <td>23/01/2022</td>
                            <td>{val.activeFlag ?  'Active':'Inactive'}</td>
                            <td><button onClick={()=>subscriptionUsage(val)}  type='button' className='btn p-0 linkView'>View Usage</button></td>
                        </tr>
                                ))
                            }
                            </>
                            
                            :
                            <tr>
                                <td colspan="8">
                                    <div className="col-sm-12 text-center py-2">
                                        <img src={nodata} alt="nodata" className="gridImg" />
                                        <p className="nodata-msg mt-3">No Datails available </p>
                                    </div>                                    
                                </td>
                            </tr>

                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
                    </tbody>
                </table>                    
                </div>
            </div> 
        </div>         
    </div>
  )
}

export default SubscriptionDetails