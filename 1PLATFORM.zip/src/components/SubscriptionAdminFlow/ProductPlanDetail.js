import React, {useState,useEffect} from 'react'
import {useHistory } from 'react-router-dom';
import logo from '../../assets/images/logo_main.png'
import './ProductPlanDetail.scss'
import { OverlayTrigger, Popover } from 'react-bootstrap';
import { tickIcon } from '../../Icons/icons';

import { useDispatch,useSelector} from 'react-redux'; 
import {getproductUsageDetails} from '../../endpoints/gateway'
const ProductPlanDetail = (props) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const [UsageDetails,setUsageDetails]=useState()
  const PlanDetails = useSelector(state => state.defaultreducder.data);
 
  useEffect(()=>{
    productUsageDetails()
    return () => {
      dispatch({ type: 'REMOVE'});
    }
  },[])

  const productUsageDetails=async()=>{
    let response = await getproductUsageDetails(`/getsubscriptionPlanDetails/${props.match.params.subscriptionPlanId}`)
    setUsageDetails(response.data)
  
  }

  return (
    <div className='ProductPlanDetail'>
      <div className="mt-2 custom-head-card">
        <div className="d-flex gap-2 align-items-center">
            <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
            <div className='h3'>{PlanDetails?.companyName} - Subscription Plan Details</div>
        </div>
      </div> 
      <div className='my-4'>
        <div className='row g-3'>
            <div className='col-md-4'>
              <div className='op_card card'>
                <div className='card-body'>             
                    <div className='row mt-2'>
                      <div className='fieldBlock col'>
                        <label className='lpanelLabel'>User Name</label>
                        <div className='labelValue'>{PlanDetails?.firstName} {PlanDetails?.lastName}</div>
                      </div>                   
                    </div>
                    <div className='row mt-3'>
                      <div className='fieldBlock col'>
                        <label className='lpanelLabel'>Product Subscribed</label>
                        <div className='labelValue'>{PlanDetails?.subscriptionName}</div>
                      </div>
                      <div className='fieldBlock col text-end'>
                        <OverlayTrigger className="m-0 p-0" placement="bottom" overlay={
                          <Popover id="popover-basic" className='p-0'>
                          <Popover.Body>
                            <div className=''>
                              <div className='card border-0 mx-0 px-0'>
                                <div className='card-body p-0'>
                                  <div className='plandetail my-2'><span className='me-2 tick-icon'>{tickIcon}</span><b>{UsageDetails?.concurrentUsers}</b> Concurrent Users </div>
                                  <div className='plandetail my-2'><span className='me-2 tick-icon'>{tickIcon}</span><b>{UsageDetails?.loadGenerator}</b> Load Generator </div>
                                  <div className='plandetail my-2'><span className='me-2 tick-icon'>{tickIcon}</span><b>{UsageDetails?.maxTestDuration}h</b> Max Test Duration  </div>
                                  <div className='plandetail my-2'><span className='me-2 tick-icon'>{tickIcon}</span><b>{UsageDetails?.apmMonitoring}</b> Monitoring  </div>
                                  <div className='plandetail my-2'><span className='me-2 tick-icon'>{tickIcon}</span><b>{UsageDetails?.virtualUserHours}</b> Virtual User Hours </div>
                                  <div className='plandetail my-2'><span className='me-2 tick-icon'>{tickIcon}</span><b>{UsageDetails?.apiCalls}</b> Api Calls </div>
                              
                                </div>          
                              </div>
                            </div>
                          </Popover.Body>
                        </Popover>
                        } trigger={["hover", "hover"]} style={{cursor:'pointer'}}>
                          <div className='linkValue'>
                              View Plan Details <span className='ms-2'><i class="bi bi-box-arrow-up-right"></i></span>
                          </div>
                        </OverlayTrigger>                   
                      </div> 
                    </div>  
                    <div className='row mt-3'>
                      <div className='fieldBlock col'>
                        <label className='lpanelLabel'>Created Date</label>
                        <div className='labelValue'>21 Jun 2021</div>
                      </div>
                      <div className='fieldBlock col text-end'>
                        <label className='lpanelLabel'>End Date</label>
                        <div className='labelValue'>20 Jun 2023</div>
                      </div>                     
                    </div>
                    <div className='row mt-3'>
                      <div className='fieldBlock col'>
                        {/* <label className='lpanelLabel'># of Projects</label>
                        <div className='labelValue'>04</div> */}
                        <label className='lpanelLabel'>Plan Type</label>
                        <div className='labelValue'>{PlanDetails?.subscriptionModeName}</div>
                      </div>
                      <div className='fieldBlock col text-end'>
                        <label className='lpanelLabel'>Email ID</label>
                        <div className='labelValue'>{PlanDetails?.userEmail}</div>
                      </div>                     
                    </div>
                    {/* <div className='row mt-3'>
                      <div className='fieldBlock col'>
                        <label className='lpanelLabel'># of Users</label>
                        <div className='usersGroupimg'>
                          <img className='w-100' src={usergroup} alt='userGroup' />
                        </div>
                      </div>                    
                    </div>                                                                       */}
                </div>
                <div className='card-footer bg-transparent mt-5'>
                    <div className='row'>
                      <div className='fieldBlock col'>
                        <label className='lpanelLabel'>Last Updated</label>
                        <div className='labelValue'><span className='me-2'><i class="bi bi-clock-history"></i></span>20 Jun 2021</div>
                      </div>
                      <div className='fieldBlock col text-end'>
                        <label className='lpanelLabel'>Account Status</label>
                        <div className='labelValue form-check form-switch shadow-none'>
                          <input className="form-check-input me-2" type="checkbox" role="switch" id="flexSwitchCheckChecked" defaultChecked  style={{float:'revert'}}/>
                          <label className="form-check-label" htmlFor="flexSwitchCheckChecked">Active</label>
                        </div>
                      </div>                    
                    </div>                                  
                </div>
              </div>
            </div>  

            <div className='col-md-12 mt-5'>
              <div className='footerPanel d-flex align-items-center justify-content-end gap-2 mx-4'>
                  <p className='content mb-0'>Powered by</p>
                  <div className='logoLayout'><img className='w-100' src={logo} alt='logo' /></div>
              </div>
            </div>                   
        </div> 

      </div>     
    </div>
  )
}

export default ProductPlanDetail