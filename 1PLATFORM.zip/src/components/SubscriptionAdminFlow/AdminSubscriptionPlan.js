import React, { useEffect, useState } from 'react'
import './AdminSubscriptionPlan.scss'
import logo from '../../assets/images/logo_main.png'
import { useHistory } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import Select from 'react-select'
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { getSubscribePlan, getProducts,saveSubscribePlan } from '../../endpoints/gateway'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import moment from 'moment';
import { toast } from 'react-toastify';

const AdminSubscriptionPlan = () => {
  const history = useHistory();
  const [plan, setPlan] = useState([])
  const [total, setTotal] =useState(0)
  const [calcTotal,setcalcTotal]=useState([])
  const [isOffer,setisOffer]=useState(false)
  const personalSchema = Yup.object().shape({
    productId: Yup.string()
      .required('Please choose Product'),
    subscriptionId: Yup.string()
      .required('Please choose Subscription plan'),
    concurrentUsers: Yup.string().required('ConcurrentUsers is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),
     
      
    concurrentUsersPrice: Yup.string().required('Concurrent Users Price is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),
    loadGenerator: Yup.string().required('Load Generator is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),
    loadGeneratorPrice: Yup.string().required('Load Generator Price is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),
    virtualUserHours: Yup.string().required('Virtual User Hours  is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),
    virtualUserHoursPrice: Yup.string().required('Virtual User Hours Price is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),

    maxTestDuration: Yup.string().required('Max Tes tDuration is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),
    maxTestDurationPrice: Yup.string().required('Max Test Duration Price is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),

    apmMonitoring: Yup.string().required('APM Monitoring is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),
    apmMonitoringPrice: Yup.string().required('APM Monitoring Price is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),

    apiCalls: Yup.string().required('API Calls is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),
    apiCallsPrice: Yup.string().required('API Calls Price is required.').matches(/^[0-9]+$/i, 'Only Numeric Value Accepted'),

    planStartDate: Yup.string()
      .required('Plan Start Date Required'),
    planExpireDate: Yup.string()
      .required('Plan Expire Date Required'),
      discription: Yup.string()
      .required('Description required'),
      offer: Yup.boolean(),
      offerPercentage: Yup
      .string()
      
      .when("offer", {
        is: true,
        then: Yup.string().required("Offer Percentage is Required")
      })
  });


  const { register,
    handleSubmit, setValue,getValues,watch,
    formState: { errors, isValid }, control, reset } = useForm({
      resolver: yupResolver(personalSchema), mode: 'onChange'
    })
  useEffect(() => {
    getPlanDetails()
    fetchProducts()
  }, [])

  const getPlanDetails = async () => {
    let response = await getSubscribePlan()
    
    setPlan(response.data)
  }

  const [allproducts, setallproducts] = useState()
  const fetchProducts = async () => {
    let response = await getProducts()
    setallproducts(response.data)
  }

  const onSubmit = async(data) => {   
    var time = new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds();   
    data.subscriptionMode = false;
    data.totalPrice =  data.totalPrice.toString()   
    data.planExpireDate = moment(new Date(data.planExpireDate)).format('YYYY-MM-DD')+'T'+time+'.105+00:00';
    data.planStartDate = moment(new Date(data.planStartDate)).format('YYYY-MM-DD')+'T'+time+'.105+00:00';   
    let response = await saveSubscribePlan('/feed','POST',data)
    
    toast.success(response.data.message)
    history.push('/listofplans')
  }

  const [startDate, setStartDate] = useState();
  const [endDate, setEndDate] = useState();

const watchOffer = watch("offer", false);
  const watchFields = watch([
    "concurrentUsersPrice", 
    "loadGeneratorPrice",
    "virtualUserHoursPrice",
    "maxTestDurationPrice",
    "apmMonitoringPrice",
    "apiCallsPrice"
  ]); 

  useEffect(()=>{
      
      const sum = watchFields.reduce((accumulator, value) => {
        return accumulator +  +value;
      }, 0);
      setTotal(sum)


      setValue('totalPrice',sum)
  },[watchFields])





  const watchofferPercentage = watch("offerPercentage");


  useEffect(()=>{
 
    setisOffer(watchOffer)
    if(watchOffer === false){
      setValue('totalPrice',total)
      setValue('offerPercentage','')
    }
    else{
      setValue('totalPrice',total)
      let finalvalue = total-(total * +watchofferPercentage/100)
      setValue('totalPrice',finalvalue)
    }
      
  },[watchOffer,watchofferPercentage])




  
  return (
    <div className='AdminSubscriptionPlan'>
      <div className="mt-2 custom-head-card">
        <div className="d-flex gap-2 align-items-center">
          <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
          <div className='h3'>Create Subscription plan</div>
        </div>
      </div>
      <div className='row my-4'>
        <form className="profile_update" onSubmit={handleSubmit(onSubmit)}>
          <div className='col-md-12'>
            <div className='card op_card'>
              <div className='card-body p-4 mx-3 mt-4'>
                <div className='row g-3 mx-1'>
                  <div className='col-md-3 suBPanel'>
                    <div className='subscriptionLabelMain'>Subscribe Product</div>
                    <div className='subscriptionLabelcontent'>Select  Product from  dropdown </div>
                  </div>
                  <div className='col-md-9'>
                    <div className='row align-items-center gap-3'>
                      <div className='col-md-7'>
                          <Controller
                            name="productId"
                            control={control}
                            render={({ field: { value, onChange } }) => <Select
                              // value={allProducts?.find((c) => c.productId === value)}
                              onChange={(val) => onChange(val.productId)}
                              options={allproducts}
                              getOptionLabel={(option) => option.productName}
                              getOptionValue={(option) => option.productId}
                              style={{ width: "100%" }}
                              className='form-control p-0 border-0'
                              placeholder='Select Product'
                            />}
                            rules={{ required: true }}
                          />
                          <span className="error">{errors.productId && <span>{errors.productId?.message}</span>}</span>                        
                      </div>
                      {/* <div className='col-md'><button className='btn p-0'><i class="bi bi-info-circle"></i></button></div> */}
                    </div>
                  </div>
                </div>
                <hr className='borderSeperator' />
                <div className='row g-3 mx-1'>
                  <div className='col-md-3 suBPanel'>
                    <div className='subscriptionLabelMain'>Subscribe Plan Name</div>
                    <div className='subscriptionLabelcontent'>Select Plan from dropdown </div>
                  </div>
                  <div className='col-md-9'>
                    <div className='row align-items-center gap-3'>
                      <div className='col-md-7'>
                          <Controller
                            name="subscriptionId"
                            control={control}
                            render={({ field: { value, onChange } }) => <Select
                              // value={allProducts?.find((c) => c.productId === value)}
                              onChange={(val) => onChange(val.subscriptionId)}
                              options={plan}
                              getOptionLabel={(option) => option.subscriptionName}
                              getOptionValue={(option) => option.subscriptionId}
                              style={{ width: "100%" }}
                              className='form-control p-0 border-0'
                              placeholder='Select plan'
                            />}
                            rules={{ required: true }}
                          />
                          <span className="error">{errors.subscriptionId && <span>{errors.subscriptionId?.message}</span>}</span>
                      </div>
                      {/* <div className='col-md'><button className='btn p-0'><i class="bi bi-info-circle"></i></button></div> */}
                    </div>
                  </div>
                </div>
                <hr className='borderSeperator' />
                <div className='row g-3 mx-1'>
                  <div className='col-md-3 suBPanel'>
                    <div className='subscriptionLabelMain'>Users</div>
                    <div className='subscriptionLabelcontent'>Enter Concurrent Users and price.</div>
                  </div>
                  <div className='col-md-9'>
                    <div className='row g-5'>
                      <div className='col-md-7'>
                        <div className='form-group'>
                          <label className='fromLabel'>Concurrent Users</label>
                          <input type='text' name="concurrentUsers" {...register("concurrentUsers")} className="form-control " placeholder=' ' />
                          <span className="error">{errors.concurrentUsers && <span>{errors.concurrentUsers?.message}</span>}</span>
                        </div>
                      </div>
                      <div className='col-md-5'>
                        <div className='form-group'>
                          <label className='fromLabel'>Price</label>
                          <input type='number' name="concurrentUsersPrice" {...register("concurrentUsersPrice")} placeholder='$0.00' className="form-control price" style={{ width: '160px' }}/>
                          <span className="error">{errors.concurrentUsersPrice && <span>{errors.concurrentUsersPrice?.message}</span>}</span>
                        </div>
                      </div>
                    </div>
                    <div className='row g-5 pt-3'>
                      <div className='col-md-7'>
                        <div className='form-group'>
                          <label className='fromLabel'>Load Generator</label>
                          <input type='text' name="loadGenerator" {...register("loadGenerator")} className="form-control " placeholder=' ' />
                          <span className="error">{errors.loadGenerator && <span>{errors.loadGenerator?.message}</span>}</span>
                        </div>
                      </div>
                      <div className='col-md-5'>
                        <div className='form-group'>
                          <label className='fromLabel'>Price</label>
                          <input type='text'  name="loadGeneratorPrice" {...register("loadGeneratorPrice")} placeholder='$0.00' className="form-control price" style={{ width: '160px' }} />
                          <span className="error">{errors.loadGeneratorPrice && <span>{errors.loadGeneratorPrice?.message}</span>}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className='borderSeperator' />
                <div className='row g-3 mx-1'>
                  <div className='col-md-3 suBPanel'>
                    <div className='subscriptionLabelMain'>Hours</div>
                    {/* <div className='subscriptionLabelcontent'>Enter the value in the text box, the price will automatically system will display it in the field box. This field is not in editable format.</div> */}

                  </div>
                  <div className='col-md-9'>
                    <div className='row g-5'>
                      <div className='col-md-7'>
                        <div className='form-group'>
                          <label className='fromLabel'>Virtual User Hours</label>
                          <input type='text' name="virtualUserHours" {...register("virtualUserHours")} className="form-control " placeholder='hh:mm:ss' />
                          <span className="error">{errors.virtualUserHours && <span>{errors.virtualUserHours?.message}</span>}</span>
                        </div>
                      </div>
                      <div className='col-md-5'>
                        <div className='form-group'>
                          <label className='fromLabel'>Price</label>
                          <input type='text'  name="virtualUserHoursPrice" {...register("virtualUserHoursPrice")} placeholder='$0.00' className="form-control price" style={{ width: '160px' }} />
                          <span className="error">{errors.virtualUserHoursPrice && <span>{errors.virtualUserHoursPrice?.message}</span>}</span>
                        </div>
                      </div>
                    </div>
                    <div className='row g-5 pt-3'>
                      <div className='col-md-7'>
                        <div className='form-group'>
                          <label className='fromLabel'>Max Test Duration</label>
                          <input type='text' name="maxTestDuration" {...register("maxTestDuration")} className="form-control" placeholder='hh:mm:ss' />
                          <span className="error">{errors.maxTestDuration && <span>{errors.maxTestDuration?.message}</span>}</span>
                        </div>
                      </div>
                      <div className='col-md-5'>
                        <div className='form-group'>
                          <label className='fromLabel'>Price</label>
                          <input type='text'  name="maxTestDurationPrice" {...register("maxTestDurationPrice")} placeholder='$0.00' className="form-control price" style={{ width: '160px' }}/>
                          <span className="error">{errors.maxTestDurationPrice && <span>{errors.maxTestDurationPrice?.message}</span>}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className='borderSeperator' />
                <div className='row g-3 mx-1'>
                  <div className='col-md-3 suBPanel'>
                    <div className='subscriptionLabelMain'>Monitoring & Calls</div>
                    {/* <div className='subscriptionLabelcontent'>Enter the value in the text box, the price will automatically system will display it in the field box. This field is not in editable format.</div> */}
                  </div>
                  <div className='col-md-9'>
                    <div className='row g-5'>
                      <div className='col-md-7'>
                        <div className='form-group'>
                          <label className='fromLabel'>APM Monitoring</label>
                          <input type='text' name="apmMonitoring" {...register("apmMonitoring")} className="form-control " placeholder=' ' />
                          <span className="error">{errors.apmMonitoring && <span>{errors.apmMonitoring?.message}</span>}</span>
                        </div>
                      </div>
                      <div className='col-md-5'>
                        <div className='form-group'>
                          <label className='fromLabel'>Price</label>
                          <input type='text' name="apmMonitoringPrice" {...register("apmMonitoringPrice")} className="form-control price" placeholder='$0.00' style={{ width: '160px' }}  />
                          <span className="error">{errors.apmMonitoringPrice && <span>{errors.apmMonitoringPrice?.message}</span>}</span>
                        </div>
                      </div>
                    </div>
                    <div className='row g-5 pt-3'>
                      <div className='col-md-7'>
                        <div className='form-group'>
                          <label className='fromLabel'>API calls</label>
                          <input type='text' name="apiCalls" {...register("apiCalls")} className="form-control " placeholder=' ' />
                          <span className="error">{errors.apiCalls && <span>{errors.apiCalls?.message}</span>}</span>
                        </div>
                      </div>
                      <div className='col-md-5'>
                        <div className='form-group'>
                          <label className='fromLabel'>Price</label>
                          <input type='text'  name="apiCallsPrice" {...register("apiCallsPrice")} placeholder='$0.00' className="form-control price" style={{ width: '160px' }}/>
                          <span className="error">{errors.apiCallsPrice && <span>{errors.apiCallsPrice?.message}</span>}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className='borderSeperator' />
                <div className='row g-3 mx-1'>
                  <div className='col-md-3 suBPanel'>
                    <div className='subscriptionLabelMain'>Plan Expire Date</div>
                  </div>
                  <div className='col-md-5 me-0 pe-0'>
                    <div className='d-flex gap-3'>
                      <div className='form-group'>
                        <label className='fromLabel'>Plan Start Date</label>
                        {/* <input type='date' name="planStartDate" {...register("planStartDate")} className="form-control "  />  
                          <span className="error">{errors.planStartDate && <span>{errors.planStartDate?.message}</span>}</span>   */}
                        <Controller
                          control={control}
                          name="planStartDate"
                          render={({ field }) => (
                            <DatePicker
                              placeholderText="MM/DD/YYYY"
                              className='form-control'
                              onChange={(date) => { field.onChange(date); setStartDate(date) }}
                              selected={field.value}
                              selectsStart
                              startDate={startDate}
                              endDate={endDate}
                              maxDate={endDate}
                              
                            />
                          )}
                        />
                        {errors.planStartDate && <span className="error">This field is required</span>}

                      </div>
                      <div className='form-group m-0 p-0'>
                        <label className='fromLabel'>Plan Expire Date</label>

                        <Controller
                          control={control}
                          name="planExpireDate"
                          render={({ field }) => (
                            <DatePicker
                            placeholderText="MM/DD/YYYY"
                              className='form-control'
                              onChange={(date) => { field.onChange(date); setEndDate(date) }}
                              selected={field.value}
                              selectsEnd
                              startDate={startDate}
                              endDate={endDate}
                              minDate={startDate}
                            />
                          )}
                        />
                        {errors.planStartDate && <span className="error">This field is required</span>}

                      </div>
                    </div>
                  </div>
                </div>
                <hr className='borderSeperator' />
                <div className='row g-3 mx-1'>
                  <div className='col-md-3 suBPanel'>
                    <div className='subscriptionLabelMain'>Description</div>
                  </div>
                  <div className='col-md-9'>
                    <div className='row g-5'>
                      <div className='col-md-7'>
                        <div className='form-group'>
                          <textarea type='text' name="discription" {...register("discription")} className="form-control" style={{height:'150px'}}/>
                          <span className="error">{errors.discription && <span>{errors.discription?.message}</span>}</span>
                        </div>
                        <div className="form-check form-switch mt-4">
                          <input className="form-check-input shadow-none" {...register("activeFlags")} type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                          <label className="form-check-label" htmlFor="flexSwitchCheckDefault">Active</label>
                        </div>
                      </div>
                      <div className='col-md-5'>
                        <div className='form-group'>
                          <label className='fromLabel'>Total Price</label>
                          <input disabled type='text' className="form-control price" {...register("totalPrice")}  style={{ width: '160px' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <hr className='borderSeperator' />
                <div className='row g-3 mx-1 align-items-center'>
                  <div className='col-md-3 suBPanel'>
                    <div className='subscriptionLabelMain'>Offer</div>
                  </div>
                  <div className='col-md-9'>
                    <div className='row g-0'>
                      <div className='col-md-7'>
                        <div className="form-check form-switch">
                          <input className="form-check-input shadow-none" {...register("offer")} type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                          <label className="form-check-label" htmlFor="flexSwitchCheckDefault">Offer</label>
                        </div>
                      </div>
                      {isOffer && 
                         <div className='col-md-5'>
                         <div className='form-group'>
                           <label className='fromLabel'>Offer Percentage</label>
                           <input type='text' name="offerPercentage" {...register("offerPercentage")} className="form-control price"  style={{ width: '160px' }} />
                           <span className="error">{errors.offerPercentage && <span>{errors.offerPercentage?.message}</span>}</span>
                         </div>
                       </div>
                      }
                   
                    </div>
                  </div>

                  
                </div>
                <div className='row my-4'>
                  <div className='col-md-12 mt-4 text-center'>
                    <button className='btn btn_outline mx-3' onClick={() => history.goBack()} style={{ width: '120px' }}>Cancel</button>
                    <button type="submit" className='btn btn_primary mx-3' style={{ width: '120px' }}>Save</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
        <div className='col-md-12 mt-5'>
          <div className='footerPanel d-flex align-items-center justify-content-end gap-2 mx-4'>
            <p className='content mb-0'>Powered by</p>
            <div className='logoLayout'><img className='w-100' src={logo} alt='logo' /></div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AdminSubscriptionPlan