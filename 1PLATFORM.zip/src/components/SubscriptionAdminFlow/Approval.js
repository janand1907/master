import React, { useEffect, useState } from 'react'
import { useForm, Controller } from "react-hook-form";
import Modal from 'react-bootstrap/Modal';
import './Approval.scss'
import { Link, useHistory } from 'react-router-dom';
import { subscriptionPendingDetails, approveRejectLicense, getLicenseValidation, generateLicenceKey } from '../../endpoints/gateway'
import { toast } from 'react-toastify';
import logo from '../../assets/images/logo_main.png'
import nodata from '../../assets/images/nodata.svg';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { backBtnIcon, validateIcon } from '../../Icons/icons';
import moment from 'moment';
import Spinner from 'react-bootstrap/Spinner';
import Select from 'react-select';

const Approval = () => {
  const history = useHistory();
  const [productDetails, setproductDetails] = useState([])
  const [startDate, setStartDate] = useState(new Date().getTime());
  const [endDate, setEndDate] = useState(new Date().getTime());
  useEffect(() => {
    PendingDetails()
  }, [])

  // modal Implement
  const [show, setShow] = useState(false);
  const [approveData, setApproveData] = useState([]);
  const [licenseKey, setLicenseKey] = useState("");
  const [licenseDetails, setLicenseDetails] = useState([]);
  const [id, setId] = useState(0);
  const [userId, setUserId] = useState(0);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [duration, setDuration] = useState(null);
  const [approveSpinner, setApproveSpinner] = useState(true);
  const [rejectSpinner, setRejectSpinner] = useState(true);

  const handleClose = () => {
    setShow(false);
    setLicenseKey("");
    setStartDate(new Date().getTime());
    setEndDate(new Date().getTime());
    setApproveData([]);
    setLicenseDetails([]);
    setMessage('');
    setDuration(null);
  }

  const getDuration = (val) => {
    setDuration(val);
  }

  const { register,
    handleSubmit, setValue,
    formState: { errors, isValid }, control, reset } = useForm({
      mode: 'onChange'
    });

  const [subscriptionPeriod, setSubscriptionPeriod] = useState([
    {
      "duration": 30,
      "productName": "1 Month",
      "productLogo": null
    },
    {
      "duration": 60,
      "productName": "2 Month",
      "productLogo": null
    },
    {
      "duration": 90,
      "productName": "3 Month",
      "productLogo": null
    },
    {
      "duration": 120,
      "productName": "4 Month",
      "productLogo": null
    },
    {
      "duration": 150,
      "productName": "5 Month",
      "productLogo": null
    },
    {
      "duration": 180,
      "productName": "6 Month",
      "productLogo": null
    },
    {
      "duration": 210,
      "productName": "7 Month",
      "productLogo": null
    },
    {
      "duration": 240,
      "productName": "8 Month",
      "productLogo": null
    },
    {
      "duration": 270,
      "productName": "9 Month",
      "productLogo": null
    },
    {
      "duration": 300,
      "productName": "10 Month",
      "productLogo": null
    },
    {
      "duration": 330,
      "productName": "11 Month",
      "productLogo": null
    },
    {
      "duration": 364,
      "productName": "12 Month",
      "productLogo": null
    }
  ])

  const handleShow = async (data, type) => {
    setId(data.subscriptionPlanId);
    if (data.activeFlag === true) {
      let response = await subscriptionPendingDetails(`/getSubscriptionApprovedDetail/1/${data.companyId}`);
      setApproveData(response.data[0]);
      setStartDate(new Date(response.data[0].subscribeOn).getTime());
      setEndDate(new Date(response.data[0].subscribeUntill).getTime());
      setShow(true);
    } else {
      setApproveData(data);
      setShow(true);
      setUserId(data.userId);
    }
  }

  const handleLicenseKey = async (product_id) => {
    if (licenseKey !== "") {
      setLoading(true);
      let response = await getLicenseValidation(product_id, licenseKey);

      if (response.data) {

        let date = response.data;

        setStartDate(date.created + "000");
        setEndDate(date.expires + "000");
        // let startdate = moment.utc(new Date(date.created)).format('DD-MMM-YYYY');
        // let enddate = moment(date.expires).format();
      }
      setLicenseDetails(response);
      setLoading(false);
    } else {

    }
  }
  const PendingDetails = async () => {
    let response = await subscriptionPendingDetails(1)
    
    setproductDetails(response.data)
  }

  const handleApprove = async (item, request_id, status) => {
    

    if (status) {
      setApproveSpinner(false);
      if (duration === null || duration === '' || duration === undefined) {
        toast.warning('Please choose license active duration');
        return;
      }

      if (message === null || message === '' || message === undefined) {
        toast.warning('Please enter Message');
        return;
      }

      let crypParam = {
        "productId": item.product_id,
        "period": duration,
        "notes": message
      }

      let key = await generateLicenceKey(crypParam);
      
      if (key.status && key.status === 200) {

        let param = {
          "requested_id": request_id,
          "license_id": key.data.license_id,
          "status": "Approved"
        }

        let response = await approveRejectLicense(param);

        if (response.status && response.status === 200) {
          toast.success(response.data.message);
          PendingDetails();
          handleClose();
          setApproveSpinner(true);
        } else {
          setApproveSpinner(true);
          toast.warning(response.response.data.message);
        }

      } else {
        setApproveSpinner(true);
        toast.warning(key.response.data.message);
      }

    } else {
      setRejectSpinner(false);
      let param = {
        "requested_id": request_id,
        "status": "Rejected"
      }

      let response = await approveRejectLicense(param);

      if (response.status && response.status === 200) {
        toast.success(response.data.message);
        setRejectSpinner(true);
        PendingDetails();
        handleClose();
      } else {
        setRejectSpinner(true);
        toast.warning(response.response.data.message);
      }

    }
  }



  return (
    <div className='subscription_panel'>
      <div className="mt-2 custom-head-card">
        <div className='d-flex align-items-center justify-content-between'>
          <div className="d-flex gap-2 align-items-center">
            {/* <button type="button" onClick={() => history.goBack()} className="btn btn_light">{backBtnIcon}</button> */}
            <div className='h3'>Subscription Pending Details</div>
          </div>
          <div className='d-none d-md-flex align-items-center gap-3'>
            {/* <Link to='/inviteuser' className='btn btn_outline'>Invite Users</Link> */}
            <Link to='/manageuser' className='btn btn_primary'>Manage Users</Link>
          </div>
        </div>
      </div>
      {/* <div className="mt-2 custom-head-card">
        <div className="d-flex gap-2 align-items-center">
          <button type="button" onClick={() => history.goBack()} className="btn btn_light">{backBtnIcon}</button>
          <div className='h3'>Subscription Pending Details</div>
        </div>
        <div className='d-flex align-items-center gap-3'>
            <Link to='/manageuser' className='btn btn_primary'>Manage Users</Link>
        </div>
      </div> */}
      <div className='row my-3 g-3'>
        <div className='col-md-12 d-block d-md-none'>
          <Link to='/manageuser' className='btn btn_primary w-100'>Manage Users</Link>
        </div>
        <div className='col-md-12'>
          <div className='card op_card'>
            <div className='card-body px-0 pb-0'>
              <div className='d-flex align-items-center justify-content-between mb-3 mx-3'>
                <div className='heading_approval'>Product Pending Details</div>
                {/* <div className='table_pagination'>
                  <nav aria-label="Page navigation example">
                    <ul className="pagination">
                      <li className="page-item"><Link className="page-link" href="#"><i class="bi bi-chevron-left"></i></Link></li>
                      <li className="page-item"><Link className="page-link active" href="#">1</Link></li>
                      <li className="page-item"><Link className="page-link" href="#">2</Link></li>
                      <li className="page-item"><Link className="page-link" href="#">3</Link></li>
                      <li className="page-item"><Link className="page-link" href="#"><i class="bi bi-chevron-right"></i></Link></li>
                    </ul>
                  </nav>
              </div>                  */}
              </div>
              <div className='table-responsive'>
                <table className="table manageuser_grid mb-0">
                  <thead>
                    <tr className='px-3 py-4'>
                      <th scope="col" className='px-3'>User Email <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                      <th scope="col">Product Name <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                      <th scope="col">Requested on <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                      <th scope="col">Plan type <span className='mx-1' style={{ fontSize: '13px' }}></span></th>
                      <th scope="col" className='text-center'>Action</th>
                    </tr>
                  </thead>
                  <tbody className='border-top-0'>
                    {
                      productDetails && productDetails.length > 0 ?
                        productDetails.map((data, index) => (
                          <tr key={index}>
                            <td className='px-3'>
                              <div className='d-flex align-items-center gap-2'>
                                <div>{data.email}</div>
                              </div>
                            </td>
                            <td>{data.product_name}</td>

                            <td>{moment(parseInt(data?.created_on)).format("DD/MM/YYYY")}</td>
                            <td>{data.plan_type}-{data.type}</td>

                            <td>
                              <div className='d-flex align-items-center justify-content-center gap-3'>
                                <button className='btn btn_action_link p-0' onClick={() => {handleShow(data, 1); getDuration(data.duration)}}>Approve</button>
                                {/* <button onClick={()=>handleShow(data, 2)} className='btn btn_action_link p-0'>Reject</button> */}
                              </div>
                            </td>
                          </tr>
                        ))
                        :
                        <tr>
                          <td colspan="8">
                            <div className="col-sm-12 text-center py-2">
                              <img src={nodata} alt="nodata" className="gridImg" />
                              <p className="nodata-msg mt-3">No Datails available </p>
                            </div>
                          </td>
                        </tr>


                    }
                  </tbody>

                </table>
              </div>
            </div>
          </div>
        </div>
        <div className='col-md-12 mt-5'>
          <div className='footerPanel d-flex align-items-center justify-content-end gap-2 mx-4'>
            <p className='content mb-0'>Powered by</p>
            <div className='logoLayout'><img className='w-100' src={logo} alt='logo' /></div>
          </div>
        </div>
      </div>
      {/* <Modal className='subscription_approval' size='lg' show={show} onHide={handleClose} backdrop="static" keyboard={false} centered>
        <Modal.Header closeButton>
          <Modal.Title>Subscription Approval</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form className='subscription_approval_form mx-4'>
            <div className='row'>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Email Id</label>
                  <input type='text' className='form-control' value={approveData.email} disabled />
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Product name</label>
                  <input type='text' className='form-control' value={approveData.product_name} disabled />
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Plan type</label>
                  <input type='text' className='form-control' value={approveData?.plan_type} disabled />
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Licence Key</label>
                  <div className='d-flex gap-2'>
                    <input type='text' value={approveData.licenseKey ? approveData.licenseKey : licenseKey} onChange={(e) => setLicenseKey(e.target.value)} className='form-control' disabled={approveData.licenseKey ? true : false} />
                    { !loading ?
                      <a className='btn validate_btn' onClick={() => { handleLicenseKey(approveData.product_id) }}>
                        {validateIcon}
                      </a>
                      :
                      <div className="btn spinners"><p><Spinner animation="border" variant="info" /></p></div>
                    }
                  </div>
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Subscription from</label>
                  <input type='text' className='form-control' value={moment(parseInt(startDate)).format("DD/MM/YYYY")} disabled />
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Subscription till</label>
                  <input type='text' className='form-control' value={moment(parseInt(endDate)).format("DD/MM/YYYY")} disabled />
                </div>
              </div>
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer className='justify-content-center'>
          <button className='btn btn_outline mx-2' onClick={handleClose}>
            Cancel
          </button>
          {approveData.licenseKey ? "" : licenseDetails.length === 0 ? "" :
            <button className='btn btn_primary mx-2' onClick={() => handleApprove(approveData, approveData.request_id)}>
              Approve
            </button>}
        </Modal.Footer>
      </Modal> */}
      <Modal className='subscription_approval' size='lg' show={show} onHide={handleClose} backdrop="static" keyboard={false} centered>
        <Modal.Header closeButton>
          <Modal.Title>Subscription Approval</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form className='subscription_approval_form mx-4'>
            <div className='row'>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Full Name: </label>
                  {/* <input type='text' className='form-control' value={approveData.email} disabled /> */}
                  <label className='form-label'>{approveData.first_name} {approveData.last_name}</label>
                </div>
              </div>
              {/* <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Last Name: </label>
                  <span>{approveData.last_name}</span>
                </div>
              </div> */}
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Email Id: </label>
                  {/* <input type='text' className='form-control' value={approveData.email} disabled /> */}
                  <label className='form-label'>{approveData.email}</label>
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Product name: </label>
                  {/* <input type='text' className='form-control' value={approveData.product_name} disabled /> */}
                  <label className='form-label'>{approveData.product_name}</label>
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Plan type: </label>
                  {/* <input type='text' className='form-control' value={approveData?.plan_type} disabled /> */}
                  <label className='form-label'>{approveData.plan_type}</label>
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Requested Days: </label>
                  {/* <input type='text' className='form-control' value={approveData.product_name} disabled /> */}
                  {/* <span>{approveData.duration}</span> */}
                  <Controller
                    name="duration"
                    control={control}
                    render={({ field: { onChange, value } }) => <Select
                      value={subscriptionPeriod.find((c) => c.duration === approveData.duration)}
                      onChange={(val) => { getDuration(val.duration) }}
                      options={subscriptionPeriod}
                      getOptionLabel={(option) => option.productName}
                      getOptionValue={(option) => option.duration}
                      style={{ width: "100%" }}
                      className='form-select p-0 border-0'
                    />}
                    rules={{ required: true }}
                  />
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Requested On: </label>
                  {/* <input type='text' className='form-control' value={approveData.product_name} disabled /> */}
                  <label className='form-label'>{moment(approveData.created_on).format("DD-MM-YYYY")}</label>

                </div>
              </div>
              <div className='col-md-12'>
                <div className='op_input_block'>
                  <label className='form-label'>Message: </label>
                  <textarea type='text' className='form-control' value={message} onChange={(e) => setMessage(e.target.value)} />

                </div>
              </div>
              {/* <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Licence Key</label>
                  <div className='d-flex gap-2'>
                    <input type='text' value={approveData.licenseKey ? approveData.licenseKey : licenseKey} onChange={(e) => setLicenseKey(e.target.value)} className='form-control' disabled={approveData.licenseKey ? true : false} />
                    { !loading ?
                      <a className='btn validate_btn' onClick={() => { handleLicenseKey(approveData.product_id) }}>
                        {validateIcon}
                      </a>
                      :
                      <div className="btn spinners"><p><Spinner animation="border" variant="info" /></p></div>
                    }
                  </div>
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Subscription from</label>
                  <input type='text' className='form-control' value={moment(parseInt(startDate)).format("DD/MM/YYYY")} disabled />
                </div>
              </div>
              <div className='col-md-6'>
                <div className='op_input_block'>
                  <label className='form-label'>Subscription till</label>
                  <input type='text' className='form-control' value={moment(parseInt(endDate)).format("DD/MM/YYYY")} disabled />
                </div>
              </div> */}
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer className='justify-content-center'>
          <button className='btn btn_outline mx-2' onClick={handleClose}>
            Cancel
          </button>
          <button className='btn btn_primary mx-2' onClick={() => handleApprove(approveData, approveData.request_id, false)} disabled={!rejectSpinner}>
           { rejectSpinner  ?
              'Reject'
           :
           <Spinner
            as="span"
            animation="border" variant="light"
            size="sm"
            role="status"
            aria-hidden="true"
            />
           }
           
          </button>
          <button className='btn btn_primary mx-2' onClick={() => handleApprove(approveData, approveData.request_id, true)} disabled={!approveSpinner}>
            { approveSpinner ?
               'Approve'
               :
               <Spinner
                as="span"
                animation="border" variant="light"
                size="sm"
                role="status"
                aria-hidden="true"
               />
            }
            
          </button>
          {/* {approveData.licenseKey ? "" : licenseDetails.length === 0 ? "" :
            <button className='btn btn_primary mx-2' onClick={() => handleApprove(approveData, approveData.request_id)}>
              Approve
            </button>} */}
        </Modal.Footer>
      </Modal>
    </div>
  )
}

export default Approval