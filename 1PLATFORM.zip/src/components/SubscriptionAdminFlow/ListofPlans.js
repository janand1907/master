import { Tab, Nav } from 'react-bootstrap'
import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import './ListofPlans.scss'
import { chatIcon } from '../../Icons/icons'
import logo from '../../assets/images/logo_main.png'
import { getSubscriptionsModes, planDetails, getProducts } from '../../endpoints/gateway'
import moment from 'moment';
import Select from 'react-select'

const ListofPlans = () => {

    const eyeIcon = <svg xmlns="http://www.w3.org/2000/svg" width="20" height="13.636" viewBox="0 0 20 13.636">
        <path id="visibility_FILL0_wght400_GRAD0_opsz48" d="M12,18.682a3.841,3.841,0,0,0,3.864-3.864A3.841,3.841,0,0,0,12,10.955a3.841,3.841,0,0,0-3.864,3.864A3.841,3.841,0,0,0,12,18.682Zm0-1.318a2.555,2.555,0,0,1-1.807-4.352,2.579,2.579,0,0,1,3.614,0A2.545,2.545,0,0,1,12,17.364Zm0,4.273A10.186,10.186,0,0,1,6,19.75a11.492,11.492,0,0,1-4-4.932A11.492,11.492,0,0,1,6,9.886,10.186,10.186,0,0,1,12,8a10.186,10.186,0,0,1,6,1.886,11.492,11.492,0,0,1,4,4.932,11.492,11.492,0,0,1-4,4.932A10.186,10.186,0,0,1,12,21.636ZM12,14.818Zm0,5.455a9.139,9.139,0,0,0,5.057-1.489,9.66,9.66,0,0,0,3.511-3.966,9.66,9.66,0,0,0-3.511-3.966,9.333,9.333,0,0,0-10.114,0,9.822,9.822,0,0,0-3.534,3.966,9.822,9.822,0,0,0,3.534,3.966A9.139,9.139,0,0,0,12,20.273Z" transform="translate(-2 -8)" fill="#333" />
    </svg>

    const dateIcon = <svg xmlns="http://www.w3.org/2000/svg" width="18.899" height="20.999" viewBox="0 0 18.899 20.999">
        <path id="Union_6" data-name="Union 6" d="M13065.575-10383a1.509,1.509,0,0,1-1.1-.473,1.507,1.507,0,0,1-.473-1.1v-16.273a1.5,1.5,0,0,1,.473-1.1,1.513,1.513,0,0,1,1.1-.473h1.7V-10404h1.708v1.577h8.923V-10404h1.707v1.577h1.705a1.515,1.515,0,0,1,1.1.473,1.5,1.5,0,0,1,.473,1.1v16.273a1.507,1.507,0,0,1-.473,1.1,1.511,1.511,0,0,1-1.1.473Zm0-1.574h15.747v-11.287h-15.747Zm15.747-12.861v-3.412h-15.747v3.412Zm-10.2,5.437v-1.5h9v1.5Zm-3.75,0v-1.5h1.5v1.5Z" transform="translate(-13063.999 10404.002)" fill="#828282" />
    </svg>

    const building = <svg xmlns="http://www.w3.org/2000/svg" width="24.956" height="22.46" viewBox="0 0 24.956 22.46">
        <path id="domain_FILL0_wght400_GRAD0_opsz48" d="M4,28.46V6H16.166v5.147h12.79V28.46Zm1.872-1.872H9.147V23.313H5.872Zm0-5.147H9.147V18.166H5.872Zm0-5.147H9.147V13.019H5.872Zm0-5.147H9.147V7.872H5.872Zm5.147,15.442h3.275V23.313H11.019Zm0-5.147h3.275V18.166H11.019Zm0-5.147h3.275V13.019H11.019Zm0-5.147h3.275V7.872H11.019Zm5.147,15.442H27.084V13.019H16.166v3.275h2.5v1.872h-2.5v3.275h2.5v1.872h-2.5Zm5.771-8.423V16.294h1.872v1.872Zm0,5.147V21.442h1.872v1.872Z" transform="translate(-4 -6)" fill="#828282" />
    </svg>

    const [selectedProduct, setselectedProduct] = useState(1)
    const [allproducts, setallproducts] = useState()
    const [subscriptionmode, setsubscriptionmode] = useState()
    const [plandetails, setplandetails] = useState([])
    const [Loader, setLoader] = useState(false)
    useEffect(() => {
        fetchProducts()
        getsubscriptionmodes()

    }, [])



    const getsubscriptionmodes = async () => {
        let response = await getSubscriptionsModes()
        setsubscriptionmode(response.data)

    }
  

    const fetchProducts = async () => {
        let response = await getProducts()
        setallproducts(response.data)
        setselectedProduct(response.data[0]?.productId)
        setTimeout(() => {
            
            handleSelect(1)
        }, 1000)


    }

    useEffect(() => {
        handleSelect(1)
    }, [selectedProduct])
    const [key,setKey]=useState(1)

    const handleSelect = async (eventKey) => {
        setLoader(true)
        let response = await planDetails(`/getSubscriptionView/${selectedProduct}/${eventKey}`);
       
        if (response.status == 200) {
            setplandetails(response.data)
            setTimeout(() => {
                setLoader(false)
            }, 0)
        }
       
       
    }

    const selectedProductChange = (e) => {
        setKey(1)
        setselectedProduct(e.productId)
    }


    return (
        <div className='ListofPlans'>
            <div className="mt-2 custom-head-card">
                <div className="d-flex justify-content-between align-items-center">
                    <div className='h3'>List of plans</div>
                    <div className='d-flex align-items-center gap-2'>

                        <Link to='/Subscriptiondetails' className='btn btn_outline_primary px-3'>Subscription Details</Link>
                        <Link to='/adminsubscriptionplan' className='btn btn_primary px-4'>Create Subscribe</Link>
                    </div>
                </div>
            </div>
            <div className='my-3'>

                <div className='row'>
                <div class="col-md-12 ">
                    <div className='product_dropdown_filter'>
                            <div className="dropdown_label">Choose Products</div>
                            <div style={{ width: '150px' }}>
                                {
                                    allproducts
                                    &&
                                    <Select className='custom_select' defaultValue={allproducts[0]} options={allproducts} getOptionLabel={(option) => option.productName}
                                        getOptionValue={(option) => option.productId} onChange={(e) => selectedProductChange(e)} />
                                }

                            </div>
                        </div>
                    </div>

                    <div className='col-md-12'>
                        <Tab.Container id="left-tabs-example" activeKey={key} unmountOnExit={true} onSelect={(activeKey) => {handleSelect(activeKey); setKey(activeKey)}}>
                            <Nav>
                                {
                                    subscriptionmode?.map((val, index) => (
                                        <Nav.Item key={index}><Nav.Link eventKey={val.subscriptionModeId}>{val.subscriptionModeName} {val.subscriptionModeId} </Nav.Link></Nav.Item>
                                    ))
                                }

                            </Nav>
                            <div className='py-4'>
                                <Tab.Content >

                                    <>
                                        {
                                            subscriptionmode?.map((val, index) => (
                                                <Tab.Pane key={index} eventKey={val.subscriptionModeId}>
                                                    <div className='row g-3 pt-4 px-5'>
                                                        {
                                                            plandetails.map((data, index) =>
                                                                <div className='col-md-4' key={index}>
                                                                    <div className='op_card card position-relative'>
                                                                        <div className={`badge ${data.subscribeTypes.subscriptionId == '1' ? 'badge_basic' : data.subscribeTypes.subscriptionId == '2' ? 'badge_pro' : 'on_demand'}`}>{data.subscribeTypes.subscriptionName}</div>
                                                                        <div className='card-header bg-transparent border-0 d-flex justify-content-between align-items-center mt-4 pt-3'>
                                                                            <div className='cardBlock '>
                                                                                <div className='blocklabel'>Subscribe</div>
                                                                                <div className='blockValue'>{val.subscriptionModeName}</div>
                                                                            </div>
                                                                            <div className='priceBlock text-end'>
                                                                                <h1 className='price'>${data.totalPrice}</h1>
                                                                                {data.subscribeTypes.subscriptionId === "3" ? <p className='smallHint m-0'>Based on the Request</p> : ""}
                                                                            </div>
                                                                        </div>
                                                                        <div className='card-body'>
                                                                            <div className='d-flex align-items-center gap-2 py-3'>
                                                                                <div>{dateIcon}</div>
                                                                                <div className='cardBlock'>
                                                                                    <div className='blocklabel'>Created on</div>
                                                                                    <div className='blockValue'>{moment(new Date(data.subscribeTypes.createdOn)).format('DD-MM-YYYY')}</div>
                                                                                </div>
                                                                            </div>
                                                                            <div className='row py-4'>
                                                                                <div className='col'>
                                                                                    <div className='d-flex align-items-center gap-2'>
                                                                                        <div>{building}</div>
                                                                                        <div className='cardBlock'>
                                                                                            <div className='blocklabel'>Subscriptions</div>
                                                                                            <div className='blockValue'>142</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div className='col'>
                                                                                    <div className='d-flex align-items-center justify-content-end gap-2'>
                                                                                        <div className='cardBlock text-end'>
                                                                                            <div className='blocklabel'>Enquires</div>
                                                                                            <div className='blockValue'>0</div>
                                                                                        </div>
                                                                                        <div>{chatIcon}</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div className='card-footer bg-transparent border-0 pb-5 pt-4'>
                                                                            <div className='d-flex align-items-center gap-2'>
                                                                                <Link to={`/activeproductdetail/${selectedProduct}`} className='d-flex  align-items-center gap-2 p-0'>
                                                                                    <span className='eyeIcon'>{eyeIcon}</span>
                                                                                    <span className='viewPlan'>View Plan</span>
                                                                                </Link>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            )
                                                        }
                                                    </div>
                                                </Tab.Pane>
                                            ))
                                        }
                                    </>
                                </Tab.Content>
                            </div>
                        </Tab.Container>
                    </div>
                    <div className='col-md-12 mt-5'>
                        <div className='footerPanel d-flex align-items-center justify-content-end gap-2 mx-4'>
                            <p className='content mb-0'>Powered by</p>
                            <div className='logoLayout'><img className='w-100' src={logo} alt='logo' /></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ListofPlans