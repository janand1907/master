import React, { useEffect } from 'react'
import './SubscriptionUsage.scss'
import {useHistory } from 'react-router-dom';
import {userIcon, settingIcon, peopleIcon, historyIcon} from '../../Icons/icons'
import ProgressBar from 'react-bootstrap/ProgressBar';
import { useSelector,useDispatch} from 'react-redux'; 
const SubscriptionUsage = () => {
    const history = useHistory();
    const dispatch = useDispatch();
    const PlanDetails = useSelector(state => state.defaultreducder.data);
    

    useEffect(()=>{
        return () => {
            dispatch({ type: 'REMOVE'});
          }
    },[])
  return (
    <div className='subscriptionUsage'>
        <div className="mt-2 custom-head-card">
            <div className="d-flex gap-2 align-items-center">
                <button type="button" onClick={() => history.goBack()} className="btn btn_light"><i class="bi bi-chevron-left"></i></button>
                <div className='h3'>Subscription Usage Status</div>
            </div>
        </div>   
        <div className='my-3'>
            <div className='card op_card'>
                <div className='d-flex align-items-center justify-content-between'>
                    <div className='py-3'>
                        <div className='content_block px-4 border-end'>
                            <div className='content_bold'>{PlanDetails.subscriptionName}</div>
                            <div className='content_light'>Subscribe Plan</div>
                        </div>
                    </div>
                    <div className=' py-3'>
                        <div className='d-flex align-items-center gap-2'>
                            <div className='icon'>{historyIcon}</div>
                            <div className='content_block'>
                                <div className='content_bold'>{PlanDetails.maxTestDuration}h</div>
                                <div className='content_light'>Max Test Duration</div>
                            </div>
                        </div>
                    </div>
                    <div className=' py-3'>
                        <div className='d-flex align-items-center gap-2'>
                            <div className='icon'>{peopleIcon}</div>
                            <div className='content_block'>
                                <div className='content_bold'>{PlanDetails.concurrentUsers}</div>
                                <div className='content_light'>Concurrent Users</div>
                            </div>
                        </div>                        
                    </div>
                    <div className=' py-3'>
                        <div className='d-flex align-items-center gap-2'>
                            <div className='icon'>{settingIcon}</div>
                            <div className='content_block'>
                                <div className='content_bold'>{PlanDetails.loadGenerator}</div>
                                <div className='content_light'>Load Generator</div>
                            </div>
                        </div>                        
                    </div>
                    <div className=' py-3'>
                        <div className='d-flex align-items-center gap-2'>
                            <div className='icon'>{userIcon}</div>
                            <div className='content_block'>
                                <div className='content_bold'>{PlanDetails.virtualUserHours}</div>
                                <div className='content_light'>Virtual User Hours</div>
                            </div>
                        </div>                        
                    </div>
                    <div className='py-3' style={{background:'#49BDDF'}}>
                        <div className='content_block px-4'>
                            <div className='content_bold text-white'>{PlanDetails.usedVirtualUserHours}<span className='smallContent'>/{PlanDetails.virtualUserHours}</span></div>
                            <ProgressBar now={Math.round((PlanDetails.usedVirtualUserHours/PlanDetails.virtualUserHours)*100)} />
                            <div className='content_light text-white'>Virtual User Hours</div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>     
    </div>
  )
}

export default SubscriptionUsage