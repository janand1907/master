import React from 'react'
import { Link } from 'react-router-dom'
import './headerfoot.scss'
import fb from '../../assets/images/op_public/social/fb.png'
import twitter from '../../assets/images/op_public/social/tw.png'
import youtube from '../../assets/images/op_public/social/you.png'
import insta from '../../assets/images/op_public/social/insta.png'
import linked from '../../assets/images/op_public/social/linked.png'
const Footerpublic = () => {
  return (
    <div className='op_footer'>
      {/* <div className='op_footer_top'>
        <div className='op_footer_top_panel container'>
          <ul className='soc_list p-0'>
            <li className='soc_list_item'><img src={linked} alt='soc' /></li>
          </ul>
        </div>
      </div> */}
      <div className='op_footer_bottom'>
        <div className='container py-4'>
          <div className='op_footer_bottom_panel'>
              <div className='op_copyRights'>© {new Date().getFullYear()} 1Platform., All rights reserved</div>
                <ul className='footet_page_list p-0'>
                  {/* <li><Link to='/terms'>Terms of use</Link> </li>
                  <li className='mx-3 d-md-block d-none'>|</li>
                  <li><Link to='/privacy'>Privacy policy</Link></li>
                  <li className='mx-3 d-md-block d-none'>|</li> */}
                  <li><Link to='/contact'>Contact Us</Link></li>
                </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Footerpublic