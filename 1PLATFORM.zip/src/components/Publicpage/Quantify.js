import React from 'react'
import { Link, useHistory } from 'react-router-dom'
import './quantify.scss'
import Headerpublic from './Headerpublic'
import Footerpublic from './Footerpublic'
import banner from '../../assets/images/op_public/qtfy/bannerright.png';
import section1 from '../../assets/images/op_public/qtfy/sectionimg1.png';
import section2 from '../../assets/images/op_public/qtfy/sectionimg2.png';
import ps_1 from '../../assets/images/op_public/qtfy/pl_support/ps_1.png'
import ps_2 from '../../assets/images/op_public/qtfy/pl_support/ps_2.png'
import ps_3 from '../../assets/images/op_public/qtfy/pl_support/ps_3.png'
import per_1 from '../../assets/images/op_public/qtfy/performance/per_1.svg'
import per_2 from '../../assets/images/op_public/qtfy/performance/per_2.svg'
import per_3 from '../../assets/images/op_public/qtfy/performance/per_3.svg'
import per_4 from '../../assets/images/op_public/qtfy/performance/per_4.svg'
import per_5 from '../../assets/images/op_public/qtfy/performance/per_5.svg'
import per_b_1 from '../../assets/images/op_public/qtfy/performance/per_b_1.svg'
import per_b_2 from '../../assets/images/op_public/qtfy/performance/per_b_2.svg'
import per_b_3 from '../../assets/images/op_public/qtfy/performance/per_b_3.svg'
import per_b_4 from '../../assets/images/op_public/qtfy/performance/per_b_4.svg'
import per_b_5 from '../../assets/images/op_public/qtfy/performance/per_b_5.svg'
import client1 from '../../assets/images/op_public/qtfy/clients/client-1.png';
import client2 from '../../assets/images/op_public/qtfy/clients/singlife.png';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
const Quantify = () => {
  const history = useHistory();
  const toRoute = () => {
    history.push(`/contact`);
  }
  return (
    <>
      <Headerpublic />
      <div className='quantify_page'>
        <section className={"herobanner"}>
          <div className={"quantify-wrapper banner-wrapper"}>
            <div className={"banner-caption"}>
              <h1>The complete & <strong>Continuous Performance testing</strong> platform</h1>
              <p>Testing & certifying your platform for Speed, response time, stability, realiability and scalability.</p>
              <button className='btn btn_primary mt-5' onClick={() => toRoute()}>Request a Demo</button>
            </div>
            <div className={"banner-image"}>
              <img src={banner} alt="" />
            </div>
          </div>
        </section>
        <section className='page-section greybg'>
          <div className={"quantify-wrapper mt-4"}>
            <div className={"section-title"}>
              <h2>Performance test with Quantify - made easy</h2>
              <div className='performace_test_block my-2'>
                <ul className='p-0 performace_test_block_list'>
                  <li className='performace_test_block_list_items'>
                    <div className='card position-relative bg_1'>
                      <div className='per_image'>
                        <img src={per_1} alt='perImage' />
                      </div>
                      <div className='card-body'>
                        <h3>Create Performance test scenario</h3>
                        <ul className='mt-2'>
                          <li>Test case creation</li>
                          <li>Test case and scenario mapping</li>
                        </ul>
                      </div>
                      <img className='border_image' src={per_b_1} alt='perImage' />
                    </div>
                  </li>
                  <li className='performace_test_block_list_items'>
                    <div className='card position-relative'>
                      <div className='per_image'>
                        <img src={per_2} alt='perImage' />
                      </div>
                      <div className='card-body'>
                        <h3>Load characterization</h3>
                        <ul className='mt-2'>
                          <li>Workload characterization</li>
                          <li>Load distribution</li>
                        </ul>
                      </div>
                      <img className='border_image' src={per_b_2} alt='perImage' />
                    </div>
                  </li>
                  <li className='performace_test_block_list_items'>
                    <div className='card position-relative'>
                      <div className='per_image'>
                        <img src={per_3} alt='perImage' />
                      </div>
                      <div className='card-body'>
                        <h3>Configure environments</h3>
                        <ul className='mt-2'>
                          <li>Configure Run time environments</li>
                          <li>Configure Auto scaling</li>
                        </ul>
                      </div>
                      <img className='border_image' src={per_b_3} alt='perImage' />
                    </div>
                  </li>
                  <li className='performace_test_block_list_items'>
                    <div className='card position-relative'>
                      <div className='per_image'>
                        <img src={per_4} alt='perImage' />
                      </div>
                      <div className='card-body'>
                        <h3>Customize execution</h3>
                        <ul className='mt-2'>
                          <li>Configure Run time parameters</li>
                          <li>Set Duration / Iterations</li>
                        </ul>
                      </div>
                      <img className='border_image' src={per_b_4} alt='perImage' />
                    </div>
                  </li>
                  <li className='performace_test_block_list_items'>
                    <div className='card position-relative'>
                      <div className='per_image'>
                        <img src={per_5} alt='perImage' />
                      </div>
                      <div className='card-body'>
                        <h3>Execute</h3>
                        <ul className='mt-2'>
                          <li>Live dashboard view</li>
                          <li>Download report</li>
                        </ul>
                      </div>
                      <img className='border_image last' src={per_b_5} alt='perImage' />
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
        <section className={"page-section"}>
          <div className={"quantify-wrapper"}>
            <div className={"section-content knowldge-section"}>
              <div className={"section-img"}>
                <img src={section2} alt="" />
              </div>
              <div className={"section-desc"}>
                <div className={"section-title text-start ms-4"}>
                  <h2 className='mb-4'>Expertise & Platform Support</h2>
                  <ul style={{ listStyleType: 'disc', fontSize: '.875rem', color: '#333333' }} >
                    <li className='mb-2'>Detailed & User-Friendly Self-help</li>
                    <li className='mb-2'>Skilled technical experise and support</li>
                    <li className='mb-2'>Meeting customer SLA </li>
                    <li className='mb-2'>Chatbot for guided help and assitance</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className={"page-section bg-white"}>
          <div className={"quantify-wrapper"}>
            <div className={"section-title"}>
              <h2>Types of Plan</h2>
              {/* <p>Our experts are availble to help you with your sepcifc needs and make your performance test journey a successful one. Reach out to us for any help!</p> */}
            </div>
            <div className={"card-container"}>
              <ul className={"card-list"}>
                <li>
                  <div className={"card-wrapper"}>
                    <div className={"icon"}>
                      <span>
                        <svg xmlns="http://www.w3.org/2000/svg" id="person_black_24dp" width="68.761" height="68.761" viewBox="0 0 68.761 68.761">
                          <path id="Path_11" data-name="Path 11" d="M0,0H68.761V68.761H0Z" fill="none" />
                          <path id="Path_12" data-name="Path 12" d="M26.494,9.624a5.624,5.624,0,1,1-5.624,5.624,5.64,5.64,0,0,1,5.624-5.624m0,28.118c7.592,0,16.308,3.627,16.871,5.624H9.624c.647-2.024,9.307-5.624,16.871-5.624M26.494,4A11.247,11.247,0,1,0,37.742,15.247,11.244,11.244,0,0,0,26.494,4Zm0,28.118C18.987,32.118,4,35.886,4,43.365v5.624H48.989V43.365C48.989,35.886,34,32.118,26.494,32.118Z" transform="translate(7.886 7.886)" fill="#828282" />
                        </svg>
                      </span>
                    </div>
                    <h4 className={"card-title"}>On-demand Plan</h4>
                    <p className='p_engagement'>Running performance tests just once (or) not so often? Subscribe to our on-demand plan which helps to pay as you need. Pay for the VU hours needed and you can optimise your spend</p>
                  </div>
                </li>
                <li>
                  <div className={"card-wrapper"}>
                    <div className={"icon"}>
                      <span>
                        <svg xmlns="http://www.w3.org/2000/svg" id="people_black_24dp" width="73.021" height="73.021" viewBox="0 0 73.021 73.021">
                          <path id="Path_13" data-name="Path 13" d="M0,0H73.021V73.021H0Z" fill="none" />
                          <path id="Path_14" data-name="Path 14" d="M23.3,31.622c-7.12,0-21.3,3.56-21.3,10.649V47.6H44.6V42.271C44.6,35.182,30.418,31.622,23.3,31.622ZM9.12,41.511c2.556-1.765,8.732-3.8,14.178-3.8s11.623,2.039,14.178,3.8ZM23.3,26.3A10.649,10.649,0,1,0,12.649,15.649,10.661,10.661,0,0,0,23.3,26.3Zm0-15.213a4.564,4.564,0,1,1-4.564,4.564A4.558,4.558,0,0,1,23.3,11.085ZM44.718,31.8c3.529,2.556,5.963,5.963,5.963,10.466V47.6h12.17V42.271C62.851,36.125,52.2,32.626,44.718,31.8ZM41.553,26.3a10.649,10.649,0,0,0,0-21.3,10.483,10.483,0,0,0-4.564,1.065,16.616,16.616,0,0,1,0,19.168A10.483,10.483,0,0,0,41.553,26.3Z" transform="translate(4.085 10.213)" fill="#828282" />
                        </svg>
                      </span>
                    </div>
                    <h4 className={"card-title"}>Basic & Pro plan</h4>
                    <p className='p_engagement'>Do you have to need to run your performance test more frequently? Get a basic plan with a monthly or annual subscription. If you need more concurrent users and VU hours, you can change your subscription to Pro-plan</p>
                  </div>
                </li>
                <li>
                  <div className={"card-wrapper"}>
                    <div className={"icon"}>
                      <span>
                        <svg xmlns="http://www.w3.org/2000/svg" id="business_black_24dp" width="70.993" height="70.993" viewBox="0 0 70.993 70.993">
                          <path id="Path_15" data-name="Path 15" d="M0,0H70.993V70.993H0Z" fill="none" />
                          <path id="Path_16" data-name="Path 16" d="M31.166,14.556V3H2V55H60.333V14.556Zm-17.5,34.668H7.833V43.446h5.833Zm0-11.556H7.833V31.89h5.833Zm0-11.556H7.833V20.334h5.833Zm0-11.556H7.833V8.778h5.833ZM25.333,49.225H19.5V43.446h5.833Zm0-11.556H19.5V31.89h5.833Zm0-11.556H19.5V20.334h5.833Zm0-11.556H19.5V8.778h5.833ZM54.5,49.225H31.166V43.446H37V37.668H31.166V31.89H37V26.112H31.166V20.334H54.5ZM48.666,26.112H42.833V31.89h5.833Zm0,11.556H42.833v5.778h5.833Z" transform="translate(4.33 6.495)" fill="#828282" />
                        </svg>
                      </span>
                    </div>
                    <h4 className={"card-title"}>Enterprise Plan</h4>
                    <p className='p_engagement'>Very suitable for enterprises to have unlimited users and VU hours with an on-premise option. With exclusive support, this plan works well for enterprises needing to have a dedicated performance testing environment/footprint</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </section>
        <section className={"page-section demo-section"}>
          <h2>See What’s Possible in Quantify</h2>
          <div className={"demobtns"}>
            <button onClick={() => toRoute()} className={"btn btn_primary"}>Request a Demo</button>
          </div>
        </section>
        <section className={"page-section"}>
          <div className={"quantify-wrapper"}>
            <div className={"section-title"}>
              <h2>Our customers</h2>
              <div className={"clients-wrap"}>
                <ul className={"clients-list"}>
                  {/* <li>
                    <img src={client1} alt='' />
                  </li> */}
                  <li>
                    <img src={client2} alt='' />
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </div>
      <Footerpublic />
    </>
  )
}

export default Quantify