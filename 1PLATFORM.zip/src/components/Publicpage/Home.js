import React, { useEffect, useState } from 'react'
import './publicpage.scss'
import { Link, useHistory } from 'react-router-dom'
import Headerpublic from './Headerpublic'
import Footerpublic from './Footerpublic'
import h_banner from '../../assets/images/op_public/home/hero_banner.png'
import oip from '../../assets/images/op_public/home/oip_1.png'
import p_image from '../../assets/images/op_public/home/platform_img.png'
import ben_1 from '../../assets/images/op_public/home/ben_1.svg'
import ben_2 from '../../assets/images/op_public/home/ben_2.svg'
import ben_3 from '../../assets/images/op_public/home/ben_3.svg'
import ben_4 from '../../assets/images/op_public/home/ben_4.svg'
import plat_1 from '../../assets/images/op_public/home/plat_1.png'
import plat_2 from '../../assets/images/op_public/home/plat_2.png'
import plat_3 from '../../assets/images/op_public/home/plat_3.png'
import client_1 from '../../assets/images/op_public/home/client_1.png'
import client_2 from '../../assets/images/op_public/home/client_2.png'
import { StrapiURL } from '../Common/APIPath'

import { Tab, Nav } from 'react-bootstrap'
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
const Home = () => {
    const history = useHistory();
    const toRoute = () => {
        history.push('/contact');
    }
    const [homeBanner, setHomeBanner] = useState([]);
    const [benefits, setBenefits] = useState([]);
    const [howItWorks, setHowItWorks] = useState([]);
    const [platformFeatures, setPlatformFeatures] = useState([]);
    const [whatisPlatformFor, setWhatIsPlatformFor] = useState([]);
    const [isImageOptimize, setImageOptimize] = useState(false);
    useEffect(() => {
        handleGeneralSettings();
        handleHomebanner();
        handleBenefits();
        handleHowItWorks();
        handlePlatformFeatures();
        handleWhatIsPlatformFor();
    }, [])

    const productData = []
    const oipList = []

    //General settings
    function handleGeneralSettings() {
        return fetch(StrapiURL + `/generals/1`)
            .then(data => data.json())
            .then((data) => {

                setImageOptimize(data.ImageCompressMode)


            },
                (error) => {

                }
            );
    }
    function optimizedImage(Image) {

        if (Image.formats && isImageOptimize) {
            if (Image.formats.large) {
                return Image.formats.large.url
            } else {
                return Image.url
            }
        } else {
            return Image.url
        }
    }

    function handleHomebanner() {
        return fetch(StrapiURL + `/home-banners/1`)
            .then(data => data.json())
            .then((data) => {

                let banner = []
                banner.push(data)
                setHomeBanner(banner)

            },
                (error) => {

                }
            );
    }

    function handleBenefits() {
        return fetch(StrapiURL + `/benefits`)
            .then(data => data.json())
            .then((data) => {

                let dataInput = data.slice().sort((a, b) => a.order - b.order);
                setBenefits(dataInput)

            },
                (error) => {

                }
            );
    }

    function handleHowItWorks() {
        return fetch(StrapiURL + `/home-how-it-works`)
            .then(data => data.json())
            .then((data) => {

                let dataInput = data.slice().sort((a, b) => a.order - b.order);
                setHowItWorks(dataInput)

            },
                (error) => {

                }
            );
    }


    function handlePlatformFeatures() {
        return fetch(StrapiURL + `/home-platform-features/1`)
            .then(data => data.json())
            .then((data) => {

                let platformFeatures1 = [];
                platformFeatures1.push(data)
                setPlatformFeatures(platformFeatures1)

            },
                (error) => {

                }
            );
    }

    function handleWhatIsPlatformFor() {
        return fetch(StrapiURL + `/home-who-is-1-platform-fors`)
            .then(data => data.json())
            .then((data) => {

                let dataInput = data.slice().sort((a, b) => a.order - b.order);
                setWhatIsPlatformFor(dataInput)
            },
                (error) => {

                }
            );
    }

    {
        howItWorks.filter(t => t.Tab === "OnePlatform").map((hRow, index) => {
            return productData.push({
                title: hRow.Title,
                content: hRow.Description_New,
                ProductURL: hRow.ProductURL,
                image: hRow.image ? StrapiURL + hRow.image.url : null,
            })
        })
    }
    {
        howItWorks.filter(t => t.Tab === "OpenInnovationPlatform").map((hRow, index) => {

            return oipList.push({
                title: hRow.Title,
                content: hRow.Description_New,
                ProductURL: hRow.ProductURL,
                image: hRow.image ? StrapiURL + hRow.image.url : null,
            })
        })
    }

    return (
        <>

            <Headerpublic />
            <div className='public_home'>
                <section className='herobanner'>
                    {
                        homeBanner.map((bannerrow, i) => {
                            return (
                                <div className="op-wrapper banner-wrapper">
                                    <div className='banner-caption'>
                                        <div className='hero_left'>
                                            <h1 className='hero_title'><ReactMarkdown rehypePlugins={[rehypeRaw]} children={bannerrow.Title} /></h1>
                                            <p><ReactMarkdown rehypePlugins={[rehypeRaw]} children={bannerrow.Description} /></p>
                                            <button onClick={() => toRoute()} className='btn btn_primary mt-5'>Request a Demo</button>
                                        </div>
                                    </div>
                                    <div className='banner-image'>
                                        <img src={StrapiURL + optimizedImage(bannerrow.BannerImage)} alt='heroimage' />
                                    </div>
                                </div>
                            )
                        })
                    }
                </section>
                <div className='body_section'>
                    <section className='page_section'>
                        <div className='op-wrapper'>
                            <div className='section_title'>Benefits</div>
                            <div className='row mt-3 px-4 g-3'>
                                {benefits && benefits.map((bfrow, index) => {

                                    return (
                                        <div className='col-lg-3 col-md-6 col-sm-12'>
                                            <div className='b_panel'>
                                                <div className='b_panel_image'>
                                                    <img src={StrapiURL + bfrow.Icon.url} alt='benimg' />
                                                </div>
                                                <div className='b_panel_content'>
                                                    <p><ReactMarkdown rehypePlugins={[rehypeRaw]} children={bfrow.Description} /></p>
                                                </div>
                                            </div>
                                        </div>
                                    )

                                })}
                                {/* <div className='col-lg-3 col-md-6 col-sm-12'>
                                    <div className='b_panel'>
                                        <div className='b_panel_image'>
                                            <img src={ben_2} alt='benimg' />
                                        </div>
                                        <div className='b_panel_content'>
                                            <p>SaaS platform with pay as you use model</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-lg-3 col-md-6 col-sm-12'>
                                    <div className='b_panel'>
                                        <div className='b_panel_image'>
                                            <img src={ben_3} alt='benimg' />
                                        </div>
                                        <div className='b_panel_content'>
                                            <p>Leveraging crowd and 1TX managed service for expertise.</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-lg-3 col-md-6 col-sm-12'>
                                    <div className='b_panel'>
                                        <div className='b_panel_image'>
                                            <img src={ben_4} alt='benimg' />
                                        </div>
                                        <div className='b_panel_content'>
                                            <p>Easy to use, script less interface with drag’n’drop functionality.</p>
                                        </div>
                                    </div>
                                </div> */}
                            </div>
                        </div>
                    </section>
                    <section className='page_section bg-white'>
                        <div className='container'>
                            <div className='section_title'>How it works</div>
                            <Tab.Container id="left-tabs-example" defaultActiveKey='oneplatform' unmountOnExit={true}>
                                <Tab.Content >
                                    <Tab.Pane eventKey="oneplatform">
                                        <div className='section_title_content px-3'>Our intuitive cloud-based platform streamlines your innovation at every stage, from setting up the environment to defining KPIs, inviting vendors, and comparing results. So, you can focus on decision-making instead of getting bogged down with details.</div>
                                    </Tab.Pane>
                                    <Tab.Pane eventKey="oip">
                                        <div className='section_title_content px-3'>Accelerate your innovation with the 1TX-OIP. Our game-changing cloud-based platform lets you refine problem statements, scout for vendors, evaluate proposals, carry out PoC testing and deployment, and simulate any type of S/W or API-based environment data and traffic flow.</div>
                                    </Tab.Pane>
                                </Tab.Content>

                                <div className='row mt-4 op_public_navtabs'>
                                    <div className='col-md-3 pt-4 op_public_navtabs_left'>
                                        <Nav className='d-block'>
                                            <Nav.Item><Nav.Link eventKey="oneplatform">One Platform <span className='float-end'><i class="bi bi-chevron-right"></i></span></Nav.Link></Nav.Item>
                                            <Nav.Item><Nav.Link eventKey="oip">Open Innovation Platform (OIP) <span className='float-end'><i class="bi bi-chevron-right"></i></span></Nav.Link></Nav.Item>
                                        </Nav>
                                    </div>
                                    <div className='col-md-9'>
                                        <div className='px-1'>
                                            <Tab.Content >
                                                <Tab.Pane eventKey="oneplatform">
                                                    <div className='row g-3 public_tab_content'>
                                                        {
                                                            productData.map((d, index) =>

                                                                <a className={productData.length < 5 ? 'col-md-6' : 'col-md-4'} key={index} href={d.ProductURL ? d.ProductURL : null} target={d.ProductURL ? '_blank' : null} style={{ cursor: d.ProductURL ? 'pointer' : 'default' }}>
                                                                    <div className='row card home_card p-2 g-2' style={{ minHeight: '102px' }}>
                                                                        <div className='col-3'>
                                                                            <img className='product-img' src={d.image} alt='imageplatform' />
                                                                        </div>
                                                                        <div className='col-9'>

                                                                            <h3><ReactMarkdown rehypePlugins={[rehypeRaw]} children={d.title} /></h3>
                                                                            <p className='my-2' title={d.content}><ReactMarkdown rehypePlugins={[rehypeRaw]} children={d.content} /></p>

                                                                        </div>
                                                                    </div>
                                                                </a>

                                                            )
                                                        }
                                                    </div>
                                                </Tab.Pane>
                                                <Tab.Pane eventKey="oip">
                                                    <div className='public_tab_content '>
                                                        <div className='row g-3 public_tab_content'>
                                                            {
                                                                oipList.map((d, index) =>
                                                                    <a className={oipList.length < 5 ? 'col-md-6' : 'col-md-4'} key={index} href={d.ProductURL ? d.ProductURL : null} target={d.ProductURL ? '_blank' : null} style={{ cursor: d.ProductURL ? 'pointer' : 'none' }}>
                                                                        <div className='row card home_card p-2 g-2' style={{ minHeight: '102px' }}>
                                                                            <div className='col-3'>
                                                                                <img className='product-img' src={d.image} alt='imageplatform' />
                                                                            </div>
                                                                            <div className='col-9'>

                                                                                <h3><ReactMarkdown rehypePlugins={[rehypeRaw]} children={d.title} /></h3>
                                                                                <p className='my-2' title={d.content}><ReactMarkdown rehypePlugins={[rehypeRaw]} children={d.content} /></p>

                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                )
                                                            }
                                                        </div>
                                                    </div>
                                                </Tab.Pane>
                                            </Tab.Content>
                                        </div>
                                    </div>
                                </div>
                            </Tab.Container>
                        </div>
                    </section>
                    {platformFeatures.map((platRow, i) => {
                        return (
                            <section className='page_section'>
                                <div className='section_title'>Platform Features</div>
                                <div className='container'>
                                    <div className='row align-items-center'>
                                        <div className='col-md-6'>
                                            <div className='platformFeatures'>
                                                <ReactMarkdown rehypePlugins={[rehypeRaw]} children={platRow.Description} />
                                            </div>
                                        </div>
                                        <div className='col-md-6'>
                                            <div className='platform_features_right'>
                                                <img src={StrapiURL + optimizedImage(platRow.Image)} alt='imageplatform' />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        )
                    })
                    }
                    <section className='page_section bg-white'>
                        <div className='op-wrapper'>
                            <div className='section_title'>Who is 1Platform for?</div>
                            <div className='row mt-0 g-3 g-lg-5'>
                                {
                                    whatisPlatformFor.map((row, i) => {

                                        return (
                                            <div className='col-lg-4 col-md-6'>
                                                <div className='s_panel'>
                                                    <div className='s_panel_image'>
                                                        <img src={StrapiURL + optimizedImage(row.Icon)} alt='platimage' />
                                                    </div>
                                                    <div className='s_panel_contentpanel'>
                                                        <h3><ReactMarkdown rehypePlugins={[rehypeRaw]} children={row.Title} /></h3>
                                                        <ReactMarkdown rehypePlugins={[rehypeRaw]} children={row.Description} />
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    })
                                }
                                {/* <div className='col-lg-4 col-md-6'>
                                    <div className='s_panel'>
                                        <div className='s_panel_image'>
                                            <img src={plat_1} alt='platimage' />
                                        </div>
                                        <div className='s_panel_contentpanel'>
                                            <h3>Businesses who want to:</h3>
                                            <ul>
                                                <li>Speed up innovation; use the 1Platform to design and develop a quick prototype and test it for functionality</li>
                                                <li>Performance benchmark software products</li>
                                                <li>Review code for quality and security before moving to production</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6'>
                                    <div className='s_panel'>
                                        <div className='s_panel_image'>
                                            <img src={plat_2} alt='platimage' />
                                        </div>
                                        <div className='s_panel_contentpanel'>
                                            <h3>Government, university & enterprise innovation labs who want to:</h3>
                                            <ul>
                                                <li>Empower collaboration between innovators and incubators, using the 1Platform as a key echo system</li>
                                                <li>Invite vendors from the marketplace to demonstrate and participate in the collaboration</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-lg-4 col-md-6'>
                                    <div className='s_panel'>
                                        <div className='s_panel_image'>
                                            <img src={plat_3} alt='platimage' />
                                        </div>
                                        <div className='s_panel_contentpanel'>
                                            <h3>Freelancers/Gigs who want to:</h3>
                                            <ul>
                                                <li>Find work in PoC and testing</li>
                                                <li>Access a remote workspace with dedicated tools and technologies</li>
                                                <li>Save time with one entry point to endless opportunities</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div> */}
                            </div>
                        </div>
                    </section>
                    <section className='page_section d-none'>
                        <div className='section_title'>Our Partners</div>
                        <ul className='client_list mt-4'>
                            <li>
                                <div className='client_panel'>
                                    <img src={client_1} alt='client' />
                                </div>
                            </li>
                            <li>
                                <div className='client_panel'>
                                    <img src={client_2} alt='client' />
                                </div>
                            </li>
                        </ul>
                    </section>
                </div>
            </div>
            <Footerpublic />
        </>
    )
}

export default Home