import React, { useEffect, useState } from 'react'
import './innerpages.scss'
import Headerpublic from './Headerpublic'
import Footerpublic from './Footerpublic'
import heroImage from '../../assets/images/op_public/img_2.png'
import { StrapiURL } from '../Common/APIPath'
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
const Privacy = () => {

    const [row, setRows] = useState([]);
    useEffect(() => {
        handleTerms();
    }, [])
    function handleTerms() {
        return fetch(StrapiURL + `/privacy-policies`)
            .then(data => data.json())
            .then((data) => {
                
                let dataInput = data.slice().sort((a, b) => a.order - b.order);
                setRows(dataInput)

            },
                (error) => {

                }
            );
    }


    return (
        <>
            <Headerpublic />
            <div className='op_bdy_panel'>
                <div className='qtfy_hero_container row px-lg-5 px-md-2'>
                    <div className='col-md-6'>
                        <div className='qtfy_hero_content_panel'>
                            <h1 className='hero_title'>Privacy policy</h1>
                        </div>
                    </div>
                    <div className='col-md-6'>
                        <div className='qtfy_hero_right'>
                            <img src={heroImage} alt='Image_right' />
                        </div>
                    </div>
                </div>
                <div className='qtfy_public_body'>
                    <div className='container py-3'>
                        <div className='row g-3'>
                            {
                                row.map((r, i) => {
                                    return (
                                        <>
                                            <div className='col-md-12'>
                                                {i == 0 ? <h1 className='qtfy_pg_title'> <ReactMarkdown rehypePlugins={[rehypeRaw]} children={r.Title} /></h1> : <div className='qtfy_paragraph_title'> <ReactMarkdown rehypePlugins={[rehypeRaw]} children={r.Title} /></div>}
                                            </div>
                                            <div className='col-md-12'>
                                                <p className='qtfy_paragraph mb-2'> <ReactMarkdown rehypePlugins={[rehypeRaw]} children={r.Description} /></p>

                                            </div>
                                        </>
                                    )
                                })
                            }
                        </div>
                    </div>
                </div>
            </div>
            <Footerpublic />
        </>
    )
}

export default Privacy