import React, { useState } from 'react'
import Headerpublic from './Headerpublic'
import Footerpublic from './Footerpublic'
import demoreg from '../../assets/images/op_public/demoreg.svg'
import './innerpages.scss'
import { saveDemoForm } from '../../endpoints/gateway'
const Contact = () => {

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastname] = useState("");
  const [email, setEmail] = useState("");
  const [comments, setComments] = useState("");
  const [message, setMessage] = useState("");

  const [firstNameError, setFirstNameError] = useState("");
  const [lastNameError, setLastnameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [commentsError, setCommentsError] = useState("");
  const [sccess, setSuccess] = useState(false);

  function ValidateEmail(myForm) {
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myForm)) {
      return (true)
    }
    return (false)
  }

  var isValid = function (value) {
    var re = /^[A-Za-z0-9']+$/;
    if (!re.test(value)) { return false; }
    if (value.length < 3) { return false; }
    // further tests could go here
    return true
  }

  var _isValid = function (value) {
    
    if (value.length < 10) { 
      return false; 
    }
    return true
  }

  var validChars = function (value) {
    var re = /^[A-Za-z0-9?!@#$%^&*~,./{}()<>|:;"' ']+$/;
    if (!re.test(value)) { 
      return false; 
    }
    return true
  }

  const handleSubmit = async () => {
    debugger

    if (firstName === "") {
      setFirstNameError("First Name is required");
      return;
    } else if (!isValid(firstName)) {
      setFirstNameError("First Name is invalid format");
    } else if (lastName === "") {
      setLastnameError("Last Name is required");
      return;
    } else if (!isValid(lastName)) {
      setLastnameError("Last Name is invalid format");
    } else if (email === "") {
      setEmailError("Email is required")
      return;
    } else if (!ValidateEmail(email)) {
      setEmailError("You have entered an invalid email address!")
      return;
    } else if (comments === "") {
      setCommentsError("questions is required")
      return;
    }

    var valid = validChars(comments);

    if(!validChars(comments)){
      setCommentsError("Enter valid specific needs or questions")
      return;
    }

    if (!_isValid(comments)) {
      setCommentsError("Comments must be more than 10 characters in length");
      return;
    } else {

      setFirstName("");
      setLastname("");
      setEmail("");
      setComments("");

    }

    let data = {
      "first_name": firstName,
      "last_name": lastName,
      "email": email,
      "comments": comments
    }

    try {
      let response = await saveDemoForm('https://djnv5g5nduiwq.cloudfront.net/1platformapi/api/user/public/demo_enquiry', 'POST', data);

      if (response.status === 200) {
        setMessage(response.data.message);
      } else {
        setMessage("Unable to send request, try again later.");
      }

    } catch (error) {

    } finally {
      setFirstName("");
      setLastname("");
      setEmail("");
      setComments("");
    }
  }

  return (
    <>
      <Headerpublic />
      <div className='op_bdy_panel'>
        <div className='qtfy_hero_container row px-lg-5 px-md-2'>
          <div className='col-md-12'>
            <div className='qtfy_hero_content_panel d-flex align-items-center justify-content-center'>
              <div className='demoReg_hero_panel text-center'>
                {/* <h1 className='demoreg_title_content'>We will <span className='demoreg_title'>get in touch with you</span> </h1> */}
                <h1 className='demoreg_title_content'>Plan a demo with our Technical experts <span className='demoreg_title'></span> </h1>
              </div>
            </div>
          </div>
        </div>
        <div className='qtfy_public_body'>
          <div className='container py-4'>
            <div className='row align-items-center mt-5'>
              <div className='col-md-6 d-lg-block d-none'>
                <div className='regdemo_imagePanel'>
                  <img src={demoreg} alt='demoimage' className='w-100' />
                </div>
              </div>
              <div className='col-lg-6 col-sm-12'>
                <div className='demoReg_form_panel'>
                  {sccess ? <h1 className='text-success'>Successfully Send </h1> : ''}

                  <h3 className='demoReg_form_panel_title'>Submit your contact information, and we will reach out to you as soon as possible.</h3>
                  <form className='mt-2 row g-3' onSubmit={() => handleSubmit()}>
                    <div className='col-md-6'>
                      <div className='op_input_block my-1'>
                        <label className='form-label'>First Name</label>
                        <input className='form-control' type='text' value={firstName} onChange={(e) => { setFirstName(e.target.value); setFirstNameError(""); }} required />
                        {firstNameError !== "" && <p className='input_error_msg'>{firstNameError}</p>}
                      </div>
                    </div>
                    <div className='col-md-6'>
                      <div className='op_input_block my-1'>
                        <label className='form-label'>Last Name</label>
                        <input className='form-control' type='text' value={lastName} onChange={(e) => { setLastname(e.target.value); setLastnameError(""); }} required />
                        {lastNameError !== "" && <p className='input_error_msg'>{lastNameError}</p>}
                      </div>
                    </div>
                    <div className='col-md-12'>
                      <div className='op_input_block my-1'>
                        <label className='form-label'>Email ID</label>
                        <input className='form-control' type='email' value={email} onChange={(e) => { setEmail(e.target.value); setEmailError(""); }} />
                        {emailError !== "" && <p className='input_error_msg'>{emailError}</p>}
                      </div>
                    </div>
                    {/* <div className='col-md-12'>
                      <div className='op_input_block my-1'>
                        <label className='form-label'>Phone Number</label>
                        <input className='form-control' type='text' />
                      </div>
                    </div>
                    <div className='col-md-12'>
                      <div className='op_input_block my-1'>
                        <label className='form-label'>Country</label>
                        <select class="form-select" aria-label="Default select example">
                          <option selected> India </option>
                          <option value="1">Singapore</option>
                          <option value="2">Europe</option>
                          <option value="3">United States</option>
                        </select>
                      </div>
                    </div> */}
                    <div className='col-md-12'>
                      <div className='op_input_block my-1'>
                        <label className='form-label'>Specific needs or questions?</label>
                        <input className='form-control' type='text' value={comments} onChange={(e) => { setComments(e.target.value); setCommentsError(""); }} required />
                        {commentsError !== "" && <p className='input_error_msg'>{commentsError}</p>}
                      </div>
                    </div>
                    <div className='col-md-12 text-center'>
                      <button type="button" onClick={() => handleSubmit()} className='btn btn_primary rounded-pill mt-2 w-50'>Submit</button>
                    </div>
                    <p>{message !== "" && message}</p>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footerpublic />
    </>
  )
}

export default Contact