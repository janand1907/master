import React, { useEffect, useState } from 'react'
import { Link, useHistory } from 'react-router-dom'
import banner from '../../assets/images/op_public/service/service_ban.png';
import ben_1 from '../../assets/images/op_public/home/ben_1.svg'
import ben_3 from '../../assets/images/op_public/home/ben_3.svg'
import ben_4 from '../../assets/images/op_public/home/ben_4.svg'
import cap_1 from '../../assets/images/op_public/capablities/1.png'
import cap_2 from '../../assets/images/op_public/capablities/2.png'
import cap_3 from '../../assets/images/op_public/capablities/3.png'
import cap_4 from '../../assets/images/op_public/capablities/4.png'
import cap_5 from '../../assets/images/op_public/capablities/5.png'
import cap_6 from '../../assets/images/op_public/capablities/6.png'

import './service.scss'
import Headerpublic from './Headerpublic'
import Footerpublic from './Footerpublic'
import { Tab, Nav } from 'react-bootstrap'
import { StrapiURL } from '../Common/APIPath'
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
const Service = () => {
  const history = useHistory();
  const toRoute = () => {
    history.push(`/contact`);
  }

  //CMS integration
  const [serviceBanner, setServiceBanner] = useState([]);
  const [block, set3Block] = useState([]);
  const [benefits, setBenefits] = useState([]);
  const [howItWorks, setHowItWorks] = useState([]);
  const [platformFeatures, setPlatformFeatures] = useState([]);
  const [whatisPlatformFor, setWhatIsPlatformFor] = useState([]);
  const [isImageOptimize, setImageOptimize] = useState(false);
  useEffect(() => {
    handleGeneralSettings();
    handleServicebanner();
    handle3Block();
    handleBenefits();
  }, [])



  //General settings
  function handleGeneralSettings() {
    return fetch(StrapiURL + `/generals/1`)
      .then(data => data.json())
      .then((data) => {

        setImageOptimize(data.ImageCompressMode)


      },
        (error) => {

        }
      );
  }
  function optimizedImage(Image) {

    if (Image.formats && isImageOptimize) {
      if (Image.formats.large) {
        return Image.formats.large.url
      } else {
        return Image.url
      }
    } else {
      return Image.url
    }
  }

  function handleServicebanner() {
    return fetch(StrapiURL + `/service-banners/1`)
      .then(data => data.json())
      .then((data) => {

        let banner = []
        banner.push(data)
        setServiceBanner(banner)

      },
        (error) => {

        }
      );
  }

  function handle3Block() {
    return fetch(StrapiURL + `/service-3-blocks`)
      .then(data => data.json())
      .then((data) => {

        let dataInput = data.slice().sort((a, b) => a.order - b.order);
        set3Block(dataInput)

      },
        (error) => {

        }
      );
  }

  function handleBenefits() {
    return fetch(StrapiURL + `/service-benefits`)
      .then(data => data.json())
      .then((data) => {

        let dataInput = data.slice().sort((a, b) => a.order - b.order);
        setBenefits(dataInput)

      },
        (error) => {

        }
      );
  }
  //-

  const callBackFunction = (category) => {
    switch (category) {
      case "Capabilities":
        return (
          <div className={"quantify-wrapper py-4"}>
            <div className='section-title'>
              <h2>Capabilities</h2>
            </div>
            <div className='row my-3 g-4'>
              <div className='col-lg-3 col-md-6 col-sm-12'>
                <div className='b_panel'>
                  <div className='b_panel_image'>
                    <img src={cap_1} alt='benimg' className='w-75' />
                  </div>
                  <div className='b_panel_content'>
                    <h3 className='cap'>Create new PoCs</h3>
                    <p>Define your goals, KPIs, evaluation criteria, instructions, and more.</p>
                  </div>
                </div>
              </div>
              <div className='col-lg-3 col-md-6 col-sm-12'>
                <div className='b_panel'>
                  <div className='b_panel_image'>
                    <img src={cap_2} alt='benimg' className='w-75' />
                  </div>
                  <div className='b_panel_content'>
                    <h3 className='cap'>Configure your environments for each PoC</h3>
                    <p>Simulate production by populating it with servers, data, APIs, and network activity.</p>
                  </div>
                </div>
              </div>
              <div className='col-lg-3 col-md-6 col-sm-12'>
                <div className='b_panel'>
                  <div className='b_panel_image'>
                    <img src={cap_3} alt='benimg' className='w-75' />
                  </div>
                  <div className='b_panel_content'>
                    <h3 className='cap'>Compare and evaluate different solutions</h3>
                    <p>By measuring against your KPIs in the dashboard and reports.</p>
                  </div>
                </div>
              </div>
              <div className='col-lg-3 col-md-6 col-sm-12'>
                <div className='b_panel'>
                  <div className='b_panel_image'>
                    <img src={cap_4} alt='benimg' className='w-75' />
                  </div>
                  <div className='b_panel_content'>
                    <h3 className='cap'>Stay safe with Red Cloud and SafeZone</h3>
                    <p>Execute complex cyber-attacks on the cloud with Redcloud and integrate new software on legacy systems with SafeZone.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )
        break;
      case "Automation":
        return (
          <>
            <div className={"quantify-wrapper py-4"}>
              <div className='section-title'>
                <h3>Features</h3>
              </div>
              <div className='row my-3 g-4'>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_5} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>Self-service SaaS portal to create and execute tests and access test data</p>
                    </div>
                  </div>
                </div>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_2} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>1TX Fully Managed end-to-end test service capabilities for customers</p>
                    </div>
                  </div>
                </div>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_3} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>On-demand automated test labs for conducting both functional and non-functional testing.</p>
                    </div>
                  </div>
                </div>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_6} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>Automation platform that includes DevOps tools and continuous implementation/delivery (CI/CD)</p>
                    </div>
                  </div>
                </div>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_4} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>Rigorous governance, testing, QA, reporting, trends, analytics, continuous improvement</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='container'>
              <h3>Types of Testing</h3>
              <p></p>
              <div className='row mt-5 justify-content-around'>
                <div className='col-lg-3 col-md-4'>
                  <ul className='service_list_test'>
                    <li>Testing Consulting Advisory Service</li>
                    <li>Core testing Service</li>
                    <li>Quality engineering service</li>
                    <li>Digital assurance</li>
                    <li>DW/BI Testing</li>
                    <li>Security engineering</li>
                  </ul>
                </div>
                <div className='col-lg-3 col-md-4'>
                  <ul className='service_list_test'>
                    <li>Robotic process automation</li>
                    <li>Security testing</li>
                    <li>Specialised testing</li>
                    <li>Testing automation</li>
                    <li>Test management</li>
                  </ul>
                </div>
              </div>
            </div>
          </>
        )
        break;
      case "Features":
        return (
          <>
            <div className={"quantify-wrapper py-4"}>
              <div className='section-title'>
                <h3>Features</h3>
              </div>
              <div className='row my-3 g-4'>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_5} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>Intelligent <br /> Automation</p>
                    </div>
                  </div>
                </div>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_2} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>Robotic Process <br /> Automation</p>
                    </div>
                  </div>
                </div>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_3} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>Operations & Services <br /> Automation</p>
                    </div>
                  </div>
                </div>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_6} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>Testing <br /> Automation</p>
                    </div>
                  </div>
                </div>
                <div className='col-lg col-md-6 col-sm-12'>
                  <div className='b_panel'>
                    <div className='b_panel_image'>
                      <img src={cap_4} alt='benimg' className='w-75' />
                    </div>
                    <div className='b_panel_content'>
                      <p>Expert guidance <br /> and support</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='container'>
              <h3>Who we can help</h3>
              <p>1TX services span the entire innovation lifecycle. We’ve got the technology and expertise support innovation in most sectors.</p>
              <div className='row mt-5 justify-content-around'>
                <div className='col-lg-3 col-md-4'>
                  <ul className='service_list_test'>
                    <li>Human resources </li>
                    <li>IT </li>
                    <li>Procurement</li>
                    <li>Banking</li>
                    <li>Financial Services</li>
                  </ul>
                </div>
                <div className='col-lg-3 col-md-4'>
                  <ul className='service_list_test'>
                    <li>Hospitality</li>
                    <li>Insurance Industries</li>
                    <li>Retail</li>
                    <li>Manufacturing</li>
                    <li>Communications</li>
                  </ul>
                </div>
                <div className='col-lg-3 col-md-4'>
                  <ul className='service_list_test'>
                    <li>Media</li>
                    <li>High-Tech</li>
                    <li>Healthcare and life sciences</li>
                    <li>Energy and utility</li>
                    <li>Transportation and logistics</li>
                  </ul>
                </div>
              </div>
            </div>
          </>
        )
        break;
      default:
        break;
    }

  }


  return (
    <>
      <Headerpublic />
      <div className='qtfy_services'>
        <section className={"herobanner"}>
          {
            serviceBanner.map((bannerrow, i) => {
              return (
                <div className={"quantify-wrapper banner-wrapper"}>
                  <div className={"banner-caption"}>
                    <h1><ReactMarkdown rehypePlugins={[rehypeRaw]} children={bannerrow.Title} /></h1>
                    <p><ReactMarkdown rehypePlugins={[rehypeRaw]} children={bannerrow.Description} /></p>
                  </div>
                  <div className={"banner-image"}>
                    <img src={StrapiURL + optimizedImage(bannerrow.Image)} alt='heroimage' />
                  </div>
                </div>
              )
            })
          }
        </section>
        <section className='bg-white'>
          <div className={"quantify-wrapper py-4"}>
            <div className='row my-3 g-3'>

              {block && block.map((bRow, i) => {
                return (
                  <div className='col-lg-4 col-md-6 col-sm-12'>
                    <div className='b_panel'>
                      <div className='b_panel_image'>
                        <img src={StrapiURL + bRow.Icon.url} alt='benimg' />
                      </div>
                      <div className='b_panel_content'>
                        <h3><ReactMarkdown rehypePlugins={[rehypeRaw]} children={bRow.Title} /></h3>
                        <p><ReactMarkdown rehypePlugins={[rehypeRaw]} children={bRow.Description} /></p>
                      </div>
                    </div>
                  </div>
                )
              })}

              {/* <div className='col-lg-4 col-md-6 col-sm-12'>
                <div className='b_panel'>
                  <div className='b_panel_image'>
                    <img src={ben_3} alt='benimg' />
                  </div>
                  <div className='b_panel_content'>
                    <h3>Testing</h3>
                    <p>Testing made simple with 1TX. Customisable, predictable, cost-effective testing solutions.</p>
                  </div>
                </div>
              </div>
              <div className='col-lg-4 col-md-6 col-sm-12'>
                <div className='b_panel'>
                  <div className='b_panel_image'>
                    <img src={ben_4} alt='benimg' />
                  </div>
                  <div className='b_panel_content'>
                    <h3>Automation</h3>
                    <p>Automate your workforce with 1TX. Build, manage and scale your business.</p>
                  </div>
                </div>
              </div> */}
            </div>
          </div>
        </section>
        <Tab.Container id="left-tabs-example" defaultActiveKey='InnovationAsAService' unmountOnExit={true}>
          <section>
            <div className="quantify-wrapper py-4">

              <Nav className='justify-content-center'>
                <Nav.Item><Nav.Link eventKey="InnovationAsAService">Innovation as a Service</Nav.Link></Nav.Item>
                <Nav.Item><Nav.Link eventKey="TestingAsAService">Testing as a Service</Nav.Link></Nav.Item>
                <Nav.Item><Nav.Link eventKey="AutomationAsAService">Automation as a Service</Nav.Link></Nav.Item>
              </Nav>
              <div className='tab_container'>
                <Tab.Content>
                  {benefits && benefits.map((tbr, i) => {

                    return (
                      <Tab.Pane eventKey={tbr.Tab}>
                        <h3><ReactMarkdown rehypePlugins={[rehypeRaw]} children={tbr.TopTitle} /></h3>
                        <p><ReactMarkdown rehypePlugins={[rehypeRaw]} children={tbr.Description} /></p>
                        <div className='container'>
                          <h3>{tbr.BenefitTitle}</h3>
                          <div className='row mt-4 benifits_container'>
                            <div className='col-lg-12 mx-auto'>
                              <div className='d-flex justify-content-between flex-wrap'>
                                <ul className='service_list service_list_width'>
                                  <ReactMarkdown rehypePlugins={[rehypeRaw]} children={tbr.BenefitBlock1Description} />
                                </ul>
                                <ul className='service_list service_list_width'>
                                  <ReactMarkdown rehypePlugins={[rehypeRaw]} children={tbr.BenefitBlock2Description} />
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                        {
                          callBackFunction(tbr.Category)
                        }

                      </Tab.Pane>
                    )

                  })}
                </Tab.Content>
              </div>
            </div>
          </section>
          <section>

          </section>
        </Tab.Container>
      </div>
      <Footerpublic />
    </>
  )
}

export default Service