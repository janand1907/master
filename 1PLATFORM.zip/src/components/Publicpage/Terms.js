import React, { useEffect, useState } from 'react'
import './innerpages.scss'
import Headerpublic from './Headerpublic'
import Footerpublic from './Footerpublic'
import heroImage from '../../assets/images/op_public/img_1.png'
import { StrapiURL } from '../Common/APIPath';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
const Terms = () => {

    const [row, setRows] = useState([]);
    useEffect(() => {
        handleTerms();
    }, [])
    function handleTerms() {
        return fetch(StrapiURL + `/terms-and-conditions`)
            .then(data => data.json())
            .then((data) => {
                
                let dataInput = data.slice().sort((a, b) => a.order- b.order);
                setRows(dataInput)

            },
                (error) => {

                }
            );
    }
    return (
        <>
            <Headerpublic />
            <div className='op_bdy_panel'>
                <div className='qtfy_hero_container row px-lg-5 px-md-2'>
                    <div className='col-md-6'>
                        <div className='qtfy_hero_content_panel'>
                            <h1 className='hero_title'>Terms and Conditions</h1>
                        </div>
                    </div>
                    <div className='col-md-6'>
                        <div className='qtfy_hero_right'>
                            <img src={heroImage} alt='Image_right' />
                        </div>
                    </div>
                </div>
                <div className='qtfy_public_body'>
                    <div className='container py-3'>
                        <div className='row g-3'>                            
                            {
                                row.map((r,i)=>{
                                    return (
                                        <>
                                            <div className='col-md-12'>
                                                {i==0? <h1 className='qtfy_pg_title'> <ReactMarkdown rehypePlugins={[rehypeRaw]} children={r.Title} /></h1>: <div className='qtfy_paragraph_title'> <ReactMarkdown rehypePlugins={[rehypeRaw]} children={r.Title} /></div>}
                                            </div>
                                            <div className='col-md-12'>
                                                <p className='qtfy_paragraph mb-2'> <ReactMarkdown rehypePlugins={[rehypeRaw]} children={r.Description} /></p>
                                               
                                            </div>
                                        </>
                                    ) 
                                })
                            }
                            {/* <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>User account</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>Users must complete the registration process and create a user account in order to use the Platform and Services offered (respectively, the “Registered Users” and the “Account”). Users will be required to provide us basic information upon registration,
                                    including but not limited to a user name, passwords, phone number, email and the name of your company or entity. If you deploy the Service through AWS you will be required to provide us with a link to your current AWS server which you wish 1TX to use so as to provide the Service.
                                    Additionally, you shall undergo a certain certification and authentication process, during which we may request additional information. Your cooperation with the authentication and certification is a condition to the right to use our Services and the access granted under these Terms.
                                    The initial user registering his Account shall be automatically designated as the sole account administrator (the “Admin”). The Admin may authorize, subject to our approval, additional Users to access the Account in order to use the Services under this Agreement as provided therein (“Authorized Users”).
                                    The Admin shall be responsible to manage the Authorized Users and shall be liable for any act or omission by such Authorized Users with respect to the Services under this Agreement. Authorized Users shall agree individually to the terms of this Agreement and shall be named and receive a personal login and password which should be maintained securely by the Admin from unauthorized use and may not be shared.
                                    If the Admin wishes to add Authorized Users, additional fees may be required as set forth in the Order Form. Once the Account has a designated Admin no other Authorized User shall be permitted to register as an administrator. Once you set up the Account, you may create a POC, you may choose to set the setting for such POC as “public”, which will allow all POC Partners to view and apply to participate in your POC, or as “private”, which will allow only the POC Partners you invite to view or apply to participate in your POC. In creating the POC you may be asked to provide information including but not limited to a description of the POC, the POC environment, and instructions to POC Partners. After completing the process for creating the POC, You may publish the POC on the Platform. You may accept or reject any application by any POC Partner and may interact with POC Partners, via the Platform messaging system, in your sole discretion. You acknowledge and agree that any and all interaction between you and any POC Partner through the Services under this Agreement or otherwise is at your own risk. We are not liable or responsible for any agreement, breach or undertaking by or between you and any POC Partner.</p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Fees and usage limits</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    Access to our Platform and Services is subject to certain Subscription fees. For more information regarding our Subscription fees when registering through the Website or by use of an off-line Order Form and payment information please contact us at Sales@1TX.io. If you are accessing the service through the AWS Market Place fees and payment shall be done through the AWS system and fees and terms may differ from those offered through our Website. In addition by registering and using the Service through AWS, additional AWS terms may apply and you should consult the AWS Terms and Conditions and Privacy Policy in order to determine if and to the extent these apply to you. Services may be subject to certain limitations as per the terms of your subscription. If you exceed your allocated usage limits under your Subscription terms, we reserve the right to charge the applicable fees for Services used in excess of your usage limits in accordance with the rated prescribed under the Order Form.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Warranties</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    Here are some commitments we make to you. We warrant that during an applicable Subscription term as indicated under your Order Form (a) the Services shall perform in all material respects with the Order Form, technical specification and Documentation , (b) We will use commercially reasonable efforts to maintain the Services in accordance with industry standards and subject to the Order Form and Documentation (c) We will not knowingly transmit Malicious Code to You, and (d) We have the requisite technical and professional knowledge, know-how, expertise, skills, talent and experience required in order to perform the Services in a professional and efficient manner. For any breach of a warranty above, your exclusive remedy shall be to cease using the Services. As our Services are web-based and require access to the internet any unavailability caused by circumstances beyond Our reasonable control, including without limitation, acts of God, acts of government, Internet service provider failures or delays, or denial of service attacks may occur.
                                </p>
                                <p className='qtfy_paragraph mb-2'>
                                    Here are some commitments you make to us. You warrant that during an applicable Subscription term as indicated under your Order Form, you (a) have the required corporate and legal authority to bind your company or such other legal entity which you represent to these terms and any payment obligations; (b) you are the rightful owner of any proprietary data, datasets and any user generated content (the “Content”) you upload to the Platform or that you have (and will continue to have) all the necessary licenses, rights, consents, and permissions from the licensors of such Content to use such content and enable inclusion and use as contemplated by these terms and that such Content does not infringe any third party’s intellectual property, privacy, publicity or other rights; (c) provide us with continuous access to one or more of your testing environments as established on our cloud server maintain your testing environments as established on our cloud server online and operational while using the Services, (d) be responsible for the accuracy, quality and legality of your Content and of the Data, (e) use commercially reasonable efforts to prevent unauthorized access to or use of your Testing Environment or the Services, and notify us promptly of any such unauthorized access or use thereto; and (f) perform at least one POC during any 6 month period so long as you are signed up for the Services. Furthermore, you authorize us to host, copy, transmit, display and adapt your Content, as necessary for us to provide the Services in accordance with the Agreement. Please note that we retain the information we collect for as long as needed to provide the Services under this Agreement and to comply with our legal obligations, resolve disputes and enforce our agreements
                                </p>
                                <p className='qtfy_paragraph mb-2'>
                                    <span className='qtfy_paragraph_title'>Restrictions:</span>
                                    During the applicable Subscription term as indicated under your Order Form, you (b) may not make available or use the Platform or any Services under this Agreement for the benefit of any third party, unless otherwise stated in the Agreement or Documentation; (c) may not sell, resell, license, sublicense, distribute, make available, rent or lease any Services under this Agreement, or exploit such Services for any commercial purposes; (d) may not use any Services under this Agreement, or any Third Party Services, to store or transmit any illegal, immoral, unlawful and/or unauthorized materials, or interfere with or violate users’ rights to privacy and other rights, or harvest or collect personally identifiable information about Users without their express consent; (e) may not use any Services under this Agreement, or any Third Party Services, to transmit or otherwise make available any malicious code, including any virus, worm, trojan horse, time bomb, web bug, spyware, or any other computer code, file, or program unless expressly detailed and determined to the contrary with respect to any POC (e.g. a POC which is conducted for the purpose of Cyber Security); (f) may not interfere with or disrupt the integrity, performance or operation of the Website, Platform or Services under this Agreement, or any part thereof, including any servers or networks provided by Third Party Service Providers; (g) may not attempt to gain unauthorized access to the POC Partner’s proprietary software or information or their related systems or networks for any purpose and shall not simulate or derive any source code or algorithms from the POC Partner or use any of the foregoing to create any software or service which shall infringe the POC Partner’s rights; (h) may not attempt to gain unauthorized access or bypass any measures imposed to prevent or restrict access to the Website, Platform or any Services under this Agreement; (i) may not use or take any direct or indirect action that imposes or circumvents a contractual usage limit, in such a manner as to put an unreasonable or disproportionately large load on our infrastructure; (j) may not copy, modify, distribute, create derivative works, translate, port, reverse engineer, decompile, or disassemble any portion of the Services under this Agreement, or any material that is subject to our proprietary rights, including without limitation for non-internal or commercial purpose, unless expressly permitted in the Agreement, the Documentation or under applicable laws, and shall not simulate or derive any source code or algorithms from the Services under this Agreement or use any of the foregoing to create any software or service similar to the Services under this Agreement; and (k) may not misrepresent or impersonate any person or entity, or falsely state your affiliation, or express, imply that we endorse you in any manner, or represent or distribute inaccurate information about the Services under this Agreement. Any breach of the terms under this Agreement or the Documentation by you or your Authorized Users, as shall be determined in our sole discretion, may result in the immediate suspension or termination of your Account. Notwithstanding the foregoing, we will provide you with reasonable notice and an opportunity to remedy any actual or threatened violation of the terms under this Agreement.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Confidentiality</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    “Confidential Information” shall mean all information disclosed by a party (a “Disclosing Party”) to the other party (a “Receiving Party”), during the term of the Subscription as indicated under an Order Form, including certain non-public proprietary, confidential and/or trade secret information or data, regardless of the manner in which it is furnished, which given the totality of the circumstances, a reasonable person or entity should have reason to believe is proprietary, confidential, or competitively sensitive. Your Confidential Information includes the Content; the POC Partners’ Confidential Information includes their POC; Our Confidential Information includes the Services and Data provided in respect therewith. Confidential Information shall exclude any information that (i) is now or subsequently becomes generally available in the public domain through no fault or breach on your part; (ii) the Receiving Party can demonstrate in your records to have had rightfully in your possession prior to disclosure of the Confidential Information; (iii) the Receiving Party rightfully obtained from a third party who has the right to transfer or disclose it, without default or breach of these Terms; (iv) the Receiving Party can demonstrate in its records to have independently developed, without breach of these Terms and/or any use of or reference to the Confidential Information. The Receiving Party agrees: (a) not to disclose the Confidential Information it may obtain to any third parties other than to its directors, officers, employees, advisors, subcontractors, service providers or consultants (collectively, the “Representatives”) on a strict “need to know” basis only, for the purpose of fulfilling its obligations under these Terms; (b) not to use, disclose or reproduce any of the Confidential Information for any purposes except to carry out your rights and responsibilities under these Terms; (c) to keep the Confidential Information confidential using at least the same degree of care the Receiving Party uses to protect your own confidential information, which shall in any event be no less than a reasonable degree of care. Notwithstanding the foregoing, if the Receiving Party is required by legal process or any applicable law, rule or regulation, to disclose any of Confidential Information, it may do so to the minimum extent required to meet its legal obligation. Notwithstanding the above, Confidential Information may be disclosed pursuant to the order or requirement of a court, administrative agency, or other governmental body; provided, that Receiving Party shall make the best effort to provide prompt notice of such court order or requirement to Disclosing Party, to enable Disclosing Party to seek a protective order or otherwise prevent or restrict such disclosure. It is hereby agreed and clarified that your undertakings pursuant to this paragraph with respect to POC Partners are for the sole benefit of the POC Partner and that we shall have no liability whatsoever with respect to any breach of such undertakings by you. We strongly encourage POC Partners and users to execute a separate NDA or other written agreement in addition to these Terms if they so choose.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Proprietary rights</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    Subject to the limited license rights expressly granted hereunder, we and our licensors and third-party providers, as may be applicable, reserve all rights, title and interest in and to the Services under this Agreement, including all related intellectual property rights. No rights are granted to you hereunder other than as expressly set forth herein. LICENSE Subject to payment of all applicable fees detailed under an applicable Order Form, We hereby grant the following licenses as may be applicable pursuant to the Subscription terms under an Order Form: (i) with respect to Subscription to the Standard Services, a non-exclusive, revocable, non-sublicensable, non-transferable worldwide and limited right and license to access and use the Standard, solely for the purpose of seeking opportunities with POC Partners, provided such Users fully comply with all of the terms herein (the “Subscription License”); (ii) with respect to Subscription to Premium Services, a non-exclusive, revocable, non-sublicensable, non-transferable worldwide and limited right and license to access and use the Premium Services solely for the propose of developing and implementing POCs with POC Partners, provided such Users fully comply with all of the Terms herein (the “Premium License”). You hereby grant us a worldwide, limited license for the term under your Subscription to host, copy transmit, and display your proprietary information and any software, applications or code created by you using a Service, or used in connection therewith, as reasonably necessary for us to provide the Services in accordance with these Terms and your Subscription (the “License”). Under the License, you hereby further grant us permission to allow Third-Party Service providers to access your Confidential Information, Content, as may be required for implementation and integration of the Services under these Terms, pending your written approval. Subject to the limited rights granted by you hereunder, we acquire no right, title or interest from you under this Agreement in or to your Content, or any of your intellectual property rights. Additionally, You hereby grant to us a royalty-free, worldwide, irrevocable, perpetual license to use and incorporate into any Services under this Agreement any suggestions, requests for enhancements, recommendations or corrections (the “Feedback”) provided by you relating to existing features or addition of new features and capabilities to any Services under this Agreement.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Open source</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    The Services under this Agreement may include the use of certain third-party components, including open-source software components (“Third Party Components”). Your use and access to the Services under this Agreement are subject to any obligation of acknowledgment and other license terms governing the use, modification and distribution of such Third Party Components. If there is a conflict between the licensing terms of Third Party Components and the terms under this Agreement, the licensing terms of such third parties providing the Third Party Components shall prevail. Third-Party Components are provided AS-IS, without any warranty, express or implied. To see the open-source licenses we use please click here.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Disclaimer</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    EXCEPT AS EXPRESSLY PROVIDED HEREIN, WE PROVIDE THE SERVICES UNDER THIS AGREEMENT TO YOU “AS IS” AND NEITHER PARTY MAKES ANY WARRANTIES OF ANY KIND, WHETHER EXPRESS, IMPLIED, STATUTORY OR OTHERWISE. EXCEPT AS EXPRESSLY PROVIDED HEREIN, EACH PARTY SPECIFICALLY DISCLAIMS ALL IMPLIED WARRANTIES, INCLUDING ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR ANY WARRANTIES REGARDING THE SECURITY, RELIABILITY, TIMELINESS, ACCURACY AND PERFORMANCE OF THE SERVICES UNDER THIS AGREEMENT TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW. NOTWITHSTANDING ANYTHING TO THE CONTRARY HEREIN, WE DO NOT WARRANT THAT THE SERVICES UNDER THIS AGREEMENT WILL BE PROVIDED UNINTERRUPTED OR ERROR-FREE OR THAT IT SHALL MEET YOUR REQUIREMENTS.
                                </p>
                                <p className='qtfy_paragraph mb-2'>
                                    You acknowledge the electronic nature of the Services under this Agreement to be provided hereunder and the inherent risk that communications by electronic means may not reach their intended destination or may do so much later than intended for reasons outside our control. You further acknowledge that we are not responsible for performance issues caused by low-performance end-user computers, low-bandwidth end-user Internet connections, periodic network congestion among network providers, and low-bandwidth connectivity from the redirected image and video sources, improperly configured campaigns, and low-bandwidth connectivity from any servers, which are beyond our reasonable control. Furthermore, we do not screen, survey or vet the POC Partner who registers to the Services, therefore We can neither assure the successful completion of any POC nor verify the competence, suitability or credibility of any POC Partner and/or POC Partner’s technology or solutions.
                                </p>
                                <p className='qtfy_paragraph mb-2'>
                                    You understand that (i) no content published on the Platform, or through the Services under this Agreement, constitutes a recommendation or opinion with respect to any particular POC Partner or its suitability for any specific POC; (ii) We, to the fullest extent permitted under law, hereby disclaim all, representations or warranties of any kind, express or implied, as to the availability, operation and use of the Platform or the information, content, materials or Services on or accessed via the Platform, including but not limited to warranties of merchantability, fitness for a particular purpose, title, non-infringement; (iii) we may provide rankings of certain POC Partners based on an algorithm which is a subjective algorithm chosen by Us, in our sole discretion; (v) our ranking depends on public information which may be inaccurate, wrong, outdated, partial or incomplete; (vi) our ranking system may be subject to errors and interruptions; (vii) the results and rankings provided by the Us may be wrong, inaccurate, outdated, partial or incomplete or do not fit for a particular purpose and do not take into account any of your or the POC Partner’s investment objectives, financial situation, or means.
                                </p>
                                <p className='qtfy_paragraph mb-2'>
                                    Please note that we do not permit other enterprise users to view any POC’s offered by you. However, in no event shall we be liable in any manner or for any cause of action, claim, or damages resulting from any enterprise receiving information, viewing or otherwise learning of the POC’s offered by you by any other means, including by gaining access to another party’s account.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Indemnification</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    We shall defend you, your assignees, agents, employees, officers and directors against any claim, demand, suit, or proceeding made or brought against You by a third party alleging that any Services under the Agreement infringe or misappropriate the intellectual property rights of a third party (a “Claim Against You“), and shall indemnify you for any damages, attorney fees and costs finally awarded against you as a result of, and for amounts paid by you under a court-approved settlement of, a Claim Against You; provided that you (a) promptly give us written notice of the Claim Against You; (b) give us sole control of the defense and settlement of the Claim Against You (provided that We may not settle any Claim Against You unless the settlement unconditionally releases You of all liability); and (c) provide to us all reasonable assistance, at our expense. In the event of a Claim Against You, or if we reasonably believe any of the Services under this Agreement may infringe or misappropriate, we may in our discretion and at no cost to you (i) modify such Services so that they no longer infringe or misappropriate or (ii) obtain a license for your continued use of such Services in accordance with the terms of this Agreement.
                                </p>
                                <p className='qtfy_paragraph mb-2'>
                                    You shall defend us, our assignees, agents, employees, officers and directors against any claim, demand, suit or proceeding made or brought against us by a third party (a) alleging that your use of the Services in accordance with these Terms, infringes or misappropriates the intellectual property rights of any party or violates applicable law as a result of your Content, the Data or your Testing Environment; (b) dispute relating to a interaction between you and a POC Partner (a “Claim Against Us“), and shall indemnify us for any damages, attorney fees and costs finally awarded against us as a result of, or for any amounts paid by us under a court-approved settlement of, a Claim Against Us; provided that we (a) promptly give you written notice of the Claim Against Us; (b) give you sole control of the defense and settlement of the Claim Against Us (provided that you may not settle any Claim Against Us unless the settlement unconditionally releases us of all liability); and (c) provide to you all reasonable assistance, at your expense.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Limitation of liability</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    EXCEPT IN THE EVENT OF 1TX’S BREACH OF CONFIDENTIALITY, NEITHER PARTY SHALL HAVE ANY LIABILITY FOR ANY INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL DAMAGES, LOST PROFITS, LOST BUSINESS OPPORTUNITIES OR LOST DATA WITH RESPECT TO THIS AGREEMENT, PLATFORM OR THE SERVICES, WHETHER OR NOT EITHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES REGARDLESS OF THE BASIS FOR LIABILITY OF ANY SUCH CLAIM (WHETHER BASED ON AGREEMENT, TORT (INCLUDING NEGLIGENCE), BREACH OF STATUTORY DUTY OR OTHERWISE). EXCEPT WITH RESPECT TO YOUR PAYMENT OBLIGATIONS, INDEMNIFICATION OBLIGATIONS, BREACH OF CONFIDENTIALITY OBLIGATIONS, FRAUD OR WILLFUL MISCONDUCT, THE MAXIMUM AGGREGATE LIABILITY OF EITHER PARTY IN CONNECTION WITH THIS AGREEMENT SHALL NOT EXCEED THE AMOUNTS PAID FOR THE SERVICES IN THE TWELVE (12) MONTHS PRECEDING THE EVENT THAT GAVE RISE TO SUCH LIABILITY CLAIM. THE MAXIMUM AGGREGATE LIABILITY FOR YOUR INTELLECTUAL PROPERTY INDEMNIFICATION OBLIGATIONS SHALL NOT EXCEED THE AMOUNT PAID FOR THE SERVICES IN THE TWELVE (12) MONTHS PRECEDING THE EVENT THAT GAVE RISE TO SUCH LIABILITY CLAIM.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Term and termination</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    These Terms enter into effect on the date you accept them and remain in effect until your Subscription has expired or have been terminated by either party in accordance with these Terms. If you wish to terminate this Agreement you may do so at any time for any reason or without reason by ceasing use of your Account. Deleting your Account can only be done by sending an email directly to support@1tx.io with a specific request which will require us to authenticate the request with you as an authorized representative. Thereafter you shall not be able to use any of the Services until you renew your registration to the Platform. Canceling your Account may cause the loss of certain information you provided us and/or the capacity of your Account. We do not accept any liability for such loss. Termination of this agreement shall not relieve you of your obligations to pay amounts accrued or owing, nor affect any legal rights or obligations which may have arisen under these terms prior to or at the date of termination. We may terminate, limit or suspend your access to all or any part of your Account under this Agreement if you have breached these Terms, with prior written notice, of 14 days, provided you have not remedied the breach during that period. We may terminate, limit or suspend your access to all or any part of your Account under this without cause, by written notice to you, and the termination will enter into effect at the later of: (a) fourteen days from the written notice to you; and (b) your completion of any then-current POC you have running on the Platform, if any. Any such termination by us may result in the destruction of all information and data associated with your use of Services under this Agreement.
                                </p>
                                <p className='qtfy_paragraph mb-2'>
                                    Upon termination of your Account: (i) the Standard License or the Premium License, as may be applicable, and all other rights granted to you hereunder will automatically terminate, (ii) you must immediately cease all use of the Services under this Agreement, delete and destroy all copies of Confidential Information in your possession or control. All Sections which by their nature are meant to survive, shall survive termination of this Agreement.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Trademarks</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    You permit us to use your name and trademark for presenting you on our Website, among other things, in order for us to provide the Services under this Agreement. 1TX and its affiliates may use Client’s name and logo to identify Client as a customer of the 1TX Services. Any use shall be subject to compliance with guidelines that Client may deliver to 1TX from time-to-time regarding the use of its name and logo. This consent terminates upon termination of the Services.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Governing law</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    These Terms are governed and shall be construed in accordance with the laws of the State of Israel. The parties will attempt to resolve any dispute out of or relating to these Terms through friendly negotiations amongst the parties. If the matter is not resolved by negotiation, the parties agree that the courts in Tel Aviv shall have the exclusive rights and jurisdiction to hear and resolve any dispute arising under or in connection with these Terms.
                                </p>
                            </div>
                            <div className='col-md-12'>
                                <div className='qtfy_paragraph_title'>Precedence</div>
                            </div>
                            <div className='col-md-12'>
                                <p className='qtfy_paragraph mb-2'>
                                    In the event of conflict or inconsistency among the following documents, the order of precedence shall be: (i) These Terms; (ii) Any Documentation; and (iii) Any Order Form.
                                </p>
                                <p className='qtfy_paragraph mb-2'>
                                    These Terms may be modified or amended in writing by mutual agreement between the parties if the writing is signed by the party obligated under the amendment.
                                </p>
                            </div> */}
                        </div>
                    </div>
                </div>
            </div>
            <Footerpublic />
        </>
    )
}

export default Terms