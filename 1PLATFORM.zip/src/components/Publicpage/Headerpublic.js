import React, { useEffect, useState } from 'react'
import './headerfoot.scss'
import oip from '../../assets/images/op_public/home/oip_1.png'
import platformLogo from '../../assets/images/op_public/logo.png'
import { Link, NavLink, useHistory } from 'react-router-dom'
import { Dropdown, Tab, Nav } from 'react-bootstrap'
import Offcanvas from 'react-bootstrap/Offcanvas';
import { StrapiURL } from '../Common/APIPath';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';

const Headerpublic = () => {

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [products, setProducts] = useState(false);
  const [productList, setProductList] = useState([]);
  const showProducts = () => { setProducts(isOpened => !isOpened); }
  const history = useHistory();
  const toReg = () => {
    history.push(`/register`);
  }
  const toLogin = () => {
    history.push(`/login`);
  }
  useEffect(() => {
    handleProductList();
  }, [])

  function handleProductList() {
    return fetch(StrapiURL + `/home-how-it-works`)
      .then(data => data.json())
      .then((data) => {

        let dataInput = data.slice().sort((a, b) => a.order - b.order);
        setProductList(dataInput)

      },
        (error) => {

        }
      );
  }
  const list1 = []
  const list2 = []
  const list3 = []
  // const list1 = [
  //   { productname: 'Proof of Concept', description: 'The 1TX proof-of-concept platform gives you full control over your PoC', link: '/' },
  //   { productname: 'Quantify', description: 'Quantify is a performance tool for load, endurance, stress, and soak testing. Develop,', link: '/quantify' },
  //   { productname: 'QA Code', description: 'QA Code helps in conducting quality and security code review of the application.', link: '/' },
  //   { productname: 'QA Virtualisation', description: 'QA Virtualisation makes it easy for developers and testers to do service virtualization,', link: '/' },
  //   { productname: 'BPM Cartridges', description: 'Domain accelerators really help in testing the implementation of packaged solutions.', link: '/' },
  // ]
  // const list2 = [
  //   { productname: 'Quantum', description: 'Quantum is a web-based application designed to fulfil customer test automation', link: '/' },
  //   { productname: 'Qualia', description: 'Qualia lets you predict and identify potential failures by breaking things on purpose.', link: '/' },
  //   { productname: 'Quotient', description: 'Quotient end-user monitoring allows support and business team to monitor various.', link: '/' },
  //   { productname: 'Quintet', description: 'Quintet helps to Value stream everything in the software delivery lifecycle (SDLC)', link: '/' },

  // ]

  // const list3 = [
  //   { productname: 'Quadrant', description: 'Quadrant provides a central portal for test environment management', link: '/' },
  //   { productname: 'Quorum', description: 'Quorum helps in complete test data management that creates, manages', link: '/' },
  //   { productname: 'Cyber Predictor', description: 'Cyber Predictor helps in security testing the applications by simulating attacks.', link: '/' },
  //   { productname: 'QA Testbox', description: 'QA testbox will help harnesses the power of the crowd for testing your application.', link: '/' },

  // ]


  const onePlatfList = []

  try {
    productList.filter(c => c.Tab === "OnePlatform").map((OIPRow, i) => {
      return onePlatfList.push({
        productname: OIPRow.Title,
        description: OIPRow.Description_New,
        url: OIPRow.ProductURL,
        image: OIPRow.image ? StrapiURL + OIPRow.image.url : null,
      })
    })
  } catch (error) {


  }


  {
    try {
      productList.filter(c => c.Tab === "OnePlatform").slice(0, 4).map((row1, i) => {
        return list1.push({
          productname: row1.Title,
          description: row1.Description_New,
          url: row1.ProductURL,
          image: row1.image ? StrapiURL + row1.image.url : null,
        })
      })
    } catch (error) {

    }

    try {
      productList.filter(c => c.Tab === "OnePlatform").slice(5, 9).map((row2, i) => {
        return list2.push({
          productname: row2.Title,
          description: row2.Description_New,
          url: row2.ProductURL,
          image: row2.image ? StrapiURL + row2.image.url : null,
        })
      })
    } catch (error) {

    }

    try {
      productList.filter(c => c.Tab === "OnePlatform").slice(10, 14).map((row3, i) => {
        return list3.push({
          productname: row3.Title,
          description: row3.Description_New,
          url: row3.ProductURL,
          image: row3.image ? StrapiURL + row3.image.url : null,
        })
      })
    } catch (error) {

    }

  }
  const oipList = []
  // const oipList = [
  //   { productname: 'Challenges', description: 'Multi-disciplinary research capabilities to develop practical, impactful challenges' },
  //   { productname: 'Problem Owners', description: 'SMEs, Enterprises, Government agencies' },
  //   { productname: 'Supporting Tools', description: 'Supported by a structured innovation process and physical innovation facility from ideation to commercialisation' },
  //   { productname: 'Solutions', description: 'Structured evaluation and scoring of Solutions' },
  //   { productname: 'Problem Solvers', description: 'Tech innovators, Start-ups, Companies, Researchers' },
  //   { productname: 'Technology and Marketing Enablers', description: 'Facilitating translation, commercialisation and scaling up of new soulutions' },
  // ]

  try {
    productList.filter(c => c.Tab === "OpenInnovationPlatform").map((OIPRow, i) => {
      return oipList.push({
        productname: OIPRow.Title,
        description: OIPRow.Description_New,
        url: OIPRow.ProductURL,
        image: OIPRow.image ? StrapiURL + OIPRow.image.url : null,
      })
    })
  } catch (error) {

  }

  return (
    <>
      <header className='oneplatform_header'>
        <div className='container-fluid px-4 py-3'>
          <div className='oneplatform_header_panel'>
            <div className='header_left'>
              <div className='logo_section'>
                <NavLink to='/home'><img src={platformLogo} alt='logo' /></NavLink>
              </div>
              <button className='btn btn_light d-block d-md-none' onClick={handleShow}><i class="bi bi-list"></i></button>
              <Offcanvas show={show} onHide={handleClose}>
                <Offcanvas.Header closeButton>
                  <Offcanvas.Title>
                    <div className='logo_section_mobile'>
                      <img src={platformLogo} alt='logo' />
                    </div>
                  </Offcanvas.Title>
                </Offcanvas.Header>
                <Offcanvas.Body className='p-0'>
                  <div className='offcanvas_menu'>
                    <ul className='public_navbar'>
                      <li onClick={showProducts}>
                        Products
                        <span className='ms-3'><i class={`bi ${products ? 'bi-chevron-up' : 'bi-chevron-down'}`}></i></span>
                      </li>
                      {products &&
                        <>
                          <li>
                            <div className='op_megamenu'>
                              <Tab.Container id="left-tabs-example" defaultActiveKey='oneplatform' unmountOnExit={true}>
                                <Nav className='justify-content-center'>
                                  <Nav.Item className='w-50'><Nav.Link eventKey="oneplatform">1Platform Products</Nav.Link></Nav.Item>
                                  <Nav.Item className='w-50'><Nav.Link eventKey="oip">OIP - Products</Nav.Link></Nav.Item>
                                </Nav>
                                <Tab.Content className='py-3' >
                                  <Tab.Pane eventKey="oneplatform">
                                    <div className='row g-3'>
                                      {
                                        onePlatfList.map((data, index) =>
                                          <a className='col-md-4' key={index} href={data.url ? data.url : null} target={data.url ? '_blank' : null} style={{ cursor: data.url ? 'pointer' : 'none' }}>
                                            <ul className='product_block'>
                                              <li className='product_block_item' >
                                                <div>
                                                  <img className='product-img' src={data.image} alt='imageplatform' />
                                                </div>
                                                <div>
                                                  <h3>{data.productname}</h3>
                                                  <p className='my-2' title={data.description}><ReactMarkdown rehypePlugins={[rehypeRaw]} children={data.description} /></p>
                                                </div>
                                              </li>
                                            </ul>
                                          </a>
                                        )
                                      }
                                    </div>
                                  </Tab.Pane>

                                  <Tab.Pane eventKey="oip">
                                    <div className='row g-3'>
                                      {
                                        oipList.map((data, index) =>
                                          <a className='col-md-45' key={index} href={data.url ? data.url : null} target={data.url ? '_blank' : null} style={{ cursor: data.url ? 'pointer' : 'none' }}>
                                            <ul className='product_block'>
                                              <li className='product_block_item' >
                                                <div>
                                                  <img className='product-img' src={data.image} alt='imageplatform' />
                                                </div>
                                                <div>
                                                  <h3>{data.productname}</h3>
                                                  <p className='my-2' title={data.description}><ReactMarkdown rehypePlugins={[rehypeRaw]} children={data.description} /></p>
                                                </div>
                                              </li>
                                            </ul>
                                          </a>
                                        )
                                      }
                                    </div>
                                  </Tab.Pane>
                                </Tab.Content>
                              </Tab.Container>
                            </div>
                          </li>
                        </>
                      }
                      <li><NavLink className='nav-item' to='/service'>Services</NavLink></li>
                      <li><NavLink className='nav-item' to='/contact'>Contact Us</NavLink>  </li>
                      <li>
                        <button className='btn btn_outline w-100 my-1' onClick={() => toReg()}>Create an Account</button>
                        <button className='btn btn_primary w-100 my-1' onClick={() => toLogin()}>Sign In</button>
                      </li>
                    </ul>
                  </div>
                </Offcanvas.Body>
              </Offcanvas>
              <div className='public_nav_section d-none d-md-block'>
                <ul className='public_navbar'>
                  <li>
                    <Dropdown>
                      <Dropdown.Toggle className="nav-link nav-item count-indicator d-flex align-items-center">
                        Products <span className='ms-2'><i class="bi bi-chevron-down"></i></span>
                      </Dropdown.Toggle>
                      <Dropdown.Menu className="dropdown-menu shadow profile_drawer navbar-dropdown">
                        <div className='op_megamenu'>
                          <Tab.Container id="left-tabs-example" defaultActiveKey='oneplatform' unmountOnExit={true}>
                            <Nav className='justify-content-center'>
                              <Nav.Item className='w-50'><Nav.Link eventKey="oneplatform">1Platform Products</Nav.Link></Nav.Item>
                              <Nav.Item className='w-50'><Nav.Link eventKey="oip">OIP - Products</Nav.Link></Nav.Item>
                            </Nav>
                            <Tab.Content className='px-3 py-3' >
                              <Tab.Pane eventKey="oneplatform">
                                <div className='mx-3 py-2'>
                                  <div className='row'>
                                    {
                                      onePlatfList.map((data, index) =>
                                        <a className={onePlatfList.length < 5 ? "col-md-6" : "col-md-4"} key={index} href={data.url ? data.url : null} target={data.url ? '_blank' : null} style={{ cursor: data.url ? 'pointer' : 'default' }}>
                                          <ul className='product_block'>
                                            <li className='product_block_item' >
                                              <div>
                                                <img className='product-img' src={data.image} alt='imageplatform' />
                                              </div>
                                              <div>
                                                <h3>{data.productname}</h3>
                                                <p className='my-2' title={data.description}><ReactMarkdown rehypePlugins={[rehypeRaw]} children={data.description} /></p>
                                              </div>
                                            </li>
                                          </ul>
                                        </a>
                                      )
                                    }
                                  </div>
                                </div>
                              </Tab.Pane>
                              <Tab.Pane eventKey="oip">
                                <div className='mx-3 py-2'>
                                  <div className='row'>
                                    {
                                      oipList.map((data, index) =>
                                        <a className={oipList.length < 5 ? "col-md-6" : "col-md-4"} key={index} href={data.url ? data.url : null} target={data.url ? '_blank' : null} style={{ cursor: data.url ? 'pointer' : 'default' }}>
                                          <ul className='product_block'>
                                            <li className='product_block_item' >
                                              <div>
                                                <img className='product-img' src={data.image} alt='imageplatform' />
                                              </div>
                                              <div>
                                                <h3>{data.productname}</h3>
                                                <p className='my-2' title={data.description}><ReactMarkdown rehypePlugins={[rehypeRaw]} children={data.description} /></p>
                                              </div>
                                            </li>
                                          </ul>
                                        </a>
                                      )
                                    }
                                  </div>
                                </div>
                              </Tab.Pane>
                            </Tab.Content>
                          </Tab.Container>
                        </div>
                      </Dropdown.Menu>
                    </Dropdown>
                  </li>
                  <li><NavLink className='nav-item' to='/service'>Services</NavLink></li>
                  <li><NavLink className='nav-item' to='/contact'>Contact Us</NavLink>  </li>
                </ul>
              </div>
            </div>
            <div className='header_right d-none d-md-flex'>
              <button className='btn btn_outline' onClick={() => toReg()}>Create an Account</button>
              <button className='btn btn_primary mediumBtn' onClick={() => toLogin()}>Sign In</button>
            </div>
          </div>
        </div>
      </header>
    </>
  )
}

export default Headerpublic