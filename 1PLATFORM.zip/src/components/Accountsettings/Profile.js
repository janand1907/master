import React from 'react'
import './Profile.scss'
import {useHistory } from "react-router-dom";
import ProfileSettings from './Settings/ProfileSettings'
import { backBtnIcon } from '../../Icons/icons';
const Profile = () => {
    const history = useHistory();
  return (
    <div className='profile_page'>
        <div className="mt-2 custom-head-card">
            <div className='d-flex align-items-center gap-2'>
                {/* <button type="button" onClick={() => history.goBack()} className="btn btn_light">{backBtnIcon}</button> */}
                <div className='h3'>Account Setup</div>
            </div>
        </div>
        <ProfileSettings />
    </div>
  )
}

export default Profile