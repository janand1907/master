import React, { useEffect, useState, useRef } from 'react'
import './ProfileSettings.scss'
import ProfilePic from '../../../assets/images/profile/noPic.png';
import { useDispatch, useSelector } from 'react-redux';
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { OverlayTrigger, Popover, Dropdown, Tab, Nav } from 'react-bootstrap';
import PhoneInput, {
    getCountryCallingCode, isValidPhoneNumber
} from "react-phone-number-input";
import "react-phone-number-input/style.css";
import { toast } from 'react-toastify';
import {
    Link, useHistory
} from "react-router-dom";
import personalIcon from '../../../assets/images/other/personal.svg'
import lockIcon from '../../../assets/images/other/lock.svg'
import cameraIcon from '../../../assets/images/other/camera_add.svg'
import orgIcon from '../../../assets/images/other/organization.svg'
import infoIcon from '../../../assets/images/other/infoIcon.svg'
import eyeIcon from '../../../assets/images/other/input/eye.svg'
import eyeOffIcon from '../../../assets/images/other/input/eye_off.svg'
import { getUserDetails, uploadFiles, updateUser, updatePassword } from '../../../endpoints/gateway'
import Organization from '../../gateway/Organization';
const ProfileSettings = () => {

    /*profile update*/
    const ref = useRef();
    const history = useHistory();
    const personalSchema = Yup.object().shape({
        first_name: Yup.string().required('First Name is required').min(3, "First Name must be at least 3 characters").max(30, "First Name must be at most 30 characters").matches(/^[A-Za-z]+$/i, 'Only Alpha Character Accepted'),
        last_name: Yup.string().required('Last Name is required').min(3, "Last Name must be at least 3 characters").max(30, "Last Name must be at most 30 characters").matches(/^[A-Za-z]+$/i, 'Only Alpha Character Accepted'),
        //jobTitle: Yup.string().required('Job title is required'),
    });


    const userDetails = useSelector(state => state.user.userInfo.allInfo);
    const [loguserDetails, setloguserDetails] = useState(userDetails)

    useEffect(() => {
        getLoggeduser()
    }, [])

    const getLoggeduser = async () => {
        let userEmail = {
            "userEmail": userDetails.email
        }
        let response = await getUserDetails(userEmail)
        setloguserDetails(response.data)
    }

    const { register,
        handleSubmit, setValue,
        formState: { errors, isValid }, control, reset } = useForm({
            resolver: yupResolver(personalSchema), mode: 'onChange'
        });




    // const [logoerror, setlogoerror] = useState(false)
    const [logoformaterror, setlogoformaterror] = useState(false)
    const [selectedLogo, setselectedLogo] = useState();
    const [islogoPicked, setislogoPicked] = useState(false);
    const [logoUploadResponse, setlogoUploadResponse] = useState();
    const [file, setFile] = useState(ProfilePic);

    const imageValidation = (file) => {
        const fileType = file['type'];
        const validImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/jpg'];
        if (!validImageTypes.includes(fileType)) {
            return false
        }
        return true
    }

    const changeImageHandler = async (event) => {
        // setlogoerror(false)
        setlogoformaterror(false)
        if (imageValidation(event.target.files[0])) {
            setselectedLogo(event.target.files[0])
            setislogoPicked(true)
            setFile(URL.createObjectURL(event.target.files[0]));
            uploadLogo(event.target.files[0]);
        } else {
            ref.current.value = "";
            setlogoformaterror(true);
            setselectedLogo('')
            setislogoPicked(false)
        }
    }

    const uploadLogo = async (file) => {
        const formData = new FormData();
        formData.append('file', file);
        let response = await uploadFiles(formData)
        setlogoUploadResponse(response.data);
        if (response.data.message) {
            toast.success(response.data.message);
        }
        // await fetch(`${process.env.REACT_APP_TESTCASEMANAGEMENT}/api/attachment/uploadfiles`,
        //     {
        //         method: 'POST',
        //         body: formData,
        //         headers: {
        //             "Authorization": `${userDetails.accessToken}`,
        //         },
        //     }
        // )
        //     .then((response) => response.json())
        //     .then((result) => {
        //         setlogoUploadResponse(result);
        //         if (result.message) {
        //             toast.error(result.message);
        //         }
        //     })
        //     .catch((error) => {
        //         toast.error(error);
        //     });
    };

    useEffect(() => {
        try {

            if (loguserDetails?.logo_url !== null) {
                setFile(`${process.env.REACT_APP_AUTH_URL_APP}${loguserDetails?.logo_url}`)
            }
            
            const fields = ['first_name', 'last_name', 'jobTitle', 'email', 'phone_number'];
            fields.forEach(field => setValue(field, loguserDetails[field]));
        } catch (error) {

        }

    }, [loguserDetails])
    const [phoneCountryCode, phoneCountryCodeSetter] = React.useState("DE");

    const onSubmit = async (data) => {
        
        // data.userId = loguserDetails.email
        // data.countyCode = parseInt(getCountryCallingCode(phoneCountryCode))
        // let cc = "+" + getCountryCallingCode(phoneCountryCode);
        // if (data.phoneNo)
        //     data.phoneNo = parseInt(data.phoneNo.substring(cc.length))
        // if (!islogoPicked) {
        //     data.userProfile = loguserDetails.userProfile
        // }
        // else {
        //     data.userProfile = logoUploadResponse[0].attachmentid;
        // }
        let datanew = {
            first_name: data.first_name,
            last_name: data.last_name,
            phone_number: data.phone_number
        }

        let response = await updateUser(datanew);
       
        toast.success("User Details Updated Successfully");
        getLoggeduser()

        // await fetch(`https://dtlehta1thuw9.cloudfront.net/auth/api/auth/updateUser`, {
        //     method: 'PUT',
        //     body: JSON.stringify(data),
        //     headers: {
        //         "Content-Type": "application/json",
        //         "Authorization": `${userDetails.accessToken}`
        //     },
        // })
        //     .then(response => response.json())
        //     .then((data) => {
        //         toast.success("User Details Updated Successfully");
        //         
        //         getLoggeduser()
        //     })
    }

    /*profile update*/

    /*password update*/

    const [viewPassword, setViewPassword] = useState(true);
    const [oldviewPassword, setoldViewPassword] = useState(true);
    const [viewconfirmPassword, setViewconfirmPassword] = useState(true);

    const passwordSchema = Yup.object().shape({
        // Old password field validation
        oldpassword: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Current Password is required')),
        password: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Password is required'))
            .matches(
                /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{12,18}$/,
                "Password must be at least 12 to 18 characters long with upper and lower case, number with special case character"
                // Password must be at least 12 to 18 characters long with upper and lower case, number with special case character
            ),
        repassword: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Confirm Password is required'))
            .oneOf([Yup.ref('password')], 'Password does not match'),
    });
    const { register: passRegister,
        handleSubmit: passSubmit, setValue: passSetvalue,
        formState: { errors: passError, isValid: passisValis }, control: passControl, reset: passReset } = useForm({
            resolver: yupResolver(passwordSchema), mode: 'onChange'
        });

    const oldpasswordviewChange = () => {
        setoldViewPassword(!oldviewPassword);
    }
    const passwordviewChange = () => {
        setViewPassword(!viewPassword);
    }

    const passwordviewconfirmChange = () => {
        setViewconfirmPassword(!viewconfirmPassword);
    }


    const passonSubmit = async (data) => {

        let details = {
            oldPassword: data.oldpassword,
            password: data.password,
            userName: userDetails.userName,
        }

        let response = await updatePassword(details);
        
        if (response?.status === 200) {
            passReset();
            toast.success(response.data.message);
        } else {
            toast.error(response.response.data.message);
        }

        //passReset();
        // await fetch(`http://dtlehta1thuw9.cloudfront.net/auth/api/auth/updatePassword`, {
        //     method: 'POST',
        //     body: JSON.stringify(details),
        //     headers: {
        //         "Content-Type": "application/json",
        //         "Authorization": `${userDetails.accessToken}`
        //     },
        // })
        //     .then(response => response.json())
        //     .then((data) => {
        //         toast.success(data.msg);
        //         passReset();
        //       
        //     })
        //
    }
    /*password update*/

    const passwordPopover = (
        <Popover id="popover-basic">
            <div className='passwordtearms'>
                <p>Password Must be: </p>
                <ul>
                    <li>At least 12 to 18 characters long</li>
                    <li>Should contain upper case and lower case</li>
                    <li>Should contain a numbers with special character</li>
                </ul>
            </div>
        </Popover>
    );


    return (
        <div className='profileSetting'>
            <Tab.Container id="left-tabs-example" defaultActiveKey='personalInfo' unmountOnExit={true}>
                <div className='row g-3 my-5'>
                    <div className='col-md-3'>
                        <div className='card op_card'>
                            <div className='card-body '>
                                <div className='profile_update'>
                                    <div className='profile_picture_layout shadow-sm'>
                                        <img src={file} className='profilePicture' alt='' />
                                        <div className='profile_update_layout'>
                                            <button className='btn profile_update_btn'> <img src={cameraIcon} alt='' /> </button>
                                            <input accept="image/png, image/gif, image/jpeg, image/jpg" name="file" className='customfileinput' type="file" ref={ref} onChange={changeImageHandler} />
                                        </div>
                                        <br />

                                        {
                                            logoformaterror &&
                                            <span className='upload_content' style={{ color: '#FF4E00' }}>
                                                Invalid Format. Please upload image format
                                            </span>
                                        }

                                    </div>
                                    <div className='user_details_block text-center'>
                                        <h3>{userDetails.firstname} {userDetails.lastname}</h3>
                                        <p>{userDetails.email}</p>
                                    </div>
                                </div>
                                <div className='card-body px-0'>
                                        <Nav className='profile_nav'>
                                            <Nav.Item><Nav.Link eventKey="personalInfo"> <span className='me-2'><img src={personalIcon} alt='' /></span> Personal Information</Nav.Link></Nav.Item>
                                            <Nav.Item><Nav.Link eventKey="passwordUpdate"><span className='me-2'><img src={lockIcon} alt='' /></span>Password</Nav.Link></Nav.Item>
                                            {/* <Nav.Item><Nav.Link eventKey="orgInfo"><span className='me-2'><img src={orgIcon} alt=''/></span>Organization</Nav.Link></Nav.Item> */}
                                        </Nav>
                                    </div>    
                            </div>
                        </div>
                        
                    </div>
                    <div className='col-md'>
                        <div className='card op_card'>
                            <div className='card-body'>
                                <Tab.Content className='px-3 py-3' >
                                    <Tab.Pane eventKey="personalInfo">
                                        <form className="profile_update" onSubmit={handleSubmit(onSubmit)}>
                                            <div className='row my-2 px-4'>
                                                <div className='col-md-6'>
                                                    <div className='op_input_block'>
                                                        <label className="form-label">First Name <span className="text-danger">*</span></label>
                                                        <input type="text" {...register("first_name", { required: true })} className={`form-control ${errors.first_name ? 'invalid' : ''}`} id="first_name" aria-describedby="first_name" />
                                                        <span className="input_error_msg">{errors.first_name?.message}</span>
                                                    </div>
                                                </div>
                                                <div className='col-md-6'>
                                                    <div className='op_input_block'>
                                                        <label className="form-label">Last Name <span className="text-danger">*</span></label>
                                                        <input type="text" {...register("last_name", { required: true })} className={`form-control ${errors.last_name ? 'invalid' : ''}`} id="last_name" aria-describedby="last_name" />
                                                        <span className="input_error_msg">{errors.last_name?.message}</span>
                                                    </div>
                                                </div>  
                                                <div className='col-md-6'>
                                                    <div className='op_input_block'>
                                                        <label className="form-label">Email ID <span className="text-danger">*</span></label>
                                                        <input disabled type="text" {...register("email")} className={`form-control ${errors.email ? 'invalid' : ''}`} id="email" aria-describedby="email" />
                                                    </div>
                                                </div>                
                                                {/* <div className='col-md-6'>
                                                    <div className='op_input_block'>
                                                        <label className="form-label">Job tile <span className="text-danger">*</span> </label>
                                                        <input type="text" {...register("jobTitle")} className={`form-control ${errors.jobTitle ? 'invalid' : ''}`} id="jobTitle" aria-describedby="jobTitle" />
                                                        <span className='input_error_msg'>{errors.jobTitle?.message}</span>
                                                    </div>
                                                </div> */}
                                                <div className='col-md-6'>
                                                    <div className='op_input_block'>
                                                        <label className="form-label">Phone Number</label>
                                                        <Controller
                                                            name="phone_number"
                                                            control={control}
                                                            render={({ field }) => (
                                                                <PhoneInput
                                                                    {...field}
                                                                    className="form-control d-flex gap-2"
                                                                    onCountryChange={(v) => phoneCountryCodeSetter(v)}
                                                                    limitMaxLength={true}
                                                                    international={false}
                                                                    defaultCountry="SG"
                                                                    addInternationalOption={false}
                                                                />
                                                            )}
                                                        />
                                                    </div>
                                                </div>
                                                <div className='col-md-12 text-center my-5'>
                                                    <button type='submit' className='btn px-4 mx-3 btn_primary'>Submit</button>
                                                </div>
                                            </div>
                                        </form>
                                    </Tab.Pane>
                                    <Tab.Pane eventKey="passwordUpdate">
                                        <form onSubmit={passSubmit(passonSubmit)} className='py-3 profile_update mx-auto passwordWrapper'>
                                            <div className='row'>
                                                {/* Old password field */}
                                                <div className='col-sm-12'>
                                                    <div className='op_input_block'>
                                                        <div className="passwordInput">
                                                            <label for="exampleFormControlInput1" class="form-label">Current Password <span className="text-danger">*</span></label>
                                                            <div className='position-relative'>
                                                                <input type={oldviewPassword ? 'password' : 'text'} {...passRegister("oldpassword", { required: true })} className={`form-control ${errors.oldpassword ? 'invalid' : ''}`} id="InputPassword" />
                                                                <span className="icon-view" onClick={oldpasswordviewChange}>
                                                                    {oldviewPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <span className="input_error_msg ">{passError.oldpassword?.message}</span>
                                                    </div>
                                                </div>
                                                <div className='col-sm-12'>
                                                    <div className='op_input_block'>
                                                        <div className="passwordInput">
                                                            <label for="exampleFormControlInput1" class="form-label">New Password <span className="text-danger">*</span></label>
                                                            <span className='ms-2'>
                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={passwordPopover}>
                                                                    <button className='btn p-0' type='button' style={{ width: '.875rem' }}> <img src={infoIcon} alt='' className='w-100' /> </button>
                                                                </OverlayTrigger>
                                                            </span>
                                                            <div className='position-relative'>
                                                                <input type={viewPassword ? 'password' : 'text'} {...passRegister("password", { required: true })} className={`form-control ${errors.password ? 'invalid' : ''}`} id="InputPassword" />
                                                                <span className="icon-view" onClick={passwordviewChange}>
                                                                    {viewPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <span className="input_error_msg">{passError.password?.message}</span>
                                                    </div>
                                                </div>
                                                <div className='col-sm-12'>
                                                    <div className='op_input_block'>
                                                        <div className="passwordInput">
                                                            <label for="exampleFormControlInput1" class="form-label">Confirm Password <span className="text-danger">*</span></label>
                                                            <span className='ms-2'>
                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={passwordPopover}>
                                                                    <button className='btn p-0' type='button' style={{ width: '.875rem' }}><img src={infoIcon} alt='' className='w-100' /></button>
                                                                </OverlayTrigger>
                                                            </span>
                                                            <div className='position-relative'>
                                                                <input type={viewconfirmPassword ? 'password' : 'text'} {...passRegister("repassword", { required: true })} className={`form-control ${errors.confirmpassword ? 'invalid' : ''}`} id="confirmInputPassword" />
                                                                <span className="icon-view" onClick={passwordviewconfirmChange}>
                                                                    {viewconfirmPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <span className="input_error_msg">{passError.repassword?.message}</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='text-center mt-2'>
                                                <button className="btn btn_primary my-3" type="submit">Change Password</button>
                                            </div>
                                        </form>
                                    </Tab.Pane>
                                    <Tab.Pane eventKey="orgInfo">
                                        <Organization />
                                    </Tab.Pane>
                                </Tab.Content>
                            </div>
                        </div>
                    </div>
                </div>
            </Tab.Container>
        </div>
    )
}

export default ProfileSettings