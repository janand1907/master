import React, { useState } from 'react';
import { useForm } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import './Auth.scss';
const Resetpassword = () => {
    const [viewPassword, setViewPassword] = useState(true);
    const [viewconfirmPassword, setViewconfirmPassword] = useState(true);
    const validationSchema = Yup.object().shape({
        password: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Password is required'))
            .matches(
                /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{12,16}$/,
                "Password (12-18) characters with alphanumeric, Upper and Lower case letters and symbols"
            ),
        confirmpassword: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .when('password', (password, schema) => {
                if (password) return schema.required('Confirm Password is required');
            })
            .oneOf([Yup.ref('password')], 'Password does not match')
    });
    const { register, handleSubmit, formState: { errors, ...formState }, control, reset } = useForm({
        resolver: yupResolver(validationSchema)
    });
    const onSubmit = (data, e) => {
      
    }
    const passwordviewChange = () => {
        setViewPassword(!viewPassword);
    }

    const passwordviewconfirmChange = () => {
        setViewconfirmPassword(!viewconfirmPassword);
    }
    return (
        <div className='container-fluid auth p-0'>
            <div className="row justify-content-center align-items-center authMAin">
                <div className="col-sm-12 col-md-10 col-lg-7 col-xl-5">
                    <div className="card p-3 my-3 custom-card">
                        <div className='card-wrapper'>
                            <div className="text-center auth-title-layout mx-4 pt-3 pb-2"><h5 class="card-title pt-2 pb-0 fs-5">New credentials updates </h5><p class="small">Your identify has been verified!, set your new password</p></div>
                            <div className="card-body px-4">
                                <form onSubmit={handleSubmit(onSubmit)} className='px-2'>
                                    <div className='row'>
                                        <div className='col-sm-12 mb-4 '>
                                            <div className="passwordInput">
                                                <label for="exampleFormControlInput1" class="form-label">New Password <span className='text-danger'>*</span></label>
                                                <input type={viewPassword ? 'password' : 'text'} {...register("password", { required: true })} className={`form-control ${errors.password ? '' : ''}`} id="InputPassword" placeholder="New Password" />
                                                <span className="icon-view" onClick={passwordviewChange}>
                                                    {viewPassword ? <i className="bi bi-eye-slash-fill"></i> : <i className="bi bi-eye-fill"></i>}
                                                </span>
                                            </div>
                                            <span className="error">{errors.password?.message}</span>
                                        </div>
                                        <div className='col-sm-12 mb-4'>
                                            <div className="passwordInput">
                                                <label for="exampleFormControlInput1" class="form-label">Confirm Password <span className='text-danger'>*</span></label>
                                                <input type={viewconfirmPassword ? 'password' : 'text'} {...register("confirmpassword", { required: true })} className={`form-control ${errors.confirmpassword ? 'invalid' : ''}`} id="confirmInputPassword" placeholder="Confirm Password" />
                                                <span className="icon-view" onClick={passwordviewconfirmChange}>
                                                    {viewconfirmPassword ? <i className="bi bi-eye-slash-fill"></i> : <i className="bi bi-eye-fill"></i>}
                                                </span>
                                            </div>
                                            <span className="error">{errors.confirmpassword?.message}</span>
                                        </div>
                                    </div>
                                    <div class="col-12 pt-4 pb-2">
                                        <button type="submit" className="btn btn_primary op-bg-primary w-100">
                                            Reset Password
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Resetpassword
