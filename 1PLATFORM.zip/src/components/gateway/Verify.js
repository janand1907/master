import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import './Login.scss';
const Verify = () => {
    const userSignDetails = useSelector(state => state.signup);
    return (
        <div className='container-fluid auth p-0'>
            <div className="row justify-content-center">
                <div className="col-sm-6">
                    <div className='login-form'>
                        <div className="brand-logo">
                            <div className="d-flex justify-content-center py-2">
                                <span className="d-none d-lg-block">Quantify</span>
                            </div>
                        </div>
                        <div className="card">
                            <div className="pt-4 pb-2 border-bottom text-center">
                                <h5 className="card-title  pb-0 fs-4">Email Confirmation Required!</h5>
                                <p className=" small">Dear <b>{userSignDetails.userInfo.firstname},</b>
                                </p>
                                <p className=" small">We sent the email to <b>{userSignDetails.userInfo.email}</b>
                                </p>
                                <p className=" small">
                                    Check your inbox to activate your account.</p>
                            </div>
                           
                                {/* <button type="submit" className="btn btn_primary mt-4 ">
                                    Resend Email
                                </button>
                             */}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )

}


export default Verify
