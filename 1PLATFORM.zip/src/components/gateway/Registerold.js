import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { signup } from '../../ducks/gateway/signup/actions';
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import ReCAPTCHA from "react-google-recaptcha";

import PhoneInput, { isValidPhoneNumber } from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import './Auth.scss';
import {
    Link, useHistory
} from "react-router-dom";
import Logo from '../Common/Logo/Logo'
import { countrylist } from '../../constants/countrylist';

const Registerold = () => {
    const [formstep, setformStep] = useState(0);
    const [pDetails, setpDetails] = useState({});
    const [stateDetails, setstateDetails] = useState([])
    const history = useHistory();
    const dispatch = useDispatch();
    const [viewPassword, setViewPassword] = useState(true);
    const [viewconfirmPassword, setViewconfirmPassword] = useState(true);
    const [selectedNo, setSelectedno] = useState('in')
    const personalSchema = Yup.object().shape({
        firstname: Yup.string().min(3).max(30).matches(/^[A-Za-z]+$/i, 'Only Alpha Character Accepted')
            .required('First Name is required'),
        lastname: Yup.string().min(3).max(30).matches(/^[A-Za-z]+$/i, 'Only Alpha Character Accepted')
            .required('Last Name is required'),
        email: Yup.string()
            .email('Email is required')
            .required('Email is required'),
        phone: Yup.string()
            .required("This field is Required")
            .matches(
                /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/,
                "Phone number is not valid"
            ),

        password: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Password is required'))
            .matches(
                /^.*(?=.{8,})((?=.*[!@#$%^&*()\-_=+{};:,<.>]){1})(?=.*\d)((?=.*[a-z]){1})((?=.*[A-Z]){1}).*$/,
                "Password must contain at least 8 characters, one uppercase, one number and one special case character"
            ),
        confirmpassword: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .when('password', (password, schema) => {
                if (password) return schema.required('Confirm Password is required');
            })
            .oneOf([Yup.ref('password')], 'Passwords must match')
    });

    const companySchema = Yup.object().shape({
        country: Yup.string()
            .required('Country is required'),
        companyname: Yup.string().min(3).max(30).matches(/^[A-Za-z]+$/i, 'Only Alpha Character Accepted')
            .required('Company Name is required'),
        agree: Yup.bool()
            .oneOf([true], 'Select terms and conditions'),

    });

    const { register,
        handleSubmit,
        formState: { errors, isValid }, control, reset } = useForm({
            resolver: yupResolver(personalSchema), mode: 'onChange'
        });
    const { register: companyregister,
        handleSubmit: companyhandleSubmit,
        watch: companyWatch,
        formState: { errors: companyErrors, isValid: companyisValid }, reset: companyReset } = useForm({
            resolver: yupResolver(companySchema), mode: 'onChange'
        });
    const values = companyWatch("country");
    const onSubmit = (data) => {
        dispatch(signup(data));
        reset();
        setSelectedno('in')
    }

    const userSignDetails = useSelector(state => state.signup);
    const onChange = (value) => {
        
    }

    useEffect(() => {

        if (userSignDetails.userInfo.isRegister) {
            history.push("/verify");

        }

    }, [userSignDetails.userInfo.isRegister])

    useEffect(() => {
        if (values) {
            let statesvalue = countrylist.find(val => {
                return val.country == values
            })
            setstateDetails(statesvalue.states)

        }
    }, [values])

    const onSubmitPersonal = (data) => {
        
        setpDetails(data);
        completedstep(1);
    }

    const onSubmitCompany = (data) => {
        let allval = { ...pDetails, ...data }
        onSubmit(allval)

    }





    const completedstep = (val) => {
        setformStep(cur => cur + (val))
    }

    const passwordviewChange = () => {
        setViewPassword(!viewPassword);
    }

    const passwordviewconfirmChange = () => {
        setViewconfirmPassword(!viewconfirmPassword);
    }

    

    return (
        <div className='container-fluid auth p-0'>
            <div className="row justify-content-center align-items-center authMAin">
                <div className="col-sm-12 col-md-10 col-lg-7 col-xl-5">
                    <div className='card p-3 my-3 custom-card'>
                        <div className='card-wrapper'>
                            <div className="text-center auth-title-layout mx-4 pt-3 pb-1">
                                <Logo />
                                <h5 className="card-title pt-2 pb-0 fs-5">Create an account </h5>
                                <p className="small">This is an initial information of your business. You can change it anytime.</p>
                            </div>
                            <div className="card-body pb-3 mx-md-3 mx-sm-1">
                                {userSignDetails.isDuplicate && <div className="alert alert-danger mt-1" role="alert">
                                    Email Already Exist. Please Register With Different Email
                                </div>}
                                <div className='row mt-4'>
                                    <div className="col-sm-6 pe-0">
                                        <button type="button" className="btn btn-top-register rounded-0 rounded-start w-100" onClick={() => setformStep(0)}>Personal Details</button>
                                    </div>
                                    <div className='col-sm-6 ps-0'>
                                        <button disabled={!isValid} type="submit" onClick={handleSubmit(onSubmitPersonal)} className="btn btn-top-register rounded-0 rounded-end w-100" >Organization Details</button>
                                    </div>
                                </div>
                                {formstep == 0 &&
                                    <form onSubmit={handleSubmit(onSubmitPersonal)} className='mx-3 pt-4'>
                                        <div className='row g-3'>
                                            <div className='col-sm-12'>
                                                <input type="text" {...register("firstname", { required: true })} className={`form-control ${errors.firstname ? 'invalid' : ''}`} id="firstname" aria-describedby="firstname" placeholder="First Name*" />
                                                <span className="error">{errors.firstname?.message}</span>
                                            </div>
                                            <div className='col-sm-12'>
                                                <input type="text" {...register("lastname", { required: true })} className={`form-control ${errors.lastname ? 'invalid' : ''}`} id="lastname" aria-describedby="lastname" placeholder="Last Name*" />
                                                <span className="error">{errors.lastname?.message}</span>
                                            </div>

                                            <div className='col-sm-12'>
                                                <input type="text" {...register("email", { required: true })} className={`form-control ${errors.email ? 'invalid' : ''}`} id="email" aria-describedby="email" placeholder="Email*" />
                                                <span className="error">{errors.email && <span>Please Enter Your Email</span>}</span>
                                            </div>

                                            <div className='col-sm-12'>
                                                <Controller
                                                    name="phone"
                                                    control={control}
                                                    rules={{
                                                        validate: (value) => isValidPhoneNumber(value)
                                                    }}
                                                    render={({ field: { onChange, value } }) => (
                                                        <PhoneInput
                                                            country={selectedNo}
                                                            value={value}
                                                            onChange={(e) => { onChange(e) }}
                                                            enableSearch={true}
                                                        />
                                                    )}
                                                />
                                                {/* <label htmlFor="phone" className='form-label'>Phone Number</label> */}
                                                <span className="error">{errors.phone?.message}</span>
                                            </div>
                                            <div className='col-sm-12'>
                                                <input type="text" {...register("telephone")} className="form-control" id="telephone" aria-describedby="telephone" placeholder="Telephone" />
                                            </div>
                                            <div className='col-sm-12 '>
                                                <div className="passwordInput">
                                                    <input type={viewPassword ? 'password' : 'text'} {...register("password", { required: true })} className={`form-control ${errors.password ? 'invalid' : ''}`} id="InputPassword" placeholder="Password" />
                                                    <span className="icon-view" onClick={passwordviewChange}>
                                                        {viewPassword ? <i className="bi bi-eye-slash-fill"></i> : <i className="bi bi-eye-fill"></i>}
                                                    </span>
                                                </div>
                                                <span className="error">{errors.password?.message}</span>
                                            </div>
                                            <div className='col-sm-12'>
                                                <div className="passwordInput">
                                                    <input type={viewconfirmPassword ? 'password' : 'text'} {...register("confirmpassword", { required: true })} className={`form-control ${errors.confirmpassword ? 'invalid' : ''}`} id="confirmInputPassword" placeholder="Confirm Password" />
                                                    <span className="icon-view" onClick={passwordviewconfirmChange}>
                                                        {viewconfirmPassword ? <i className="bi bi-eye-slash-fill"></i> : <i className="bi bi-eye-fill"></i>}
                                                    </span>
                                                </div>
                                                <span className="error">{errors.confirmpassword?.message}</span>
                                            </div>

                                        </div>
                                        <div className="justify-content-center align-items-center pt-4 row">
                                            <Link to="/login" className="col-md col-sm-12 font-weight-bold text-center text-decoration-none text-muted" >Cancel</Link>                                        
                                            <button className="btn col-md-6 col-sm-12 btn_primary mx-2" type="submit">Save and Continue</button>
                                        </div>                                         
                                    </form>
                                }
                                {formstep == 1 &&
                                    <form onSubmit={companyhandleSubmit(onSubmitCompany)} className='mx-3 pt-4'>
                                        <div className='row'>
                                            <div className='col-sm-12 mb-4'>
                                                <select {...companyregister("country", { required: true })} className='form-control'>
                                                    {countrylist.map((val, index) =>
                                                        <option key={index} value={val.country}>{val.country}</option>
                                                    )}
                                                </select>
                                                <span className="error">{errors.country?.message}</span>
                                            </div>
                                            <div className='col-sm-12 mb-4'>
                                                <select {...companyregister("state", { required: true })} className='form-control'>
                                                    {stateDetails.map((val, index) =>
                                                        <option key={index} value={val}>{val}</option>
                                                    )}
                                                </select>
                                                <span className="error">{errors.country?.message}</span>
                                            </div>
                                            <div className='col-sm-12 mb-4'>
                                                <input type="text" {...companyregister("companyname", { required: true })} className={`form-control ${errors.companyname ? 'invalid' : ''}`} id="companyname" aria-describedby="companyname" placeholder="Company Name" />
                                                <span className="error">{companyErrors.companyname?.message}</span>
                                            </div>
                                            <div className='col-sm-12 mb-4'>
                                                <input type="text" {...companyregister("jobtitle")} className='form-control' id="jobtitle" aria-describedby="jobtitle" placeholder="Job Title" />
                                            </div>
                                            <div className='col-sm-12 mb-4'>
                                                <input type="text" {...companyregister("companywebsite")} className='form-control' id="companywebsite" aria-describedby="companywebsite" placeholder="company Website" />
                                            </div>
                                            <div className='col-sm-12'>
                                                <div className="my-2 d-flex justify-content-between align-items-center">
                                                    <div className="form-check form-switch">
                                                        <input className="form-check-input" type="checkbox"  {...companyregister("agree", { required: true })} id="flexSwitchCheckChecked" defaultChecked />
                                                        <label className="form-check-label" htmlFor="flexSwitchCheckChecked">I agree to all Terms and Conditions</label>
                                                        <div className="error">{companyErrors.agree?.message}</div>
                                                    </div>
                                                </div>
                                            </div>
                                            {/* <div className='col-sm-12'>
                                            <div className="mb-3">
                                                <ReCAPTCHA
                                                    sitekey="6Ld3askeAAAAADej0WhI91EGd3jK3X7fAmisrXIj"
                                                    onChange={onChange}
                                                />
                                            </div>
                                        </div> */}

                                        </div>
                                        <div className="row align-items-center mt-4">
                                            <div className="col-sm-6">
                                                <button type="button" className="muted-button w-100" onClick={() => completedstep(-1)}><span className="me-3"><i className="fa fa-chevron-left" /></span>Back</button>
                                            </div>
                                            <div className='col-sm-6'>
                                                <button type="submit" className="btn btn_primary w-100">SIGNUP</button>
                                            </div>
                                        </div>
                                    </form>
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )

}


export default Registerold
