import React, { useState, useEffect } from 'react';
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from 'react-redux';
import './Auth.scss';
import Spinner from 'react-bootstrap/Spinner'
import { Link, useHistory } from "react-router-dom";
import { login, loginReset } from '../../ducks/gateway/login/actions';
import Loginimage from '../../assets/images/auth/mobilelogin.svg'
import googleIcon from '../../assets/images/other/google.png'
import eyeIcon from '../../assets/images/other/input/eye.svg'
import eyeOffIcon from '../../assets/images/other/input/eye_off.svg'
import Logo from '../Common/Logo/Logo';
const Login = () => {

    const history = useHistory();
    const dispatch = useDispatch();
    const userState = useSelector(state => state.user);

    const [viewPassword, setViewPassword] = useState(true);
    const { register, handleSubmit, formState: { errors } } = useForm();

    const onSubmit = (data, e) => {
        dispatch(login(data.userName.toLowerCase(), data.password));
    };

    useEffect(() => {

        if (userState.userInfo.isLoggedIn) {
            let payload = {
                userId: userState.userInfo.userId,
                userName: userState.userInfo.username
            }
            dispatch({ type: 'Loggedinstate', payload: payload });
            history.push("/platformadmin");
        } else {
            dispatch(loginReset(null));
            history.push("/login");
        }
    }, [userState.userInfo.isLoggedIn])

    const passwordviewChange = () => {
        setViewPassword(!viewPassword);
    }

    const toRegister = () => {
        history.push(`/register`);
    }

    return (
        <div className='login_screen h-100'>
            <div className='authenticationScreen'>
                <div className='authenticationScreen_panel'>
                    <div className='authenticationScreen_panel_left'>
                        <img src={Loginimage} alt="Left sectionimage" style={{ width: '65%' }} />
                    </div>
                    <div className='authenticationScreen_panel_seperator'></div>
                    <div className='authenticationScreen_panel_right'>
                        <div className='authenticationScreen_panel_right_btnpanel'>
                            <button className='btn btn_active w-auto'>Sign In</button>
                            <button className='btn btn_normal w-auto' onClick={() => toRegister()}>Sign Up</button>
                        </div>
                        <div className='authenticationScreen_panel_right_formPanel'>
                            <div className='authenticationScreen_panel_right_formPanel_logo py-3 text-center'>
                                <Logo />
                            </div>
                            {userState.isError &&
                                <div className="invalidCredentials  mx-auto">
                                    <p className="invalidCredentials_Err">{userState.error}</p>
                                </div>
                            }
                            <form className="row mt-2 mx-auto " onSubmit={handleSubmit(onSubmit)}>
                                <div className="col-12">
                                    <div className='op_input_block'>
                                        <label for="exampleFormControlInput1" class="form-label d-none">Email ID <span className='text-danger'>*</span></label>
                                        <input type="text" {...register("userName", { required: true })} className={`form-control ${errors.userName ? 'invalid' : ''}`} id="email" aria-describedby="userName" placeholder="Enter Username" />
                                        <span className="input_error_msg">{errors.userName && <span>Please Enter your Email ID</span>}</span>
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className='op_input_block'>
                                        <div className="passwordInput">
                                            <label for="exampleFormControlInput1" class="form-label d-none">Password <span className='text-danger'>*</span></label>
                                            <input type={viewPassword ? 'password' : 'text'} {...register("password", { required: true })} className={`form-control && rounded-end ${errors.password ? 'invalid' : ''}`} id="InputPassword" placeholder="Enter Password" />
                                            <span className="icon-view" onClick={passwordviewChange}>
                                                {viewPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                            </span>
                                        </div>
                                        <span className="input_error_msg">{errors.password && <span>Please Enter your Password</span>}</span>
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className='op_input_block'>
                                        <div className="form-check">
                                            {/* <input className="form-check-input" {...register("agree")} type="checkbox" id="flexSwitchCheckChecked" defaultChecked />
                                            <label className="form-check-label" htmlFor="flexSwitchCheckChecked">Remember</label> */}
                                            <Link className='float-end forgot_password' to="/forgotpwd">Forgot Password</Link>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" className="btn btn_auth_submit py-2 my-3">
                                    {userState.isPending ?
                                        <span>
                                            <Spinner
                                                as="span"
                                                animation="border" variant="light"
                                                size="sm"
                                                role="status"
                                                aria-hidden="true"
                                            /> LOADING...</span> : <>Sign In</>

                                    }
                                </button>
                            </form>
                            {userState.isPendingAccount && <div className="alert alert-danger mt-1" role="alert">
                                Need to activate your account. Activation link send to your registered email
                            </div>}
                            <div className="col-12 resend_link">
                                <p className="mb-0"><Link to="/resend">Re-send Verification Email</Link></p>
                            </div>
                            {/* <div className='decorated_seperator'>
                                <p>or</p>
                                <div class="border_line"></div>
                            </div>
                            <button className='btn btn_google'> <span className='me-2'><img src={googleIcon} alt='G' /></span> Sign-in with Google</button> */}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    )
}
export default Login
