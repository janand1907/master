import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { signupComplete } from '../../ducks/gateway/signup/actions';
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import './Auth.scss';
import {
    Link, useHistory
} from "react-router-dom";
import Logo from '../Common/Logo/Logo'
import { countrylist } from '../../constants/countrylist';

import { InputTags } from 'react-bootstrap-tagsinput';
import 'react-bootstrap-tagsinput/dist/index.css'
const Profile = () => {
    const history = useHistory();
    const dispatch = useDispatch();
    const personalSchema = Yup.object().shape({
        company_type: Yup.string()
            .required('Company Type is required'),
        job_title: Yup.string()
            .required('Job title is required'),
        about_oip: Yup.string()
            .required('About OIP is required'),
            role_type: Yup.string()
            .required('Role Type is required'),
            company_name: Yup.string()
            .required('Company Name is required'),
            organization_type: Yup.string()
            .required('Organization Type is required'),
            phone: Yup.string()
            .required('Phone is required'),
            location: Yup.string()
            .required('Location is required'),
            marketing_emails_enabled: Yup.bool()
            .oneOf([true], 'Required'),
            is_singapore_company: Yup.bool()
            .oneOf([true], 'Required'),
    });



    const { register,
        handleSubmit,
        formState: { errors, isValid }, control, reset } = useForm({
            resolver: yupResolver(personalSchema), mode: 'onChange'
        });



    const userSignDetails = useSelector(state => state.signup);


    useEffect(() => {

        if (userSignDetails.userInfo.isRegister) {
            history.push("/verify");

        }

    }, [userSignDetails.userInfo.isRegister])
    const [state, setState] = useState([])
    const [state1, setState1] = useState([])
    const onSubmit = (data) => {
     let countrycode = countrylist.find(val=>val.country == data.location);    
        data.user_information_provided = true;
        data.company_information_provided = true;
        data.phone = {
            country_code: countrycode.alpha2Code,
            phone_number: data.phone
        }
     
      dispatch(signupComplete(data));
      reset();
    }

    
    const checkKeyDown = (e) => {
        if (e. code === 'Enter') e. preventDefault();
        };
    return (
        <div className='container-fluid auth p-0'>
            <div className="row justify-content-center align-items-center authMAin">
                <div className="col-sm-8">
                    <div className='card p-3 my-3 custom-card'>
                        <div className='card-wrapper'>
                            <div className="text-center auth-title-layout mx-4 pt-3 pb-1">
                                <Logo />
                                <h5 className="card-title pt-2 pb-0 fs-5">Complete your Profile</h5>
                                <p className="small">This is an initial information of your business. You can change it anytime.</p>
                            </div>
                            <div className="card-body pb-3 mx-md-3 mx-sm-1">
                                {userSignDetails.isDuplicate && <div className="alert alert-danger mt-1" role="alert">
                                    Email Already Exist. Please Register With Different Email
                                </div>}

                               

                                <form onSubmit={handleSubmit(onSubmit)} onKeyDown={(e) => checkKeyDown(e)} className='mx-3 pt-4'>
                                    <div className='row g-3'>
                                        <div className='col-sm-6'>
                                            <input type="text" {...register("company_type", { required: true })} className={`form-control ${errors.company_type ? 'invalid' : ''}`} id="company_type" aria-describedby="company_type" placeholder="company type*" />
                                            <span className="error">{errors.company_type?.message}</span>
                                        </div>
                                        <div className='col-sm-6'>
                                            <input type="text" {...register("job_title", { required: true })} className={`form-control ${errors.job_title ? 'invalid' : ''}`} id="job_title" aria-describedby="job_title" placeholder="job title*" />
                                            <span className="error">{errors.job_title?.message}</span>
                                        </div>

                                        <div className='col-sm-6'>
                                            <input type="text" {...register("about_oip", { required: true })} className={`form-control ${errors.about_oip ? 'invalid' : ''}`} id="about_oip" aria-describedby="about_oip" placeholder="about oip*" />
                                            <span className="error">{errors.about_oip?.message}</span>
                                        </div>
                                        <div className='col-sm-6'>
                                            <input type="text" {...register("role_type", { required: true })} className={`form-control ${errors.role_type ? 'invalid' : ''}`} id="role_type" aria-describedby="role_type" placeholder="role type*" />
                                            <span className="error">{errors.role_type?.message}</span>
                                        </div>
                                        <div className='col-sm-6'>
                                            <input type="text" {...register("company_name", { required: true })} className={`form-control ${errors.company_name ? 'invalid' : ''}`} id="company_name" aria-describedby="company_name" placeholder="company_name*" />
                                            <span className="error">{errors.company_name?.message}</span>
                                        </div>
                                        <div className='col-sm-6'>
                                            <input type="text" {...register("organization_type", { required: true })} className={`form-control ${errors.organization_type ? 'invalid' : ''}`} id="organization_type" aria-describedby="organization_type" placeholder="organization_type*" />
                                            <span className="error">{errors.organization_type?.message}</span>
                                        </div>
                                        <div className='col-sm-6'>
                                            <input type="text" {...register("phone", { required: true })} className={`form-control ${errors.phone ? 'invalid' : ''}`} id="phone" aria-describedby="phone" placeholder="phone*" />
                                            <span className="error">{errors.phone?.message}</span>
                                        </div>
                                        <div className='col-sm-6 mb-4'>
                                                <select {...register("location", { required: true })} className='form-control'>
                                                    {countrylist.map((val, index) =>
                                                        <option key={index} value={val.country}>{val.country}</option>
                                                    )}
                                                </select>
                                                <span className="error">{errors.location?.message}</span>
                                        </div>

                                        <div className='col-sm-6'>
                                        <div className="my-2 d-flex justify-content-between align-items-center">
                                            <div className="form-check form-switch">
                                                <input className="form-check-input" type="checkbox"  {...register("marketing_emails_enabled", { required: true })} id="flexSwitchCheckChecked" defaultChecked />
                                                <label className="form-check-label" htmlFor="flexSwitchCheckChecked">Marketing Emails</label>
                                                <div className="error">{errors.marketing_emails_enabled?.message}</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-sm-6'>
                                        <div className="my-2 d-flex justify-content-between align-items-center">
                                            <div className="form-check form-switch">
                                                <input className="form-check-input" type="checkbox"  {...register("is_singapore_company", { required: true })} id="flexSwitchCheckChecked" defaultChecked />
                                                <label className="form-check-label" htmlFor="flexSwitchCheckChecked">Singapore Company</label>
                                                <div className="error">{errors.is_singapore_company?.message}</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className='col-sm-6'>
                                        <Controller
                                            name="skillsets"
                                            control={control}   
                                            rules={{ required: true }}                                         
                                            render={({ field: { onChange} }) => (
                                                <InputTags values={state} onTags={(value) =>{onChange(value.values); setState(value.values)}}/>
                                                
                                            )}
                                        />
                                        {/* <div className="error">{errors.suggestions?.message}</div> */}
                                    </div>

                                    <div className='col-sm-6'>
                                        <Controller
                                            name="industries"
                                            control={control}   
                                            rules={{ required: true }}                                         
                                            render={({ field: { onChange} }) => (
                                                <InputTags values={state1} onTags={(value) =>{onChange(value.values); setState1(value.values)}}/>
                                                
                                            )}
                                        />
                                        {/* <div className="error">{errors.suggestions?.message}</div> */}
                                    </div>


                                    </div>
                                    
                                  
                                    <div className="justify-content-center align-items-center pt-4 row">
                                        <Link to="/login" className="col-md col-sm-12 font-weight-bold text-center text-decoration-none text-muted" >Cancel</Link>
                                        <button className="btn col-md-6 col-sm-12 btn_primary mx-2" type="submit">Register</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )

}


export default Profile
