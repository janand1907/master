import React, { useState } from 'react';
import { useForm } from "react-hook-form";
import Loginimage from '../../assets/images/auth/resend.png'
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import './Auth.scss'
import {
    Link, useHistory
} from "react-router-dom";
import Logo from '../Common/Logo/Logo'
import { resendEmail } from '../../endpoints/gateway'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const Resend = () => {
    const history = useHistory();

    const [registeredStatus, setRegisteredStatus] = useState(false);
    const personalSchema = Yup.object().shape({
        userName: Yup.string()
            .email('Email id is invalid')
            .required('Email id is required'),
    });
    const { register,
        handleSubmit,
        formState: { errors, isValid }, control, reset } = useForm({
            resolver: yupResolver(personalSchema), mode: 'onChange'
        });


    const onSubmit = async (data) => {
        let response = await resendEmail(data.userName.toLowerCase())
debugger;
        setRegisteredStatus(true);
        // if (response.data.message) {
        //     setTimeout(() => {
        //         setRegisteredStatus(true);
        //     })
        // }else {
        //     toast.error(response.data.msg)
        // }
    }

    const toLogin = () => {
        history.push(`/login`);
    }

    return (
        <div className='authenticationScreen'>
            <div className='authenticationScreen_panel'>
                <div className='authenticationScreen_panel_left'>
                    <img src={Loginimage} className="L_image" alt="Left sectionimage" style={{ width: '65%' }} />
                </div>
                <div className='authenticationScreen_panel_seperator'></div>
                <div className='authenticationScreen_panel_right'>
                    <div className='authenticationScreen_panel_right_btnpanel border-0 position-relative'>
                        <div className='authenticationScreen_panel_right_formPanel_logo py-3 mx-auto my-5'>
                            <Logo />
                        </div>
                    </div>
                    <div className='authenticationScreen_panel_right_formPanel h-auto mt-0'>

                        {!registeredStatus ?

                            <>
                                <div className='titleSection mx-auto'>
                                    <h1>Resend Email</h1>
                                    <p className='mt-2 mb-0'>We’ll send you an email with a link to activate your email ID.</p>
                                </div>
                                <form className="row my-3 g-0 mx-auto" onSubmit={handleSubmit(onSubmit)}>
                                    <div className='col-sm-12'>
                                        <div className='op_input_block'>
                                            <input type="text" {...register("userName", { required: true })} className={`form-control ${errors.userName ? 'invalid' : ''}`} id="userName" aria-describedby="userName" placeholder="Email ID" />
                                            <span className="input_error_msg">{errors.userName?.message}</span>
                                        </div>
                                    </div>
                                    <div className='col-12 text-center' style={{ marginTop: '5rem' }}>
                                        <button className="btn btn_auth_submit mb-2" type="submit">Resend Email</button>
                                        <button className="btn btn_link w-75 mt-2" onClick={() => toLogin()} type="button">Cancel</button>
                                    </div>
                                </form>
                            </> :
                            <>
                                <div className='titleSection text-center mx-auto'>
                                    <div className='mb-4'>
                                        <svg xmlns="http://www.w3.org/2000/svg" height="48" width="48" fill='#828282'><path d="M21.05 33.1 35.2 18.95l-2.3-2.25-11.85 11.85-6-6-2.25 2.25ZM24 44q-4.1 0-7.75-1.575-3.65-1.575-6.375-4.3-2.725-2.725-4.3-6.375Q4 28.1 4 24q0-4.15 1.575-7.8 1.575-3.65 4.3-6.35 2.725-2.7 6.375-4.275Q19.9 4 24 4q4.15 0 7.8 1.575 3.65 1.575 6.35 4.275 2.7 2.7 4.275 6.35Q44 19.85 44 24q0 4.1-1.575 7.75-1.575 3.65-4.275 6.375t-6.35 4.3Q28.15 44 24 44Zm0-3q7.1 0 12.05-4.975Q41 31.05 41 24q0-7.1-4.95-12.05Q31.1 7 24 7q-7.05 0-12.025 4.95Q7 16.9 7 24q0 7.05 4.975 12.025Q16.95 41 24 41Zm0-17Z" /></svg>
                                    </div>
                                    <h1>Email Resend successfully!</h1>
                                    <p className='mt-2 mb-0'>
                                        An email has been sent to you. Do check and verify your account using the email.
                                        If you have not received your verification email, please check your junk mail folder
                                    </p>
                                    <div className='col-12 text-center' style={{ marginTop: '5rem' }}>
                                        <button className="btn btn_auth_submit w-75 mt-2" onClick={() => toLogin()} type="button"><i class="bi bi-arrow-left me-2"></i> Back to Sign in</button>
                                    </div>
                                </div>
                            </>
                        }
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Resend
