import React, { useEffect, useState } from 'react';
import './Auth.scss'
import { useDispatch, useSelector } from 'react-redux';
import { signupComplete, signupUpdate } from '../../ducks/gateway/signup/actions';
import { signup } from '../../endpoints/gateway';
import { OverlayTrigger, Popover } from 'react-bootstrap';
import LeftImage from '../../assets/images/auth/register.svg'
import LeftImage_2 from '../../assets/images/auth/email.svg'
import { useForm, useFormState } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import {
    Link, useHistory
} from "react-router-dom";
import Logo from '../Common/Logo/Logo'
import eyeIcon from '../../assets/images/other/input/eye.svg'
import eyeOffIcon from '../../assets/images/other/input/eye_off.svg'

const Register = () => {

    const history = useHistory();
    const dispatch = useDispatch();
    const [viewPassword, setViewPassword] = useState(true);
    const [viewconfirmPassword, setViewconfirmPassword] = useState(true);
    const [registeredStatus, setRegisteredStatus] = useState(false);
    const [userSignDetails, setUserSignDetails] = useState({
        message: '',
        isError: false,
        isPending: false,
        isDuplicate: false,
        isRegister: false,
    });
    const personalSchema = Yup.object().shape({
        firstName: Yup.string().required('First Name is required').min(3, "First name (3-30 characters)").max(30, "First name (3-30 characters)").matches(/^[A-Za-z]+$/i, 'Enter alphabets in first name'),
        lastName: Yup.string().required('Last Name is required').min(3, "Last name (3-30 characters)").max(30, "Last name (3-30 characters)").matches(/^[A-Za-z]+$/i, 'Enter alphabets in last name'),
        email: Yup.string()
            .email('Please enter a valid email address')
            .required('Email is required')
            .matches(/^[a-zA-Z0-9._%+-]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)(?!yahoo.co.in)(?!aol.com)(?!live.com)(?!outlook.com)[a-zA-Z0-9_-]+.[a-zA-Z0-9-.]{2,61}$/,
                "Only Business emails are accepted"),
        password: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Password is required'))
            .matches(
                /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{12,18}$/,
                "Password (12-18) characters with alphanumeric, Upper and Lower case letters and symbols"
            ),
        repassword: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Confirm Password is required'))
            .oneOf([Yup.ref('password')], 'Password does not match'),
        user_agreed_with_terms_and_conditions: Yup.bool()
            .oneOf([true], 'Select terms and conditions'),
    });



    const { register,
        handleSubmit,
        formState: { errors }, reset } = useForm({
            resolver: yupResolver(personalSchema), mode: 'onChange'
        });


    const onSubmit = async (data) => {

        //dispatch(signup(data));
        let response = await signup(data);

        if (response.status === 200) {
            dispatch(signupUpdate(response.data));
            setUserSignDetails({
                message: response.data.message,
                isError: true,
                isPending: false,
                isDuplicate: false,
                isRegister: true,
            });
            setRegisteredStatus(true);
            reset();
        } else {
            //dispatch(signupUpdate(response.response.data));
            setUserSignDetails(
                {
                    message: response.response.data.message,
                    isError: true,
                    isPending: false,
                    isDuplicate: false,
                    isRegister: true,
                }
            );
        }

    }

    //const userSignDetails = useSelector(state => state.signup);

    // useEffect(() => {

    //     setTimeout(() => {
    //         if (userSignDetails.isRegister) {
    //             dispatch(signupComplete())
    //             setRegisteredStatus(true)
    //         }
    //     }, 1000)
    // }, [userSignDetails.isRegister])

    // useEffect(() => {
    //     return () => {
    //         dispatch(signupComplete())
    //     }
    // }, [])

    const passwordviewChange = () => {
        setViewPassword(!viewPassword);
    }

    const passwordviewconfirmChange = () => {
        setViewconfirmPassword(!viewconfirmPassword);
    }

    const toLogin = () => {
        history.push(`/login`);
    }

    const passwordPopover = (
        <Popover id="popover-basic">
            <div className='passwordtearms'>
                <p>Password Must be: </p>
                <ul>
                    <li>At least 12 to 18 characters long</li>
                    <li>Should contain upper case and lower case</li>
                    <li>Should contain a numbers with special character</li>
                </ul>
            </div>
        </Popover>
    );

    return (
        <div className='authenticationScreen'>
            <div className='authenticationScreen_panel'>
                <div className='authenticationScreen_panel_left'>
                    <img src={!registeredStatus ? LeftImage : LeftImage_2} alt="Left sectionimage" style={{ width: '75%' }} />
                </div>
                <div className='authenticationScreen_panel_seperator'></div>
                <div className='authenticationScreen_panel_right'>
                    {!registeredStatus ?

                        <>
                            <div className='authenticationScreen_panel_right_btnpanel'>
                                <button className='btn btn_normal w-auto' onClick={() => toLogin()}>Sign In</button>
                                <button className='btn btn_active w-auto'>Sign Up</button>
                            </div>
                            <div className='authenticationScreen_panel_right_formPanel'>
                                <div className='authenticationScreen_panel_right_formPanel_logo py-3 text-center'>
                                    <Logo />
                                </div>
                                <div className="mx-auto">
                                    {userSignDetails.isError &&
                                        <div className="alert alert-danger mt-1" role="alert">
                                            {userSignDetails.message}
                                        </div>
                                    }

                                    <form onSubmit={handleSubmit(onSubmit)} className='mt-2'>
                                        <div className='row'>
                                            <div className='col-sm-6'>
                                                <div className='op_input_block'>
                                                    <label for="exampleFormControlInput1" class="form-label d-none">First Name <span className='text-danger'>*</span></label>
                                                    <input type="text" {...register("firstName", { required: true })} className={`form-control ${errors.firstName ? 'invalid' : ''}`} id="firstname" aria-describedby="firstname" placeholder="Enter First Name" />
                                                    <span className="input_error_msg">{errors.firstName?.message}</span>
                                                </div>
                                            </div>
                                            <div className='col-sm-6'>
                                                <div className='op_input_block'>
                                                    <label for="exampleFormControlInput1" class="form-label d-none">Last Name <span className='text-danger'>*</span></label>
                                                    <input type="text" {...register("lastName", { required: true })} className={`form-control ${errors.lastName ? 'invalid' : ''}`} id="lastname" aria-describedby="lastname" placeholder="Enter Last Name" />
                                                    <span className="input_error_msg">{errors.lastName?.message}</span>
                                                </div>
                                            </div>
                                            <div className='col-sm-12'>
                                                <div className='op_input_block'>
                                                    <label for="exampleFormControlInput1" class="form-label d-none">Email ID <span className='text-danger'>*</span></label>
                                                    <input type="text" {...register("email", { required: true })} className={`form-control ${errors.email ? 'invalid' : ''}`} id="email" aria-describedby="email" placeholder="Enter your Email ID" />
                                                    <span className="input_error_msg">{errors.email && <span>{errors.email?.message}</span>}</span>
                                                    <span className="input_error_msg">{userSignDetails.isError && <span>{userSignDetails.message}</span>}</span>
                                                </div>
                                            </div>
                                            <div className='col-sm-12'>
                                                <div className='op_input_block'>
                                                    <div className="passwordInput">
                                                        <label for="exampleFormControlInput1" class="form-label d-none">Password <span className='text-danger'>*</span></label>
                                                        <input type={viewPassword ? 'password' : 'text'} {...register("password", { required: true })} className={`form-control ${errors.password ? 'invalid' : ''}`} id="InputPassword" placeholder="Enter Password" />
                                                        <span className="icon-view" onClick={passwordviewChange}>
                                                            {viewPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                                        </span>
                                                    </div>
                                                    <span className="input_error_msg">{errors.password?.message}</span>
                                                </div>
                                            </div>
                                            <div className='col-sm-12'>
                                                <div className='op_input_block'>
                                                    <div className="passwordInput">
                                                        <label for="exampleFormControlInput1" class="form-label d-none">Confirm Password <span className='text-danger'>*</span></label>
                                                        <input type={viewconfirmPassword ? 'password' : 'text'} {...register("repassword", { required: true })} className={`form-control ${errors.confirmpassword ? 'invalid' : ''}`} id="confirmInputPassword" placeholder="Re-enter the Password" />
                                                        <span className="icon-view" onClick={passwordviewconfirmChange}>
                                                            {viewconfirmPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                                        </span>
                                                    </div>
                                                    <span className="input_error_msg">{errors.repassword?.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='col-sm-12'>
                                            <div className="op_input_block">
                                                <div className="form-check">
                                                    <input className="form-check-input" type="checkbox"  {...register("user_agreed_with_terms_and_conditions", { required: true })} id="flexSwitchCheckChecked" />
                                                    <label className="form-check-label" htmlFor="flexSwitchCheckChecked">I agree with the terms and conditions and the privacy statements.</label>
                                                    <div className="input_error_msg">{errors.user_agreed_with_terms_and_conditions?.message}</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='text-center op_input_block'>
                                            <button className="btn btn_auth_submit w-75 my-2" type="submit">Sign Up</button>
                                            <button className="btn btn_link w-75 my-2" onClick={() => toLogin()} type="button">Cancel</button>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </> :
                        <>
                            <div className='authenticationScreen_panel_right_btnpanel position-relative border-0'>
                                <div className='authenticationScreen_panel_right_formPanel_logo py-3 mx-auto my-5 '>
                                    <Logo />
                                </div>
                            </div>
                            <div className='authenticationScreen_panel_right_formPanel h-auto mt-0'>
                                <div className='titleSection text-center mx-auto'>
                                    <div className='mb-4'>
                                        <svg xmlns="http://www.w3.org/2000/svg" height="48" width="48" fill='#828282'><path d="M21.05 33.1 35.2 18.95l-2.3-2.25-11.85 11.85-6-6-2.25 2.25ZM24 44q-4.1 0-7.75-1.575-3.65-1.575-6.375-4.3-2.725-2.725-4.3-6.375Q4 28.1 4 24q0-4.15 1.575-7.8 1.575-3.65 4.3-6.35 2.725-2.7 6.375-4.275Q19.9 4 24 4q4.15 0 7.8 1.575 3.65 1.575 6.35 4.275 2.7 2.7 4.275 6.35Q44 19.85 44 24q0 4.1-1.575 7.75-1.575 3.65-4.275 6.375t-6.35 4.3Q28.15 44 24 44Zm0-3q7.1 0 12.05-4.975Q41 31.05 41 24q0-7.1-4.95-12.05Q31.1 7 24 7q-7.05 0-12.025 4.95Q7 16.9 7 24q0 7.05 4.975 12.025Q16.95 41 24 41Zm0-17Z" /></svg>
                                    </div>
                                    <h1>Thank you for registering</h1>
                                    <p className='mt-2 mb-0'>An email has been sent to you. Do check and verify your account using the email. If you have not received your verification email. Please check your junk mail folder</p>
                                    <div className='col-12 text-center' style={{ marginTop: '5rem' }}>
                                        <button className="btn btn_auth_submit w-75 mt-2" onClick={() => toLogin()} type="button"> Back to Sign in</button>
                                        <button className="btn btn_link w-75 my-2" onClick={() => toLogin()} type="button">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </>

                    }

                </div>
            </div>
        </div>
    )

}


export default Register
