import React, { useState, useEffect } from 'react';
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from 'react-redux';
import './Auth.scss';
import Spinner from 'react-bootstrap/Spinner';
import { Link, useHistory } from "react-router-dom";
import Loginimage from '../../../assets/images/auth/authimg.svg';
import Logo from '../../../components/Common/Logo/Logo';
import eyeIcon from '../../../assets/images/other/input/eye.svg';
import eyeOffIcon from '../../../assets/images/other/input/eye_off.svg';

const LoginForm = ({ pending, handleLogin, ...props }) => {
    const history = useHistory();
    const dispatch = useDispatch();
    const userState = useSelector(state => state.user);

    const [viewPassword, setViewPassword] = useState(true);
    const { register, handleSubmit, formState: { errors } } = useForm();
    const onSubmit = (data) => {
        handleLogin(data);
    };

    const passwordviewChange = () => {
        setViewPassword(!viewPassword);
    }
    const toRegister = () => {
        history.push(`/register`);
    }

    const arrow = () => {
        return (
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" />
            </svg>
        )
    }

    return (
        <div className='login_screen h-100'>
            <div className='authenticationScreen'>
                <div className='authenticationScreen_panel'>
                    <div className='authenticationScreen_panel_left'>
                        <img src={Loginimage} alt="Left sectionimage" style={{ width: '65%' }} />
                    </div>
                    <div className='authenticationScreen_panel_seperator'></div>
                    <div className='authenticationScreen_panel_right'>
                        <div className='authenticationScreen_panel_right_btnpanel'>
                            <button className='btn btn_active w-auto'>Sign In</button>
                            <button className='btn btn_normal w-auto' onClick={() => toRegister()}>Sign Up</button>
                        </div>
                        <div className='authenticationScreen_panel_right_formPanel'>
                            <div className='authenticationScreen_panel_right_formPanel_logo py-3 text-center'>
                                <Logo />
                            </div>
                            {userState.isError &&
                                <div className="invalidCredentials  mx-auto">
                                    <p className="invalidCredentials_Err">{userState.error}</p>
                                </div>
                            }
                            <form className="row mt-2 mx-auto " onSubmit={handleSubmit(onSubmit)}>
                                <div className="col-12">
                                    <div className='op_input_block'>
                                        <label for="exampleFormControlInput1" class="form-label d-none">Email ID <span className='text-danger'>*</span></label>
                                        <input type="text" {...register("userName", { required: true })} className={`form-control ${errors.userName ? 'invalid' : ''}`} id="email" aria-describedby="userName" placeholder="Enter Username" />
                                        <span className="input_error_msg">{errors.userName && <span>Please Enter your Email ID</span>}</span>
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className='op_input_block'>
                                        <div className="passwordInput">
                                            <label for="exampleFormControlInput1" class="form-label d-none">Password <span className='text-danger'>*</span></label>
                                            <input type={viewPassword ? 'password' : 'text'} {...register("password", { required: true })} className={`form-control && rounded-end ${errors.password ? 'invalid' : ''}`} id="InputPassword" placeholder="Enter Password" />
                                            <span className="icon-view" onClick={passwordviewChange}>
                                                {viewPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                            </span>
                                        </div>
                                        <span className="input_error_msg">{errors.password && <span>Please Enter your Password</span>}</span>
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className='op_input_block'>
                                        <div className="form-check">
                                            {/* <input className="form-check-input" {...register("agree")} type="checkbox" id="flexSwitchCheckChecked" />
                                            <label className="form-check-label" htmlFor="flexSwitchCheckChecked">Remember</label> */}
                                            <Link className='float-end forgot_password' to="/forgotpwd">Forgot Password</Link>
                                        </div>
                                        <span className="input_error_msg">{errors.agree && <span>Please Choose Remember me</span>}</span>
                                    </div>
                                </div>
                                <button type="submit" className="btn btn_auth_submit py-2 my-3">
                                    {userState.isPending ?
                                        <span>
                                            <Spinner
                                                as="span"
                                                animation="border" variant="light"
                                                size="sm"
                                                role="status"
                                                aria-hidden="true"
                                            /> LOADING...</span> : <>Sign-in {arrow()}</>

                                    }
                                </button>
                            </form>
                            {userState.isPendingAccount && <div className="alert alert-danger mt-1" role="alert">
                                Need to activate your account. Activation link send to your registered email
                            </div>}
                            <div className="col-12 resend_link">
                                <p className="mb-0"><Link to="/resend">Re-send email verification</Link></p>
                            </div>
                            {/* <div className='decorated_seperator'>
                                <p>or</p>
                                <div class="border_line"></div>
                            </div>
                            <button className='btn btn_google'> <span className='me-2'><img src={googleIcon} alt='G'/></span> Sign-in with Google</button> */}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    )
}
export default LoginForm
