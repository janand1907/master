import React, { useState, useEffect } from 'react';
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from 'react-redux';
import './Auth.scss';
import Spinner from 'react-bootstrap/Spinner';
import { Link, useHistory } from "react-router-dom";
import Loginimage from '../../../assets/images/auth/authimg.svg';
import Logo from '../../../components/Common/Logo/Logo';
import eyeIcon from '../../../assets/images/other/input/eye.svg';
import eyeOffIcon from '../../../assets/images/other/input/eye_off.svg';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';

const ForceResetPassword = ({ pending, email, handleForcePassword, ...props }) => {
    
    const userState = useSelector(state => state.user);
    
    const [viewPassword, setViewPassword] = useState(true);

    const [viewPasswordTwo, setViewPasswordTwo] = useState(true);

    //const { register, handleSubmit, formState: { errors } } = useForm();

    const onSubmit = (data) => {
        handleForcePassword(data);
    };

    const passwordviewChange = () => {
        setViewPassword(!viewPassword);
    }

    const passwordviewChangeTwo = () => {
        setViewPasswordTwo(!viewPasswordTwo);
    }

    const validationSchema = Yup.object().shape({
        password: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('New Password is required'))
            .matches(
                /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{12,18}$/,
                "Password (12-18) characters with alphanumeric, Upper and Lower case letters and symbols"
                // Password must be at least 12 to 18 characters long with upper and lower case, number with special case character
            ),
        repassword: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Confirm Password is required'))
            .oneOf([Yup.ref('password')], 'Password does not match'),
    });

    const { register,
        handleSubmit,
        formState: { errors }, reset } = useForm({
            resolver: yupResolver(validationSchema), mode: 'onChange'
    });

    return (
        <div className='login_screen h-100'>
            <div className='authenticationScreen'>
                <div className='authenticationScreen_panel'>
                    <div className='authenticationScreen_panel_left'>
                        <img src={Loginimage}  alt="Left sectionimage" style={{width:'65%'}} />
                    </div>
                    <div className='authenticationScreen_panel_seperator'></div>
                    <div className='authenticationScreen_panel_right'>
                        <div className='authenticationScreen_panel_right_formPanel'>
                            <div className='authenticationScreen_panel_right_formPanel_logo py-3 text-center'>
                                <Logo />
                            </div>
                            {userState.isError &&
                                <div className="invalidCredentials  mx-auto">
                                    <p className="invalidCredentials_Err">{userState.error}</p>
                                </div>
                            }
                            <div className="col-12">
                                <div className='op_input_block'>
                                    <label for="exampleFormControlInput1" class="form-label d-none">Email ID <span className='text-danger'>*</span></label>
                                    <input type="text" className={`form-control`} id="email" value={email} aria-describedby="userName" placeholder="Enter Username" disabled />
                                </div>
                            </div>
                            <form className="row mt-2 mx-auto " onSubmit={handleSubmit(onSubmit)}>
                                <div className='col-sm-12 bottom-space'>
                                    <div className='op_input_block'>
                                        <div className="passwordInput">
                                            <label for="exampleFormControlInput1" class="form-label d-none">New Password <span className='text-danger'>*</span></label>
                                            <input type={viewPassword ? 'password' : 'text'} {...register("password", { required: true })} className={`form-control ${errors.password ? 'invalid' : ''}`} id="InputPassword" placeholder="Enter New Password" />
                                            <span className="icon-view" onClick={passwordviewChange}>
                                                {viewPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                            </span>
                                        </div>
                                        <span className="input_error_msg">{errors.password?.message}</span>
                                    </div>
                                </div>
                                <div className='col-sm-12'>
                                    <div className='op_input_block'>
                                        <div className="passwordInput">
                                            <label for="exampleFormControlInput1" class="form-label d-none">Confirm Password <span className='text-danger'>*</span></label>
                                            <input type={viewPasswordTwo ? 'password' : 'text'} {...register("repassword", { required: true })} className={`form-control ${errors.confirmpassword ? 'invalid' : ''}`} id="confirmInputPassword" placeholder="Re-Enter the New Password" />
                                            <span className="icon-view" onClick={passwordviewChangeTwo}>
                                                {viewPasswordTwo ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                            </span>
                                        </div>
                                        <span className="input_error_msg">{errors.repassword?.message}</span>
                                    </div>
                                </div>
                                <button type="submit" className="btn btn_auth_submit py-2 my-3">
                                    {userState.isPending ?
                                        <span>
                                            <Spinner
                                                as="span"
                                                animation="border" variant="light"
                                                size="sm"
                                                role="status"
                                                aria-hidden="true"
                                            /> LOADING...</span> : <>Reset Password</>

                                    }
                                </button>
                            </form>
                            {userState.isForcePassword && <div className="alert alert-danger mt-1" role="alert">
                                Please reset your password to access your account. 
                            </div>}
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    )
}
export default ForceResetPassword;
