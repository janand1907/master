/* eslint camelcase: "off" */
import PropTypes from 'prop-types';
import React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { parse } from 'qs';
import { login, loginReset, forcePassword } from '../../../ducks/gateway/login/actions';
import LoginForm from './LoginForm';
import { tokenExpiry, forceUpdatePassword } from '../../../endpoints/gateway';
import { getUserSubscriptions } from '../../../endpoints/subscription/users';
import ForceResetPassword from './ForceResetPassword';

class LoginFormContainer extends React.PureComponent {

    constructor(props, context) {
        super(props, context);

        this.state = {
            pending: false,
            sessionExpired: false,
            resetPassword: false,
            client: false,
            vendor: false,
            type: 'password',
            isForcePassword: false,
            userName: null
        };

        this.handleLogin = this.handleLogin.bind(this);
        this.handleForcePassword = this.handleForcePassword.bind(this);
    }

    componentDidMount(){
        // this.props.loginReset(null);
    }

    UNSAFE_componentWillMount() {

        const { location, userInfo } = this.props;
        const query = parse(location.search.substr(1));

        if (userInfo.isLoggedIn) {
           
            let rUrl = "";

            let Expiry = tokenExpiry();
            if (Expiry) {

                localStorage.clear();

            } else {
                
                if(userInfo?.isForcePassword){
                    return;
                }else if(userInfo.allInfo?.platformAdmin){
                    rUrl = "/dashboard-admin"
                }else if(userInfo.allInfo?.superUser === "ADMIN"){
                    rUrl = "/dashboard-user"
                }else if(userInfo.allInfo?.superUser === "USER"){
                    rUrl = "/dashboard"
                }else if(userInfo.allInfo?.superUser === "NEW"){
                    rUrl = "/dashboard-user"
                }else if(userInfo.allInfo?.superUser === null){
                    rUrl = "/dashboard"
                }
                
                this.props.history.push({
                    pathname: query.redirect || rUrl
                });

            }
        } else {

            localStorage.clear();
            this.props.loginReset(null);
        }

    }

    UNSAFE_componentWillReceiveProps(nextProps) {

        if (nextProps.userInfo.isLoggedIn) {

            let rUrl = "";

            let Expiry = tokenExpiry();
            if (Expiry) {
                localStorage.clear();
            } else {
                
                if(nextProps.userInfo?.isForcePassword){
                    return;
                }else if(nextProps.userInfo.allInfo?.platformAdmin){
                    rUrl = "/dashboard-admin"
                }else if(nextProps.userInfo.allInfo?.superUser === "ADMIN"){
                    rUrl = "/dashboard-user"
                }else if(nextProps.userInfo.allInfo?.superUser === "USER"){
                    rUrl = "/dashboard"
                }else if(nextProps.userInfo.allInfo?.superUser === "NEW"){
                    rUrl = "/dashboard-user"
                }else if(nextProps.userInfo.allInfo?.superUser === null){
                    rUrl = "/dashboard"
                }

                const { location } = this.props;
                const query = parse(location.search.substr(1));

                this.props.history.push({
                    pathname: query.redirect || rUrl
                });
            }

        }
    }

    handleLogin(payload) {
        this.props.login(payload.userName, payload.password);
    }

    async handleForcePassword(payload){
        
        var userName = this.props.userInfo.username;
        var sessionId = this.props.userInfo.sessionId;
        //this.props.forcePassword(userName, payload.password, sessionId);

        let response = await forceUpdatePassword(userName, payload.password, sessionId);
        if (response.status === 200) {
            this.props.forcePassword(response.data);
        }else{
            this.props.forcePassword(response.data);
        }
    }

    render() {
        return (
            <>
                {this.props.userInfo.isForcePassword ?
                    <ForceResetPassword 
                        handleForcePassword={this.handleForcePassword}
                        email={this.props.userInfo.email}
                        pending={this.state.pending}
                    />
                    :
                    <LoginForm
                        handleLogin={this.handleLogin}
                        pending={this.state.pending}
                    />
                }
            </>
        );
    }
}

function mapStateToProps(state) {
    const userInfo = state.user.userInfo;
    
    return {
        userInfo
    };
}

export default withRouter(
    connect(mapStateToProps, {
        login,
        loginReset,
        forcePassword
    })(LoginFormContainer)
);
