/* eslint camelcase: "off" */
import PropTypes from 'prop-types';
import React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { parse } from 'qs';
import { login, loginReset, forcePassword, logout } from '../../../ducks/gateway/login/actions';
import LoginForm from './LoginForm';
import { tokenExpiry, forceUpdatePassword } from '../../../endpoints/gateway';
import { getUserSubscriptions } from '../../../endpoints/subscription/users';
import ForceResetPassword from './ForceResetPassword';

class LoginFormContainer extends React.PureComponent {

    constructor(props, context) {
        super(props, context);

        this.state = {
            pending: false,
            sessionExpired: false,
            resetPassword: false,
            client: false,
            vendor: false,
            type: 'password',
            isForcePassword: false,
            userName: null
        };
        
    }

    componentDidMount(){
        let rUrl = "/login";
        localStorage.clear();
        this.props.logout();
        const { location } = this.props;
        const query = parse(location.search.substr(1));
        this.props.history.push({
            pathname: query.redirect || rUrl
        });
    }

    

    

    render() {
        return (
            <>
                <LoginForm
                        handleLogin={this.handleLogin}
                        pending={this.state.pending}
                    />
            </>
        );
    }
}

function mapStateToProps(state) {
    const userInfo = state.user.userInfo;
    
    return {
        userInfo
    };
}

export default withRouter(
    connect(mapStateToProps, {
        login,
        loginReset,
        forcePassword,
        logout
    })(LoginFormContainer)
);
