import React, { useState, useRef, useEffect } from 'react'
import { Link, useHistory } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux';
import UploadLogo from '../../assets/images/nodata.png';
import clientLogo from '../../assets/images/singlife.png';
import styles from './Organization.module.scss';
import { toast } from 'react-toastify';
import { useForm } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { testcase } from '../Common/APIPath';
import {uploadFiles,saveCompanyDetails,fetchCompanyUser} from '../../endpoints/gateway'
const Organization = () => {
    const history = useHistory();
    const ref = useRef();
    const organizationSchema = Yup.object().shape({

        companyName: Yup.string()
            .required('Company Name is required'),
        country: Yup.string()
            .required('Country is required'),
        website: Yup.string()
            .required('Company Website is required'),
            uen: Yup.string()
            .required('VAT is required'),
            address: Yup.string()
            .required('Address is required'),
        // acceptTerms: Yup.bool()
        // .oneOf([true], 'Accept Ts & Cs is required'),
    });


    const userDetails = useSelector(state => state.user);
    
    const userallDetails = useSelector(state => state.user.userInfo.allInfo);
    
    const { register,
        handleSubmit, setValue,
        formState: { errors, isValid }, control, reset } = useForm({
            resolver: yupResolver(organizationSchema), mode: 'onChange'
        });

    const [organizationDetails, setorganizationDetails] = useState()
    const [showDetails, setshowDetails] = useState(false)
    const [logoerror, setlogoerror] = useState(false)
    const [logoformaterror, setlogoformaterror] = useState(false)
    const [selectedLogo, setselectedLogo] = useState();
    const [islogoPicked, setislogoPicked] = useState(false);
    const [logoUploadResponse, setlogoUploadResponse] = useState();
    const [isEdit, setisEdit] = useState(false)
    const [file, setFile] = useState(UploadLogo);
    const imageValidation = (file) => {
        
        const fileType = file['type'];
        const validImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/jpg'];
        if (!validImageTypes.includes(fileType)) {
            return false
        }
        return true
    }

    const changeImageHandler = async (event) => {
        setlogoerror(false)
        setlogoformaterror(false)
        if (imageValidation(event.target.files[0])) {
            setselectedLogo(event.target.files[0])
            setislogoPicked(true)
            setFile(URL.createObjectURL(event.target.files[0]));
            uploadLogo(event.target.files[0]);
        } else {
            ref.current.value = "";
            setlogoformaterror(true);
            setselectedLogo('')
            setislogoPicked(false)
        }
    }

    const uploadLogo = async (file) => {
        const formData = new FormData();
        formData.append('files', file);       
        let response = await uploadFiles(formData)
        setlogoUploadResponse(response.data);
        if (response.data.message) {
            toast.success(response.data.message);
        }
    };

    const saveDetails = async (data, savemethod) => {       
        let response = await saveCompanyDetails(data,savemethod)
        toast.success(response.data.message);
        if (savemethod == 'PUT') {
            fetchUser()
            setisEdit(false)
        }
        if (savemethod == 'POST') {
            fetchUser()
            reset();
            ref.current.value = "";
            setislogoPicked(false)
            setselectedLogo('')
            setFile('')
        }


    }


    const onSubmit = async (data) => {        
        if (isEdit) {
            data.userId = userDetails.userInfo.userId;
            data.companyId = organizationDetails.companyId
            data.acceptTerms = true
            if (!islogoPicked) {
                data.companyLogo = organizationDetails.companyLogo
            }
            else {
                data.companyLogo = logoUploadResponse[0].attachmentid;
            }

            saveDetails(data, 'PUT')

        }
        else {

            if (!islogoPicked) {
                setlogoerror(true)
                return false
            }
            else {
                setlogoerror(false)
                data.userId = userDetails.userInfo.userId;
                data.companyLogo = logoUploadResponse[0].attachmentid;
                data.acceptTerms = true;
                saveDetails(data, 'POST')
            }
           
        }

    }


    useEffect(() => {
        fetchUser();
    }, [])


    useEffect(() => {
        if (showDetails) {
            const fields = ['companyName', 'country', 'website','uen','address'];
            fields.forEach(field => setValue(field, organizationDetails[field]));
        }
    }, [isEdit])

    const fetchUser = async () => {
            let response = await fetchCompanyUser(userDetails.userInfo.userId)
            if (response.data.message) {
                setshowDetails(false)
            }
            else {
                setshowDetails(true)
                setorganizationDetails(response.data)
                setFile(`https://dtlehta1thuw9.cloudfront.net/testcasemgmt/api/attachment/views/${response.data?.companyLogo}`)
            }
    }

    const organizationEdit = () => {
        setisEdit(!isEdit)
    }
    return (
        <div className={`mx-auto ${styles.organizationPage}`}>
            <div className={`${styles.signUpForm_section}`}>
                <div className="col-md-8 offset-1">
                    {showDetails ?
                        <>
                            {!isEdit ?
                                <> 
                                    <div className='row my-4 align-items-center'>
                                        <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Name</div>
                                        <div className='col-md-8'><div className={styles.OrgItem}>{organizationDetails?.companyName}</div></div>
                                    </div>
                                    <div className='row my-4 align-items-center'>
                                        <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Logo</div>
                                        <div className='col-md-8'>
                                            <div className={styles.logo_upload_section}>
                                                <img src={`https://dtlehta1thuw9.cloudfront.net/testcasemgmt/api/attachment/views/${organizationDetails?.companyLogo}`} className={styles.logoUpload} alt="Company logo" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className='row my-4 align-items-center'>
                                        <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Website</div>
                                        <div className='col-md-8'><div className={styles.OrgItem}>{organizationDetails?.website}</div></div>
                                    </div>
                                    <div className='row my-4 align-items-center'>
                                        <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Country</div>
                                        <div className='col-md-8'><div className={styles.OrgItem}>{organizationDetails?.country}</div></div>
                                    </div>
                                    <div className='row my-4 align-items-center'>
                                        <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>VAT </div>
                                        <div className='col-md-8'><div className={styles.OrgItem}>{organizationDetails?.uen}</div></div>
                                    </div> 
                                    <div className='row my-4 align-items-center'>
                                        <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Address </div>
                                        <div className='col-md-8'>
                                            <p className={`m-0 ${styles.OrgItem}`}>{organizationDetails?.address}</p> 
                                        </div>
                                    </div>                                    

                                    {(userDetails.userInfo.allInfo.platformAdmin || userDetails.userInfo.allInfo.productAdmin) &&

                                        <div className='row offset-4 mt-2 pb-4'>
                                            <button className={`btn mt-2 btn_primary w-75`} type="button" onClick={organizationEdit}> Edit Details </button><br />
                                        </div>

                                    }
                                </> :
                                <>
                                    <form onSubmit={handleSubmit(onSubmit)}>
                                        <div className='pt-4'>

                                            <div className='row my-4 align-items-center'>
                                                <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Name <span className={styles.textdanger}>*</span></div>
                                                <div className='col-md-8'>
                                                    <input type="text" {...register("companyName", { required: true })} className={`form-control ${errors.companyName ? 'invalid' : ''}`} id="company" aria-describedby="company" placeholder="Company Name*" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', fontSize: '.9rem' }} />
                                                    <span className={styles.error}>{errors.companyName?.message}</span>
                                                </div>
                                            </div>
                                            <div className='row my-4 align-items-center'>
                                                <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Logo <span className={styles.textdanger}>*</span></div>
                                                <div className='col-md-8'>
                                                    <div className='d-flex align-items-center gap-4'>
                                                        <div className={styles.logo_upload_section}>
                                                            <img src={file} className={styles.logoUpload} alt="Company logo" />
                                                            <p className={`mb-0 mt-1 ms-1 ${styles.upload_content}`}>File size 2mb, format JPG, PNG</p>
                                                        </div>
                                                        <div className={styles.fileUploadWrapper}>
                                                            <button className={`btn ${styles.browseBtn}`} ><i class="bi bi-folder"></i></button>
                                                            <input className={styles.customfileinput} name="file" type="file" ref={ref} onChange={changeImageHandler} />
                                                        </div>
                                                    </div>
                                                </div>
                                                {
                                                    logoerror &&
                                                    <span className='upload_content' style={{ color: '#FF4E00' }}>
                                                        Logo Required
                                                    </span>
                                                }
                                                {
                                                    logoformaterror &&
                                                    <span className='upload_content' style={{ color: '#FF4E00' }}>
                                                        Invalid Format. Please upload image format
                                                    </span>
                                                }
                                                {/* <span className='upload_content' style={{ color: '#FF4E00' }}>
                                                    {islogoPicked &&
                                                        <div><p className='pt-2 text-info'>Filename: <b>{selectedLogo.name}</b> ready for upload</p></div>
                                                    }
                                                </span> */}
                                            </div>
                                            <div className='row my-4 align-items-center'>
                                                <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Country <span className={styles.textdanger}>*</span></div>
                                                <div className='col-md-8'>
                                                    <select {...register("country", { required: true })} className="form-select" aria-label="Default select example" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', boxShadow: 'none', fontSize: '.9rem' }}>
                                                        <option selected>India</option>
                                                        <option value="United States">United States</option>
                                                        <option value="Europe">Europe</option>
                                                        <option value="Russia">Russia</option>
                                                    </select>
                                                    <span className={styles.error}>{errors.country?.message}</span>
                                                </div>
                                            </div>
                                            <div className='row my-4 align-items-center'>
                                                <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Website <span className={styles.textdanger}>*</span></div>
                                                <div className='col-md-8'>
                                                    <input type="text" {...register("website", { required: true })} className={`form-control ${errors.website ? 'invalid' : ''}`} id="company" aria-describedby="company" placeholder="Company website" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', boxShadow: 'none', fontSize: '.9rem' }} />
                                                    <span className={styles.error}>{errors.website?.message}</span>
                                                </div>
                                            </div>
                                            <div className='row my-4 align-items-center'>
                                                <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>VAT <span className={styles.textdanger}>*</span></div>
                                                <div className='col-md-8'>
                                                    <input type="text" {...register("uen", { required: true })} className="form-control" id="vat" aria-describedby="company" placeholder="Enter the VAT number" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', fontSize: '.9rem' }} />
                                                    <span className={styles.error}>{errors.uen?.message}</span>
                                                </div>
                                            </div> 
                                            <div className='row my-4 align-items-center'>
                                                <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Address <span className={styles.textdanger}>*</span></div>
                                                <div className='col-md-8'>
                                                    <textarea type="text" rows={4}  {...register("address", { required: true })} className="form-control" id="address" aria-describedby="address" placeholder="Enter the Address" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', fontSize: '.9rem', height: '120px' }} />
                                                    <span className={styles.error}>{errors.address?.message}</span>
                                                </div>
                                            </div>                                            
                                        </div>
                                        <div className='row offset-4 mt-2 pb-4'>
                                            <button className={`btn mt-2 px-4 btn_primary`} type="submit">Update</button><br />
                                            <button className={`btn mt-2 px-4 btn_link`} type="button" onClick={organizationEdit}>Cancel</button>
                                        </div>
                                    </form>
                                </>
                            }
                        </>
                        :
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <div className='pt-4'>
                                {/* <div className='row my-4 align-items-center'>
                                    <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Job Title</div>
                                    <div className='col-md-8'>
                                        <input type="text" {...register("jobTtile", { required: true })} className={`form-control  ${errors.jobTtile ? '' : ''}`} id="jobTitle" aria-describedby="jobTitle" placeholder="Job Title*" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', fontSize: '.9rem' }} />
                                        <span className={styles.error}>{errors.jobTtile?.message}</span>
                                    </div>
                                </div> */}
                                <div className='row my-4 align-items-center'>
                                    <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Name <span className={styles.textdanger}>*</span></div>
                                    <div className='col-md-8'>
                                        <input type="text" {...register("companyName", { required: true })} className={`form-control ${errors.companyName ? 'invalid' : ''}`} id="company" aria-describedby="company" placeholder="Company Name*" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', fontSize: '.9rem' }} />
                                        <span className={styles.error}>{errors.companyName?.message}</span>
                                    </div>
                                </div>
                                <div className='row my-4 align-items-center'>
                                    <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Logo <span className={styles.textdanger}>*</span></div>
                                    <div className='col-md-8'>
                                        <div className='d-flex align-items-center gap-4'>
                                            <div className={styles.logo_upload_section}>
                                                <img src={file} className={styles.logoUpload} alt="Company logo" />
                                                <p className={`mb-0 mt-1 ms-1 ${styles.upload_content}`}>File size 2mb, format JPG, PNG</p>
                                            </div>
                                            <div className={styles.fileUploadWrapper}>
                                                <button className={`btn ${styles.browseBtn}`} ><i class="bi bi-folder"></i></button>
                                                <input className={styles.customfileinput} name="file" type="file" ref={ref} onChange={changeImageHandler} />
                                            </div>
                                        </div>
                                    </div>
                                    {
                                        logoerror &&
                                        <span className='upload_content' style={{ color: '#FF4E00' }}>
                                            Logo Required
                                        </span>
                                    }
                                    {
                                        logoformaterror &&
                                        <span className='upload_content' style={{ color: '#FF4E00' }}>
                                            Invalid Format. Please upload image format
                                        </span>
                                    }
                                    {/* <span className='upload_content' style={{ color: '#FF4E00' }}>
                                        {islogoPicked &&
                                            <div><p className='pt-2 text-info'>Filename: <b>{selectedLogo.name}</b> ready for upload</p></div>
                                        }
                                    </span> */}
                                </div>
                                <div className='row my-4 align-items-center'>
                                    <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Country <span className={styles.textdanger}>*</span></div>
                                    <div className='col-md-8'>
                                        <select {...register("country", { required: true })} className="form-select" aria-label="Default select example" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', boxShadow: 'none', fontSize: '.9rem' }}>
                                            <option selected>India</option>
                                            <option value={1}>United States</option>
                                            <option value={2}>Europe</option>
                                            <option value={3}>Russia</option>
                                        </select>
                                        <span className={styles.error}>{errors.country?.message}</span>
                                    </div>
                                </div>

                                <div className='row my-4 align-items-center'>
                                    <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Website <span className={styles.textdanger}>*</span></div>
                                    <div className='col-md-8'>
                                        <input type="text" {...register("website", { required: true })} className={`form-control ${errors.website ? 'invalid' : ''}`} id="company" aria-describedby="company" placeholder="Company website" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', boxShadow: 'none', fontSize: '.9rem' }} />
                                        <span className={styles.error}>{errors.website?.message}</span>
                                    </div>
                                </div>
                                <div className='row my-4 align-items-center'>
                                    <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>VAT <span className={styles.textdanger}>*</span></div>
                                    <div className='col-md-8'>
                                        <input type="text" {...register("uen", { required: true })} className="form-control" id="vat" aria-describedby="company" placeholder="Enter the VAT number" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', fontSize: '.9rem' }} />
                                        <span className={styles.error}>{errors.uen?.message}</span>
                                    </div>
                                </div> 
                                <div className='row my-4 align-items-center'>
                                    <div for="exampleFormControlInput1" class={`col-md-4 text-end ${styles.formLabel}`}>Company Address <span className={styles.textdanger}>*</span></div>
                                    <div className='col-md-8'>
                                        <textarea type="text" rows={4} {...register("address", { required: true })} className="form-control" id="address" aria-describedby="address" placeholder="Enter the Address" style={{ borderColor: '#D6D6D6', borderRadius: '4px', color: '#333333', fontSize: '.9rem' }} />
                                        <span className={styles.error}>{errors.address?.message}</span>
                                    </div>
                                </div>                                                                
                            </div>
                            <div className='row offset-4 mt-2 pb-4'>
                                <button className={`btn mt-2 px-4 btn_primary w-75 mx-auto`} type="submit">Submit</button><br />
                                <button className={`btn mt-2 btn_link`} type="button">cancel</button>
                            </div>
                        </form>
                    }


                </div>
            </div>
        </div>
    )
}

export default Organization