import React, { useEffect, useState } from 'react';
import './Auth.scss'
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import Loginimage from '../../assets/images/auth/forgetpass.png'
import { yupResolver } from '@hookform/resolvers/yup';
import { OverlayTrigger, Popover } from 'react-bootstrap';
import eyeIcon from '../../assets/images/other/input/eye.svg'
import eyeOffIcon from '../../assets/images/other/input/eye_off.svg'
import * as Yup from 'yup';
import {
    Link, useHistory
} from "react-router-dom";
import Logo from '../Common/Logo/Logo'
import { createcodereset, resetclear } from '../../ducks/gateway/forgotpassword/actions';//createcode, resetpassword, 
import { createcode, resetpassword } from '../../endpoints/gateway';


const Forgotpwd = () => {
    const history = useHistory();
    const dispatch = useDispatch();
    const [viewPassword, setViewPassword] = useState(true);
    const [viewconfirmPassword, setViewconfirmPassword] = useState(true);
    const [createcodeDetails, setcreatecodeDetails] = useState(null);
    // const createcodeDetails = useSelector(state => state.createcode);
    const resetDetails = useSelector(state => state.reset);
    
    const [username, setUsername] = useState(null);
    const [submitted, setSubmitted] = useState(false);

    const personalSchema = Yup.object().shape({
        userName: Yup.string()
            .email('Email id is invalid')
            .required('Email id is required'),
    });

    const pwdSchema = Yup.object().shape({
        confirmCode: Yup.string()
            .required('Verification code is required')
            .min(6, "Verification code (6 digits only)")
            .max(6, "Verification code (6 digits only)")
            .matches(/^[0-9]+$/i, 'Enter numbers in Verification code'),
        password: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('New Password is required'))
            .matches(
                /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{12,18}$/,
                "Password (12-18) characters with alphanumeric, Upper and Lower case letters and symbols"
                // Password must be at least 12 to 18 characters long with upper and lower case, number with special case character
            ),
        repassword: Yup.string()
            .transform(x => x === '' ? undefined : x)
            .concat(Yup.string().required('Confirm Password is required'))
            .oneOf([Yup.ref('password')], 'Password does not match'),
    });

    const { register,
        handleSubmit,
        formState: { errors, isValid }, control } = useForm({
            resolver: yupResolver(personalSchema), mode: 'onChange'
        });

    const { register: registerPwd,
        handleSubmit: handleSubmitPwd,
        formState: { errors: passError, isValid: passisValis }, control: passControl, reset } = useForm({
            resolver: yupResolver(pwdSchema), mode: 'onBlur'
        });

    const onSubmit = async (data) => {

        let response = await createcode(data.userName)
        var payload;
        
        if (response.status == 200) {

            payload = {
                isCodesend: true,
                messgae: response.data.message,
                isError: false,
                error: false,
                isChange: false
            }
            setcreatecodeDetails(payload)
        } else {
            var payload = {
                isCodesend: false,
                messgae: response.response.data.message,
                isError: true,
                error: false,
                isChange: false
            }

            setcreatecodeDetails(payload)
        }

        //dispatch(createcode(data.userName));
        setUsername(data.userName);
        //reset();
    }

    const onResetPass = async (data) => {

        let response = await resetpassword(username, data.password, data.confirmCode)
       
        if (response.status == 200) {

            var payload = {
                isCodesend: false,
                messgae: response.data.message,
                isError: false,
                error: false,
                isCodeValid: false,
                isChange: true
            }

            setcreatecodeDetails(payload)
            setSubmitted(true);
            
        }else{

            var payload = {
                isCodesend: true,
                messgae: response.response.data.message,
                isError: false,
                error: false,
                isCodeValid: true,
                isChange: true
            }

            setcreatecodeDetails(payload)
            
        }

        //dispatch(createcodereset());
        //dispatch(resetpassword(username, data.password, data.confirmCode));        
        
    }

    const passwordviewChange = () => {
        setViewPassword(!viewPassword);
    }

    const passwordviewconfirmChange = () => {
        setViewconfirmPassword(!viewconfirmPassword);
    }

    useEffect(() => {
        if (resetDetails.userInfo.isChange) {
            dispatch(createcodereset());
            reset();
            setUsername(null);
            setTimeout(() => {
                dispatch(resetclear());
                history.push("/login");
                // setSubmitted(true)
            }, 2000)
        }

    }, [resetDetails.userInfo.isChange])

    const passwordPopover = (
        <Popover id="popover-basic">
            <div className='passwordtearms'>
                <p>Password Must be: </p>
                <ul>
                    <li>At least 12 to 18 characters long</li>
                    <li>Should contain upper case and lower case</li>
                    <li>Should contain a numbers with special character</li>
                </ul>
            </div>
        </Popover>
    );
    const toLogin = () => {
        history.push(`/login`);
    }
    return (
        <>
            <div className='authenticationScreen'>
                <div className='authenticationScreen_panel'>
                    <div className='authenticationScreen_panel_left'>
                        <img src={Loginimage} className="L_image" alt="Left sectionimage" style={{ width: '85%' }} />
                    </div>
                    <div className='authenticationScreen_panel_seperator'></div>
                    <div className='authenticationScreen_panel_right'>
                        <div className='authenticationScreen_panel_right_btnpanel border-0 position-relative'>
                            <div className='authenticationScreen_panel_right_formPanel_logo py-3 mx-auto my-5'>
                                <Logo />
                            </div>
                        </div>
                        <div className='authenticationScreen_panel_right_formPanel h-auto mt-0'>
                            {(createcodeDetails?.isCodesend && !createcodeDetails?.isCodeValid) &&
                                <div className="alert alert-success mt-5" style={{ fontSize: '.875rem', fontWeight: '500' }} role="alert">
                                    {createcodeDetails?.messgae}
                                </div>
                            }

                            {createcodeDetails?.isError &&
                                <div className="alert alert-danger mt-5" style={{ fontSize: '.875rem', fontWeight: '500' }} role="alert">
                                    {createcodeDetails?.messgae}
                                </div>
                            }

                            {createcodeDetails?.isCodeValid &&
                                <div className="alert alert-danger mt-5" style={{ fontSize: '.875rem', fontWeight: '500' }} role="alert">
                                    {createcodeDetails?.messgae}
                                </div>
                            }

                            <div className='titleSection mx-auto'>
                                <h1>Reset password</h1>
                                <p className='mt-2 mb-0'>We’ll send you an email with a verification code to reset your password.</p>
                            </div>
                            {submitted ?
                                <>
                                    <div className="text-center mx-auto">
                                        <div className="alert alert-success mt-5" style={{ fontSize: '.875rem', fontWeight: '500' }} role="alert">
                                            Password Reset Successfully
                                        </div>
                                        <Link to={"/login"} className="btn btn_auth_submit py-2 mx-auto" style={{ marginTop: '8rem' }}>
                                            Back to Login
                                        </Link>
                                    </div>
                                </> 
                                :
                                <>
                                    <form className="row my-3 g-0 mx-auto " onSubmit={!createcodeDetails?.isCodesend ? handleSubmit(onSubmit) : handleSubmitPwd(onResetPass)}>
                                        {!createcodeDetails?.isCodesend ?
                                            <div className='col-sm-12'>
                                                <div className='op_input_block'>
                                                    <label for="exampleFormControlInput1" class="form-label d-none">Email ID <span className='text-danger'>*</span></label>
                                                    <input disabled={createcodeDetails?.isCodesend} type="text" {...register("userName", { required: true })} className={`form-control ${errors.userName ? 'invalid' : ''}`} id="userName" aria-describedby="userName" placeholder="Email ID" />
                                                    <span className="input_error_msg">{errors.userName?.message}</span>
                                                </div>
                                            </div> :
                                            <>
                                                <div className='col-sm-12'>
                                                    <div className='op_input_block'>
                                                        <label for="exampleFormControlInput1" class="form-label d-none">OTP <span className='text-danger'>*</span></label>
                                                        <input type="text" {...registerPwd("confirmCode", { required: true })} className={`form-control ${passError.confirmCode ? 'invalid' : ''}`} id="code" aria-describedby="code" placeholder="Enter OTP" />
                                                        <span className="input_error_msg">{passError.confirmCode?.message}</span>
                                                    </div>
                                                </div>
                                                <div className='col-sm-12 bottom-space'>
                                                    <div className='op_input_block'>
                                                        <div className="passwordInput">
                                                            <label for="exampleFormControlInput1" class="form-label d-none">New Password <span className='text-danger'>*</span></label>
                                                            <input type={viewPassword ? 'password' : 'text'} {...registerPwd("password", { required: true })} className={`form-control ${passError.password ? 'invalid' : ''}`} id="InputPassword" placeholder="Enter New Password" />
                                                            <span className="icon-view" onClick={passwordviewChange}>
                                                                {viewPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                                            </span>
                                                        </div>
                                                        <span className="input_error_msg">{passError.password?.message}</span>
                                                    </div>
                                                </div>
                                                <div className='col-sm-12'>
                                                    <div className='op_input_block'>
                                                        <div className="passwordInput">
                                                            <label for="exampleFormControlInput1" class="form-label d-none">Confirm Password <span className='text-danger'>*</span></label>
                                                            <input type={viewconfirmPassword ? 'password' : 'text'} {...registerPwd("repassword", { required: true })} className={`form-control ${passError.confirmpassword ? 'invalid' : ''}`} id="confirmInputPassword" placeholder="Re-Enter the New Password" />
                                                            <span className="icon-view" onClick={passwordviewconfirmChange}>
                                                                {viewconfirmPassword ? <img src={eyeOffIcon} alt='' /> : <img src={eyeIcon} alt='' />}
                                                            </span>
                                                        </div>
                                                        <span className="input_error_msg">{passError.repassword?.message}</span>
                                                    </div>
                                                </div>
                                            </>
                                        }
                                        <div className='col-12 text-center' style={{ marginTop: '5rem' }}>
                                            <button className="btn btn_auth_submit w-75 mb-2" type="submit">Reset Password</button>
                                            <button className="btn btn_link w-75 mt-2" onClick={() => toLogin()} type="button">Cancel</button>
                                        </div>
                                    </form>
                                </>

                            }
                        </div>

                    </div>
                </div>
            </div>
        </>
    )
}
export default Forgotpwd
