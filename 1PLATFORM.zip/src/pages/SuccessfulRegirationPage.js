import React from "react";
import verifyUser from "./auth.service";
import { Link } from "react-router-dom";
import './Sccuessfull.scss'

const SuccessfulRegirationPage = (props) => {
  if (props.match.path === "/regconfirm/:confirmationCode") {
        verifyUser(props.match.params.confirmationCode);
  }

  return (
    <div className="container">
      <header className="jumbotron">
        <h3>
          <strong>{props.match.params.confirmationCode}</strong>
        </h3>
        <p>
        An email has been sent to you. Do check and verify your account using the email. 
        If you have not received your verification email, please check your junk mail folder.
        </p>
        <Link to={"/login"}>
        Back to Login
      </Link>
      </header>
      
    </div>
  );
};

export default SuccessfulRegirationPage;