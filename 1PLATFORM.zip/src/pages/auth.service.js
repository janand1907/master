
import axios from 'axios';
const BASE_URL = 'http://3.110.159.102:7000'
const verifyUser = (code) => {
    
    return axios.post(BASE_URL + "/confirm/" + code).then((response) => {
      return response.data;
    });
};

export default verifyUser;