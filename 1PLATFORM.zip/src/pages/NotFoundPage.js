import React, { Component } from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import * as i18n from '../i18n/en/pages.json'
import style from './ErrorPage.scss';

const NotFoundPage = ({ history }) => {
	return (
		<div className={style.root}>
			<header className={style.header}>
				{/* <img src={magichat} /> */}
				<div className={style.textArea}>
					<h4 style={{ 'color': '#00b88d' }}>{i18n.notFoundPage.magician}</h4>
					<h6>{i18n.notFoundPage.endedUp}</h6>
					<p className={style.paragraph}>{i18n.seeYouBack}</p>
				</div>
			</header>
			<footer className={style.footer}>
				<button className={style.backBtn} onClick={() => history.push('/welcome')}>Go Back</button>
			</footer>
		</div>

	);
};

NotFoundPage.propTypes = {
	/**
	 * @ignore react-router
	 */
	history: PropTypes.shape({
		push: PropTypes.func.isRequired
	}).isRequired
};

export default withRouter(NotFoundPage);
