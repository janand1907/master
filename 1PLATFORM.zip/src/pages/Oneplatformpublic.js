import React, { Component } from 'react'
import { Switch, Redirect, Route } from 'react-router-dom';
import Contact from '../components/Publicpage/Contact';
import Home from '../components/Publicpage/Home';
import Quantify from '../components/Publicpage/Quantify';
import Service from '../components/Publicpage/Service';
import Terms from '../components/Publicpage/Terms';
import Privacy from '../components/Publicpage/Privacy';
const Oneplatformpublic = () => {
    return (
        <div>
            <Switch>
                <Route
                    key="home"
                    path="/(home)"
                    exact={true}
                    component={Home}
                />
                <Route
                    key="quantify"
                    path="/(quantify)"
                    exact={true}
                    component={Quantify}
                />
                <Route
                    key="contact"
                    path="/(contact)"
                    exact={true}
                    component={Contact}
                />
                <Route
                    key="service"
                    path="/(service)"
                    exact={true}
                    component={Service}
                />                                
                <Route
                    key="terms"
                    path="/(terms)"
                    exact={true}
                    component={Terms}
                />
                <Route
                    key="privacy"
                    path="/(privacy)"
                    exact={true}
                    component={Privacy}
                />                                                                
            </Switch>
        </div>
    )
}

export default Oneplatformpublic