import React from 'react'

const Noaccess = () => {
  return (
    <div>Contact your Admin to get Access</div>
  )
}

export default Noaccess