import React, { Component } from 'react'
import { Switch, Redirect, Route } from 'react-router-dom';
import GatewayMaster from '../layout/GatewayMasterPage';
import LoginFormContainer from '../components/gateway/login/LoginFormContainer';
import LogoutContainer from '../components/gateway/login/LogoutContainer';
const Register = React.lazy(() => import('../components/gateway/Register'));
const ForgotPwd = React.lazy(() => import ('../components/gateway/Forgotpwd'));

export default class GatewayPage extends Component {
    render() {
        return (
            <div className='h-100'>
                <GatewayMaster>
                    <Switch>
                        <Route
                            key="login"
                            path="/(login)"
                            exact={true}
                            component={LoginFormContainer}
                        />
                        <Route
                            key="register"
                            path="/(register)"
                            exact={true}
                            component={Register}
                        />
                        
                        <Route
                            key="forgotpwd"
                            path="/(forgotpwd)"
                            exact={true}
                            component={ForgotPwd}
                        />

                        <Route
                            key="logout"
                            path="/(logout)"
                            exact={true}
                            component={LogoutContainer}
                        />
                       
                    </Switch>
                </GatewayMaster>
            </div>
        )
    }
}
