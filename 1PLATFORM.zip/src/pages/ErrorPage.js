import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Link } from 'react-router-dom';

import * as i18n from '../i18n/en/pages.json'
import style from './ErrorPage.scss';

export class ErrorPage extends Component {
    render() {
        return (
            <div className={style.root}>
			<div className={style.errorPageContainer}>
				<h4>Whoops...</h4>
				<h6>{i18n.errorPage}</h6>
				<p>
					<Link to="/userbase">Take me back</Link>
				</p>
			</div>
		</div>
        )
    }
}

const mapStateToProps = (state) => ({
    
})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(ErrorPage)
