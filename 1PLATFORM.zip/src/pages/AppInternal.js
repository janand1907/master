import React, { Component } from 'react'
import PropTypes from 'prop-types'
import MasterPage from '../layout/MasterPage';
import { connect } from 'react-redux'
import { Switch, Redirect, Route } from 'react-router-dom';

//Admin flow Subscription
const Subscriptionapprove = React.lazy(() => import('../components/SubscriptionAdminFlow/Approval'));
const SubscriptionUsage = React.lazy(() => import('../components/SubscriptionAdminFlow/SubscriptionUsage'));
const SubscriptionDetails = React.lazy(() => import('../components/SubscriptionAdminFlow/SubscriptionDetails'));
const AdminSubscriptionPlan = React.lazy(() => import('../components/SubscriptionAdminFlow/AdminSubscriptionPlan'));
const ListofPlans = React.lazy(() => import('../components/SubscriptionAdminFlow/ListofPlans'));
const ActiveProductDetail = React.lazy(() => import('../components/SubscriptionAdminFlow/ActiveProductDetail'));
const ProductPlanDetail = React.lazy(() => import('../components/SubscriptionAdminFlow/ProductPlanDetail'));
// End of Admin flow Subscription

//New Subscription
const DashboardAdmin = React.lazy(() => import('../components/PlatformAdmin/Dashboard'));
const SubscriptionLists = React.lazy(() => import('../components/PlatformAdmin/SubscriptionLists'));
const FeaturesLists = React.lazy(() => import('../components/PlatformAdmin/FeaturesLists'));
const CreatePlanFeature = React.lazy(() => import('../components/PlatformAdmin/CreatePlanFeature'));
const CreateSubscriptionPlan = React.lazy(() => import('../components/PlatformAdmin/CreateSubscriptionPlan'));
const SubscribedUsersList = React.lazy(() => import('../components/PlatformAdmin/manageUsers/SubscribedUsersList'));
const EditSubscribedUser = React.lazy(() => import('../components/PlatformAdmin/manageUsers/EditSubscribedUser'));
const ViewSubscribedUser = React.lazy(() => import('../components/PlatformAdmin/manageUsers/ViewSubscribedUser'));
const ViewAllUser = React.lazy(() => import('../components/PlatformAdmin/manageUsers/ViewAllUser'));
const UserProductList = React.lazy(() => import('../components/PlatformAdmin/userAdmin/UserProductList'));
const Plandetail = React.lazy(() => import('../components/PlatformAdmin/userAdmin/Plandetails'));
const UserSubPlan = React.lazy(() => import('../components/PlatformAdmin/userAdmin/UserSubPlan'));
const Payment = React.lazy(() => import('../components/PlatformAdmin/userAdmin/Payment'));
const Productdetails = React.lazy(() => import('../components/PlatformAdmin/userAdmin/Productdetails'));
const PaymentMethod = React.lazy(() => import('../components/PlatformAdmin/PaymentMethod'));
const PlanUserList = React.lazy(() => import('../components/PlatformAdmin/PlanUserList'));
const DashboardUserAdmin = React.lazy(() => import('../components/PlatformAdmin/userAdmin/Dashboard'));
const DashboardUser = React.lazy(() => import('../components/PlatformAdmin/user/Dashboard'));
const ProductDiscount = React.lazy(() => import('../components/PlatformAdmin/ProductDiscount'));
const ManageUsers = React.lazy(() => import('../components/PlatformAdmin/userAdmin/ManageUsers'));
const PaymentStatus = React.lazy(() => import('../components/PlatformAdmin/userAdmin/PaymentStatus'));
const CreateUser = React.lazy(() => import('../components/PlatformAdmin/userAdmin/CreateUser'));
const ApproveContactus = React.lazy(() => import('../components/PlatformAdmin/manageUsers/ApproveContactus'));
//End New Subscription

// Subscription Screens
const Subscription = React.lazy(() => import('../components/Subscription/Subscribe'));
const Billing = React.lazy(() => import('../components/Subscription/Billing'));
const Checkout = React.lazy(() => import('../components/Subscription/Checkout'));
// End of Subscription Screens

// User Management Static Pages
const Productadmin = React.lazy(() => import('../components/UserManagement/ProductAdmin/Productadmin'));
const Platformadmin = React.lazy(() => import('../components/UserManagement/PlatformAdmin/Platformadmin'));
const Inviteuser = React.lazy(() => import('../components/UserManagement/PlatformAdmin/Inviteuser'));
const Inviteuseradmin = React.lazy(() => import('../components/UserManagement/ProductAdmin/InviteUserAdmin'));
const Manageuser = React.lazy(() => import('../components/UserManagement/PlatformAdmin/Manageuser'));
const Manageuseradmin = React.lazy(() => import('../components/UserManagement/ProductAdmin/ManageuserAdmin'));
//const ProductDetails = React.lazy(() => import('../components/UserManagement/Productdetails'));
// End of User Management Static Pages

const Organization = React.lazy(() => import('../components/gateway/Organization'));
//const DashboardAdmin = React.lazy(() => import('../components/UserManagement/ProductAdmin/DashboardAdmin'));
const Profile = React.lazy(() => import('../components/Accountsettings/Profile.js'));

const Noaccess = React.lazy(() => import('./static/Noaccess'));

//const Plandetail = React.lazy(() => import('../components/Subscriptionnew/Plandetails'))
const Newsubdetails = React.lazy(() => import('../components/Subscriptionnew/Newsubdetails'))
const SubscribedPlans = React.lazy(() => import('../components/Subscriptionnew/SubscribedPlans'))
const ManageSubscribedUsers = React.lazy(() => import('../components/Subscriptionnew/ManageSubscribedUsers'))
const SubUserDetails = React.lazy(() => import('../components/Subscriptionnew/SubUserDetails'))
const SubscriptionManagement = React.lazy(() => import('../components/Subscriptionnew/Admin/SubscriptionManagement'))
const CreateSubscriptionList = React.lazy(() => import('../components/Subscriptionnew/Admin/CreateSubscriptionList'))
const SubscriptionEntry = React.lazy(() => import('../components/Subscriptionnew/Admin/SubscriptionEntry'))
const ProductSubList = React.lazy(() => import('../components/Subscriptionnew/ProductSubList'))
const Paymentmode = React.lazy(() => import('../components/Subscriptionnew/Admin/Paymentmode'))
const EditSubscriptiondetails = React.lazy(() => import('../components/Subscriptionnew/Admin/EditSubscriptiondetails'))

class AppInternal extends Component {

    componentDidMount() {

    }

    render() {
        return (
            <div className='h-100'>
                {this.props.user.userInfo.allInfo &&
                    <MasterPage>
                        <Switch>

                            {/* Admin flow Subscription */}
                            <Route key="approve" path="/(approve)" exact={true} component={Subscriptionapprove} />
                            <Route key="subscriptionUsage" path="/(subscriptionUsage)" exact={true} component={SubscriptionUsage} />
                            <Route key="Subscriptiondetails" path="/(Subscriptiondetails)" exact={true} component={SubscriptionDetails} />
                            <Route key="adminSubscriptionPlan" path="/(adminsubscriptionplan)" exact={true} component={AdminSubscriptionPlan} />
                            <Route key="listofplans" path="/(listofplans)" exact={true} component={ListofPlans} />
                            <Route key="activeproductdetail" path="/activeproductdetail/:productId" exact={true} component={ActiveProductDetail} />
                            <Route key="productplandetail" path="/productplandetail/:subscriptionPlanId" exact={true} component={ProductPlanDetail} />
                            <Route key="profile" path="/user-profile" exact={true} component={Profile} />
                            {/* End of Admin flow Subscription */}


                            {/* Subscription */}
                            <Route key="subscription" path="/subscription/:productId" exact={true} component={Subscription} />
                            <Route key="billing" path="/billing" exact={true} component={Billing} />
                            <Route key="checkout" path="/(checkout)" exact={true} component={Checkout} />
                            {/*End of  Subscription */}

                            {/* New Subscription */}
                            {/* <Route key="plandetails" path="/(plandetails)" exact={true} component={Plandetail} /> */}
                            <Route key="productSubList" path="/(productSubList)" exact={true} component={ProductSubList} />
                            <Route key="newsubdetails" path="/(newsubdetails)" exact={true} component={Newsubdetails} />
                            <Route key="subscribedPlans" path="/(subscribedPlans)" exact={true} component={SubscribedPlans} />
                            <Route key="manageSubscribedUsers" path="/(manageSubscribedUsers)" exact={true} component={ManageSubscribedUsers} />
                            <Route key="subUserDetails" path="/(subUserDetails)" exact={true} component={SubUserDetails} />

                            <Route key="subscriptionManagement" path="/(subscriptionManagement)" exact={true} component={SubscriptionManagement} />
                            <Route key="createSubscriptionList" path="/(createSubscriptionList)" exact={true} component={CreateSubscriptionList} />
                            <Route key="subscriptionEntry" path="/(subscriptionEntry)" exact={true} component={SubscriptionEntry} />
                            <Route key="paymentmode" path="/(paymentmode)" exact={true} component={Paymentmode} />
                            <Route key="editSubscriptiondetails" path="/(editSubscriptiondetails)" exact={true} component={EditSubscriptiondetails} />
                            {/* End of New Subscription */}
                            <Route key="SubscriptionLists" path="/(SubscriptionLists)" exact={true} component={SubscriptionLists} />
                            <Route key="FeaturesLists" path="/(FeaturesLists)" exact={true} component={FeaturesLists} />
                            <Route key="CreatePlanFeature" path="/(CreatePlanFeature)" exact={true} component={CreatePlanFeature} />
                            <Route key="updatefeature" path="/updatefeature/:featureId" exact={true} component={CreatePlanFeature} />
                            <Route key="CreateSubscriptionPlan" path="/(CreateSubscriptionPlan)" exact={true} component={CreateSubscriptionPlan} />
                            <Route key="updateplan" path="/updateplan/:productId/:planId" exact={true} component={CreateSubscriptionPlan} />
                            <Route key="viewplan" path="/viewplan/:productId/:planId" exact={true} component={CreateSubscriptionPlan} />
                            <Route key="SubscribedUsersList" path="/(SubscribedUsersList)" exact={true} component={SubscribedUsersList} />
                            <Route key="EditSubscribedUser" path="/(EditSubscribedUser)" exact={true} component={EditSubscribedUser} />
                            <Route key="ViewSubscribedUser" path="/ViewSubscribedUser" exact={true} component={ViewSubscribedUser} />
                            <Route key="allusers" path="/allusers" exact={true} component={ViewAllUser} />
                            <Route key="plandetails" path="/plandetails" exact={true} component={Plandetail} />
                            <Route key="subproduct" path="/subproduct" exact={true} component={UserSubPlan} />
                            <Route key="payment" path="/payment" exact={true} component={Payment} />
                            <Route key="productview" path="/productview" exact={true} component={Productdetails} />
                            <Route key="planusers" path="/planusers" exact={true} component={PlanUserList} />
                            <Route key="dashboard-user" path="/dashboard-user" exact={true} component={DashboardUserAdmin} />
                            <Route key="dashboard" path="/dashboard" exact={true} component={DashboardUser} />
                            <Route key="dashboard-admin" path="/dashboard-admin" exact={true} component={DashboardAdmin} />
                            <Route key="manage-user" path="/manage-user" exact={true} component={ManageUsers} />
                            <Route key="status" path="/payment/status" exact={true} component={PaymentStatus} />
                            <Route key="create-user" path="/create-user" exact={true} component={CreateUser} />
                            <Route key="update-user" path="/update-user" exact={true} component={CreateUser} />
                            <Route key="approve-contact" path="/approve-contact" exact={true} component={ApproveContactus} />
                            <Route key="plan-discount" path="/(plan-discount)" exact={true} component={ProductDiscount} />
                            <Route key="paymentMethod" path="/(paymentMethod)" exact={true} component={PaymentMethod} />

                            <Route key="adminsubscription" path="/adminsubscription" exact={true} component={UserProductList} />


                            {/*User Management Static Page  */}

                            <Route key="noaccess" path="/(noaccess)" exact={true} component={Noaccess} />
                            <Route key="organization" path="/(organization)" exact={true} component={Organization} />

                            <Route key="manageuseradmin" path="/(manageuseradmin)" exact={true} component={Manageuseradmin} />

                            <Route key="inviteuseradmin" path="/inviteuseradmin/:productId" exact={true} component={Inviteuseradmin} />

                            <Route key="productadmin" path="/(productadmin)" exact={true} component={Productadmin} />
                            {/* <Route key="dashboardadmin" path="/(dashboardadmin)" exact={true} component={DashboardAdmin} /> */}


                            <Route key="profile" path="/profile" exact={true} component={Profile} />


                            {this.props.user.userInfo.allInfo.platformAdmin ? <>

                                <Route key="manageuser" path="/(manageuser)" exact={true} component={Manageuser} />
                                <Route key="inviteuser" path="/(inviteuser)" exact={true} component={Inviteuser} />
                                <Route key="platformadmin" path="/(platformadmin)" exact={true} component={Platformadmin} />
                            </>
                                :
                                <Redirect to="/noaccess" />

                            }

                        </Switch>

                    </MasterPage>
                }
            </div>
        )
    }
}


function mapStateToProps(state) {
    const userInfo = state.user.userInfo;
    return {
        user: state.user,
        menu: state.menu,
        userInfo: userInfo
    };
}

export default connect(mapStateToProps, null)(AppInternal);
