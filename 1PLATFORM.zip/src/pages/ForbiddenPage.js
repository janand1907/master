import React, { Component } from 'react'
import { connect } from 'react-redux'
import style from './ErrorPage.scss';
import * as i18n from '../i18n/en/pages.json'

export class ForbiddenPage extends Component {
    render() {
        return (
            <div className={style.root}>
            <header className={style.header}>
                {/* <img className={style.errorImage} src={mountains} /> */}
                <div className={style.textArea}>
                    <p>Error 403</p>
                    <h4 style={{ 'color': '#00b88d' }}>{i18n.forbiddenPage.awkward}</h4>
                    <h6>{i18n.forbiddenPage.shouldnt}</h6>
                    <p className={style.paragraph}>{i18n.seeYouBack}</p>
                </div>
            </header>
            <footer className={style.footer}>
                <button className={style.backBtn} onClick={() => this.props.history.push('/welcome')}>Go Back</button>
            </footer>
        </div>
        )
    }
}

const mapStateToProps = (state) => ({
    
})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(ForbiddenPage)
