import {
    fetchApi,
    getTescaseManagementApi,
    getplatformadminApi,
    getSubscribeApi,
    getProductSubscribeApi,
} from '../utils/fetch-api';

import { authApi } from '../utils/authapi'
import { recordApi } from '../utils/recordapi'

import jwt_decode from "jwt-decode";
import { method } from 'lodash';


export function login(userName, password, auth_type) {
    return authApi(`/auth/login`, {
        method: 'POST',
        body: {
            email: userName,
            secret: password
        }
    });
}

export function forceUpdatePassword(userName, password, session_id) {
    debugger;
    return authApi(`/auth/force_updatePassword`, {
        method: 'POST',
        body: {
            email: userName,
            new_password: password,
            session_id: session_id
        }
    });
}

export function signup(details) {
    return authApi(`/signup/cognito`, {
        method: 'POST',
        body: {
            first_name: details.firstName,
            last_name: details.lastName,
            email: details.email,
            password: details.password,
            repassword: details.repassword,
            user_agreed_with_terms_and_conditions: details.user_agreed_with_terms_and_conditions
        }
    });
}

export function resendEmail(userName) {
    return authApi(`/auth/resend`, {
        method: 'POST',
        body: {
            "email": userName
        }
    });
}

export function createcode(userName, password) {
    return authApi(`/auth/reset_password`, {
        method: 'POST',
        body: {
            email: userName
        }
    });
}

export function resetpassword(userName, password, confirmCode) {
    return authApi(`/auth/confirm_password`, {
        method: 'POST',
        body: {
            email: userName,
            password,
            verification_code: confirmCode
        }
    });
}

export function updatePassword(payload) {
    return fetchApi(`/user/profile/update_password`, {
        method: 'POST',
        body: {
            current_password: payload.oldPassword,
            new_password: payload.password
        }
    })
}

export function getUserProducts() {
    return fetchApi(`/user/subscription`, {
        method: 'get'
    });
}

export function getAllProducts() {
    return fetchApi(`/platform/products?type=json`, {
        method: 'get'
    });
}

//Get User Subcription Products
export function getUserSubcriptionProducts() {
    return fetchApi(`/user/subscription`, {
        method: 'get'
    });
}

//Get One Platform Products
export function getOnePlatformProducts() {
    return fetchApi(`/platform/products?type=json`, {
        method: 'get'
    });
}


//Get Product Plans
export function getProductPlans(id) {
    return fetchApi(`/platform/product/plans?id=${id}`, {
        method: 'get'
    });
}

//User Subscription Request
export function userSubscriptionRequest(product_id, plan_id, duration) {
    return fetchApi(`/user/subscription?product_id=${product_id}&plan_id=${plan_id}&duration=${duration}`, {
        method: 'post'
    });
}


//Subscription Admin Get Pending List
export function subscriptionPendingDetails(type) {
    return fetchApi(`/platform/product/subscription/list?type=${type}`, {
        method: 'GET'
    })
}

//Approve/Reject License
export function approveRejectLicense(data) {
    return fetchApi(`/platform/product/subscription/update`, {
        method: 'post',
        body: {
            requested_id: data.requested_id,
            license_id: data.license_id,
            status: data.status
        }
    })
}

export function generateLicenceKey(data) {
    return fetchApi(`/platform/product/subscription/createLicense`, {
        method: 'post',
        body: {
            productId: data.productId,
            period: data.period,
            notes: data.notes
        }
    })
}

//Get License Info 
export function getLicenseInfo(product_id, license) {
    return fetchApi(`/platform/product/subscription/license_info/${product_id}/${license}`, {
        method: 'GET'
    })
}

//Search User
export function getSearchUser(keyword) {
    return fetchApi(`/platform/user/search/${keyword}`, {
        method: 'GET'
    })
}

//Active License
export function activeLicense(data) {
    return fetchApi(`/platform/product/subscription/license`, {
        method: 'POST',
        body: {
            product_id: data.product_id,
            license: data.license,
            email: data.email
        }
    })
}

export function getLicenseValidation(productId, licenseId) {
    return fetchApi(`/platform/product/subscription/license_info/${productId}/${licenseId}`, {
        method: 'GET'
    })
}

export function getSubscriptionUserDetails(url) {
    return getplatformadminApi(`${url}`, {
        method: "GET"
    })
}

// export function getAllProducts(userId) {
//     return getProductSubscribeApi(`/platform/allProducts/${userId}`, {
//         method: 'GET'
//     })
// }

//subscription details
// export function getUserProducts(details) {
//     return getplatformadminApi(`/getUserProducts/${details.userId}`, {
//         method: "GET"
//     })
// }

export function signupComplete(details) {
    return authApi(`/api/signup/cognito`, {
        method: 'PATCH',
        headers: {
            'Cookie': '_ga=GA1.1.924631854.1644574619; _gid=GA1.1.665798991.1651565894; mp_554cd4b7d1891b6d43ff3853b39f615c_mixpanel=%7B%22distinct_id%22%3A%20%22gvinoth76%2B450%40gmail.com%22%2C%22%24device_id%22%3A%20%2217ee84931d86df-0e55cbc7002cda-576153e-144000-17ee84931d910ee%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%2C%22%24user_id%22%3A%20%22gvinoth76%2B471%40gmail.com%22%7D'
        },
        body: details
    });
}
export function getCompanyDetails(userId) {
    return fetchApi(`/getCompany/${userId}`, {
        method: 'get'
    });
}
export function getUserDetails(details) {
    return fetchApi(`/user/profile`, {
        method: "GET"
    })
}
export function saveCompanyDetails(data, method) {
    return fetchApi(`/company`, {
        method: method,
        body: data
    })
}

export function fetchCompanyUser(id) {
    return fetchApi(`/getCompany/${id}`, {
        method: "GET"
    })
}

export function saveSubscribe(payload) {
    return getSubscribeApi(`/saveSubscriptionInfo`, {
        method: 'POST',
        body: payload
    })
}

export function getSubscribe(productId, subscriptionModeId) {
    return getSubscribeApi(`/getSubscriptionsForProduct/${productId}/${subscriptionModeId}`, {
        method: 'GET'
    })
}

export function sendPlatformInvite(userEmail) {
    return getProductSubscribeApi(`/invite/sendPlatformInvite/${userEmail}/1`, {
        method: 'POST'
    })
}

export function getMappedUsers(userEmail) {
    return getProductSubscribeApi(`/platform/getMappedUsers/${userEmail}`, {
        method: 'GET'
    })
}

export function getRoles() {
    return getProductSubscribeApi(`/platform/getRoles`, {
        method: 'GET'
    })
}

export function deleteMapperUser(id) {
    return getProductSubscribeApi(`/platform/deleteMappedProduct/${id}`, {
        method: 'DELETE'
    })
}

export function getProducts() {
    return getProductSubscribeApi(`/platform/getProducts`, {
        method: 'GET'
    })
}

export function getProductsCounts(userEmail) {
    return getProductSubscribeApi(`/platform/getProductsDetails/${userEmail}`, {
        method: 'GET'
    })
}

export function getUsersInOrg(userEmail) {
    return getProductSubscribeApi(`/platform/getUsersInOrg/${userEmail}`, {
        method: 'GET'
    })
}

export function inviteProductMemebr(data) {
    return getProductSubscribeApi(`/platform/userMapProductMember`, {
        method: 'GET',
        body: data
    })
}

export function getOrgProductMemebr(companyId) {
    return getProductSubscribeApi(`/platform/orgProducts/${companyId}`, {
        method: 'GET',
    })
}
export function getproductByUser(userId, productId) {
    return getProductSubscribeApi(`/platform/productByUser/${userId}/${productId}`, {
        method: 'GET',
    })
}

export function getSubscriptedProducts(companyId) {
    return getProductSubscribeApi(`/platform/getSubscriptedProducts/${companyId}`, {
        method: 'GET',
    })
}

export function productMap(REQUEST_METHOD, payload) {
    return getProductSubscribeApi(`/platform/userProductMap`, {
        method: REQUEST_METHOD,
        body: payload
    })
}

export function updateUser(payload) {
    return fetchApi(`/user/profile/update`, {
        method: 'PUT',
        body: payload
    })
}

export function getSubscribePlan() {
    return getSubscribeApi(`/getSubscriptions`, {
        method: 'GET'
    })
}

export function saveSubscribePlan(url, method, payload) {
    return getSubscribeApi(`${url}`, {
        method: method,
        body: payload
    })
}

export function getSubscriptionsModes() {
    return getSubscribeApi(`/getSubscriptionsModes`, {
        method: 'GET'
    })
}

export function planDetails(url) {
    return getSubscribeApi(`${url}`, {
        method: 'GET'
    })
}

export function allProductSubscriptionDetail(url) {
    return getSubscribeApi(`${url}`, {
        method: 'GET'
    })
}

export function getproductUsageDetails(url) {
    return getSubscribeApi(`${url}`, {
        method: 'GET'
    })
}

export function subscriptionPlanDetails(url) {
    return getSubscribeApi(`${url}`, {
        method: 'GET'
    })
}

export function subscriptionApprove(url) {
    return getSubscribeApi(`${url}`, {
        method: 'POST'
    })
}



export function saveMonthlySubscribePlan(url, method, payload) {
    return getSubscribeApi(`${url}`, {
        method: method,
        body: payload
    })
}

export function saveProductSubscribe(url, payload, method) {
    return getSubscribeApi(`${url}`, {
        method: method,
        body: payload
    })
}

export function uploadFiles(formData) {
    return fetchApi(`/user/profile_image`, {
        method: "POST",
        body: formData
    })
}

export function saveDemoForm(url, method, body) {
    return recordApi(`${url}`, {
        method: method,
        body: body
    })
}

export function tokenExpiry() {
    let token = JSON.parse(localStorage.getItem('USER_INFO'));
    
    if(token){
        let decodedToken = jwt_decode(token.allInfo.accessToken);
        let currentDate = new Date();
        // JWT exp is in seconds
        if (decodedToken.exp * 1000 < currentDate.getTime()) {
            
            return true
        } else {
              
            return false;
        }
    }else{
        return true
    }
    
}

