import {
    getSubscribeApiV2
} from '../../utils/fetch-api';

// POST METHODS STARTS 
export function createPlan(payload) {
    
    return getSubscribeApiV2(`/plan/create`, {
        method: 'POST',
        body: payload
    });
}


export function planUpdatable(payload, _plan_id) {
    
    return getSubscribeApiV2(`/plan/updatable?_plan_id=${_plan_id}`, {
        method: 'POST',
        body: payload
    });
}

export function getPlanRemove(_plan_id) {
    return getSubscribeApiV2(`/plan/remove?_plan_id=${_plan_id}`, {
        method: 'POST'
    });
}

// POST METHODS END

// GET METHOD STARTS

export function getPlanDetails(_plan_id) {
    return getSubscribeApiV2(`/plan/getDetails?_plan_id=${_plan_id}`, {
        method: 'GET'
    });
}
export function getPlanFeature(profile_id) {
    return getSubscribeApiV2(`/plan/features?profile_id=${profile_id}`, {
        method: 'GET'
    });
}
export function getPlanList(_product_id, status) {
    return getSubscribeApiV2(`/plan/list?_product_id=${_product_id}&status=${status}`, {
        method: 'GET'
    });
}
export function getUserSlot(_plan_id) {
    return getSubscribeApiV2(`/plan/getUserSlots?_plan_id=${_plan_id}`, {
        method: 'GET'
    });
}
export function getFeatureProfile(_product_id, type) {
    return getSubscribeApiV2(`/plan/feature_profiles?_product_id=${_product_id}&type=${type}`, {
        method: 'GET'
    });
}
export function getPlanFeatureDetails(_plan_id) {
    return getSubscribeApiV2(`/plan/feature_details?_plan_id=${_plan_id}`, {
        method: 'GET'
    });
}
export function getPlanDelete(_plan_id) {
    return getSubscribeApiV2(`/plan/delete?_plan_id=${_plan_id}`, {
        method: 'GET'
    });
}
export function getPlanUpdate(_plan_id) {
    return getSubscribeApiV2(`/plan/check_update?_plan_id=${_plan_id}`, {
        method: 'GET'
    });
}

export function getAllActiveUsers(_product_id, _plan_id) {
    return getSubscribeApiV2(`/plan/getAllActiveUsers?_product_id=${_product_id}&_plan_id=${_plan_id}`, {
        method: 'GET'
    });
}

export function checkOrderNumberExist(_product_id, order_number, plan_id) {
    return getSubscribeApiV2(`/plan/checkOrderNumberExist?_product_id=${_product_id}&order_number=${order_number}&_plan_id=${plan_id}`, {
        method: 'GET'
    });
}
// GET METHOD ENDS

// PUT METHOD STARTS
export function planUpdate(payload, _plan_id) {
    return getSubscribeApiV2(`/plan/update?_plan_id=${_plan_id}`, {
        method: 'PUT',
        body: payload
    })
}
//PUT METHOD ENDS