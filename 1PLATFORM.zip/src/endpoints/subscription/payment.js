import { getSubscribeApiV2 } from '../../utils/fetch-api';


// POST METHODS STARTS 
export function setPaymentOptions(payload) {
    
    return getSubscribeApiV2(`/payment/set_options`, {
        method: 'POST',
        body: payload
    });
}

// GET METHOD STARTS
export function getPaymentOptions() {
    return getSubscribeApiV2(`/payment/get_options`, {
        method: 'GET'
    });
}

// POST METHODS STARTS 
export function createPaymentSession(payload, _plan_id, _duration, _user_slot, _request_type) {
    
    return getSubscribeApiV2(`/payment/createSession?_plan_id=${_plan_id}&_duration=${_duration}&_user_slot=${_user_slot}&_request_type=${_request_type}`, {
        method: 'POST',
        body: payload
    });
}

// GET METHOD STARTS
export function getUserPaymentStatus(_session_id) {
    return getSubscribeApiV2(`/payment/details?_session_id=${_session_id}`, {
        method: 'GET'
    });
}