import { getSubscribeApiV2 } from '../../utils/fetch-api';


// POST METHODS STARTS 
export function changeOwnership(payload) {
    return getSubscribeApiV2(`/platform/user/changeOwnership`, {
        method: 'PUT',
        body: payload
    });
}

export function setAction(payload) {
    return getSubscribeApiV2(`/platform/user/set_Action`, {
        method: 'POST',
        body: payload
    });
}

export function setProductAction(payload, subscribed_id) {
    return getSubscribeApiV2(`/platform/user/product/set_Action?subscribed_id=${subscribed_id}`, {
        method: 'POST',
        body: payload
    });
}

export function setPlanRequestAction(payload, request_id) {
    return getSubscribeApiV2(`/platform/plan_request/set_Action?request_id=${request_id}`, {
        method: 'POST',
        body: payload
    });
}

// GET METHOD STARTS
export function getUserProductPlan(email, plan_id) {
    return getSubscribeApiV2(`/platform/user/${email}/product/${plan_id}`, {
        method: 'GET'
    });
}

export function getAllproducts(email) {
    return getSubscribeApiV2(`/platform/user/${email}/getAllproducts`, {
        method: 'GET'
    });
}

export function getSlotUsers(subscribed_id) {
    return getSubscribeApiV2(`/platform/user/product/slotUsers?subscribed_id=${subscribed_id}`, {
        method: 'GET'
    });
}

export function getBillings(subscribed_id) {
    return getSubscribeApiV2(`/platform/user/getBillings?subscribed_id=${subscribed_id}`, {
        method: 'GET'
    });
}

export function getBoardView() {
    return getSubscribeApiV2(`/platform/user/boardView`, {
        method: 'GET'
    });
}

export function requestPlanDetails(request_id) {
    return getSubscribeApiV2(`/platform/requestPlanDetails?request_id=${request_id}`, {
        method: 'GET'
    });
}

export function getActionDetails(request_id) {
    return getSubscribeApiV2(`/platform/get_ActionDetails?request_id=${request_id}`, {
        method: 'GET'
    });
}

export function getAllUsers(request_id) {
    return getSubscribeApiV2(`/platform/getAllUsers?request_type=${request_id}`, {
        method: 'GET'
    });
}

export function productBoardView(product_id) {
    return getSubscribeApiV2(`/platform/product/boardView?product_id=${product_id}`, {
        method: 'GET'
    });
}

