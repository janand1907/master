import {
    getSubscribeApiV2
} from '../../utils/fetch-api';

// POST METHODS STARTS
export function addFeature(payload) {
    return getSubscribeApiV2(`/feature/create_feature`, {
        method: 'POST',
        body: payload
    });
}
// POST METHODS END

// GET METHOD STARTS

export function getFeaturesLookup(_product_id, type) {
    return getSubscribeApiV2(`/feature/lookups?_product_id=${_product_id}&type=${type}`, {
        method: 'GET'
    });
}
export function getFeaturesDetails(_feature_config_id) {
    return getSubscribeApiV2(`/feature/getDetails?_feature_config_id=${_feature_config_id}`, {
        method: 'GET'
    });
}
export function getAllProductFeatures(_product_id) {
    return getSubscribeApiV2(`/feature/feature_list?_product_id=${_product_id}`, {
        method: 'GET'
    });
}

// GET METHOD ENDS

// PUT METHOD STARTS
export function featureUpdate(payload, _feature_config_id) {
    return getSubscribeApiV2(`/feature/update_feature?_feature_config_id=${_feature_config_id}`, {
        method: 'PUT',
        body: payload
    })
}
//PUT METHOD ENDS

// DELETE METHOD STARTS
export function deleteFeature(feature_config_id) {
    return getSubscribeApiV2(`/feature/delete?feature_config_id=${feature_config_id}`, {
        method: 'DELETE'
    });
}