import {
    getSubscribeApiV2
} from '../../utils/fetch-api';


// GET METHOD STARTS
export function getProducts(type) {
    return getSubscribeApiV2(`/lookup/products?type=${type}`, {
        method: 'GET'
    });
}
export function getSubProducts(_product_key, type) {
    return getSubscribeApiV2(`/lookup/sub_products?_product_key=${_product_key}&type=${type}`, {
        method: 'GET'
    });
}
export function getFeatures(_product_id, type) {
    return getSubscribeApiV2(`/lookup/features?_product_id=${_product_id}&type=${type}`, {
        method: 'GET'
    });
}
export function getDiscountDuration(type) {
    return getSubscribeApiV2(`/lookup/discount_duration?type=${type}`, {
        method: 'GET'
    });
}
export function getDiscountCondition(type) {
    return getSubscribeApiV2(`/lookup/discount_condition?type=${type}`, {
        method: 'GET'
    });
}
export function getPlanDuration(type) {
    return getSubscribeApiV2(`/lookup/plan_duration?type=${type}`, {
        method: 'GET'
    });
}

export function getAllproducts(type) {
    return getSubscribeApiV2(`/lookup/getAllproducts?type=${type}`, {
        method: 'GET'
    });
}
// GET METHOD ENDS