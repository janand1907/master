import { getSubscribeApiV2 } from '../../utils/fetch-api';

// POST METHODS STARTS 
export function saveTerms(payload) {
    
    return getSubscribeApiV2(`/platform/set_terms`, {
        method: 'PUT',
        body: payload
    });
}

// GET METHOD STARTS
export function getTerms(_session_id) {
    return getSubscribeApiV2(`/platform/terms`, {
        method: 'GET'
    });
}