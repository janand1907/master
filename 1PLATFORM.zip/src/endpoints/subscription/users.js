import { getSubscribeApiV2 } from '../../utils/fetch-api';


// PUT METHODS STARTS 
export function updateUserProduct(payload) {
    return getSubscribeApiV2(`/user/product/updateUser`, {
        method: 'PUT',
        body: payload
    });
}

// POST METHODS STARTS
export function createUserProduct(payload, _product_id) {
    return getSubscribeApiV2(`/user/product/addUser?_product_id=${_product_id}`, {
        method: 'POST',
        body: payload
    });
}

export function manualSubscriptionRequest(payload) {
    return getSubscribeApiV2(`/user/request`, {
        method: 'POST',
        body: payload
    });
}

export function createUser(payload) {
    return getSubscribeApiV2(`/user/product/createUser`, {
        method: 'POST',
        body: payload
    });
}

export function uploadFiles(formData) {
    return getSubscribeApiV2(`/api/attachment/uploadfiles`, {
        method: "POST",
        body: formData
    })
}

// GET METHODS STARTS
export function getUserSubscriptions(timezone) {

    return getSubscribeApiV2(`/user/subscriptions?timezone=${timezone}`, {
        method: 'GET'
    });
}

export function getAdminEmailDetails() {

    return getSubscribeApiV2(`/user/contact_owner`, {
        method: 'GET'
    });
}

export function getAllUserProduct(_product_id, status) {
    return getSubscribeApiV2(`/user/product/getAllUsers?_product_id=${_product_id}&status=${status}`, {
        method: 'GET'
    });
}

export function getUserPlan(_product_id, _duration_id) {
    return getSubscribeApiV2(`/user/plans?_product_id=${_product_id}&_duration_id=${_duration_id}`, {
        method: 'GET'
    });
}

export function getchangePlans(_product_id, _duration_id) {
    return getSubscribeApiV2(`/user/getchangePlans?_product_id=${_product_id}&_duration_id=${_duration_id}`, {
        method: 'GET'
    });
}

export function getUserSlots(_plan_id) {
    return getSubscribeApiV2(`/user/getUserSlots?_plan_id=${_plan_id}`, {
        method: 'GET'
    });
}

export function getSubProducts(_product_key) {
    return getSubscribeApiV2(`/user/getSubProducts?_product_key=${_product_key}`, {
        method: 'GET'
    });
}

export function getPaymentOptions() {
    return getSubscribeApiV2(`/user/getPaymentOptions`, {
        method: 'GET'
    });
}

export function getDiscountDetails(_plan_id) {
    return getSubscribeApiV2(`/user/getDiscountDetails?_plan_id=${_plan_id}`, {
        method: 'GET'
    });
}

export function getChargeDetails(_request_type, _plan_id, _duration_id, required_slot) {
    return getSubscribeApiV2(`/user/getChargeDetails?_request_type=${_request_type}&_plan_id=${_plan_id}&_duration_id=${_duration_id}&required_slot=${required_slot}`, {
        method: 'GET'
    });
}

export function purchasedSlotDetails() {
    return getSubscribeApiV2(`/user/product/purchasedSlotDetails`, {
        method: "GET"
    })
}

export function checkUser(email) {
    return getSubscribeApiV2(`/user/product/checkUser/${email}`, {
        method: "GET"
    })
}

export function subscribedProducts(type) {
    return getSubscribeApiV2(`/user/lookup/subscribedProducts?type=${type}`, {
        method: "GET"
    })
}

export function getApi(URL) {
    return getSubscribeApiV2(URL, {
        method: "GET"
    })
}

export function userViewBoards() {
    return getSubscribeApiV2(`/user/product/viewBoards`, {
        method: "GET"
    })
}

export function getAdditionalSlotCharge(_plan_id) {
    return getSubscribeApiV2(`/user/getAdditionalSlotCharge?_plan_id=${_plan_id}`, {
        method: "GET"
    })
}

export function getPlanTerms(_pln_id) {
    return getSubscribeApiV2(`/user/subscription_terms`, {
        method: "GET"
    })
}

// DELETE METHODS STARTS
export function deleteUser(email) {
    return getSubscribeApiV2(`/user/product/${email}/delete`, {
        method: 'DELETE'
    });
}