import React, { Component } from 'react'
import { connect } from 'react-redux';
import Header from '../container/Header';
import SideMenu from '../container/sidemenu';
import './MasterPage.scss';
import { useSelector, useDispatch } from 'react-redux';

const MasterPage=(props)=>{
    
    const dispatch = useDispatch();

        return (
            <>
            <Header />
            <div className="page-body-wrapper">
              <div className="sideMenu">
                  <SideMenu />
              </div>
              <div className="main-panel">
                    {props.children}
              </div>
            </div>
            </>
        )
    
}



export default MasterPage
