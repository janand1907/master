import React, { Component } from 'react'
import { connect } from 'react-redux'

export class GatewayMasterPage extends Component {
    render() {
        return (
            <>
                <div className='h-100'>
                    {this.props.children}
                </div>
            </>
        )
    }
}

const mapStateToProps = (state) => ({
    
})

const mapDispatchToProps = {
    
}

export default connect(mapStateToProps, mapDispatchToProps)(GatewayMasterPage)
