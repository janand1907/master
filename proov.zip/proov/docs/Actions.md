Actions
=======

All dispatched actions MUST be [FSAs (Flux Standard Actions)](https://github.com/acdlite/flux-standard-action).

## Utilities

In order to keep all actions standard, please use the following utilities when possible.

### `createAction(type [, payload, meta])`

Creates a basic FSA with the given type and optional payload and meta.

---

### `createApiCall(options [, meta])`
Creates a FSA that will be interpreted by the API Middleware.

##### `options.endpoint` (string, required)
The URL endpoint for the API call.

##### `options.method` (string, required)
The HTTP method for the API call.<br/>
	It must be one of the strings `GET`, `HEAD`, `POST`, `PUT`, `PATCH`, `DELETE` or `OPTIONS`, in any mixture of lowercase and uppercase letters.
	Exception is `PATCH`! It must be in uppercase letters!

##### `options.types` (array, required)
An array of size 3, that contains the action types to dispatch: `[requestType, successType, failureType]`.

##### `options.body` (any, optional)
The body of the API call.

##### `options.headers` (object, optional)
The HTTP headers for the API call. <br/>
An object in which the keys are the header names and the values are the content.

##### `options.credentials` (string, optional)
Whether or not to send cookies with the API call. It must be one of the following strings:
- `omit` is the default, and does not send any cookies.
- `same-origin` only sends cookies for the current domain.
- `include` always sends cookies, even for cross-origin calls.

##### `meta` (object, optional)
Metadata to for the action. e.g: if you want the action to be interpreted by the Gateway Middleware, you could specify the meta `{ auth: true }`.
