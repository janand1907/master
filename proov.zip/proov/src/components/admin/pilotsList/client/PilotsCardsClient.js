import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import Permission from 'components/Permission';
import { Tooltip } from 'components/ui/Tooltip';
import MyPilotCard from 'components/common/cards/MyPilotCard';
import { MediaQuery } from 'components/ui/MediaQuery';
import { up, down } from 'utils/mediaQuery';
import { Spinner } from 'components/ui/Spinner';
import cx from 'utils/classNames';
import * as i18n from 'i18n/en/pilotsList.json';
import css from '../PilotsList.scss';

const PilotsCardsClient = ({
	pending,
	pilotCards,
	activeCount,
	showTooltip,
	handleShowTooltip,
	handleCreatePoC,
}) => {
	return (
		<div className={cx('container-fluid', css.pilotCardsWrapper)}>
			<div className={cx('container', css.pilotCardsRow)}>
				<MediaQuery query={down('md')}>
					<Permission
						alias="CreateNewPilot"
						component={
							<span className={css.createPilotLink} onClick={handleShowTooltip}>
								+ Create New PoC
								{showTooltip && (
									<Tooltip placement="bottom" className={css.myTooltip}>
										{i18n.client.tooltip}
									</Tooltip>
								)}
							</span>
						}
					/>
				</MediaQuery>
				<p className={css.activePilots}>
					<span>{activeCount}</span> Active PoCs
				</p>

				{pending ? (
					<Spinner className={css.pilotCardsSpinner} />
				) : (
					[
						<MediaQuery key="md1" query={down('sm')}>
							<ul className={css.pilotList}>
								<li key="card0">
									<p>PoC with fewest vendors</p>
									{pilotCards[0] ? (
										
											<MyPilotCard
												pilot={pilotCards[0]}
												className={css.myPilot}
												type="client"
											/>
									) : (
										<div className={css.emptyPilot} />
									)}
								</li>
								<li key="card1">
									<p>PoC ending soon</p>
									{pilotCards[1] ? (
										
											<MyPilotCard
												pilot={pilotCards[1]}
												className={css.myPilot}
												type="client"
											/>
								
									) : (
										<div className={css.emptyPilot} />
									)}
								</li>
							</ul>
						</MediaQuery>,
						<MediaQuery key="md2" query={up('md')}>
							<ul className={css.pilotList}>
								<li key="card0">
									<p>PoC with fewest vendors</p>
									{pilotCards[0] ? (
											<MyPilotCard
												pilot={pilotCards[0]}
												className={css.myPilot}
												type="client"
											/>
									) : (
										<div className={css.emptyPilot} />
									)}
								</li>
								<li key="card1">
									<p>PoC ending soon</p>
									{pilotCards[1] ? (
											<MyPilotCard
												pilot={pilotCards[1]}
												className={css.myPilot}
												type="client"
											/>
									) : (
										<div className={css.emptyPilot} />
									)}
								</li>

								<MediaQuery query={up('lg')}>
									<li key="card2">
										<Permission
											alias="CreateNewPilot"
											component={
												<button
													onClick={() => handleCreatePoC()}
													className={css.createPilot}
												>
													Create New PoC
												</button>
											}
										/>
									</li>
								</MediaQuery>
							</ul>
						</MediaQuery>,
					]
				)}
			</div>
		</div>
	);
};

PilotsCardsClient.propTypes = {
	pending: PropTypes.bool.isRequired,
	pilotCards: PropTypes.array.isRequired,
	activeCount: PropTypes.number,
	handleShowTooltip: PropTypes.func,
	showTooltip: PropTypes.bool,
};

export default PilotsCardsClient;
