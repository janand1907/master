/* eslint-disable camelcase */
import * as STATUS from 'constants/pilotStatus';
import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Link, withRouter } from 'react-router-dom';
import { Spinner } from 'components/ui/Spinner';
import { GridView } from 'components/ui/GridView';
import { Tabs } from 'components/ui/Tabs';
import getDateDiff from 'utils/getDateDiff';
import { up, down } from 'utils/mediaQuery';
import { MediaQuery } from 'components/ui/MediaQuery';
import cx from 'utils/classNames';
import * as i18n from 'i18n/en/pilotsList.json';
import css from '../PilotsList.scss';
import PilotsCardsClient from './PilotsCardsClient';
import cssTable from './PilotsListClient.scss';
import { resetSelectedMetric } from 'ducks/admin/analytics/metrics/actions';
import { Tooltip, TooltipTarget } from 'components/ui/Tooltip';
import { EditIcon, DashboardIcon } from 'components/ui/Icons';


const sortStatusCompare = (a, b) => {
	let rule = [STATUS.ACTIVE, STATUS.COMPLETED];
	let val1 = rule.indexOf(a),
		val2 = rule.indexOf(b);
	return val1 === val2 ? 0 : val1 > val2 ? 1 : -1;
};

const sortCompanyCompare = (a, b) => {
	return a.name === b.name ? 0 : a.name > b.name ? 1 : -1;
};

const redirectToDashboard = (id) => {
	return (e) => {
		e.stopPropagation(); window.location.href = `/admin/pilot/${id}/dashboard`
	};
};
const redirectToEdit = (id) => {
	return (e) => {
		e.stopPropagation(); window.location.href = `/admin/pilot/${id}/details/overview/edit`
	};
};
const configTable = [
	{
		title: 'PoC',
		value: ({ id, name }) => ({ id, name }),
		format: (value) =>
			<Link className={cssTable.pocName} to={'/admin/pilot/' + value.id + '/details'}>
				<TooltipTarget
					className={cssTable.nameWithTooltip}
					tooltip={<Tooltip placement="top">{value.name}</Tooltip>}>
					<span>{value.name}</span>
				</TooltipTarget>
			</Link>,
		sort: sortCompanyCompare,
	},
	{
		title: 'Created At',
		value: ({ created_at }) => created_at,
		format: 'date',
		sort: true,
	},
	{
		title: 'Start Date',
		value: ({ start_time }) => start_time,
		format: 'date',
		sort: true,
	},
	{
		title: 'End Date',
		value: ({ end_time }) => end_time,
		format: 'date',
		sort: true,
	},
	{
		title: 'Last Update',
		value: ({ updated_at }) => updated_at,
		format: 'date',
		sort: true,
	},
	{
		title: 'Days Left',
		value: ({ end_time }) => {
			let days_left = getDateDiff(new Date().getTime(), end_time).days;
			return days_left <= 0 ? 0 : days_left;
		},
		sort: true,
	},
	{ title: 'Vendors', value: 'num_vendors', sort: true },
	{
		title: 'Status',
		value: ({ my_status }) => {
			return my_status.charAt(0).toUpperCase() + my_status.slice(1);
		},
		sort: sortStatusCompare,
	},
	{
		title: 'Edit',
		value: ({ id }) => id,
		format: (id) => {
			return <button className={cssTable.wrapperEditIcon} onClick={redirectToEdit(id)} > <EditIcon className={cssTable.tableIcon} />  </button>
		}
	},
	{
		title: 'Dashboard',
		value: ({ id }) => id,
		format: (id) => {
			return <button className={cssTable.dashboardBtnLink} onClick={redirectToDashboard(id)}><DashboardIcon className={cssTable.tableIcon} /></button>
		}
	}
];

class PilotsListClient extends Component {
	constructor() {
		super();
		this.changeTab = this.changeTab.bind(this);
		this.handleShowTooltip = this.handleShowTooltip.bind(this);
		this.goToDashboard = this.goToDashboard.bind(this);
		this.transformTable = this.transformTable.bind(this);
		this.state = {
			isLoaded: false,
			activeStatus: 'ACTIVE',
			pilotCards: [],
			showTooltip: false,
		};
	}

	UNSAFE_componentWillReceiveProps(nextProps) {
		this.props.resetSelectedMetric();
		if (nextProps.myPilots) {
			let pilots = nextProps.myPilots,
				activeCount = 0;
			let pilotCards = [];
			let myPilotsProps = [];

			pilots.forEach((row, key) => {
				let newStatus = '';
				if (row.status === STATUS.ACTIVE) newStatus = STATUS.ACTIVE;
				else if (row.status === STATUS.FUTURE) newStatus = STATUS.ACTIVE;
				else if (row.status === STATUS.JOINING) newStatus = STATUS.ACTIVE;
				else if (row.status === STATUS.PREPARATION) newStatus = STATUS.ACTIVE;
				else if (row.status === STATUS.EXECUTION) newStatus = STATUS.ACTIVE;
				else if (row.status === STATUS.EVALUATION) newStatus = STATUS.ACTIVE;
				else if (row.status === STATUS.CONFIGURATION) newStatus = STATUS.ACTIVE;
				else if (row.status === STATUS.DEPLOYMENT) newStatus = STATUS.ACTIVE;
				else if (row.status === STATUS.COMPLETED) newStatus = STATUS.COMPLETED;
				else if (row.status === STATUS.TERMINATED)
					newStatus = STATUS.TERMINATED;
				let newRow = { ...row, my_status: newStatus };
				myPilotsProps.push(newRow);
			});

			activeCount = myPilotsProps.filter(
				(item) => item.my_status === STATUS.ACTIVE
			).length;

			myPilotsProps
				.filter((item) => item.my_status === STATUS.ACTIVE)
				.map((row, key) => {
					if (key === 0) {
						pilotCards[0] = row;
						pilotCards[1] = row;
					} else {
						if (pilotCards[0].num_vendors > row.num_vendors)
							pilotCards[0] = row;
						if (
							getDateDiff(new Date().getTime(), pilotCards[1].end_time).days >
							getDateDiff(new Date().getTime(), row.end_time).days
						) {
							pilotCards[1] = row;
						}
					}
				});
			if (pilotCards[0] === pilotCards[1]) {
				myPilotsProps
					.filter((item) => item.my_status === STATUS.ACTIVE)
					.map((row, key) => {
						if (
							pilotCards[0].id != row.id &&
							pilotCards[0].end_time === row.end_time
						) {
							pilotCards[1] = row;
						}
					});
			}
			this.setState(
				{
					pending: nextProps.pending,
					isLoaded: true,
					myPilotsProps: myPilotsProps,
					myPilots: myPilotsProps,
					pilotCards: pilotCards,
					activeCount: activeCount,
				},
				() => {
					this.changeTab(this.state.activeStatus);
				}
			);
		}
	}

	transformTable(configTable) {
		const active = [
			'PoC',
			'Start Date',
			'End Date',
			'Days Left',
			'Vendors',
			'Status',
			'Dashboard',
			'Edit'
		];
		const completed = ['PoC', 'Start Date', 'End Date', 'Vendors', 'Status', 'Dashboard', 'Edit'];
		const terminated = [
			'PoC',
			'Created At',
			'Last Update',
			'Vendors',
			'Status',
			'Dashboard',
			'Edit'
		];

		switch (this.state.activeStatus.toLowerCase()) {
			case STATUS.ACTIVE:
				return configTable.filter((header) => {
					return active.includes(header.title);
				});
			case STATUS.COMPLETED:
				return configTable.filter((header) => {
					return completed.includes(header.title);
				});
			case STATUS.TERMINATED:
				return configTable.filter((header) => {
					return terminated.includes(header.title);
				});
			default:
				return configTable;
		}
	}

	changeTab(status) {
		this.setState({
			myPilots:
				status === 'ALL PoCs'
					? this.state.myPilotsProps
					: this.state.myPilotsProps.filter(
						(item) => item.my_status === status.toLowerCase()
					),
			activeStatus: status,
		});
	}

	

	goToDashboard(pilot) {
		this.props.history.push('/admin/pilot/' + pilot.id + '/dashboard');
	}

	handleShowTooltip() {
		this.setState({ showTooltip: !this.state.showTooltip });
	}

	render() {
		const { pending, handleCreatePoC } = this.props;
		const {
			myPilots,
			myPilotsProps,
			pilotCards,
			activeCount,
			showTooltip,
		} = this.state;
		return (
			<div>
				<PilotsCardsClient
					pending={pending}
					pilotCards={pilotCards}
					activeCount={activeCount}
					showTooltip={showTooltip}
					onShowTooltip={this.handleShowTooltip}
					handleCreatePoC={handleCreatePoC}
				/>

				{pending ? (
					<Spinner className={css.pilotListSpinner} />
				) : (
					<div
						className={cx(
							'container-fluid',
							myPilotsProps && myPilotsProps.length
								? css.tableArea
								: css.pilotsNone
						)}
					>
						<div
							className={cx(
								'container',
								myPilotsProps && myPilotsProps.length
									? null
									: css.myPilotsNoneText
							)}
						>
							<Tabs
								tabList={['ACTIVE', 'COMPLETED', 'TERMINATED', 'ALL PoCs']}
								activeTab={this.state.activeStatus}
								className={css.tabsUl}
								onChange={this.changeTab}
							/>
							{myPilotsProps && myPilotsProps.length ? (
								configTable &&
								myPilots && (
									<div>
										<MediaQuery query={up('md')}>
											<GridView
												config={this.transformTable(configTable)}
												data={myPilots}
												sortConfig={{ sortColumn: 0, sortOrder: 1 }}
												className={cssTable.pilotTableClient}
											/>
										</MediaQuery>

										<MediaQuery query={down('sm')}>
											<GridView
												config={this.transformTable(configTable)}
												data={myPilots}
												sortConfig={{ sortColumn: 0, sortOrder: 1 }}
												className={cssTable.pilotTableClient}
												rowClick={this.goToDashboard}
											/>
										</MediaQuery>
									</div>
								)
							) : (
								<div>
									<h4>{i18n.client.noPocCreated}</h4>
									<button
										onClick={() => handleCreatePoC()}
										className={css.myPilotsNoneLink}
									>
										Create New PoC
									</button>
								</div>
							)}
						</div>
					</div>
				)}
			</div>
		);
	}
}

PilotsListClient.propTypes = {
	/**
	 * @ignore react-router
	 */
	history: PropTypes.shape({
		push: PropTypes.func.isRequired,
	}).isRequired,

	myPilots: PropTypes.array,
	pending: PropTypes.bool,
};
export default withRouter(
	connect(null, { resetSelectedMetric })(PilotsListClient)
);