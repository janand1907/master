import PilotsListVendor from './vendor/PilotsListVendor';
import PilotsListClient from './client/PilotsListClient';

export {
	PilotsListVendor, PilotsListClient
};
