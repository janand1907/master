import React, { Fragment, useEffect, useState } from 'react';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import style from './WebContainer.scss';

const Heatmap = (props) => {
	const [imgWidth, setImgWidth] = useState(null);
	const [imgHeight, setImgHeight] = useState(null);
	const {
		selectedMetric,
		selectedEndpointData,
		isEndpointDataPending
	} = props

	useEffect(() => {
		if (!isEndpointDataPending) {
			const element = document.getElementById("imgHeatmap");
			if (element) {
				setImgWidth(element.offsetWidth);
				setImgHeight(element.offsetHeight);
			}
		}
	});

	const clicksArr = selectedMetric.movingAvg && selectedEndpointData ? selectedEndpointData[selectedMetric.movingAvg] : [];
	let groups = {};
	clicksArr && clicksArr.map(item => {
		const group = JSON.stringify(item);
		if (groups.hasOwnProperty(group)) {
			groups[group] = groups[group] + 1;
		} else {
			groups[group] = 1;
		}
	});
	const maxNum = Math.max(...Object.values(groups));
	const minNum = Math.min(...Object.values(groups));
	const range = (maxNum - minNum) / 4;
	const ranges = [minNum, minNum + range, minNum + 2 * range, minNum + 3 * range, maxNum];
	const getPropertiesByNum = (num) => {
		if (num <= ranges[1]) return { color: "blue", zIndex: '97' };
		if (num <= ranges[2]) return { color: "green", zIndex: '98' };
		if (num <= ranges[3]) return { color: "orange", zIndex: '99' };
		return { color: "red", zIndex: '100' }
	}

	const transformPoints = imgWidth ? Object.keys(groups)
		.map(group => {
			const obj = JSON.parse(group);
			const properties = getPropertiesByNum(groups[group]);
			return { left: (obj.x) * imgWidth, top: (obj.y) * imgHeight, ...properties, count: groups[group] }
		}) : [];

	return !selectedEndpointData ?
		<div className={style.noData}>No data to display</div> :
		<Fragment>
			<img className={style.heatmap} id="imgHeatmap" src={selectedEndpointData.url}></img>
			{transformPoints.map((point, index) =>
				<TooltipTarget key={index} className={style.point}
					style={{ left: point.left, top: point.top, 'zIndex': point.zIndex, 'boxShadow': `5px 9px 7px 7px ${point.color}`, }}
					tooltip={<Tooltip placement="left">{point.count}</Tooltip>} >oo</TooltipTarget>
			)}
			{(transformPoints && transformPoints.length) ? <div className={style.rangeBarWrapper}><span>{maxNum}</span><div className={style.rangeBar} /><span>{minNum}</span></div> : ""}
		</Fragment>
}

export default Heatmap;