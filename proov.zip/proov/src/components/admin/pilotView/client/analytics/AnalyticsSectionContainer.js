import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter, Switch, Route } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { addItem } from 'ducks/admin/dashboard/actions';
import { createToast } from 'ducks/toaster/actions';
import * as actions from 'ducks/admin/analytics/metrics/actions';
import {
	getMetricsSection,
	isSelectedMetricIsCustom,
	hasMetrics,
	getSelectedMetric,
	getSelectedGraphs,
} from 'ducks/admin/analytics/metrics/selectors';
import { getPending } from 'ducks/admin/analytics/charts/selectors';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { Spinner } from 'components/ui/Spinner';
import { showModal } from 'ducks/modal/actions';
import { getSubscription } from '../../../../../ducks/myAccount/selectors';
import AnalyticsSection from './AnalyticsSection';
import css from './../../PilotPageClient.scss';

class AnalyticsSectionContainer extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleShowCustomChart = this.handleShowCustomChart.bind(this);
		this.handleGoToCreateMetric = this.handleGoToCreateMetric.bind(this);
	}

	componentDidMount() {
		this.props.actions.initialize();
	}

	UNSAFE_componentWillReceiveProps(nextProps) {
		if (nextProps.channelId != this.props.channelId) {
			this.props.actions.initialize();
		}
	}

	componentWillUnmount() {
		this.props.actions.resetAnalytics();
	}

	handleShowCustomChart() {
		this.props.actions.showModal('CustomChart');
	}

	handleGoToCreateMetric(e) {
		const { history, match } = this.props;
		history.push(`${match.url}/new-metric`);
	}
	render() {
		const {
			pending,
			periodicPending,
			isDeletedChannel,
			hasMetrics,
			channelId,
			isCustomMetric,
			pilot,
			selectedMetric,
			error,
		} = this.props;

		const isCustomChart = channelId === 'customChart';
		if (pending) {
			return <Spinner size="lg" className={css.spinner} />;
		} else {
			return (
				<Switch>
					<Route
						key="tabs"
						render={(props) => (
							<AnalyticsSection
								{...props}
								periodicPending={periodicPending}
								channelId={channelId}
								handleGoToCreateMetric={this.handleGoToCreateMetric}
								isCustomChart={isCustomChart}
								isCustomMetric={isCustomMetric}
								isBusinessMetric={channelId === null}
								isDeletedChannel={isDeletedChannel}
								hasMetrics={hasMetrics}
								selectedMetric={selectedMetric}
								pilot={pilot}
								error={error}
								showCustomChartModal={this.handleShowCustomChart}
								businessKpiSubscription={this.props.subscription.business_kpi}
							/>
						)}
					/>
				</Switch>
			);
		}
	}
}

AnalyticsSectionContainer.propTypes = {
	/**
	 * @ignore react-router
	 */
	history: PropTypes.shape({
		push: PropTypes.func.isRequired,
	}).isRequired,

	/**
	 * @ignore react-router
	 */
	match: PropTypes.shape({
		params: PropTypes.object.isRequired,
	}).isRequired,

	actions: PropTypes.object,
	subscription: PropTypes.object.isRequired,
	pilot: PropTypes.object,
	isCustomMetric: PropTypes.bool,
	isDeletedChannel: PropTypes.bool,
	hasMetrics: PropTypes.bool,
	error: PropTypes.string,
	pending: PropTypes.bool,
	periodicPending: PropTypes.bool,
	channelId: PropTypes.string,
	addItem: PropTypes.func,
	endpointLabel: PropTypes.string,
	selectedMetric: PropTypes.object,
	selectedGraphs: PropTypes.object,
};

function mapStateToProps(state) {
	const {
		endpointLabel,
		channelId,
		setMetricDescription,
		error,
		pending,
	} = getMetricsSection(state);

	return {
		pilot: getAdminPilot(state),
		hasMetrics: hasMetrics(state),
		isCustomMetric: isSelectedMetricIsCustom(state),
		periodicPending: getPending(state),
		selectedMetric: getSelectedMetric(state),
		selectedGraphs: getSelectedGraphs(state),
		subscription: getSubscription(state).total,
		error,
		pending: pending.data,
		channelId,
		endpointLabel,
		setMetricDescription,
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators(
			{
				...actions,
				addItem,
				createToast,
				showModal,
			},
			dispatch
		),
	};
}

export default withRouter(
	connect(mapStateToProps, mapDispatchToProps)(AnalyticsSectionContainer)
);
