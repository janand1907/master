import React from 'react';
import PropTypes from 'prop-types';
import { NewSpinner } from 'components/ui/NewSpinner';
import cn from 'utils/classNames';
import NoDataMessage from 'components/admin/common/charts/NoDataMessage/NoDataMessage';
import css from './AnalyticsSection.scss';

class NoData extends React.PureComponent {

	render() {
		if (this.props.error) {
			return <div className={css.noItemsLayout}><p>{this.props.error}</p></div>;
		} else if (this.props.pending) {
			return <NewSpinner wrapperClassName={css.spinnerWrapper} />;
		} else { return <NoDataMessage type="nodata" wrapperClassName={cn(css.chartWrapper, this.props.className)} className={css.noDataMessage} /> }
	}

}

NoData.propTypes = {
	pending: PropTypes.bool,
	className: PropTypes.string,
	error: PropTypes.string
};

export default NoData;

