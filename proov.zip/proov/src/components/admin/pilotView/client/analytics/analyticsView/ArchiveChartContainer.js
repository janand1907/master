import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import * as chartsSelectors from 'ducks/admin/analytics/charts/selectors';
import * as actions from 'ducks/admin/analytics/charts/actions';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import * as generalSelectors from 'ducks/admin/analytics/metrics/selectors';
import NoData from '../NoData';
import ArchiveChart from './ArchiveChart';
import ToolBarContainer from 'components/admin/pilotView/client/analytics/ToolBar/ToolBarContainer';
import NoDataMessage from 'components/admin/common/charts/NoDataMessage/NoDataMessage';
import * as metricSelectors from 'ducks/admin/analytics/metrics/selectors';
import css from './../AnalyticsSection.scss';

class ArchiveChartContainer extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleGetArchiveChart = this.handleGetArchiveChart.bind(this);
		this.handleChartZoom = this.handleChartZoom.bind(this);
		this.handleShowAllClick = this.handleShowAllClick.bind(this);
		this.state = { firstRender: true, resolution: null };
	}

	

	componentWillUnmount() {
		this.props.resetPeriodicData();
	}

	handleGetArchiveChart(chart) {
		this.archiveChart = chart;
	}

	handleChartZoom(event) {
		if (!this.state.firstRender) {
			const start = new Date(event.startDate).toISOString();
			const end = new Date(event.endDate).toISOString();
			this.props.setDateRange(start, end);
		} else {
			this.setState({ firstRender: false });
		}
	}

	handleShowAllClick() {
		this.setState({ firstRender: true }, () =>
			this.props.actions.getArchivePeriodic()
		);
	}

	render() {
		const {
			data,
			pending,
			error,
			pilot,
			metric,
			selectedGraphs,
			colorMap,
			enableShowAll,
			metricView,
			resolution,
			metrics,
		} = this.props;

		if (pending) {
			return <NewSpinner wrapperClassName={spinnerWrapper} size="m" />;
		}

		return (
			<React.Fragment>
				<ToolBarContainer
					type="chart"
					id={metric.id}
					metrics={metrics}
					metricView={metricView}
					selectedMetric={metric}
					handleShowAll={this.handleShowAllClick}
					resolution={resolution}
					metricId={metricId}
				/>
				{(!data || data.length === 0) && <NoData className={css.noData} pending={pending} error={error} />}
				{!pilot || !pilot.vendors || pilot.vendors.length == 0 && <NoDataMessage className={css.noData} type="archive"/>}

				<div className={css.chartWrapper}>
					{data && data.length > 0 && (
						<ArchiveChart
							className={css.archiveChart}
							onGetChart={this.handleGetArchiveChart}
							onZoom={this.handleChartZoom}
							onShowAllClick={this.handleShowAllClick}
							data={data}
							vendors={pilot.vendors}
							selectedMetric={metric}
							selectedGraphs={selectedGraphs}
							colorMap={colorMap}
							movingAvg={metric.movingAvg}
							enableShowAll={enableShowAll}
						/>
					)}
				</div>
			</React.Fragment>
		);
	}
}

ArchiveChartContainer.propTypes = {
	data: PropTypes.array,
	pilot: PropTypes.object,
	error: PropTypes.string,
	metric: PropTypes.object,
	pending: PropTypes.bool,
	selectedGraphs: PropTypes.object,
	resolution: PropTypes.string,
	enableShowAll: PropTypes.bool,
	colorMap: PropTypes.object,
	actions: PropTypes.object,
	setDateRange: PropTypes.func.isRequired,
	resetPeriodicData: PropTypes.func.isRequired,
	metrics: PropTypes.array,
	metricView: PropTypes.string,
};

function mapStateToProps(state) {
	return {
		data: chartsSelectors.getData(state),
		error: chartsSelectors.getError(state),
		pending: chartsSelectors.getPending(state),
		resolution: chartsSelectors.getResolution(state),
		enableShowAll: chartsSelectors.getEnableShowAll(state),
		pilot: getAdminPilot(state),
		metric: generalSelectors.getSelectedMetric(state),
		channelId: generalSelectors.getChannelId(state),
		selectedGraphs: generalSelectors.getSelectedGraphs(state),
		colorMap: getAdminPilot(state).vendorToColorMap,
		metrics: metricSelectors.getMetrics(state),
	};
}

export default connect(mapStateToProps, { ...actions })(ArchiveChartContainer);
