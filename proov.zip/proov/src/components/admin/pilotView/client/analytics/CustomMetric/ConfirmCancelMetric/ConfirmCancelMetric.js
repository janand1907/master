import React from 'react';
import PropTypes from 'prop-types';
import * as i18n from 'i18n/en/pilotView.json';
import style from './ConfirmCancelMetric.scss';

const ConfirmCancelMetric = props => {
	return (
		<div className={style.root}>
			<h4>{i18n.client.cancel}</h4>
			<p>{i18n.client.cancelBody}</p>
			<button type="button" className={style.btnCancel} onClick={props.onCancel}>No</button>
			<button type="button" className={style.btnConfirm} onClick={props.onConfirm}>Yes, cancel it</button>
		</div>
	);
};

ConfirmCancelMetric.propTypes = {
	onConfirm: PropTypes.func,
	onCancel: PropTypes.func,
};

export default ConfirmCancelMetric;
