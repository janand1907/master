import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createChart, getChartMetrics } from 'ducks/admin/analytics/customChart/actions';
import { hideModal } from 'ducks/modal/actions';
import * as selectors from 'ducks/admin/analytics/customChart/selectors';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { NewSpinner } from 'components/ui/NewSpinner';
import CreateNewCustomChart from './CreateNewCustomChart';

class CreateNewCustomChartContainer extends React.PureComponent {
	constructor() {
		super();

		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleCancel = this.handleCancel.bind(this);
	}

	componentDidMount() {
		this.props.getChartMetrics();
	}

	handleSubmit(values) {
		this.props.createChart(this.props.pilotId, values);
	}

	handleCancel() {
		this.props.hideModal();
	}

	render() {
		const { environment, metrics, pending, pendingMetrics } = this.props;

		if (!metrics) {
			return null;
		}
		if (metrics && metrics.length === 0) {
			return <h2>No metrics data</h2>;
		}
		if (pendingMetrics) {
			return <NewSpinner />;
		}

		return (
			<CreateNewCustomChart
				environment={environment.filter(env => env.status === 'ready')}
				metrics={metrics}
				onSubmit={this.handleSubmit}
				pending={pending}
				onCancel={this.handleCancel}
			/>
		);
	}
}

CreateNewCustomChartContainer.propTypes = {
	environment: PropTypes.array,
	metrics: PropTypes.array,

	getChartMetrics: PropTypes.func.isRequired,
	createChart: PropTypes.func.isRequired,
	hideModal: PropTypes.func.isRequired,
	pilotId: PropTypes.string.isRequired,

	pendingMetrics: PropTypes.bool,
	pending: PropTypes.bool
};

function mapStateToProps(state) {
	const pilot = getAdminPilot(state);
	return {
		pilotId: pilot.id,
		environment: pilot.environment,
		metrics: selectors.getChartMetrics(state),
		pending: selectors.getChartSubmitPending(state),
		pendingMetrics: selectors.getPendingCustomCharts(state)
	};
}

export default connect(
	mapStateToProps,
	{ getChartMetrics, createChart, hideModal }
)(CreateNewCustomChartContainer);
