import React from 'react';
import PropTypes from 'prop-types';
import { matches, cloneDeep, filter } from 'lodash';
import css from './CreateNewCustomChart.scss';
import { CLOUD_TYPE_TO_ICON, SUPPORTED_CLOUD_CHANNEL_TYPE } from 'constants/channel/cloudType';

//TODO Functional component

class ChannelListField extends React.PureComponent {
	constructor() {
		super();
		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(e) {
		const envId = e.target.dataset.id;
		const env = this.props.environment.find(f => f.id === envId);
		let checkedEnv = [...this.props.checkedEnv];
		const index = checkedEnv.findIndex(v => v.channel_id === envId);
		let kpiId;

		// Get kpiId from config
		// Compare env obj with config obj.
		// If env contains config -> get kpiId from config
		//should stop after matched criteria
		this.props.metric.config.some(envType => {
			const envTypeNew = cloneDeep(envType);
			if (envTypeNew.hasOwnProperty('kpi_id')) { delete envTypeNew.kpi_id }
			const isContain = filter([env], matches(envTypeNew)).length;
			if (isContain === 1) { return kpiId = envType.kpi_id }
		});

		if (index === -1) {
			checkedEnv.push({ channel_id: envId, kpi_id: kpiId }); // eslint-disable-line camelcase
		} else {
			checkedEnv.splice(index, 1);
		}

		this.props.onChange(checkedEnv);
	}

	render() {
		const { environment, checkedEnv } = this.props;

		if (!environment || environment.length === 0) {
			return (
				<p>There is no channels for this metric</p>
			);
		}

		return (
			<div className={css.environment}>
				{environment.map((env, i) => {
					const Icon = env.cloud_type && CLOUD_TYPE_TO_ICON[env.cloud_type].icon;

					return <div key={'ch' + env.id + '_' + i}>
						<input
							data-id={env.id}
							name={`environment[${env.id}_${i}]`}
							type="checkbox"
							className="form-control"
							onChange={this.handleChange}
							checked={checkedEnv.some(f => f.channel_id === env.id)}
						/>
						<label className={css.environmentLabel}>{Icon && <Icon className={css.cloudTypeIcon} />}{env.name}</label>
					</div>
				})}
			</div>
		);
	}
}

ChannelListField.propTypes = {
	checkedEnv: PropTypes.array,
	environment: PropTypes.array,
	metric: PropTypes.object,
	onChange: PropTypes.func.isRequired
};

export default ChannelListField;
