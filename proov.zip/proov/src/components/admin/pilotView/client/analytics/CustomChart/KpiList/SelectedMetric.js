import React from 'react';
import PropTypes from 'prop-types';
import { ChevronSmallIcon } from 'components/ui/Icons';
import style from './KpiList.scss';

const SelectedMetric = props => {
	const { selectedMetric, onToggle } = props;
	const { label } = selectedMetric;
	return (
		<div className={style.selectedMetric} onClick={onToggle}>
			<span className={style.selectedLabel}>{label}</span>
			<ChevronSmallIcon className={style.chevronIcon} />
		</div>
	);
};

SelectedMetric.propTypes = {
	selectedMetric: PropTypes.object.isRequired,
	onRemoveMetric: PropTypes.func,
	onToggle: PropTypes.func
};

export default SelectedMetric;
