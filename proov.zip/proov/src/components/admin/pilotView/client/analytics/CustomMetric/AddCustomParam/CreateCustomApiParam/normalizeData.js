export default function normalizeData(data) {
	const { label, locator, auth, id } = data;
	let loc = { ...locator };
	const mappedAuth = { ...auth };
	if (data.httpHeaderKey && data.httpHeaderValue) {
		loc = { ...locator };
		loc.optional_headers = mapObjectsToMap(data);
	}

	if (auth.httpHeaderKey && auth.httpHeaderValue) {
		mappedAuth.headers = mapObjectsToMap(auth);
		delete mappedAuth.httpHeaderKey;
		delete mappedAuth.httpHeaderValue;
	}
	if (!locator.method) {
		loc.method = 'POST';
	}

	return { id, label, loc, auth: mappedAuth };
}

const mapObjectsToMap = (data) => {
	let headers = [];
	Object.keys(data.httpHeaderKey).forEach(key => {
		if (data.httpHeaderKey[key] && data.httpHeaderValue[key]) {
			headers.push({ key: data.httpHeaderKey[key], value: data.httpHeaderValue[key] });
		}
	});
	return headers;
}
