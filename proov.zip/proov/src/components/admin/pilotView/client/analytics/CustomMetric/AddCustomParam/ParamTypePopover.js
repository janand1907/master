import React from 'react';
import PropTypes from 'prop-types';
import { Popover } from 'components/ui/Popover';
import css from './AddCustomParam.scss';

class ParamTypePopover extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleSelect = this.handleSelect.bind(this);
	}

	handleSelect(e) {
		e.stopPropagation();
		this.props.onSelect(e.target.id);
	}

	render() {
		return (
			<Popover {...this.props} className={css.selectParamPopover}>
				<button type="button" id="db" className={css.actionBtn} onClick={this.handleSelect}>Query DB</button>
				<button type="button" id="api" className={css.actionBtn} onClick={this.handleSelect}>Get from API</button>
			</Popover>
		);
	}
}

ParamTypePopover.propTypes = {
	onSelect: PropTypes.func
};

export default ParamTypePopover;
