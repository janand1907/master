import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { Field, Password, FormGroup } from 'components/common/Forms';
import { InfoIcon, FileIcon } from 'components/ui/Icons';
import style from './../../CreateCustomParam.scss';
import cx from 'utils/classNames';

const HttpHeadersShelf = ({ httpHeaders }) => {
	return (
		<div key={httpHeaders.key} className={style.shelfContainer}>
			<div className={style.halfWidthWrapper}>
				<FormGroup
					inline
					className={style.credentialField}
					mandatory
				>
					<Field
						disabled={true}
						component="input"
						type="text"
						maxLength="2083"
						value={httpHeaders.key}
						title={httpHeaders.value}
						className={cx("form-control",style.cursorAuto)}

					/>
				
				</FormGroup>
				<FormGroup
					inline
					className={style.credentialField}
					mandatory
				>
						<Field
						disabled={true}
						component="input"
						type="text"
						maxLength="2083"
						value={httpHeaders.value}
						title={httpHeaders.value}
						className={cx("form-control",style.cursorAuto)}

					/>

					
				</FormGroup>
			</div>

		</div>
	);
};

HttpHeadersShelf.propTypes = {
	credential: PropTypes.object
};

export default HttpHeadersShelf;
