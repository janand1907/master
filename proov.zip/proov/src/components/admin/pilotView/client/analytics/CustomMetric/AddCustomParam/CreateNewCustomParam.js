
import React from 'react';
import { connect } from 'react-redux';
import ApiIcon_v3 from 'components/ui/Icons/ApiIcon_v3';
import DBIcon from 'components/ui/Icons/DBIcon';
import cn from 'utils/classNames';
import { showModal, hideModal } from 'ducks/modal/actions';
import css from './CreateCustomParam.scss';

function CreateNewCustomParam(props) {

    function onIconClick(type) {
        return async () => {
            await props.closeModal();
            if (type === 'DB') {
                props.onAddDBCustomParam();
            } else {
                props.onAddApiCustomParam();
            }
        }
    }

    return <div className={cn(css.modal, css.directionRow)}>
        <div className={css.iconWrapper}>
            <DBIcon className={css.icon} />
            <button className={css.btnLink} onClick={onIconClick('DB')}>DB Query</button>
        </div>
        <div className={css.divided} />
        <div className={css.iconWrapper}>
            <ApiIcon_v3 className={css.icon} />
            <button className={css.btnLink} onClick={onIconClick('Api')}>API Request</button>
        </div>
    </div>
}

function mergeProps(stateProps, dispatchProps, ownProps) {
    const { pilotId } = ownProps;
    return {
        onAddDBCustomParam: () => {
            dispatchProps.showModal('CreateCustomDbParam', { pilotId: pilotId, isConfirmCancel: true });
        },
        onAddApiCustomParam: () => {
            dispatchProps.showModal('CreateCustomApiParam', { pilotId: pilotId, isConfirmCancel: true });
        },
        closeModal: () => {
            dispatchProps.hideModal();
        }
    };
}


export default
    connect(
        null, { showModal, hideModal }, mergeProps
    )(CreateNewCustomParam);
