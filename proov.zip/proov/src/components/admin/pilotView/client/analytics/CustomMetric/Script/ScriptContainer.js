import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { getSubscription } from 'ducks/myAccount/selectors';
import {
	getParameters,
	getCustomMetric,
	getParametersPending,
	getAllowedParamsByChannel,
	getCustomMetricValidation
} from 'ducks/admin/analytics/customMetric/selectors';
import * as actions from 'ducks/admin/analytics/customMetric/actions';
import { showModal } from 'ducks/modal/actions';
import { modelSelector } from 'ducks/forms/selectors';
import Script from './Script';

class ScriptContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleSelect = this.handleSelect.bind(this);
		this.handleChannelChanged = this.handleChannelChanged.bind(this);
		this.handleCustomParamDetails = this.handleCustomParamDetails.bind(this);
		this.handleDeleteParam = this.handleDeleteParam.bind(this);
		this.handleDeleteDraft = this.handleDeleteDraft.bind(this);
		this.handleEditCustomParam = this.handleEditCustomParam.bind(this);
	}

	componentDidMount() {
		this.props.actions.updateUsedParameters(this.props.params);
	}

	componentWillUnmount() {
		this.props.actions.resetUsedParameters();
	}

	handleSelect(selection) {
		this.props.onAddCustomParam(selection);
	}

	handleChannelChanged(value) {
		const channelId = value.split(/_(.+)?/)[0];
		const endPoint = value.split(/_(.+)?/)[1];
		this.props.actions.setSelectedChannelIdForCreateWizard({ channelId, endPoint });
	}

	handleCustomParamDetails(param) {
		let convertAuth = param.auth, convertLocator = param.locator;
		if (param.auth.headers) {
			let authHeaderKey = [], authHeaderValue = [];
			Object.keys(param.auth.headers).map(k => {
				authHeaderKey.push(k); authHeaderValue.push(param.auth.headers[k])
			});
			convertAuth = { ...param.auth, httpHeaderKey: authHeaderKey, httpHeaderValue: authHeaderValue };
		}
		if (param.locator.headers) {
			let headers = [];
			Object.keys(param.locator.headers).map(k =>
				headers.push({ key: k, value: param.locator.headers[k] }));
			convertLocator = { ...param.locator, optional_headers: headers };
		}
		this.props.actions.showModal(
			param.type === "db" ? 'CreateCustomDbParam' : 'CreateCustomApiParam',
			{
				formValues: {
					...param,
					auth: convertAuth,
					locator: convertLocator
				},
				isViewMode: true,
				pilotId: this.props.pilotId
			});
		// this.props.actions.showModal('CustomParamDetails', { ...param });
	}

	handleEditCustomParam(param) {
		let convertAuth = param.auth, convertLocator = param.locator;
		if (param.auth.headers) {
			let authHeaderKey = [], authHeaderValue = [];
			Object.keys(param.auth.headers).map(k => {
				authHeaderKey.push(k); authHeaderValue.push(param.auth.headers[k])
			});
			convertAuth = { ...param.auth, httpHeaderKey: authHeaderKey, httpHeaderValue: authHeaderValue };
		}
		if (param.locator.headers) {
			let headers = [];
			Object.keys(param.locator.headers).map(k =>
				headers.push({ key: k, value: param.locator.headers[k] }));
			convertLocator = { ...param.locator, optional_headers: headers };
		}
		this.props.actions.showModal(
			param.type === "db" ? 'CreateCustomDbParam' : 'CreateCustomApiParam',
			{
				formValues: {
					...param,
					auth: convertAuth,
					locator: convertLocator
				},
				isEditMode: true,
				pilotId: this.props.pilotId
			});
	}

	handleDeleteParam(param) {
		const { pilotId } = this.props;
		this.props.actions.showModal('DeleteCustomParam', { pilotId, param });
	}
	handleDeleteDraft(isNewDraft) {
		const { pilotId, metric, history } = this.props;
		this.props.actions.showModal('ConfirmDiscardDraft', { pilotId, metricId: metric.id, isNewDraft, history });
	}

	render() {
		const filteredEnvironment = this.props.environment.filter(
			channel => channel.status === CHANNEL_STATUS.READY.value
		);

		return (
			<Script
				form={this.props.form}
				vendors={this.props.vendors}
				environment={filteredEnvironment}
				selectedChannelId={this.props.selectedChannelId}
				selectedEndPoint={this.props.selectedEndPoint}
				parameters={this.props.parameters}
				paramsByChannel={this.props.paramsByChannel}
				onExpressionTypeChange={this.props.onExpressionTypeChange}
				usedParameters={this.props.usedParameters}
				onSelect={this.handleSelect}
				onChannelChanged={this.handleChannelChanged}
				onUpdateUsedParams={this.props.onUpdateUsedParams}
				customMetricValidation={this.props.customMetricValidation}
				model={this.props.model}
				pendingCreate={this.props.pendingCreate}
				pendingDraft={this.props.pendingDraft}
				parameterPending={this.props.parameterPending}
				onTest={this.props.onTest}
				onDeleteDraft={this.handleDeleteDraft}
				handleEdit={this.handleEditMetric}
				handleShowDetails={this.handleCustomParamDetails}
				handleEditParamClick={this.handleEditCustomParam}
				handleDelete={this.handleDeleteParam}
				mode={this.props.mode}
				metric={this.props.metric}
				setItemToInject={this.props.actions.setItemToInject}
			/>
		);
	}
}

ScriptContainer.propTypes = {
	history: PropTypes.shape({
		push: PropTypes.func.isRequired,
	}).isRequired,
	form: PropTypes.object,
	environment: PropTypes.array,
	parameters: PropTypes.array,
	usedParameters: PropTypes.array,
	paramsByChannel: PropTypes.array,
	actions: PropTypes.object,
	selectedChannelId: PropTypes.string,
	selectedEndPoint: PropTypes.string,
	onAddCustomParam: PropTypes.func,
	onUpdateUsedParams: PropTypes.func,
	onExpressionTypeChange: PropTypes.func,
	pendingCreate: PropTypes.bool,
	model: PropTypes.object,
	onTest: PropTypes.func,
	customMetricValidation: PropTypes.object,
	parameterPending: PropTypes.bool,
	vendors: PropTypes.array,
	showModal: PropTypes.func,
	pilotId: PropTypes.string,
	mode: PropTypes.string,

};

function mapStateToProps(state) {
	const parameters = getParameters(state);
	const pilot = getAdminPilot(state);
	const pendingCreate = getCustomMetric(state).pending;
	const pendingDraft = getCustomMetric(state).draft.pending;
	const pending = getParametersPending(state);
	const paramsByChannel = getAllowedParamsByChannel(state);
	const customMetricValidation = getCustomMetricValidation(state);
	const subscription = getSubscription(state).total.business_kpi;

	return {
		pilotId: pilot.id,
		vendors: pilot.vendors,
		model: modelSelector(state, 'customMetric') || {},
		environment: pilot && pilot.environment,
		selectedChannelId: parameters && parameters.selectedChannelId,
		selectedEndPoint: parameters && parameters.selectedEndPoint,
		parameterPending: parameters && pending.get,
		usedParameters: parameters && parameters.used,
		paramsByChannel,
		pendingCreate,
		pendingDraft,
		subscription,
		customMetricValidation
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators(
			{
				...actions,
				showModal
			},
			dispatch
		),
		dispatch
	};
}

export default withRouter(connect(
	mapStateToProps,
	mapDispatchToProps
)(ScriptContainer));
