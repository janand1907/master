import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { deleteParameter } from 'ducks/admin/analytics/customMetric/actions';
import { getParametersPending } from 'ducks/admin/analytics/customMetric/selectors';
import { hideModal } from 'ducks/modal/actions';
import { Spinner } from 'components/ui/Spinner';
import cn from 'utils/classNames';
import * as i18n from 'i18n/en/analytics.json';
import style from './DeleteCustomParam.scss';

class DeleteCustomParam extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleCancel = this.handleCancel.bind(this);
		this.handleConfirm = this.handleConfirm.bind(this);
	}

	handleConfirm() {
		this.props.actions.deleteParameter(this.props.pilotId, this.props.param);
	}

	handleCancel() {
		this.props.actions.hideModal();
	}

	render() {
		const { pendingDelete } = this.props;

		if (pendingDelete) {
			return (
				<div className={cn(style.root, style.progressRoot)}>
					<Spinner className={style.spinner} />
				</div>
			);
		}

		return (
			<div className={style.root}>
				<p className={style.content}>{globalize.parseString(i18n.customParam.delete.confirm)}</p>
				<button type="button" className={style.btnCancel} onClick={this.handleCancel}>
					No
				</button>
				<button type="button" className={style.btnConfirm} onClick={this.handleConfirm}>
					Yes
				</button>
			</div>
		);
	}
}

DeleteCustomParam.propTypes = {
	actions: PropTypes.object,
	pendingDelete: PropTypes.bool,
	pilotId: PropTypes.string.isRequired,
	param: PropTypes.object.isRequired
};

function mapStateToProps(state) {
	return {
		pendingDelete: getParametersPending(state).delete
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators({ deleteParameter, hideModal }, dispatch)
	};
}

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(DeleteCustomParam);
