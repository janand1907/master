import React from 'react';
import { Field, FormGroup, Error } from 'components/common/Forms';
import HeaderTooltip from './tooltips/HeaderTooltip';
import cx from 'utils/classNames';
import css from './../CreateCustomParam.scss';

const HttpHeaders = props => {
	return (
		<div className={css.authArea}>
			<FormGroup
				label={
					<span>
						HTTP Header <HeaderTooltip type={props.type} />
					</span>
				}
				className={css.field}
			>
				<Field
					name={`${props.keyName}httpHeaderKey[0]`}
					component="input"
					type="text"
					placeholder="Key"
					className="form-control"
					disabled={props.disabled}
				/>
				<Error sticky name="httpHeaderKey[0]" />
			</FormGroup>
			<FormGroup label={`${'\u00A0'}`} className={css.field}>
				<Field
					name={`${props.keyName}httpHeaderValue[0]`}
					component="input"
					type="text"
					placeholder="Value"
					className={cx("form-control", css.httpHeadeValue)}
					disabled={props.disabled}
				/>
				<Error sticky name="httpHeaderValue[0]" />
			</FormGroup>
			<FormGroup className={css.field}>
				<Field
					name={`${props.keyName}httpHeaderKey[1]`}
					component="input"
					type="text"
					placeholder="Key"
					className="form-control"
					disabled={props.disabled}
				/>
				<Error sticky name="httpHeaderKey[1]" />
			</FormGroup>
			<FormGroup className={css.field}>
				<Field
					name={`${props.keyName}httpHeaderValue[1]"`}
					component="input"
					type="text"
					placeholder="Value"
					className="form-control"
					disabled={props.disabled}
				/>
				<Error sticky name="httpHeaderValue[1]" />
			</FormGroup>
		</div>

	);
};

HttpHeaders.defaultProps = {
	keyName: "",
};

export default HttpHeaders;
