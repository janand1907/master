import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import Rack from 'components/ui/Rack/Rack';
import HttpHeadersEditor from './HttpHeadersEditor';
import HttpHeadersShelf from './HttpHeadersShelf';

function HttpHeadersFields({ fieldName, authType, isViewMode, items }) {
	const [itemsState, setItemsState] = useState(items);

	function renderAddShelf({ handleAdd, items, customProps }) {
		return (
			<HttpHeadersEditor
				authType={customProps}
				mode="create"
				onAdd={handleAdd}
				existingValue={items}
			/>
		);
	}

	// @tomer - this function doesn't rendered?
	function renderEditShelf({
		value,
		handleSave,
		handleCancel,
		items,
		index,
		customProps,
	}) {
		return (
			<HttpHeadersEditor
				mode="edit"
				authType={customProps}
				onSave={handleSave}
				onCancel={handleCancel}
				initialValue={value}
				existingValue={items}
				existingIndex={index}
			/>
		);
	}

	function renderShelf(value) {
		return <HttpHeadersShelf httpHeaders={value} />;
	}

	return (
		<FormGroup label="Add Http Headers (Up to 5)" mandatory>
			<Field
				validateOn="change"
				name={fieldName}
				defaultValue={items || []}
				component={({ input }) => {
					return (
						<Rack
							classNam
							shelfProps={{
								renderValue: renderShelf,
								renderEdit: renderEditShelf,
								allowEdit: false,
								allowRemove: true,
							}}
							customProps={authType}
							renderEdit={renderAddShelf}
							items={input.value}
							onChange={isViewMode ? null : (value) => {
								input.onChange(value);
								setItemsState(value)
							}}
							allowAdd={!isViewMode}
						/>
					);
				}}
			/>
			<Error sticky name={fieldName} />
		</FormGroup>
	);
}

HttpHeadersFields.propTypes = {
	httpHeaders: PropTypes.array,
	authType: PropTypes.string,
	fieldName: PropTypes.string,
};

export default HttpHeadersFields;
