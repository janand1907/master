import React from 'react';
import PropTypes from 'prop-types';
import { debounce } from 'lodash';
import { SearchBox } from 'components/ui/SearchBox';
import * as i18n from 'i18n/en/pilotView.json';
import TestResult from 'components/admin/common/script/TestResult/TestResult';
import { NewSpinner } from 'components/ui/NewSpinner';
import {
	// getAllowedChannels,
	transformChannels,
	getSelectedChannelValue,
	isMetricReadyForCreate
} from 'components/admin/common/script/utils';
import ChannelSelect from '../ChannelSelect/ChannelSelect';
import AddCustomParam from '../AddCustomParam/AddCustomParam';
import MetricsGridView from 'components/admin/common/script/MetricsGridView/MetricsGridView';
import CreateFormulaForm from './CreateFormulaForm';
import css from './Formula.scss';

class Formula extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleSelect = this.handleSelect.bind(this);
		this.handleGetFormRef = this.handleGetFormRef.bind(this);
		this.handleSearchChanged = this.handleSearchChanged.bind(this);
		this.handleSearchChangedDebounced = debounce(
			this.handleSearchChangedDebounced.bind(this),
			500
		);
		this.state = { searchText: '' };
	}

	handleGetFormRef(ref) {
		this.selectHandler = ref;
	}

	handleSelect(item) {
		const { id, name, param_type, channel_id = null } = item;
		const transformedItem = {
			id,
			type: param_type,
			channel_id,
			variable: `${name}_${channel_id || id}`
		};
		this.selectHandler.insertItem(transformedItem);
	}

	handleSearchChangedDebounced(value) {
		this.setState({ searchText: value });
	}

	handleSearchChanged(e) {
		this.handleSearchChangedDebounced(e.target.value);
	}

	render() {
		const {
			selectedChannelId,
			selectedEndPoint,
			parameters,
			onChannelChanged,
			onAddCustomParam,
			parameterPending,
			environment,
			model,
			pendingCreate,
			customMetricValidation,
			onTest,
			mode,
			form,
			handleEdit,
			handleDelete,
			handleShowDetails
		} = this.props;

		let allowedChannels = transformChannels(environment);
		allowedChannels.Custom = {
			type: 'custom',
			channelType: 'custom',
			channelId: 'Custom',
			id: 'Custom',
			name: 'Custom Parameters'
		};

		return (
			<div className={css.editor}>
				<div className={css.testZone}>
					<CreateFormulaForm
						form={this.props.form}
						onGetFormRef={this.handleGetFormRef}
						mode={mode}
					/>

					<TestResult
						disabled={parameterPending || pendingCreate}
						pending={customMetricValidation.pending}
						error={customMetricValidation.error}
						result={customMetricValidation.result}
						onTest={onTest}
					/>

					<button
						type="button"
						className={css.btnCreate}
						disabled={
							!isMetricReadyForCreate(model) ||
							!customMetricValidation.result ||
							pendingCreate
						}
						onClick={() => form && form.submit()}
					>
						{pendingCreate && <NewSpinner size="s" />}
						{mode === 'create' ? 'Create' : 'Update'}
					</button>
				</div>

				<div className={css.formulaKpiPickListWrapper}>
					<div className={css.formulaKpiPickListHeader}>
						<ChannelSelect
							options={allowedChannels}
							type="formula"
							onChange={onChannelChanged}
							value={getSelectedChannelValue(selectedChannelId, selectedEndPoint)}
						/>

						<SearchBox
							className={css.searchBox}
							disabled={!parameters || parameters.length === 0}
							onTextChanged={this.handleSearchChanged}
							placeholder={i18n.client.placeholder.searchBox}
						/>
					</div>

					<MetricsGridView
						selectedChannelId={selectedChannelId}
						selectedEndPoint={selectedEndPoint}
						parameterPending={parameterPending}
						searchText={this.state.searchText}
						parameters={parameters}
						onSelect={this.handleSelect}
						className={css.metricsGridView}
						handleEdit={handleEdit}
						handleDelete={handleDelete}
						handleShowDetails={handleShowDetails}
						expressionType={'formula'}
						plusTooltipText={i18n.client.tooltips.plusIcon}
					/>

					{selectedChannelId === 'Custom' && <AddCustomParam onSelect={onAddCustomParam} />}

				</div>
			</div>
		);
	}
}

Formula.propTypes = {
	parameters: PropTypes.array,
	selectedChannelId: PropTypes.string,
	environment: PropTypes.array,
	selectedEndPoint: PropTypes.string,
	onChannelChanged: PropTypes.func,
	onAddCustomParam: PropTypes.func,
	parameterPending: PropTypes.bool,
	model: PropTypes.object,
	pendingCreate: PropTypes.bool,
	customMetricValidation: PropTypes.object,
	onTest: PropTypes.func,
	form: PropTypes.object,
	handleEdit: PropTypes.func,
	handleShowDetails: PropTypes.func,
	handleDelete: PropTypes.func,
	mode: PropTypes.string
};

export default Formula;
