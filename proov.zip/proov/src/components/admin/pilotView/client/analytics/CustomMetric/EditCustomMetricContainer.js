import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { modelSelector } from 'ducks/forms/selectors';
import * as selectors from 'ducks/admin/analytics/customMetric/selectors';
import * as parametersActions from 'ducks/admin/analytics/customMetric/actions';
import * as metricsActions from 'ducks/admin/analytics/metrics/actions';
import { NewSpinner } from 'components/ui/NewSpinner';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import {
	getChannelId,
	getMetrics,
	getPending
} from 'ducks/admin/analytics/metrics/selectors';
import { showModal } from 'ducks/modal/actions';
import { createToast } from 'ducks/toaster/actions';
import { createScriptExpression } from 'utils';
import {
	transformParams,
	combineParameters,
	cleanExpressionFromSyntax,
	joinFormula
} from 'components/admin/common/script/utils';
import EditCustomMetric from './EditCustomMetric';

const EXPRESSION_TYPE = {
	formula: 'FORMULA',
	javascript: 'JS6',
	python: 'PY3'
};

class EditCustomMetricContainer extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleExpressionTypeChange = this.handleExpressionTypeChange.bind(this);
		this.handleTest = this.handleTest.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);

		const metricId = this.props.location.pathname.split('/').pop();
		const selectedMetric = this.props.metrics.find(({ id }) => id === metricId);
		let script = selectedMetric.script;
		const environment = this.props.environment;
		const params = this.props.scriptParameters;
		if (selectedMetric.args.length) {
			selectedMetric.args.forEach(a => {
				const channel = environment.find(env => env.id === a.channel_id);
				let param, type;
				if(!channel) {
					param = params.find(p => p.id ===a.id);
					type = param.param_type === 'vendor' ? 'Vendor List' : 'Script Parameters';
				}
				if (channel || param) {
					const str = channel?
					`\${${channel.name}->${a.variable.substr(0, a.variable.search('_'))}}`
					: `\${${type}->${param.name}}`
					script = script.replaceAll(a.variable, str);
				}
			})
		}
		this.state = {
			metric: { ...selectedMetric, script: script }
		};
	}

	UNSAFE_componentWillReceiveProps(nextProps) {
		if (
			nextProps.model &&
			nextProps.model.expression_type !== this.props.model.expression_type
		) {
			this.props.actions.resetMetricValidate();
		}
		if (nextProps.metrics != this.props.metrics) {
			const metricId = this.props.location.pathname.split('/').pop();
			const selectedMetric = nextProps.metrics.find(({ id }) => id === metricId);
			this.setState({ metric: selectedMetric });

		}
	}

	componentWillUnmount() {
		if (this._form) this._form.reset();
		this.props.actions.resetCustomMetric();
	}

	handleTest() {
		if (this._form) this._form.clearErrors();
		const { label, schedule, script, formula, expression_type } = this.props.model;

		let expression = null;
		if (expression_type === 'formula') {
			expression = joinFormula(formula);
		} else {
			expression = cleanExpressionFromSyntax(
				script,
				this.props.usedParameters,
				this.props.environment
			);
		}
		this.props.onValidateMetric(
			label,
			schedule,
			expression,
			expression_type,
			transformParams(this.props.usedParameters)
		);
	}

	handleSubmit(model, args) {
		const {
			label,
			description,
			schedule,
			script,
			formula,
			expression_type
		} = this.props.model;

		const metricId = this.props.location.pathname.split('/').pop();

		let expression = null;
		const isDraft = args.length && args[0].type;

		if (expression_type === 'formula') {
			expression = joinFormula(formula);
		} else {
			expression = cleanExpressionFromSyntax(
				script,
				this.props.usedParameters,
				this.props.environment
			);
		}
		this.props.onSubmit(
			metricId,
			label,
			description,
			schedule,
			expression_type,
			expression,
			transformParams(this.props.usedParameters),
			isDraft
		);
	}

	handleExpressionTypeChange(expressionType) {
		this._form && this._form.change('expression_type', expressionType);
	}

	render() {
		const { pendingCreate, pendingMetrics, pendingParameters } = this.props;

		if (pendingParameters || pendingMetrics || !this.state.metric) {
			return <NewSpinner />;
		} else {
			return (
				<EditCustomMetric
					{...this.props}
					onTest={this.handleTest}
					onSubmit={this.handleSubmit}
					onExpressionTypeChange={this.handleExpressionTypeChange}
					metric={this.state.metric}
					pendingCreate={pendingCreate}
					form={this._form}
					scriptParameters={this.props.scriptParameters}
					formulaParameters={this.props.formulaParameters}
					usedParameters={this.props.usedParameters}
					formRef={node => {
						this._form = node && node.getWrappedInstance();
					}}
				/>
			);
		}
	}
}

EditCustomMetricContainer.propTypes = {
	history: PropTypes.shape({
		push: PropTypes.func.isRequired
	}).isRequired,
	location: PropTypes.shape({
		pathname: PropTypes.string
	}).isRequired,
	actions: PropTypes.object,
	model: PropTypes.object.isRequired,
	form: PropTypes.object,
	pendingCreate: PropTypes.bool,
	pendingMetrics: PropTypes.bool,
	pendingParameters: PropTypes.bool,
	pilot: PropTypes.object.isRequired,
	scriptParameters: PropTypes.array,
	formulaParameters: PropTypes.array,
	onValidateMetric: PropTypes.func,
	onSubmit: PropTypes.func,
	environment: PropTypes.array,
	getMetrics: PropTypes.func, // fetching metrics if user refresh the page
	metrics: PropTypes.array,
	usedParameters: PropTypes.array
};

function mapStateToProps(state) {
	const parameters = selectors.getParameters(state);
	const pilot = getAdminPilot(state);

	return {
		pilot,
		environment: pilot.environment,
		metrics: getMetrics(state),
		channelId: getChannelId(state),
		scriptParameters: parameters && combineParameters(parameters.data, pilot.vendors),
		formulaParameters: parameters && parameters.data,
		usedParameters: parameters.used,
		pendingMetrics: getPending(state).data,
		pendingCreate: selectors.getCustomMetric(state).pending,
		customMetricValidation: selectors.getCustomMetricValidation(state),
		model: modelSelector(state, 'customMetric') || {},
		pendingParameters: selectors.getParametersPending(state).get
	};
}

function mergeProps(stateProps, dispatchProps, ownProps) {
	const { pilot } = stateProps;
	return {
		...stateProps,
		...ownProps,
		...dispatchProps,
		onUpdateUsedParams: parameters =>
			dispatchProps.actions.updateUsedParameters(parameters),
		onValidateMetric: (label, schedule, cleanExpression, expressionType, params) => {
			dispatchProps.actions.validateMetric(
				pilot.id,
				label,
				schedule,
				createScriptExpression(cleanExpression),
				EXPRESSION_TYPE[expressionType],
				params
			);
		},
		onAddCustomParam: () => {
			dispatchProps.actions.showModal('CreateNewCustomParam', { pilotId: pilot.id });
		},
		onSubmit: (
			metricId,
			label,
			description,
			schedule,
			expression_type,
			cleanExpression,
			params,
			isDraft
		) => {
			const { history } = ownProps;
			if (isDraft)
				dispatchProps.actions.updateDraft(
					pilot.id,
					metricId,
					label,
					description,
					schedule,
					createScriptExpression(cleanExpression),
					EXPRESSION_TYPE[expression_type],
					params,
					history
				);
			else dispatchProps.actions.updateMetric(
				pilot.id,
				metricId,
				label,
				description,
				schedule,
				createScriptExpression(cleanExpression),
				EXPRESSION_TYPE[expression_type],
				params,
				history
			);
		}
	};
}

function mapDispatchToProps(dispatch) {
	return {
		dispatch: dispatch,
		actions: bindActionCreators(
			{ showModal, getMetrics, createToast, ...parametersActions, ...metricsActions },
			dispatch
		)
	};
}

export default withRouter(
	connect(
		mapStateToProps,
		mapDispatchToProps,
		mergeProps
	)(EditCustomMetricContainer)
);
