import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import MetricDescriptionContainer from 'components/admin/common/charts/MetricDescription/MetricDescriptionContainer';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import * as metricSelectors from 'ducks/admin/analytics/metrics/selectors';
import * as chartSelectors from 'ducks/admin/analytics/charts/selectors';
import VendorsGridContainer from 'components/admin/pilotView/client/analytics/ToolBar/VendorsGrid/VendorsGridContainer';
import * as metricActions from 'ducks/admin/analytics/metrics/actions';
import { setMetricView } from 'ducks/admin/analytics/metrics/actions';
import FeedContainer from './FeedContainer';
import ChartContainer from './ChartContainer';
import MatrixContainer from './MatrixContainer';
import * as style from './Analytics.scss';
import WebContainer from './WebContainer';

function AnalyticsContainer(props) {
	React.useEffect(() => {
		props.actions.setMetricView('analytics');
		let selectedVendors;
		if (props.selectedVendors && props.selectedVendors[0]) {
			selectedVendors = props.selectedVendors[0];
		}
		if (!props.selectedMetric.id) {
			props.actions.getMetrics({
				pilotId: props.pilotId,
				channelId: null,
				endpointLabel: null,
			})
		}
		props.actions.setMetric(
			props.selectedMetric.id,
			props.resolution,
			selectedVendors || props.vendors.length > 0 && props.vendors[0].id,
			props.endpointLabel.type === 'web' ? props.endpointLabel : props.selectedMetric
		);
	}, []);
	const channel = props.channels.find(({ id }) => id === props.channelId);
	const type = props.selectedMetric && props.selectedMetric.resp_type;
	let metricType = null;

	if (type === 'value') {
		metricType =
			props.selectedMetric.resp_example.meta[0].type === 'number'
				? 'chart'
				: 'feed';
	} else if (type === 'table') {
		metricType = 'matrix';
	} else if (type === 'vector') {
		metricType = 'feed';
	} else if (channel && channel.type == 'web') {
		metricType = 'web';
	}
	else {
		metricType = 'chart';
	}

	return (
		<div className={style.layout}>
			{(() => {
				switch (metricType) {
					case 'chart':
						return <ChartContainer {...props} />;
					case 'matrix':
						return <MatrixContainer {...props} />;
					case 'feed':
						return <FeedContainer {...props} />;
					case 'web':
						return <WebContainer {...props} channel={channel} />;
					default:
						return <ChartContainer {...props} />;
				}
			})()}
			<MetricDescriptionContainer />
			<VendorsGridContainer
				channelId={props.channelId}
				metricConfig={props.selectedMetric.config}
				metricType={metricType}
			/>
		</div>
	);
}

AnalyticsContainer.propTypes = {
	pilotId: PropTypes.string,
	selectedMetric: PropTypes.object.isRequired,
	channelId: PropTypes.string,
	isDeletedChannel: PropTypes.bool,
	vendors: PropTypes.array,
	actions: PropTypes.object.isRequired,
	resolution: PropTypes.string,
};

AnalyticsContainer.defaultProps = {
	isDeletedChannel: false,
	metricView: 'analytics',
};

function mapStateToProps(state) {
	const { id, vendors, vendorToColorMap, environment } = getAdminPilot(state);
	const { endpointLabel, selectedMetric, channelId, selectedVendors, metrics } = metricSelectors.getMetricsSection(state);
	return {
		pilotId: id,
		vendorToColorMap,
		vendors,
		channels: environment,
		isDeletedChannel: metricSelectors.isDeletedChannel(state),
		selectedVendors: selectedVendors,
		metrics: metrics,
		data: chartSelectors.getData(state),
		pending: chartSelectors.getPending(state),
		error: chartSelectors.getError(state),
		channelId: channelId,
		selectedMetric: selectedMetric,
		endpointLabel: endpointLabel
	};
}

function mapDispatchToProps(dispatch) {
	return {
		dispatch: dispatch,
		actions: bindActionCreators({ ...metricActions, setMetricView }, dispatch),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(AnalyticsContainer);
