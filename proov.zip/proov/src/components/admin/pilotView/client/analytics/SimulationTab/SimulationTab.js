import React from 'react';
import PropTypes from 'prop-types';
import * as i18n from 'i18n/en/pilotView.json';
import SliderContainer from './Simulator/SliderContainer';
import PredictionScoreContainer from './Simulator/PredictionScoreContainer';
import Graph3dContainer from './Simulator/Graph3dContainer';
import ToolBarContainer from './../ToolBar/ToolBarContainer';
import style from './Simulator/Simulator.scss';
import NoDataMessage from 'components/admin/common/charts/NoDataMessage/NoDataMessage';

const SimulationTab = ({ selectedMetric, hasVendors, metrics, metricView }) => {
	if (!hasVendors) {
		return (
			<NoDataMessage
				message={i18n.client.noSimulation}
				className={style.errorMessage}
			/>
		);
	}

	if (metrics.length === 0) {
		return (
			<NoDataMessage
				message={i18n.client.noSimulationMessage}
				className={style.errorMessage}
			/>
		);
	}

	return (
		<div>
			<ToolBarContainer
				metrics={metrics}
				selectedMetric={selectedMetric}
				type="chart"
				resolution="simulator"
				metricView={metricView}
			/>

			<div className={style.simulator}>
				<SliderContainer />
				<div>
					<PredictionScoreContainer />
					<Graph3dContainer />
				</div>
			</div>
		</div>
	);
};

SimulationTab.defaultProps = {
	metricView: 'analytics',
};

SimulationTab.propTypes = {
	selectedMetric: PropTypes.object,
	metrics: PropTypes.array,
	hasVendors: PropTypes.bool,
};

export default SimulationTab;
