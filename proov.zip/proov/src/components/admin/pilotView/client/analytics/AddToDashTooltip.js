import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import * as i18n from 'i18n/en/pilotView.json';
import css from './AnalyticsSection.scss';

const AddToDashTooltip = props => {
	return (
		<TooltipTarget tooltip={
			<Tooltip placement="top" anchor={{ x: 11, y: -35 }} className={css.addToDashTooltip}>
				{props.limited ? i18n.client.addToDashTooltip.true : i18n.client.addToDashTooltip.false}
			</Tooltip>}>
			{props.children}
		</TooltipTarget>
	);
};

AddToDashTooltip.propTypes = {
	children: PropTypes.node
};

export default AddToDashTooltip;
