import * as PARAM_TYPES from 'constants/admin';
import { READY, IN_PROGRESS, FAILED } from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { debounce } from 'lodash';
import { connect } from 'react-redux';
import { Field, FormGroup, Error } from 'components/common/Forms';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { getParameters } from 'ducks/admin/analytics/customMetric/selectors';
import { getSelectedMetric } from 'ducks/admin/analytics/metrics/selectors';
import PillsInput from 'components/ui/PillsInput/PillsInput';
import * as i18n from 'i18n/en/pilotView.json';
import style from './Formula.scss';

class CreateFormulaForm extends React.PureComponent {
	componentDidMount() {
		this.props.form && this.props.form.clearErrors('formula');
	}

	renderPillMarkup(channel) {
		switch (channel.status) {
			case READY.value:
				return style.ready;
			case IN_PROGRESS.value:
				return style.inProgress;
			case FAILED.value:
				return style.failed;
		}
	}

	render() {
		return (
			<div>
				<FormGroup>
					<Field name="expression_type" type="hidden" component="input" />
				</FormGroup>

				<FormGroup>
					<Field
						name="formula"
						className="form-control"
						required
						defaultValue={[]}
						validateOn={['blur', 'change']}
						component={({ input }) => {
							return (
								<PillsInput
									ref={this.props.onGetFormRef}
									items={input.value}
									renderPill={({ item, index, defaultRender }) => {
										if (typeof item === 'object') {
											const anchor = item.variable.lastIndexOf('_');
											const [variable, channelId] = [
												item.variable.slice(0, anchor),
												item.variable.slice(anchor + 1, item.variable.length)
											];
											const channel =
												item.type === PARAM_TYPES.STANDARD
													? this.props.environment.find(({ id }) => id === channelId)
													: null;
											return channel
												? defaultRender(`${channel.name}->${variable}`)
												: defaultRender(`Custom Parameters->${variable}`);
										} else {
											return item !== '' ? item : null;
										}
									}}
									isItemEditable={({ item, index }) => typeof item === 'string'}
									pillProps={{
										allowRemove: true,
										className: ({ item }) => {
											if (typeof item === 'object') {
												const paramType = item.type || item.param_type;
												const channel =
													paramType === PARAM_TYPES.STANDARD
														? this.props.environment.find(
															env => env.id === item.channel_id
														  )
														: null;
												return channel ? this.renderPillMarkup(channel) : null;
											} else {
												const anchor = item.variable.lastIndexOf('_');
												const channelId = item.variable.slice(anchor + 1, item.variable.length);
												const channel = this.props.environment.find(
													({ id }) => id === channelId
												);
												return channel ? this.renderPillMarkup(channel) : null;
											}
										}
									}}
									placeholder={i18n.client.placeholder.expression_formula}
									onChange={input.onChange}
									onBlur={debounce(input.onBlur, 100)}
									rootClassName={style.pillsField}
								/>
							);
						}}
					/>
					<Error className={style.errorLabel} name="formula" />
				</FormGroup>
			</div>
		);
	}
}

CreateFormulaForm.propTypes = {
	form: PropTypes.object,
	mode: PropTypes.string,
	onGetFormRef: PropTypes.func,
	environment: PropTypes.array,
	usedParameters: PropTypes.array,
	selectedMetric: PropTypes.object
};

function mapStateToProps(state) {
	return {
		selectedMetric: getSelectedMetric(state),
		environment: getAdminPilot(state).environment,
		usedParameters: getParameters(state).used
	};
}

export default connect(mapStateToProps)(CreateFormulaForm);
