import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { RadioGroup, Radio } from 'components/ui/RadioGroup';
import { Field, FormGroup, Error } from 'components/common/Forms';
import ApiKey from 'components/admin/common/commonFields/ApiKey';
import cx from 'utils/classNames';
import UsernamePasswordField from './UsernamePasswordField';
import OAuthFields from './OAuthFields';
import BearerToken from './BearerToken';
import css from './../CreateCustomParam.scss';

const AuthFields = ({ auth, isRest, isViewMode }) => {
	const renderChildern = (authType, grantType) => {

		switch (authType) {
			case "basic":
				return <UsernamePasswordField key="authFields" name="auth" isViewMode={isViewMode}/>
			case "oauth2":
				return <OAuthFields grantType={grantType} isViewMode={isViewMode} />
			case "bearer":
				return <BearerToken isViewMode={isViewMode} />
			case "api_key":
				return <ApiKey isViewMode={isViewMode} />
			default:
				return null;
		}
	}
	return (
		<div>
			<FormGroup label="Authentication Type" mandatory>
				<Field
					defaultValue={auth && auth.type || "basic"}
					name="auth.type"
					validateOn="change"
					disabled={isViewMode}
					component={({ input }) => (
						<RadioGroup name={input.name} selectedValue={input.value} onChange={!isViewMode && input.onChange}>
							<label className={cx("form-check-inline", css.authTypeRadio)}>
								<Radio value="basic" className="form-control" />
								Basic
							</label>
							<label className={cx("form-check-inline", css.authTypeRadio)}>
								<Radio value="oauth2" className="form-control" />
								OAuth 2.0
							</label>
							{isRest && <Fragment>< label className={cx("form-check-inline", css.authTypeRadio)}>
								<Radio value="api_key" className="form-control" />
								API Key
							</label>
								< label className={cx("form-check-inline", css.authTypeRadio)}>
									<Radio value="bearer" className="form-control" />
									Bearer Token
								</label></Fragment>}
							<label className={cx("form-check-inline", css.authTypeRadio)}>
								<Radio value="none" className="form-control" />
								None
							</label>
						</RadioGroup>
					)}
				/>
				<Error sticky name="auth.type" />
			</FormGroup>
			{auth && renderChildern(auth.type, auth.grant_type)}
		</div>
	);
};

AuthFields.propTypes = {
	auth: PropTypes.object
};

export default AuthFields;
