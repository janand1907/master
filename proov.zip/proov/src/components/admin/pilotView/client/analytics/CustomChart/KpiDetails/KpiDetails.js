import React from 'react';
import * as i18n from 'i18n/en/pilotView.json';
import CodeEditor from 'components/admin/common/script/CodeEditor/CodeEditor';
import cn from 'utils/classNames';
import { CRON_SCHEDULER } from 'constants/admin';
import * as style from "./KpiDetails.scss";

function KpiDetails({
    name,
    vendor_name,
    status,
    script_type,
    schedule,
    script,
    draft,
    nclients
}) {

    const lng = script_type === "js6" || script_type === "js_saas" ? "JavaScript" : "Python";
    const scheduleKey = Object.keys(CRON_SCHEDULER).find(key => CRON_SCHEDULER[key] === schedule);

    return <div className={style.modal}>
        <div className={style.header}>PARAMETER DETAILS</div>
        <div className={style.content}>
            <div className={style.row}>
                <span className={style.label}>{i18n.client.kpiDetailes.name}</span>
                <span className={style.value}>{vendor_name || name}</span>
            </div>
            <div className={style.row}>
                <span className={style.label}>{i18n.client.kpiDetailes.status}</span>
                <span className={style.value}>
                    {status === 'failed' && (
                        <span className={style.failed}>{i18n.client.kpiDetailes.statusTypes.failed}</span>
                    )}
                    {status === 'draft' && (
                        <span className={style.draft}>{i18n.client.kpiDetailes.statusTypes.draft}</span>
                    )}
                    {status === 'ready' && (
                        <span className={style.ready}>{i18n.client.kpiDetailes.statusTypes.active}</span>
                    )}
                </span>
            </div>
            <div className={style.row}>
                <span className={style.label}>{i18n.client.kpiDetailes.lng}</span>
                <span className={style.value}>{lng}</span>
            </div>
            <div className={style.row}>
                <span className={style.label}>{i18n.client.kpiDetailes.scheduler}</span>
                <span className={style.value}>{scheduleKey}</span>
            </div>
            <div className={style.row}>
                <span className={style.label}>{i18n.client.kpiDetailes.virtualUsers}</span>
                <span className={style.value}>{nclients||1}</span>
            </div>
            <div className={style.row}>
                <span className={style.label}>{i18n.client.kpiDetailes.sourceCode}</span>
            </div>
        </div>
        <div className={cn(style.value, style.sourceCode)}>
            <CodeEditor
                value={status === 'draft' ? draft : script}
                onChange={() => { }}
                lng={lng.toLowerCase()}
                readonly={true}
                mode={'detailes'}
            />
        </div>
    </div>
}

export default KpiDetails;