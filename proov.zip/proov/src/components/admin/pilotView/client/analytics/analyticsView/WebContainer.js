import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as dashboardActions from 'ducks/admin/dashboard/actions';
import * as analyticsActions from 'ducks/admin/analytics/charts/actions';
import ToolBarContainer from 'components/admin/pilotView/client/analytics/ToolBar/ToolBarContainer';
import ChartRadius from 'components/ui/AmCharts/types/AmSerial/ChartRadius';
import NoDataMessage from 'components/admin/common/charts/NoDataMessage/NoDataMessage';
import { getSelectedIsvEndpoint } from 'ducks/admin/analytics/metrics/selectors';
import * as metricSelectors from 'ducks/admin/analytics/metrics/selectors';
import cn from 'utils/classNames';
import { Spinner } from 'components/ui/Spinner';
import { setMovingAvg } from 'ducks/admin/analytics/metrics/actions';
import { setMovingAvg as setDashboardMovingAvg } from 'ducks/admin/dashboard/actions';
import Heatmap from './Heatmap';
import style from './WebContainer.scss';

function WebContainer(props) {

	const {
		id,
		metricId,
		data,
		selectedMetric,
		metricView,
		metrics,
		isIsvWebChannel,
		endpointLabel,
		pending,
		channel,
		isEndpointDataPending,
		selectedGraphs,
		vendorToColorMap,
		actions
	} = props
	useEffect(() => {
		if (!isIsvWebChannel) {
			actions.stopLiveData(metricId);
			actions.getArchivePeriodic(metricId);
		}
	}, [selectedMetric.movingAvg, metrics]);
	const dataBySelectedGraph = () => {
		return data.map((kpi) => { return kpi && kpi.filter((vendor) => vendor && selectedGraphs && selectedGraphs[vendor.company_id]) })
	}
	const handleMovingAvg = (v) => {
		switch (metricView) {
			case 'analytics':
				actions.setMovingAvg(v);
				break;
			case 'dashboard':
				actions.setDashboardMovingAvg(metricId, v);
				break;
			default:
				break;
		}
	}
	const chartRef = React.useRef({ ignoreZoom: true });

	const dateOptions = [
		{ id: 'hourly', label: 'Hourly' },
		{ id: 'daily', label: 'Daily' },
		{ id: 'weekly', label: 'Weekly' }
	];

	const eventsOptions = [
		{ id: 'a', label: 'Click' },
		// { id: 'c', label: 'Scroll' },
		{ id: 'b', label: 'Move' }
	];
	const getChart = (ref) => {
		chartRef.current.chart = ref;
	};

	const handleMetricAnnotations = React.useCallback(() => {
		chartRef.current.chart.annotator()
	}, []);

	const handleDownloadMetric = React.useCallback((format) => {
		if (chartRef.current.chart.export) {
			switch (format) {
				case 'PDF':
					chartRef.current.chart.export(format.toLowerCase(), { addURL: false }); break;
				case 'JPG':
				case 'PNG':
				case 'CSV':
				case 'XLSX':
				case 'JSON':
					chartRef.current.chart.export(format.toLowerCase()); break;
				case 'PRINT':
				default:
					chartRef.current.chart.print();
			}

		}
	}, []);
	if (!isIsvWebChannel && pending) {
		return (
			<NoDataMessage
				message="Loading metric data..."
				className={style.loadingData}
			/>
		);
	}
	const script = isIsvWebChannel && selectedMetric.isvs && selectedMetric.isvs.find((m) => m.customer_id === endpointLabel.id).script;
	const endpoints = script && script.args[0].endpoints.map((e) => ({ "name": e })) || [];
	const dataProvider = dataBySelectedGraph();
	return (
		<React.Fragment>

			<ToolBarContainer
				type="web"
				id={selectedMetric.id}
				options={isIsvWebChannel ? eventsOptions : dateOptions}
				metrics={metrics}
				metricView={metricView}
				channel={channel}
				selectedMetric={selectedMetric}
				data={data}
				handleDownloadMetric={handleDownloadMetric}
				handleMetricAnnotations={handleMetricAnnotations}
				isIsvWebChannel={isIsvWebChannel}
				endpoints={endpoints}
				handleMovingAvg={handleMovingAvg}
				optionsTooltip={"Types of Heatmaps"}
			/>
			{!isIsvWebChannel ?
				data.length > 0 ?
					<ChartRadius
						colors={vendorToColorMap}
						chartID={'amChart' + id}
						onGetRef={getChart}
						data={dataProvider}
						style={{ height: '350px' }}
					/> 
					: 
					<NoDataMessage
						message="No data to display"
						className={cn(style.loadingData,style.noData)}
					/> :
				<div className={style.heatmapWrapper} id="heatmapWrapper">
					{isEndpointDataPending ?
						<Spinner />
						: <Heatmap {...props} />
					}
				</div>
			}</React.Fragment>
	);
}

WebContainer.propTypes = {
	isIsvWebChannel: PropTypes.bool,
	data: PropTypes.array,
	metrics: PropTypes.array,
	selectedMetric: PropTypes.object,
	metricView: PropTypes.string,
	endpointLabel: PropTypes.object,
	selectedGraphs: PropTypes.object,
	pending: PropTypes.bool
};


function mapStateToProps(state, ownProps) {
	return {
		metricId: ownProps.id || null,
		isIsvWebChannel: ownProps.endpointLabel.id && ownProps.endpointLabel.id !== ownProps.selectedMetric.id,
		isEndpointDataPending: getSelectedIsvEndpoint(state).pending,
		selectedEndpointData: getSelectedIsvEndpoint(state).data,
		metrics: ownProps.metrics,
		selectedGraphs: ownProps.selectedGraphs
			? ownProps.selectedGraphs
			: metricSelectors.getSelectedGraphs(state)

	};
}

function mapDispatchToProps(dispatch, ownProps) {
	let actions;
	if (ownProps.metricView === 'analytics') {
		actions = analyticsActions;
	} else {
		actions = dashboardActions;
	}
	return {
		dispatch: dispatch,
		actions: bindActionCreators({ ...actions, setMovingAvg, setDashboardMovingAvg }, dispatch),
	};
}
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(WebContainer));
