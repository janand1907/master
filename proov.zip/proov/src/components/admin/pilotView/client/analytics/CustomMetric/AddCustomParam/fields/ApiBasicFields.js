import React, { Fragment } from 'react';
import { Field, FormGroup, Error } from 'components/common/Forms';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import Select from 'components/ui/Select/Select';
import css from './../CreateCustomParam.scss';

const ApiBasicFields = props => {
	return (
		<Fragment>
			{!props.isViewMode && <Fragment >
				<FormGroup label="Parameter Name" mandatory>
					<Field
						name="label"
						component="input"
						type="text"
						className="form-control"
						maxLength="40"
					/>
					<Error sticky name="label" />
				</FormGroup>
			</Fragment>}

			<FormGroup label="API Type" mandatory className={{[css.hidden]: props.isViewMode}}>
				<Field
					name="locator.type"
					validateOn="change"
					component={({ input }) => (
						<RadioGroup
							name={input.name}
							selectedValue={input.value}
							onChange={input.onChange}
							className={css.controlPushMdWrapper}
						>
							<PushButton value="api.rest" className={css.controlPushMd}>
								REST
							</PushButton>
							<PushButton value="api.soap" className={css.controlPushMd}>
								SOAP
							</PushButton>
						</RadioGroup>
					)}
				/>
				<Error sticky name="locator.type" />
			</FormGroup>

			<div className={css.methodsWrapper}>
				{props.type === "api.rest" &&
					<FormGroup label="Methods" mandatory className={css.methods} key="locator.method">
						<Field
							name="locator.method"
							validateOn={['blur', 'change']}
							disabled={props.isViewMode}
							component={({ input }) => (
								<Select
									options={[{ id: 'GET', label: 'GET' }, { id: 'POST', label: 'POST' }, { id: 'PUT', label: 'PUT' }]}
									{...input}
									value={input.value}
									getValue="id"
									getLabel="label"
									required
								/>
							)}
						/>
						<Error sticky name="locator.method" />
					</FormGroup>
				}

				<FormGroup label="URL" mandatory className={css.url}>
					<Field
						name="locator.url"
						component="input"
						type="text"
						className="form-control"
						maxLength="2083"
						disabled={props.disabled || props.isViewMode}
					/>
					<Error sticky name="locator.url" />
				</FormGroup>
			</div>
		</Fragment>
	);
};

export default ApiBasicFields;
