import React from 'react';
import HttpHeaders from './HttpHeaders';
import { FormGroup, Field, Error } from 'components/common/Forms';
import css from './../CreateCustomParam.scss';

const BearerToken = (props) => {
    return <div>
        <div className={css.authArea}>
            <FormGroup key="auth.key" label="Response Token Field Name" mandatory className={css.field}>
                <Field name="auth.key" component="input" type="text" className="form-control"  disabled={props.isViewMode}/>
                <Error sticky name="auth.key" />
            </FormGroup>
            <FormGroup key="auth.token_url" label="Token URL" mandatory className={css.field}>
                <Field name="auth.token_url" component="input" type="text" className="form-control" disabled={props.isViewMode}/>
                <Error sticky name="auth.token_url" />
            </FormGroup>
        </div>
        <HttpHeaders type={props.type} disabled={props.disabled || props.isViewMode} keyName={"auth."} />
        <FormGroup label="Body" mandatory>
				<Field
					name="auth.body"
					component="textarea"
					type="text"
					className="form-control"
					maxLength="2083"
                    disabled={props.isViewMode}
				/>
                 <Error sticky name="auth.body" />
			</FormGroup>
    </div>
}

export default BearerToken;