import React from 'react';
import PropTypes from 'prop-types';
import { memoize } from 'lodash';
import AmSerialMetric from 'components/ui/AmCharts/AmSerialMetric/AmSerialMetric';
import { calculateMovingAvgData } from 'utils/movingAverage';

const calcMovingAvg = memoize(calculateMovingAvgData, (...args) =>
	JSON.stringify(args)
);

class ArchiveChart extends React.PureComponent {
	render() {
		const {
			data,
			movingAvg,
			selectedMetric,
			vendors,
			selectedGraphs,
			colorMap,
			onZoom,
			onShowAllClick,
			enableShowAll,
		} = this.props;

		return (
			<AmSerialMetric
				data={movingAvg ? calcMovingAvg(data, movingAvg) : data}
				vendors={vendors}
				selectedGraphs={selectedGraphs}
				metric={selectedMetric}
				graphsIds={selectedGraphs}
				colorMap={colorMap}
				onZoom={onZoom}
				onShowAll={onShowAllClick}
				enableShowAll={enableShowAll}
			/>
		);
	}
}

ArchiveChart.propTypes = {
	onZoom: PropTypes.func,
	movingAvg: PropTypes.number,
	onShowAllClick: PropTypes.func,
	data: PropTypes.array,
	vendors: PropTypes.array,
	selectedMetric: PropTypes.object,
	selectedGraphs: PropTypes.object,
	colorMap: PropTypes.object,
	enableShowAll: PropTypes.bool,
};

export default ArchiveChart;
