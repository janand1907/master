import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { setMetric } from 'ducks/admin/analytics/metrics/actions';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import {
	getSelectedMetric,
	getMetrics,
} from 'ducks/admin/analytics/metrics/selectors';
import { getSimulatorSelector } from 'ducks/admin/analytics/simulator/selectors';
import {
	resetSimulator,
	setSimulatorVendor,
	getSimulator,
} from 'ducks/admin/analytics/simulator/actions';
import SimulationTab from './SimulationTab';

class SimulationTabContainer extends React.PureComponent {
	componentDidMount() {
		const { pilot, selectedMetric, simulator, metrics } = this.props;
		const filteredMetrics = metrics.filter(
			({ is_simulation }) => is_simulation
		);

		const vendorId =
			simulator.vendorId || (pilot.vendors.length > 0 && pilot.vendors[0].id);
		if (vendorId && pilot.vendors.length > 0 && filteredMetrics.length > 0) {
			this.props.actions.setMetric(
				filteredMetrics[0].id,
				'simulator',
				vendorId,
				filteredMetrics[0]

			);
			this.props.actions.setSimulatorVendor(vendorId);
			this.props.actions.getSimulator(
				pilot.id,
				selectedMetric.channel_id,
				filteredMetrics[0].id,
				vendorId
			);
		}
	}

	render() {
		const metrics = this.props.metrics.filter(
			({ is_simulation }) => is_simulation
		);

		return (
			<SimulationTab
				selectedMetric={this.props.selectedMetric}
				metrics={metrics}
				hasVendors={this.props.vendors.length > 0}
			/>
		);
	}

	componentWillUnmount() {
		this.props.actions.resetSimulator();
	}
}

SimulationTabContainer.propTypes = {
	actions: PropTypes.object,
	vendors: PropTypes.array,
	selectedMetric: PropTypes.object,
	metrics: PropTypes.array,
};

function mapStateToProps(state) {
	const pilot = getAdminPilot(state);
	return {
		vendors: pilot && pilot.vendors,
		pilot,
		selectedMetric: getSelectedMetric(state),
		simulator: getSimulatorSelector(state),
		metrics: getMetrics(state),
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators(
			{
				setMetric,
				setSimulatorVendor,
				getSimulator,
				resetSimulator,
			},
			dispatch
		),
	};
}

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(SimulationTabContainer);
