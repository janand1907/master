import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import css from './PathTooltip.scss';

const PathTooltip = ({ type }) => {
	return (
		<TooltipTarget tooltip={
			type === 'soap' ?
				<Tooltip className={css.root}>
				XPath is used to navigate through elements and <br />
				attributes in an XML document. <br />
				For exmple: <br />
				/bookstore/book3/title
				</Tooltip> :
				<Tooltip className={css.root}>
				JsonPath is used to navigate through objects<br />
				in a JSON structure document.<br />
				For exmple:<br />
				$.phoneNumbers:1.type
				</Tooltip>}>
			<InfoIcon className={css.infoIcon} />
		</TooltipTarget>
	);
};

PathTooltip.propTypes = {
	type: PropTypes.string.isRequired
};

export default PathTooltip;
