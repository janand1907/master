import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as dashboardActions from 'ducks/admin/dashboard/actions';
import * as analyticsActions from 'ducks/admin/analytics/charts/actions';
import { withRouter } from 'react-router-dom';
import { showModal } from 'ducks/modal/actions';
import { NewSpinner } from 'components/ui/NewSpinner';
import { checkVendorMetric } from 'ducks/admin/analytics/metrics/actions';
import { getMetricView } from 'ducks/admin/analytics/metrics/selectors';
import * as i18n from 'i18n/en/charts.json';
import EditIcon from 'components/ui/Icons/EditIcon';
import ToolBarContainer from '../ToolBar/ToolBarContainer';
import Feed from './Feed';
import { DATA_RESOLUTION } from 'constants/dataResolution';
import { spinnerWrapper, notActive, editIcon } from './Feed.scss';

function FeedContainer({
	data,
	error,
	pending,
	metrics,
	selectedMetric,
	selectedVendors,
	vendorToColorMap,
	channelId,
	actions,
	resolution,
	metricView,
	pilotId,
	metricId,
	handleShowAll,
	history
}) {

	React.useEffect(() => {
		if (resolution === DATA_RESOLUTION.ARCHIVE) {
			actions.stopLiveData(metricId);
			actions.getArchivePeriodic(metricId);
		} else {
			actions.stopLiveData(metricId);
			actions.getLiveData(metricId);
		}

		() => {
			if (resolution === DATA_RESOLUTION.LIVE) {
				actions.stopLiveData(metricId);
			}
		};
	}, [resolution, metricId]);

	const handleEditMetric = () => {
		history.push(
			`/admin/pilot/${pilotId}/analytics/edit-metric/${selectedMetric.id}`
		);
	}

	const selectedVendorData = data.filter(({ company_id }) =>
		selectedVendors.includes(company_id)
	);

	if (pending) {
		return <NewSpinner wrapperClassName={spinnerWrapper} size="m" />;
	}

	return (
		<React.Fragment>
			<ToolBarContainer
				id={selectedMetric.id}
				metrics={metrics}
				metricView={metricView}
				metricId={metricId}
				selectedMetric={selectedMetric}
				handleShowAll={handleShowAll}
				type="feed"
			/>
			{resolution === DATA_RESOLUTION.LIVE && (selectedMetric.status === 'failed' || (!selectedMetric.script && selectedMetric.draft)) ?
				<div className={notActive}> <p onClick={handleEditMetric}>{i18n.messages.isnotactive}</p> <EditIcon className={editIcon} onClick={handleEditMetric} /> </div> :
				<Feed
					data={selectedVendorData}
					resolution={resolution}
					metricView={metricView}
					selectedVendors={selectedVendors}
					selectedMetric={selectedMetric}
					colorMap={vendorToColorMap}
				/>}
		</React.Fragment>
	);
}

FeedContainer.propTypes = {
	/**
	 * @ignore react-router
	 */
	history: PropTypes.shape({
		push: PropTypes.func.isRequired,
	}).isRequired,
	data: PropTypes.array.isRequired,
	error: PropTypes.string,
	pending: PropTypes.bool,
	metrics: PropTypes.array,
	selectedMetric: PropTypes.object.isRequired,
	selectedVendors: PropTypes.array,
	vendorToColorMap: PropTypes.object.isRequired,
	channelId: PropTypes.string,
	actions: PropTypes.object.isRequired,
	resolution: PropTypes.string,
	metricId: PropTypes.string,
	metricView: PropTypes.string,
	pilotId: PropTypes.string,
	handleShowAll: PropTypes.func,
};

function mapStateToProps(state, ownProps) {
	return {
		id: ownProps ? ownProps.id : undefined,
		metricView: getMetricView(state),
		metricId: ownProps.id || ownProps.selectedMetric.id
	};
}

function mapDispatchToProps(dispatch, ownProps) {
	let actions;
	if (ownProps.metricView === 'analytics') {
		actions = analyticsActions;
	} else {
		actions = dashboardActions;
	}
	return {
		dispatch: dispatch,
		actions: bindActionCreators({ ...actions, checkVendorMetric, showModal }, dispatch),
	};
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(FeedContainer)
);
