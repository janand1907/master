import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import css from './FuncTooltip.scss';

const BUSINESS_KPI = 'Business KPI';
const CUSTOM_CHART = 'Custom Chart';

const FuncTooltip = props => {
	const { metric, category } = props;
	const { script, formula } = metric;
	if (!script || (!formula && category === BUSINESS_KPI)) return null;
	if (!metric.kpi_label && category === CUSTOM_CHART) return null;

	let textToDisplay;

	switch (category) {
		case BUSINESS_KPI:
			textToDisplay = metric.expression_to_display;
			break;

		case CUSTOM_CHART:
			textToDisplay = metric.kpi_label;
			break;
	}

	return (
		<TooltipTarget
			tooltip={
				<Tooltip placement="bottom" className={css.funcTooltip}>
					{textToDisplay}
				</Tooltip>
			}
		>
			<InfoIcon className={css.infoIcon} />
		</TooltipTarget>
	);
};

FuncTooltip.propTypes = {
	metric: PropTypes.object,
	category: PropTypes.string
};

export default FuncTooltip;
