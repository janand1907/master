import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { modelSelector } from 'ducks/forms/selectors';
import * as selectors from 'ducks/admin/analytics/customMetric/selectors';
import * as actions from 'ducks/admin/analytics/customMetric/actions';
import { NewSpinner } from 'components/ui/NewSpinner';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { getChannelId } from 'ducks/admin/analytics/metrics/selectors';
import { showModal } from 'ducks/modal/actions';
import { createToast } from 'ducks/toaster/actions';
import { createScriptExpression } from 'utils';
import { transformParams, combineParameters, cleanExpressionFromSyntax } from 'components/admin/common/script/utils';
import CreateNewCustomMetric from './CreateNewCustomMetric';

const EXPRESSION_TYPE = {
	formula: 'FORMULA',
	javascript: 'JS6',
	python: 'PY3'
};
class CreateNewCustomMetricContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleExpressionTypeChange = this.handleExpressionTypeChange.bind(this);
		this.handleTest = this.handleTest.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}

	componentDidMount() {
		if (this._form) this._form.reset();
		this.props.resetCustomMetric();
		this.props.getParameters(this.props.pilot.id);
	}

	UNSAFE_componentWillReceiveProps(nextProps) {
		if (
			nextProps.model &&
			nextProps.model.expression_type !== this.props.model.expression_type
		) {
			this.props.resetMetricValidate();
		}
	}

	handleTest() {
		if (this._form) this._form.clearErrors();
		const { label, schedule, script, formula, expression_type } = this.props.model;

		let expression = null,
			usedParameters = null;
		if (expression_type === 'formula') {
			expression = formula;
			usedParameters = formula;
		} else {
			expression = cleanExpressionFromSyntax(
				script,
				this.props.usedParameters,
				this.props.environment
			);
			usedParameters = this.props.usedParameters;
		}

		this.props.onValidateMetric(
			label,
			schedule,
			expression,
			expression_type,
			transformParams(usedParameters)
		);
	}

	handleSubmit(model, args) {
		const {
			label,
			description,
			schedule,
			script,
			formula,
			expression_type
		} = this.props.model;

		let expression = null,
			usedParameters = null;
		if (expression_type === 'formula') {
			expression = formula;
			usedParameters = formula;
		} else {
			expression = cleanExpressionFromSyntax(
				script,
				this.props.usedParameters,
				this.props.environment
			);
			usedParameters = this.props.usedParameters;
		}
		const isDraft = args.length && args[0].type;
		this.props.onSubmit(
			label,
			description,
			schedule,
			expression_type,
			expression,
			transformParams(usedParameters),
			isDraft
		);
	}

	handleExpressionTypeChange(expressionType) {
		this._form && this._form.change('expression_type', expressionType);
	}

	render() {
		if (this.props.pendingParameters) {
			return <NewSpinner />;
		} else {
			return (
				<CreateNewCustomMetric
					{...this.props}
					scriptParameters={this.props.scriptParameters}
					onTest={this.handleTest}
					onSubmit={this.handleSubmit}
					onExpressionTypeChange={this.handleExpressionTypeChange}
					form={this._form}
					formRef={node => {
						this._form = node && node.getWrappedInstance();
					}}
				/>
			);
		}
	}
}

CreateNewCustomMetricContainer.propTypes = {
	model: PropTypes.object.isRequired,
	form: PropTypes.object,
	pendingParameters: PropTypes.bool,
	pilot: PropTypes.object.isRequired,
	getParameters: PropTypes.func,
	resetMetricValidate: PropTypes.func,
	resetCustomMetric: PropTypes.func,
	onValidateMetric: PropTypes.func,
	onSubmit: PropTypes.func,
	usedParameters: PropTypes.array,
	environment: PropTypes.array,
	scriptParameters: PropTypes.array
};

function mapStateToProps(state) {
	const parameters = selectors.getParameters(state);
	const pilot = getAdminPilot(state);

	return {
		pilot,
		environment: pilot.environment,
		channelId: getChannelId(state),
		scriptParameters: parameters && combineParameters(parameters.data, pilot.vendors),
		usedParameters: parameters.used,
		model: modelSelector(state, 'customMetric') || {},
		pendingParameters: selectors.getParametersPending(state).get
	};
}

function mergeProps(stateProps, dispatchProps, ownProps) {
	const { pilot } = stateProps;
	return {
		...stateProps,
		...ownProps,
		...dispatchProps,
		onUpdateUsedParams: parameters => dispatchProps.updateUsedParameters(parameters),
		onValidateMetric: (label, schedule, cleanExpression, expressionType, params) => {
			dispatchProps.validateMetric(
				pilot.id,
				label,
				schedule,
				createScriptExpression(cleanExpression),
				EXPRESSION_TYPE[expressionType],
				params
			);
		},
		onAddCustomParam: () => {
			dispatchProps.showModal('CreateNewCustomParam', { pilotId: pilot.id });
		},
		onSubmit: (
			label,
			description,
			schedule,
			expression_type,
			cleanExpression,
			params,
			isDraft
		) => {
			const { history } = ownProps;
			if (isDraft)
				dispatchProps.saveDraft(
					pilot.id,
					label,
					description,
					schedule,
					createScriptExpression(cleanExpression),
					EXPRESSION_TYPE[expression_type],
					params,
					history
				);
			else dispatchProps.createMetric(
				pilot.id,
				label,
				description,
				schedule,
				createScriptExpression(cleanExpression),
				EXPRESSION_TYPE[expression_type],
				params,
				history,
			);
		}
	};
}

export default connect(
	mapStateToProps,
	{ showModal, createToast, ...actions },
	mergeProps
)(CreateNewCustomMetricContainer);
