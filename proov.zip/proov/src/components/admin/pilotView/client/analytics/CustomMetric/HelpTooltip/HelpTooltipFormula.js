import React from 'react';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import * as i18n from 'i18n/en/pilotView.json';
import css from './HelpTooltip.scss';

const HelpTooltipFormula = () => {
	return (
		<TooltipTarget tooltip={
			<Tooltip placement="bottom" className={css.root}>
				{globalize.parseString(i18n.client.helpTooltip.formula1)}

				{globalize.parseString(i18n.client.helpTooltip.formula2)}
				<br />

				{i18n.client.helpTooltip.formula3}
			</Tooltip>}>
			<InfoIcon className={css.infoIcon} />
		</TooltipTarget>
	);
};

export default HelpTooltipFormula;
