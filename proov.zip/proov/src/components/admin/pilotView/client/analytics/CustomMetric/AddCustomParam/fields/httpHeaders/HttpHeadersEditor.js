import React from 'react';
import PropTypes from 'prop-types';
import isLength from 'validator/lib/isLength';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { FormGroup, Field, Error } from 'components/common/Forms';
import * as i18n from 'i18n/en/channelForm.json';
import DropZone from 'components/ui/DropZone/DropZone';
import { CloseIcon, PlusIcon } from 'components/ui/Icons';
import { FileIcon } from 'components/ui/Icons';
import { readFileAsText } from 'utils';
import { AutoComplete } from 'components/ui/AutoComplete';
import { autocompleteConstant } from 'ducks/flows/invitePilot/actions';
import Shelf from 'components/ui/Rack/Shelf';
import style from './../../CreateCustomParam.scss';
import { HTTP_HEADERS_VALUE, HTTP_HEADERS_KEY } from 'constants/customParams';
import cx from 'utils/classNames';

function HttpHeadersEditor({
	onAdd,
	onSave,
	onCancel,
	initialValue,
	mode,
	authType,
	existingValue,
	existingIndex,
	actions
}) {
	const [httpHeaders, setHttpHeaders] = React.useState({});

	React.useEffect(() => {
		const key = initialValue ? initialValue.key : '';
		const value = initialValue ? initialValue.value :'';

		setHttpHeaders({
			currentKey: key,
			invalidKey: false,
			illegalKey: false,
			duplicateKey: false,
			currentValue: value,
			invalidValue: false,
		});
	}, [initialValue, setHttpHeaders]);

	function handleValidate(event,value) {
		const { currentKey, currentValue } = httpHeaders;
		const fieldName = event.target.name;

		if (fieldName === 'http_headers_key') {
			setHttpHeaders({
				...httpHeaders,currentKey:value
			});
		} else {
			setHttpHeaders({
				...httpHeaders,currentValue:value
			});
		}
	}

	function duplicateKeyCheck() {
		if (existingValue.length !== 0) {
			const duplicateKey =
				existingValue.filter(
					(c, index) =>
						index !== existingIndex && c.value === httpHeaders.currentKey
				).length !== 0;
			setHttpHeaders({ ...httpHeaders, duplicateKey: duplicateKey });
		}
	}

	function handleAddClick() {
			const { currentKey, currentValue } = httpHeaders;
				onAdd({
					key: currentKey.trim(),
					value: currentValue.trim(),
				});
				setHttpHeaders({ ...httpHeaders, currentKey: '', currentValue: '' })
		
	}

	function handleUpdateClick() {
		const { currentKey, currentValue } = httpHeaders;
		onSave({
			key: currentKey.trim(),
			value: currentValue.trim(),
		});
	}

	function handleCancelClick() {
		onCancel();
		setHttpHeaders({ ...httpHeaders, currentKey: '', currentValue: '' });
	}

	function handleInputChange(event) {
		event.persist();
		const fieldData = event;
		const fieldName =
			event.target.name === 'http_headers_key'
				? 'currentKey'
				: 'currentValue';

		setHttpHeaders({ ...httpHeaders, [fieldName]: event.target.value }, () =>
			handleValidate(fieldData)
		);
	}
	function handleChange(value, done, input) {
		 input.onChange(value);
		let suggestionsData = [];
		if (value) {
			const items = input.name.includes("key") ? HTTP_HEADERS_KEY : HTTP_HEADERS_VALUE;
			return actions.autocompleteConstant(value, items, done)
		}
		else {
			done();
			return null;
		}

	}

	const AutoCompleteHeaders = ({ input }) => {
		return <div>
			<AutoComplete
				itemRenderFn={item => { return item.item.value }}
				onChange={(val, done) => { handleChange(val, done, input) }}
				isInput={true}
				allowDuplicates={false}
				onSelect={(value) => input.onChange(value.value)}
				style={{ width: '100%' }}
				classNameMenu={style.autocompleteConstant}
				inputProps={{ className: 'form-control', ...input,onBlur:handleValidate}}
			/>

		</div>
	}
	const {
		currentKey,
		invalidKey,
		duplicateKey,
		currentValue,
		invalidValue,
		illegalKey,
	} = httpHeaders;
	const disabled =  currentKey=='' ||currentValue ==''
	return (

		<div className={style.editor}>
			<div className={style.halfWidthWrapper}>
				<FormGroup
					inline
					className={style.credentialField}
					mandatory
				>
					<Field
						key="http_headers_key"
						name="http_headers_key"
						className="form-control"
						data-invalid={
							invalidKey || duplicateKey || illegalKey
						}
						type="text"
						maxLength="200"
						
						component={({ input }) => (
							<AutoCompleteHeaders input={{...input,value:currentKey,placeholder:"key"}} 	 />
						)}
						
					/>

					<Error sticky name="http_headers_key" />

				</FormGroup>
				<FormGroup
					inline
					className={style.credentialField}
					mandatory
				>
					<Field
						key="value"
						name="http_headers_value"
						className="form-control"
						type="text"
						maxLength="200"
						component={({ input }) => (
							<AutoCompleteHeaders input={{...input,value:currentValue,placeholder:"Value"}} />
						)}
					/>
					<Error sticky name="http_headers_value" />


				</FormGroup>
			</div>


			<div className={style.editActions}>
				{mode === 'edit' && (
					<button
						type="button"
						onClick={handleCancelClick}
						className={style.actionBtn}
					>
						Cancel
					</button>
				)}
				<PlusIcon
					onClick={!disabled && handleAddClick}
					className={cx(style.actionBtn, disabled && style.disabled)}
				>
					<title>Add Headers</title>
				</PlusIcon>
			</div>
		</div>
	);
}

HttpHeadersEditor.propTypes = {
	onAdd: PropTypes.func,
	onSave: PropTypes.func,
	onCancel: PropTypes.func,
	initialValue: PropTypes.object,
	existingValue: PropTypes.array,
	mode: PropTypes.string,
	authType: PropTypes.string,
	existingIndex: PropTypes.number,
};
HttpHeadersEditor.defaultProps = {
	authType: 'basic',
};
function mapDispatchToProps(dispatch) {
	return {
		dispatch: dispatch,
		actions: bindActionCreators({ autocompleteConstant }, dispatch),
	};
}
export default connect(null, mapDispatchToProps)(
	HttpHeadersEditor
);