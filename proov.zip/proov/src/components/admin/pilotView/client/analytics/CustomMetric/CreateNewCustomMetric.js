import { CRON_SCHEDULER } from 'constants/admin';
import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import { Field, FormGroup, Form, Error } from 'components/common/Forms';
import { Alert } from 'components/ui/Alert';
import { ErrorIcon } from 'components/ui/Icons';
import { Tabs } from 'components/ui/Tabs';
import Select from 'components/ui/Select/Select';
import { TEMPLATES } from 'constants/templates';
import ScriptContainer from './Script/ScriptContainer';
import css from './CustomMetric.scss';
import validators from 'components/admin/common/script/validation';

class CreateNewCustomMetric extends React.Component {
	constructor(props) {
		super(props);
		this.onUpdateUsedParams = this.onUpdateUsedParams.bind(this);
		this.state = { activeTab: 'Draft' };
	}

	onUpdateUsedParams(parameters, val) {
		this.props.onUpdateUsedParams(parameters)
	}

	render() {
		const {
			onSubmit,
			formRef,
			form,
			onAddCustomParam,
			onUpdateUsedParams,
			onTest,
			scriptParameters,
			onExpressionTypeChange
		} = this.props;

		const config = {
			form: 'customMetric',
			validators: pick(validators, ['label', 'description', 'javascript', 'python']),
			ref: formRef,
			onSubmit: onSubmit,
			initialValues: {
				expression_type: 'javascript',
				schedule: CRON_SCHEDULER['5 min']
			}
		};

		return (
			<div className={css.root}>
				<h3>CREATE BUSINESS KPI</h3>
				<Form {...config}>
					<Error
						name=""
						component={({ error }) => (
							<Alert type="error">
								<ErrorIcon className={css.errorIcon} />
								<span>{error}</span>
							</Alert>
						)}
					/>
					<div className={css.kpiFields}>
						<FormGroup className={css.kpiName} label="KPI Name" mandatory>
							<Field
								name="label"
								component="input"
								type="text"
								className="form-control"
								placeholder="Enter a name for the KPI"
								maxLength="40"
							/>
							<Error sticky name="label" />
						</FormGroup>
						<FormGroup className={css.kpiScheduler} label="Execution Scheduler">
							<Field
								name="schedule"
								validateOn={['blur', 'change']}
								component={({ input }) => (
									<Select
										required
										options={Object.keys(CRON_SCHEDULER)}
										{...input}
										getValue={interval => CRON_SCHEDULER[interval]}
									/>
								)}
							/>
							<Error sticky name="schedule" />
						</FormGroup>
					</div>
					<FormGroup  className={css.description} label="KPI Description">
						<Field
							name="description"
							component="input"
							type="text"
							className="form-control"
							placeholder="Enter a description for the KPI"
							maxLength="100"
						/>
						<Error sticky name="description" />
					</FormGroup>

					<Tabs
						tabList={["Draft"]}
						activeTab={this.state.activeTab}
					>
						<ScriptContainer
							form={form}
							parameters={scriptParameters}
							onAddCustomParam={onAddCustomParam}
							onUpdateUsedParams={this.onUpdateUsedParams}
							onExpressionTypeChange={onExpressionTypeChange}
							onTest={onTest}
							mode="create"

						/>
					</Tabs>
				</Form>
			</div>
		);
	}
}

CreateNewCustomMetric.propTypes = {
	onSubmit: PropTypes.func.isRequired,
	onUpdateUsedParams: PropTypes.func,
	onAddCustomParam: PropTypes.func.isRequired,
	onExpressionTypeChange: PropTypes.func.isRequired,
	onTest: PropTypes.func,
	formRef: PropTypes.func.isRequired,
	form: PropTypes.object,
	scriptParameters: PropTypes.array
};

export default CreateNewCustomMetric;
