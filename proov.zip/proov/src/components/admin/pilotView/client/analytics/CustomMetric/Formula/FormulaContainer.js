import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { modelSelector } from 'ducks/forms/selectors';
import {
	getParameters,
	getCustomMetric,
	getCustomMetricValidation,
	getParametersPending
} from 'ducks/admin/analytics/customMetric/selectors';
import * as actions from 'ducks/admin/analytics/customMetric/actions';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { showModal } from 'ducks/modal/actions';
import Formula from './Formula';

class FormulaContainer extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleChannelChanged = this.handleChannelChanged.bind(this);
		this.handleCustomParamDetails = this.handleCustomParamDetails.bind(this);
		this.handleDeleteParam = this.handleDeleteParam.bind(this);
	}

	UNSAFE_componentWillMount() {
		this.props.form && this.props.form.change('expression_type', 'formula');
	}

	componentDidMount() {
		this.props.actions.updateUsedParameters(this.props.params);
	}

	componentDidUpdate(prevProps) {
		const { formula } = this.props.model;
		if (formula && prevProps.model.formula !== formula) {
			this.props.actions.updateUsedParameters(formula);
		}
	}

	componentWillUnmount() {
		this.props.actions.resetUsedParameters();
	}

	handleChannelChanged(value) {
		const channelId = value.split(/_(.+)?/)[0];
		const endPoint = value.split(/_(.+)?/)[1];
		const { actions } = this.props;
		actions.setSelectedChannelIdForCreateWizard({ channelId, endPoint });
	}

	handleCustomParamDetails(param) {
		this.props.actions.showModal('CustomParamDetails', { ...param });
	}

	handleDeleteParam(param) {
		const { pilotId } = this.props;
		this.props.actions.showModal('DeleteCustomParam', { pilotId, param });
	}

	render() {
		const filteredEnvironment = this.props.environment.filter(
			channel => channel.status === CHANNEL_STATUS.READY.value
		);

		return (
			<Formula
				form={this.props.form}
				model={this.props.model}
				onTest={this.props.onTest}
				environment={filteredEnvironment}
				selectedChannelId={this.props.selectedChannelId}
				selectedEndPoint={this.props.selectedEndPoint}
				parameters={this.props.parameters}
				onAddCustomParam={this.props.onAddCustomParam}
				parameterPending={this.props.parameterPending}
				onChannelChanged={this.handleChannelChanged}
				pendingCreate={this.props.pendingCreate}
				customMetricValidation={this.props.customMetricValidation}
				handleEdit={this.handleEditMetric}
				handleShowDetails={this.handleCustomParamDetails}
				handleDelete={this.handleDeleteParam}
				mode={this.props.mode}
			/>
		);
	}
}

FormulaContainer.propTypes = {
	form: PropTypes.object,
	parameters: PropTypes.array,
	actions: PropTypes.object,
	params: PropTypes.array, // usedParameters in formula
	environment: PropTypes.array,
	selectedChannelId: PropTypes.string,
	selectedEndPoint: PropTypes.string,
	onAddCustomParam: PropTypes.func,
	parameterPending: PropTypes.bool,
	model: PropTypes.object,
	pendingCreate: PropTypes.bool,
	customMetricValidation: PropTypes.object,
	onTest: PropTypes.func,
	showModal: PropTypes.func,
	pilotId: PropTypes.string,
	mode: PropTypes.string
};

function mapStateToProps(state) {
	const pilot = getAdminPilot(state);
	const parameters = getParameters(state);
	const pending = getParametersPending(state);
	const pendingCreate = getCustomMetric(state).pending;
	const customMetricValidation = getCustomMetricValidation(state);

	return {
		pilotId: pilot.id,
		environment: pilot && pilot.environment,
		parameterPending: parameters && pending.get,
		selectedChannelId: parameters && parameters.selectedChannelId,
		selectedEndPoint: parameters && parameters.selectedEndPoint,
		model: modelSelector(state, 'customMetric') || {},
		pendingCreate,
		customMetricValidation
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators({ ...actions, showModal }, dispatch),
		dispatch
	};
}

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(FormulaContainer);
