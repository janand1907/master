import React, { Fragment } from 'react';
import { Field, FormGroup, Error } from 'components/common/Forms';
import PathTooltip from './tooltips/PathTooltip';

const RestFields = props => {
	return (
		<Fragment>
			<FormGroup
				label={
					<span>
						JSON Path <PathTooltip type="rest" />
					</span>
				}
			>
				<Field
					name="locator.path"
					component="input"
					type="text"
					className="form-control"
					maxLength="2083"
					disabled={!props.method || props.isViewMode}
				/>
				<Error sticky name="locator.path" />
			</FormGroup>
		</Fragment>
	);
};

export default RestFields;
