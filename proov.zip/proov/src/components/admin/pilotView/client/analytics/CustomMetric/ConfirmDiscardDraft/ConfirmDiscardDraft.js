import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { hideModal } from 'ducks/modal/actions';
import { deleteDraft } from 'ducks/admin/analytics/customMetric/actions';
import style from './ConfirmDiscardDraft.scss';
import * as i18n from 'i18n/en/analytics.json';

function ConfirmDiscardDraft(props) {
	function handleConfirm() {
		props.deleteDraft ? props.deleteDraft(props) : props.actions.deleteDraft(props);
	}

	function handleCancel() {
		props.actions.hideModal();
	}
	return (
		<div className={style.root}>
			<h4>{i18n.customMetric.draft.delete.warning}</h4>
			<p>{globalize.parseString(i18n.customMetric.draft.delete.info)}</p>
			<button type="button" className={style.btnCancel} onClick={handleCancel}>
				No
			</button>
			<button type="button" className={style.btnConfirm} onClick={handleConfirm}>
				Yes, Delete Draft
			</button>
		</div>
	);
}

ConfirmDiscardDraft.propTypes = {
	handleCancel: PropTypes.func,
	handleConfirm: PropTypes.func,
};

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators({ deleteDraft, hideModal }, dispatch)
	};
}

export default connect(
	null,
	mapDispatchToProps
)(ConfirmDiscardDraft);
