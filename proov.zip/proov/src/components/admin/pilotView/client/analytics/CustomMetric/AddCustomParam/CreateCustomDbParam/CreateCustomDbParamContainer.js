import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { find } from 'lodash';
import {
	getParameters,
	getParametersPending,
	getParamValidation
} from 'ducks/admin/analytics/customMetric/selectors';
import * as actions from 'ducks/admin/analytics/customMetric/actions';
import { modelSelector } from 'ducks/forms/selectors';
import { hideModal } from 'ducks/modal/actions';
import { createToast } from 'ducks/toaster/actions';
import CreateCustomDbParam from './CreateCustomDbParam';

class CreateCustomDbParamContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleTest = this.handleTest.bind(this);
	}

	componentWillUnmount() {
		if (this._form) this._form.reset();
		this.props.resetParameterValidate();
	}

	handleTest() {
		if (this._form) this._form.clearErrors();
		if (find(this.props.parameters, param => param.label === this.props.model.label)) {
			this._form.setErrors({
				label: 'Parameter name must be unique'
			});
		} else {
			this.props.onValidate(this.props.model);
		}
	}

	render() {
		const { formValues } = this.props;
		return (
			<CreateCustomDbParam
				{...this.props}
				onTest={this.handleTest}
				form={this._form}
				formRef={node => {
					this._form = node && node.getWrappedInstance();
				}}
				initialValues={{ ...formValues, label: formValues ?formValues.name: null }}
			/>
		);
	}
}

CreateCustomDbParamContainer.propTypes = {
	resetParameterValidate: PropTypes.func,
	model: PropTypes.object,
	parameters: PropTypes.array,
	onValidate: PropTypes.func.isRequired
};

function mapStateToProps(state) {
	const parameters = getParameters(state);

	return {
		parameters: parameters.data,
		pendingCreateParam: getParametersPending(state).create,
		customParamValidation: getParamValidation(state),
		model: modelSelector(state, 'createDbParam') || {}
	};
}

function mergeProps(stateProps, dispatchProps, ownProps) {
	const { pilotId } = ownProps;
	return {
		...stateProps,
		...ownProps,
		...dispatchProps,
		onValidate: model => {
			dispatchProps.validateParameter(pilotId, model.id, model.label, model.locator, model.auth);
		},
		onSubmit: values => {
			const { id, label, locator, auth} = values;
			if(id){
				dispatchProps.editParameter(pilotId, id, label, locator, auth, history);
			}
			else {
				dispatchProps.createParameter(pilotId, label, locator, auth, history);
			}
		},
		defaultValue: ownProps.defaultValue
	};
}

export default withRouter(
	connect(
		mapStateToProps,
		{ ...actions, hideModal, createToast },
		mergeProps
	)(CreateCustomDbParamContainer)
);
