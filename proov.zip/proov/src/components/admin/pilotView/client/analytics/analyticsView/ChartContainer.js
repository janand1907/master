import chartBullet from 'constants/chartBulletShape';
import React from 'react';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import { memoize } from 'lodash';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { DATA_RESOLUTION } from 'constants/dataResolution';
import { getDashboardItem } from 'ducks/admin/dashboard/selectors';
import * as analyticsCss from 'components/ui/AmCharts/AmSerialMetric/analytics.scss';
import * as style from 'components/admin/pilotView/client/analytics/AnalyticsSection.scss';
import { calculateMovingAvgData } from 'utils/movingAverage';
import { isChartHasData, isSelectedGraphs } from 'utils/charts/chartUtils';
import * as i18n from 'i18n/en/charts.json';
import EditIcon from 'components/ui/Icons/EditIcon';
import NoDataMessage from 'components/admin/common/charts/NoDataMessage/NoDataMessage';
import ToolBarContainer from 'components/admin/pilotView/client/analytics/ToolBar/ToolBarContainer';
import AmSerial from 'components/ui/AmCharts/types/AmSerial/AmSerial';
import * as metricSelectors from 'ducks/admin/analytics/metrics/selectors';
import * as chartSelectors from 'ducks/admin/analytics/charts/selectors';
import * as dashboardActions from 'ducks/admin/dashboard/actions';
import * as analyticsActions from 'ducks/admin/analytics/charts/actions';
import { checkVendorMetric, setMovingAvg } from 'ducks/admin/analytics/metrics/actions';
import * as dashboardCss from 'components/ui/AmCharts/AmSerialMetric/dashboard.scss';
import { setConfig as setConfigAnalytics } from 'components/ui/AmCharts/AmSerialMetric/configAnalytics';
import { setConfig as setConfigDashboard } from 'components/ui/AmCharts/AmSerialMetric/configDashboard';
import { transformData, configGraphs } from 'components/ui/AmCharts/utils';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import {
	setMovingAvg as setDashboardMovingAvg,
} from 'ducks/admin/dashboard/actions';
import cn from 'utils/classNames';
const calcMovingAvg = memoize(calculateMovingAvgData, (...args) =>
	JSON.stringify(args)
);

function ChartContainer({
	data,
	metricId,
	selectedMetric,
	channelId,
	pilotId,
	movingAvg,
	vendorToColorMap,
	selectedGraphs,
	selectedVendors,
	metricView,
	pending,
	error,
	type,
	resolution,
	metrics,
	actions,
	history,
	id
}) {
	const [isTrendLine, setIsTrendLine] = React.useState(false);
	const chartRef = React.useRef({ ignoreZoom: true });
	const chartData = movingAvg ? calcMovingAvg(data, movingAvg) : data;
	const nodata = isChartHasData(chartData);
	const isNotActive = resolution === DATA_RESOLUTION.LIVE && (selectedMetric.status === 'failed' || (!selectedMetric.script && selectedMetric.draft));
	const transform = transformData(chartData);
	const samples = data && data.length ? data[0].values[0].samples.length : 0;
	const avgOptions = [
		{ id: 5, label: 'MA5' },
		{ id: 10, label: 'MA10' },
		{ id: 15, label: 'MA15' }
	];
	const options = avgOptions.filter((avg) => avg.id < samples);

	React.useEffect(() => {
		if (resolution === DATA_RESOLUTION.ARCHIVE) {
			actions.stopLiveData(metricId);
			actions.getArchivePeriodic(metricId);
		} else {
			actions.stopLiveData(metricId);
			actions.getLiveData(metricId);
		}

		() => {
			if (resolution === DATA_RESOLUTION.LIVE) {
				actions.stopLiveData(metricId);
			}

			chartRef.current.chart.clear();
			chartRef.current = null;
		};
	}, [resolution, metricId]);

	const getChart = (ref) => {
		chartRef.current.chart = ref;
	};
	const handleShowAll = React.useCallback(() => {
		chartRef.current.chart.zoomOut();
	}, []);
	const toggleTrendLine = () => {
		setIsTrendLine(!isTrendLine);
	};
	const handleMovingAvg = (v) => {
		switch (metricView) {
			case 'analytics':
				actions.setMovingAvg(v);
				break;
			case 'dashboard':
				actions.setDashboardMovingAvg(metricId, v);
				break;
			default:
				break;
		}
	}
	const getFullTime = (date) => {
		let newDate = new Date(date);
		if (resolution === DATA_RESOLUTION.ARCHIVE) {
			newDate.setMinutes(newDate.getMinutes() + 30);
		}
		let getDate = `${newDate.getFullYear()}-${newDate.getMonth() + 1}-${newDate.getDate()}`;
		let time = `${newDate.getHours()}:${("0" + newDate.getMinutes()).slice(-2)}:${("0" + newDate.getSeconds()).slice(-2)}`;
		return `${getDate} ${time}`;
	}
	const handleMetricAnnotations = React.useCallback(() => {
		chartRef.current.chart.annotator()
	}, []);
	const handleEditMetric = () => {
		history.push(
			`/admin/pilot/${pilotId}/analytics/edit-metric/${selectedMetric.id}`
		);
	}

	const handleDownloadMetric = React.useCallback((format) => {
		if (chartRef.current.chart.export) {
			switch (format) {
				case 'PDF':
					chartRef.current.chart.export(format.toLowerCase(), { addURL: false }); break;
				case 'JPG':
				case 'PNG':
				case 'CSV':
				case 'XLSX':
				case 'JSON':
					chartRef.current.chart.export(format.toLowerCase()); break;
				case 'PRINT':
				default:
					chartRef.current.chart.print();
			}

		}
	}, []);

	if (!metrics) {
		return <NoDataMessage type="nodata" className={style.noData} />;
	}
	
	const metric =
		metrics && type === 'custom_chart'
			? [selectedMetric.id]
			: metrics.filter((metric) => metric && selectedMetric.id === metric.id);

	if (pending) {
		return (
			<NoDataMessage
				message="Loading metric data..."
				className={style.noData}
			/>
		);
	}

	const noVendors = isSelectedGraphs(selectedGraphs);
	let message =error|| "No data to display";
	if (noVendors) {
		message = "There are no Vendors in this PoC";
	}
	const selectedConfig =
		metricView === 'dashboard' ? setConfigDashboard : setConfigAnalytics;
	let config = selectedConfig(resolution, metric.unit, metric.label, transform);
	let trendLines = null;

	if (isTrendLine) {
		trendLines = chartData.length && chartData.map((data) => {
			const samples = data.values[0].samples.filter(sam => sam.y !== null);
			const compantId = data.company_id;
			return samples.length && selectedGraphs && selectedGraphs[data.company_id] &&
			{
				id: compantId,
				data: [{
					timestamp: new Date(samples[0].x).getTime()
					, [compantId]: samples.length && Math.round(samples[0].y * 100) / 100
				},
				{
					timestamp: new Date(samples[samples.length - 1].x).getTime(),
					[compantId]: samples.length && samples[samples.length - 1].y
				}]

			}


		}).filter((vendor) => vendor).reduce((a, v) => ({ ...a, [v.id]: v }), {})

	}
	config = {
		...config,
	}

	const selectedStyle =
		metricView === 'dashboard' ? dashboardCss : analyticsCss;
	const unit = metric.length && metric[0].unit;
	return (
		<React.Fragment>
			<ToolBarContainer
				type="chart"
				options={options}
				id={selectedMetric.id}
				metricId={metricId}
				metrics={metrics}
				metricView={metricView}
				selectedMetric={selectedMetric}
				data={data}
				handleShowAll={handleShowAll}
				handleDownloadMetric={handleDownloadMetric}
				handleMetricAnnotations={handleMetricAnnotations}
				handleTrendLine={toggleTrendLine}
				handleMovingAvg={handleMovingAvg}
			/>
			{isNotActive ? (
				<div className={style.notActive}> <p onClick={handleEditMetric}>{i18n.messages.isnotactive}</p> <EditIcon className={style.editIcon} onClick={handleEditMetric} /> </div>
			) : nodata ? (
				<NoDataMessage message={message} 	className={cn(style.noData, style.emptyData)} />
			) : (
				<AmSerial
					id={id}
					onGetRef={getChart}
					className={selectedStyle.chart}
					config={config}
					graphs={configGraphs(
						chartData,
						unit,
						vendorToColorMap,
						selectedGraphs,
						selectedVendors,
						chartBullet.ROUND,
						trendLines
					)}
					dataProvider={transform}
					listeners={[
						{
							event: 'dataUpdated',
							method: () => {
								chartRef.current.ignoreZoom = true;
							},
						},
						{
							event: 'drawn',
							method: () => {
								setTimeout(() => {
									chartRef.current.chart.zoomOut();
								}, 0);
							},
						},
					]}
				/>
			)}
		</React.Fragment>
	);
}

ChartContainer.propTypes = {
	/**
	  * @ignore react-router
	  */
	history: PropTypes.shape({
		push: PropTypes.func.isRequired,
	}).isRequired,
	actions: PropTypes.object,
	type: PropTypes.string, // the type of the metric
	pilotId: PropTypes.string,
	dataType: PropTypes.string,
	isFetchingLiveDataActive: PropTypes.bool,
	channelId: PropTypes.string,
	onZoom: PropTypes.func,
	onShowAllClick: PropTypes.func,
	data: PropTypes.array,
	metrics: PropTypes.array,
	pending: PropTypes.bool,
	vendors: PropTypes.array,
	selectedVendors: PropTypes.array,
	selectedMetric: PropTypes.object,
	selectedGraphs: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
	metricView: PropTypes.string,
	movingAvg: PropTypes.number,
	vendorToColorMap: PropTypes.object,
	className: PropTypes.string,
	resolution: PropTypes.string,
};

ChartContainer.defaultProps = {
	onZoom: () => { },
	onShowAll: () => { },
	enableShowAll: false,
};

function mapStateToProps(state, ownProps) {
	// ownProps - props coming from dashboard card
	return {
		metricId: ownProps.id || ownProps.selectedMetric.id,
		vendors: getAdminPilot(state).vendors,
		movingAvg:
			ownProps.metricView === 'dashboard' // if view is dashboard
				? getDashboardItem(state, ownProps.id).selectedMetric.movingAvg // get the average of the selected item
				: metricSelectors.getSelectedMetric(state).movingAvg, // this selector should retrieve from dashboard/analytics depends on the view

		selectedGraphs: ownProps.selectedGraphs
			? ownProps.selectedGraphs
			: metricSelectors.getSelectedGraphs(state),

		isFetchingLiveDataActive: ownProps.isFetchingLiveDataActive
			? ownProps.isFetchingLiveDataActive
			: chartSelectors.isFetchingLiveDataActive(state),

		selectedDates: ownProps.selectedDates
			? ownProps.selectedDates
			: chartSelectors.getSelectedDates(state),
	};
}

function mapDispatchToProps(dispatch, ownProps) {
	let actions;
	if (ownProps.metricView === 'analytics') {
		actions = analyticsActions;
	} else {
		actions = dashboardActions;
	}
	return {
		dispatch: dispatch,
		actions: bindActionCreators({ ...actions, checkVendorMetric, setMovingAvg, setDashboardMovingAvg }, dispatch),
	};
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ChartContainer));
