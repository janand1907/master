import React from 'react';
import PropTypes from 'prop-types';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import { FormGroup, Field, Error } from 'components/common/Forms';
import cn from 'utils/classNames';
import css from './../CreateCustomParam.scss';
import UsernamePasswordField from './UsernamePasswordField';

const OAuthFields = ({ grantType , isViewMode}) => {
	return (
		<div className={css.authArea}>
			<FormGroup label="Grant Type" mandatory className={css.grantTypeWrapper}>
				<Field
					name="auth.grant_type"
					validateOn="change"
					component={({ input }) => (
						<RadioGroup name={input.name} selectedValue={input.value} onChange={!isViewMode && input.onChange} className={css.controlPushMdWrapper}>
							<PushButton value="client_credentials" className={cn(css.controlPushMd, css.grantTypeField)}>Client Credentials</PushButton>
							<PushButton value="password" className={cn(css.controlPushMd, css.grantTypeField, css.password)}>Password</PushButton>
						</RadioGroup>
					)}
				/>
				<Error sticky name="auth.grant_type" />
			</FormGroup>

			<FormGroup key="auth.client_id" label="Client ID" mandatory className={css.field}>
				<Field name="auth.client_id" component="input" type="text" className="form-control"  disabled={isViewMode}/>
				<Error sticky name="auth.client_id" />
			</FormGroup>
			<FormGroup key="auth.client_secret" label="Client Secret" mandatory className={css.field}>
				<Field name="auth.client_secret" component="input" type="text" className="form-control"  disabled={isViewMode}/>
				<Error sticky name="auth.client_secret" />
			</FormGroup>
			<FormGroup key="auth.token_url" label="Token URL" mandatory className={css.tokenUrl}>
				<Field name="auth.token_url" component="input" type="text" className="form-control"  disabled={isViewMode}/>
				<Error sticky name="auth.token_url" />
			</FormGroup>

			{grantType === 'password' && <UsernamePasswordField />}

		</div>
	);
};

OAuthFields.propTypes = {
	grantType: PropTypes.string.isRequired
};

OAuthFields.defaultProps = {
	grantType: 'client_credentials'
};

export default OAuthFields;
