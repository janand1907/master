import React from 'react';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import * as i18n from 'i18n/en/pilotView.json';
import css from './HelpTooltip.scss';

const HelpTooltipScript = () => {
	return (
		<TooltipTarget tooltip={
			<Tooltip placement="bottom" className={css.root}>
				{globalize.parseString(i18n.client.helpTooltip.script)}
			</Tooltip>}>
			<InfoIcon className={css.infoIcon} />
		</TooltipTarget>
	);
};

export default HelpTooltipScript;
