/* eslint-disable camelcase */
import isLength from 'validator/lib/isLength';
import isIP from 'validator/lib/isIP';
import isInt from 'validator/lib/isInt';
import isURL from 'validator/lib/isURL';
import { createScriptExpression } from 'utils';
import * as i18n from 'i18n/en/customMetricValidation.json';

const isExist = value => !!value;
const str = value => (value || '').toString().trim();
const validator = (validate, message) => value =>
	!validate(value) ? message : undefined;
const projectIdPattern = /^[A-Za-z0-9\!\-\"\']{4,30}$/;
const variableName = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;

const validators = {
	label: val => {
		if (!str(val).match(variableName)) {
			return i18n.invalidName;
		} else if (!isLength(str(val), { min: 2, max: 40 })) {
			return i18n.invalidLength;
		}
	},
	'locator.db_type': validator(val => isExist(val), i18n.db_type),

	'locator.db_name': (val, { db_type }) => {
		if (db_type === 'bigquery') {
			const strVal = str(val);
			if (!isLength(strVal, { min: 4, max: 30 })) {
				return i18n.db_name.invalidLength1;
			}
			if (!strVal.match(projectIdPattern)) {
				return i18n.db_name.invalidProjectID;
			}
			if (!isLength(str(val), { min: 2, max: 128 })) {
				return i18n.db_name.invalidLength2;
			}
		} else if (!isLength(str(val), { min: 2, max: 128 })) {
			return i18n.db_name.invalidLength2;
		}
	},
	'locator.host': validator(val => {
		const valStr = str(val);
		return (
			(isIP(valStr) || isURL(valStr, { allow_underscores: true })) &&
			isLength(str(valStr), { min: 4, max: 2083 })
		);
	}, i18n.host),
	'locator.port': validator(val => isInt(str(val)) && val <= 65535, i18n.port),
	'locator.optional_headers': (val) => val.length > 4 ? "Up to 5 http headers" : val.length == 0 ? "Invalid user credentials" : undefined,
	'auth.username': validator(
		val => isLength(str(val), { min: 2, max: 110 }),
		i18n.username
	),
	'auth.password': value => {
		if (value && typeof value === 'object') return;
		if (!isLength(str(value), { min: 2, max: 200 })) {
			return i18n.password;
		}
	},
	'locator.query': validator(val => isExist(val), i18n.query),
	'locator.url': validator(
		val =>
			isLength(str(val), { min: 4, max: 2083 }) &&
			isURL(val, { allow_underscores: true }),
		i18n.url
	),
	'locator.body': validator(val=> isExist(val), i18n.body),
	'locator.path': validator(val => isExist(val), i18n.path),
	'locator.method': validator(val =>{ return isExist(val)}, i18n.method),
	'auth.client_id': validator(val => isExist(val), i18n.client_id),
	'auth.client_secret': validator(val => isExist(val), i18n.client_secret),
	'auth.token_url': validator(
		val =>
			isLength(str(val), { min: 4, max: 2083 }) &&
			isURL(val, { allow_underscores: true }),
		i18n.token_url
	),
	'auth.key':validator(val => isExist(val), i18n.key),
	'auth.value':validator(val => isExist(val), i18n.value),
	'auth.add_to': validator(val => isExist(val), i18n.add_to),
	'auth.key': validator(val=> isExist(val), i18n.response_token_key),
	'auth.body': validator(val=> isExist(val), i18n.body),
	script: val => {
		if (!isExist(val)) return i18n.expression_script.empty_script;
		if (str(val).match(/`/g)) return i18n.expression_script.invalid_script;
	},
	formula: val => {
		if (!isExist(createScriptExpression(val))) return i18n.expression_formula;
	}
};

export default validators;
