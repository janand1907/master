import React from 'react';
import PropTypes from 'prop-types';
import isLength from 'validator/lib/isLength';
import { filter, cloneDeep, uniqBy } from 'lodash';
import { Field, FormGroup, Form, Error } from 'components/common/Forms';
import { NewSpinner } from 'components/ui/NewSpinner';
import KpiList from './KpiList/KpiList';
import ChannelListField from './ChannelListField';
import css from './CreateNewCustomChart.scss';

//TODO validators, messages to i18n and text

class CreateNewCustomChart extends React.PureComponent {
	constructor(props) {
		super(props);
		this.filterChannelsByMetric = this.filterChannelsByMetric.bind(this);
		this.selectedChannels = this.selectedChannels.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
		this._formRef = this._formRef.bind(this);
		this.state = {
			filteredEnv: this.props.environment,
			metricId: null,
			selectedChannels: []
		};
	}

	_formRef(node) {
		if (node) {
			this._form = node.getWrappedInstance();
		}
	}

	filterChannelsByMetric(id) {
		let envTypes = cloneDeep(this.props.metrics)
			.find(f => f.id === id)
			.config.map(et => {
				if (et.hasOwnProperty('kpi_id')) {
					delete et.kpi_id;
				}
				return et;
			});

		if (!envTypes) return;

		let filteredEnv = [];
		envTypes.forEach(envType => {
			filteredEnv = filteredEnv.concat(
				filter(cloneDeep(this.props.environment), envType)
			);
		});

		filteredEnv = uniqBy(filteredEnv, env => {
			return env.id;
		});

		this.setState({ filteredEnv, metricId: id, selectedChannels: [] });
	}

	selectedChannels(selectedChannels) {
		this.setState({ selectedChannels });
	}

	handleSubmit(values) {
		this.props.onSubmit(values);
	}
	render() {
		const { pending, metrics } = this.props;
		const { filteredEnv, metricId, selectedChannels } = this.state;
		const config = {
			form: 'newCustomChart',
			ref: this._formRef,
			//validations
			validators: {
				label: value =>
					value && isLength(value, { min: 2 })
						? undefined
						: 'Please provide chart name (at least 2 characters) ',
				metric_id: value =>
					value && isLength(value, { min: 1 }) ? undefined : 'Please choose metric', // eslint-disable-line camelcase
				config: value =>
					value && value.length > 0 ? undefined : 'Please choose minimum one channel' // eslint-disable-line camelcase
			},
			onSubmit: this.handleSubmit
		};
		return (
			<div className={css.modal}>
				<div className={css.header}>
					<h2>New Custom Chart</h2>
				</div>

				<Form {...config} className={css.content}>
					<FormGroup label="Graph Name" mandatory>
						<Field
							name="label"
							component="input"
							type="text"
							className="form-control"
							placeholder="Enter a name for the custom graph"
						/>
						<Error sticky name="label" />
					</FormGroup>

					<FormGroup label="Metric" mandatory>
						<Field
							name="metric_group_id"
							component={({ input }) => (
								<KpiList
									metrics={metrics}
									onChange={id => {
										input.onChange(id);
										this.filterChannelsByMetric(id);
									}}
								/>
							)}
						/>
						<Error sticky name="metric_group_id" />
					</FormGroup>

					<FormGroup label="Channels" className={css.channelField} mandatory>
						<Field
							name="config"
							component={({ input }) => (
								<ChannelListField
									checkedEnv={selectedChannels || []}
									environment={filteredEnv}
									metric={metrics.find(f => f.id === metricId)}
									onChange={channels => {
										input.onChange(channels);
										this.selectedChannels(channels);
									}}
								/>
							)}
						/>
						<Error sticky name="config" />
					</FormGroup>
				</Form>

				<div className={css.footer}>
					<button
						type="button"
						disabled={pending}
						className={css.btnCancel}
						onClick={this.props.onCancel}
					>
						Cancel
					</button>

					<button
						onClick={() => this._form.submit()}
						className={css.btnCreate}
						disabled={pending || !selectedChannels.length}
					>
						{pending ? <NewSpinner size="s" /> : 'Create'}
					</button>
				</div>
			</div>
		);
	}
}

CreateNewCustomChart.propTypes = {
	environment: PropTypes.array,
	metrics: PropTypes.array,
	pending: PropTypes.bool,
	pendingMetrics: PropTypes.bool,

	onSubmit: PropTypes.func.isRequired,
	onCancel: PropTypes.func.isRequired
};

export default CreateNewCustomChart;
