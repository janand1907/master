import React from 'react';
import PropTypes from 'prop-types';
import css from './CustomParamToolTip.scss';

const Soap = ({ locator }) => {
	return (
		<ul className={css.list}>
			<li>
				<span className={css.locatorLabel}>xPath</span>
				<span className={css.locatorValue}>{locator.path}</span>
			</li>
			<li>
				<span className={css.locatorLabel}>URL</span>
				<span className={css.locatorValue}>{locator.url}</span>
			</li>
		</ul>
	);
};

Soap.propTypes = {
	locator: PropTypes.object
};

export default Soap;
