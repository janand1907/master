import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { find } from 'lodash';
import * as selectors from 'ducks/admin/analytics/customMetric/selectors';
import * as createMetricActions from 'ducks/admin/analytics/customMetric/actions';
import { modelSelector } from 'ducks/forms/selectors';
import { hideModal } from 'ducks/modal/actions';
import { createToast } from 'ducks/toaster/actions';
import normalizeData from './normalizeData';
import CreateCustomApiParam from './CreateCustomApiParam';

class CreateCustomApiParamContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleTest = this.handleTest.bind(this);
	}

	componentWillUnmount() {
		if (this._form) this._form.reset();
		this.props.resetParameterValidate();
	}

	handleTest() {
		if (this._form.validate())
			this.props.onValidate(this.props.model);
	}

	render() {
		const { formValues, isEditMode } = this.props;
		return (
			<CreateCustomApiParam
				{...this.props}
				onTest={this.handleTest}
				form={this._form}
				formRef={node => {
					this._form = node && node.getWrappedInstance();
				}}
				initialValues={{
					...formValues,
					locator: formValues && formValues.locator ? formValues.locator : { type: 'api.rest' },
					auth: formValues && formValues.auth ? formValues.auth : { type: 'basic', grant_type: 'client_credentials' },
					label: formValues && formValues.name,
					resp_example: formValues && formValues.resp_example,
					id: formValues && formValues.id
				}}
				isEditMode={isEditMode}
			/>
		);
	}
}

CreateCustomApiParamContainer.propTypes = {
	resetParameterValidate: PropTypes.func,
	onValidate: PropTypes.func,
	parameters: PropTypes.array,
	model: PropTypes.object
};

function mapStateToProps(state) {
	const parameters = selectors.getParameters(state);
	return {
		parameters: parameters.data,
		pendingCreateParam: selectors.getParametersPending(state).create,
		customParamValidation: selectors.getParamValidation(state),
		model: modelSelector(state, 'createApiParam') || {}
	};
}

function mergeProps(stateProps, dispatchProps, ownProps) {
	const { pilotId, history } = ownProps;
	return {
		...stateProps,
		...ownProps,
		...dispatchProps,
		onValidate: model => {
			const data = normalizeData(model);
			dispatchProps.validateParameter(pilotId, model.id, data.label, data.loc, data.auth);
		},
		onSubmit: (values, done) => {
			const data = normalizeData(values);
			const { label, loc, auth, id } = data;
			if (id != null) {
				dispatchProps.editParameter(pilotId, id, label, loc, auth, history);
			}
			else {
				dispatchProps.createParameter(pilotId, label, loc, auth, history);
			}
		}
	};
}

export default withRouter(
	connect(
		mapStateToProps,
		{ ...createMetricActions, hideModal, createToast },
		mergeProps
	)(CreateCustomApiParamContainer)
);
