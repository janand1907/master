import React from 'react';
import PropTypes from 'prop-types';
import ItemsExplorer from 'components/ui/ItemsExplorer/ItemsExplorer';
import ClickOutsideListener from 'components/ui/ClickOutsideListener/ClickOutsideListener';
import SelectedMetric from './SelectedMetric';
import style from './KpiList.scss';

class KpiList extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleSelectMetricToggle = this.handleSelectMetricToggle.bind(this);
		this.handleSelectMetricClose = this.handleSelectMetricClose.bind(this);
		this.handleItemSelected = this.handleItemSelected.bind(this);

		this.state = {
			isSelectMetricActive: false,
			selectedMetric: this.props.metrics[0]
		};
	}

	componentDidMount() {
		this.props.onChange(this.props.metrics[0].id);
	}

	handleSelectMetricToggle() {
		this.setState({ isSelectMetricActive: !this.state.isSelectMetricActive });
	}

	handleSelectMetricClose() {
		this.setState({ isSelectMetricActive: false });
	}

	handleItemSelected(item) {
		this.handleSelectMetricClose();
		this.setState({ selectedMetric: item }, () => {
			this.props.onChange(item.id);
		});
	}

	render() {
		const { metrics } = this.props;
		const { selectedMetric } = this.state;

		const {
			isSelectMetricActive
		} = this.state;
		return (
			<div className={style.root}>
				<ClickOutsideListener onClickOutside={this.handleSelectMetricClose} preventWrap>
					<div className={style.metricSelectWrapper}>
						<SelectedMetric
							selectedMetric={selectedMetric}
							onToggle={this.handleSelectMetricToggle}
						/>
						{isSelectMetricActive &&
							<ItemsExplorer
								className={style.metricsExplorer}
								categoriesListClassName={style.categoriesList}
								searchBoxClassName={style.searchBoxToolbar}
								items={metrics}
								categorized={true}
								allowSearch
								expandAllWhileSearching
								onItemSelected={this.handleItemSelected}
								getItemCategory={item => item.category}
								selectedItem={selectedMetric}
								searchPredicate={(text, item) => { return item.label.toLowerCase().indexOf(text) !== -1 }}
								renderItem={item => (<span>{item.label}</span>)}
								renderCategory={category => (<span className={style.explorerCategory}>{category}</span>)}
							/>}
					</div>
				</ClickOutsideListener>
			</div>
		);
	}
}

KpiList.propTypes = {
	metrics: PropTypes.array,
	onChange: PropTypes.func,
};

export default KpiList;
