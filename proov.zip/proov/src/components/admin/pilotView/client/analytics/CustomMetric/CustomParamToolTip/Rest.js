import React from 'react';
import PropTypes from 'prop-types';
import css from './CustomParamToolTip.scss';

const Rest = ({ locator }) => {
	return (
		<ul className={css.list}>
			<li>
				<span className={css.locatorLabel}>JSON Path</span>
				<span className={css.locatorValue}>{locator.path}</span>
			</li>
			<li>
				<span className={css.locatorLabel}>URL</span>
				<span className={css.locatorValue}>{locator.url}</span>
			</li>
		</ul>
	);
};

Rest.propTypes = {
	locator: PropTypes.object
};

export default Rest;
