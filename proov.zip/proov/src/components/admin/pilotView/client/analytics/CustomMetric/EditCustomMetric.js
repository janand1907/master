import { CRON_SCHEDULER } from 'constants/admin';
import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import { Field, FormGroup, Form, Error } from 'components/common/Forms';
import { Alert } from 'components/ui/Alert';
import { ErrorIcon } from 'components/ui/Icons';
import Select from 'components/ui/Select/Select';
import { Tabs } from 'components/ui/Tabs';
import FormulaContainer from './Formula/FormulaContainer';
import ScriptContainer from './Script/ScriptContainer';
import css from './CustomMetric.scss';
import validators from 'components/admin/common/script/validation';
import { transformScriptToFormula } from 'components/admin/common/script/utils';

const EXPRESSION_TYPE = {
	formula: 'formula',
	js6: 'javascript',
	py3: 'python'
};

class EditCustomMetric extends React.Component {

	constructor(props) {
		super(props);
		this.onChangeTab = this.onChangeTab.bind(this);
		this.state = { activeTab: props.metric.script ? 'Active': 'Draft' };
	}

	onChangeTab(tab) {
		this.setState({ activeTab: tab });
	}

	render() {
		const {
			onSubmit,
			formRef,
			form,
			onAddCustomParam,
			onUpdateUsedParams,
			onTest,
			onExpressionTypeChange,
			metric,
			formulaParameters,
			scriptParameters
		} = this.props;

		const { name, description, schedule, script_type, script, args, draft } = metric;
		const type = script_type === 'formula' ? 'formula' : 'script';
		const config = {
			form: 'customMetric',
			ref: formRef,
			onSubmit: onSubmit,
			validators: pick(validators, ['label', 'description', type]),
			initialValues: {
				label: name,
				description: description,
				schedule: schedule,
				[type]: type === 'formula' ? transformScriptToFormula(script, args) : this.state.activeTab === 'Draft' ? draft || script : script,
				expression_type: EXPRESSION_TYPE[script_type]
			}
		};

		return (
			<div className={css.root}>
				<h3>EDIT BUSINESS KPI</h3>
				<Form {...config}>
					<Error
						name=""
						component={({ error }) => (
							<Alert type="error">
								<ErrorIcon className={css.errorIcon} />
								<span>{error}</span>
							</Alert>
						)}
					/>
					<div className={css.kpiFields}>
						<FormGroup className={css.kpiName} label="KPI Name" mandatory>
							<Field
								name="label"
								component="input"
								type="text"
								className="form-control"
								placeholder="Enter a name for the KPI"
								maxLength="40"
							/>
							<Error sticky name="label" />
						</FormGroup>
						<FormGroup className={css.kpiScheduler} label="Execution Scheduler">
							<Field
								name="schedule"
								validateOn={['blur', 'change']}
								component={({ input }) => (
									<Select
										required
										options={Object.keys(CRON_SCHEDULER)}
										{...input}
										value={input.value}
										getValue={schedule => CRON_SCHEDULER[schedule]}
									/>
								)}
							/>
							<Error sticky name="schedule" />
						</FormGroup>
					</div>
					<FormGroup className={css.description} label="KPI Description">
						<Field
							name="description"
							component="input"
							type="text"
							className="form-control"
							placeholder="Enter a description for the KPI"
							maxLength="100"
						/>
						<Error sticky name="description" />
					</FormGroup>

					{this.props.metric.script_type === 'formula' ? (
						<FormulaContainer
							form={form}
							parameters={formulaParameters}
							params={metric.args}
							onAddCustomParam={onAddCustomParam}
							onTest={onTest}
							mode="edit"
						/>
					) : (
						<Tabs
							tabList={metric.script ? ['Active', 'Draft']: ['Draft']}
							activeTab={this.state.activeTab}
							onChange={this.onChangeTab}
						>
							<ScriptContainer
								form={form}
								params={metric.args}
								parameters={scriptParameters}
								onAddCustomParam={onAddCustomParam}
								onUpdateUsedParams={onUpdateUsedParams}
								metric={metric}
								onExpressionTypeChange={onExpressionTypeChange}
								onTest={onTest}
								mode={this.state.activeTab === 'Active' ? 'edit': 'draft'}
							/>
						</Tabs>
					)}
				</Form>
			</div>
		);
	}
}

EditCustomMetric.propTypes = {
	customMetricValidation: PropTypes.object.isRequired,
	onSubmit: PropTypes.func.isRequired,
	onUpdateUsedParams: PropTypes.func,
	onAddCustomParam: PropTypes.func.isRequired,
	usedParameters: PropTypes.array,
	onExpressionTypeChange: PropTypes.func.isRequired,
	onTest: PropTypes.func,
	formRef: PropTypes.func.isRequired,
	form: PropTypes.object,
	pendingCreate: PropTypes.bool,
	metric: PropTypes.object
};

export default EditCustomMetric;
