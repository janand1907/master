import React from 'react';
import PlusIcon from 'components/ui/Icons/PlusIcon';
import cn from 'utils/classNames';
import css from './AddCustomParam.scss';

function AddCustomParam(props) {
	return <div className={cn(css.wrapper, props.className)}>
		<div className={css.plusParamWrapper}>
			<button className={css.plusParamButton} type="button" onClick={props.onSelect}>
				<PlusIcon className={css.plusIcon} />
				<span className={css.plusParam}>{'PARAMETER'}</span>
			</button>
		</div>
	</div >
}

export default AddCustomParam;
