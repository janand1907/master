import { DELETED } from 'constants/channel/channelStatus';
import { API, VPN, SFTP, B_KPI, CUSTOM_CHART, SAAS, READY, FAILED, LIVE, SERVER, DOCKER, STORAGE, DB, BLOCKCHAIN, WEB } from 'constants/channel/channelType';
import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import SearchBox from 'components/ui/SearchBox/SearchBox';
import ItemsExplorer from 'components/ui/ItemsExplorer/ItemsExplorer';
import ParentCategory from 'components/ui/ItemsExplorer/ParentCategory';
import CategoryHeader from 'components/ui/ItemsExplorer/CategoryHeader';
import Accordion from 'components/ui/Accordion/Accordion';
import cn from 'utils/classNames';
import css from './ChannelsMenu.scss';

const ChannelsMenu = (props) => {
	const [searchText, setSearchText] = React.useState("");
	const [filterChannels, setChannels] = React.useState(props.channels)
	const { channelId, endpointLabel, channels, onSetChannel, onClickISV, metrics, metricsChart, vendors, onClickWebChannel } = props;
	let mappedChannel = {
		B_KPI: { type: B_KPI, items: [], id: null, name: "Business KPI", status: 'ready', level: 2, className: css.largeIcon, itemCategoryStyle: css.bkpItemCategory, itemFieldToDisplay: "name", withMetrics: true },
		CUSTOM_CHART: { type: CUSTOM_CHART, items: [], id: 'customChart', name: 'Custom Chart', status: 'ready', level: 2, itemCategoryStyle: css.customChartItemCategory, itemFieldToDisplay: "label", withMetrics: true },
		LIVE: { type: LIVE, id: 'live', name: 'Live', items: [], level: 1, isNoSpace: true },
		API: { type: API, id: 'api', items: [], name: 'Api', level: 3, },
		BLOCKCHAIN: { type: BLOCKCHAIN, id: 'blockchain', items: [], name: "Blockchain", level: 2, itemCategoryStyle: css.channelItemCategory, itemFieldToDisplay: "name", isNoSpace: true, iconWrapperStyle: css.iconWrapperStyle },
		DB: { type: DB, id: 'db', items: [], name: 'DB', level: 2, itemCategoryStyle: css.channelItemCategory, itemFieldToDisplay: "name", className: css.largeIcon, isNoSpace: true, iconWrapperStyle: css.iconWrapperStyle },
		DOCKER: { type: DOCKER, id: 'docker', items: [], name: 'Docker', level: 2, itemCategoryStyle: css.channelItemCategory, itemFieldToDisplay: "name", isNoSpace: true, iconWrapperStyle: css.iconWrapperStyle },
		SERVER: { type: SERVER, id: 'server', items: [], name: 'Server', level: 2, itemCategoryStyle: css.channelItemCategory, itemFieldToDisplay: "name", isNoSpace: true, iconWrapperStyle: css.iconWrapperStyle },
		STORAGE: { type: STORAGE, id: 'storage', items: [], name: 'Storage', level: 2, itemCategoryStyle: css.channelItemCategory, itemFieldToDisplay: "name", isNoSpace: true, iconWrapperStyle: css.iconWrapperStyle },
		SAAS: { type: SAAS, id: 'saas', items: [], name: "SaaS Channel", level: 4, groupIconStyle: css.groupIconStyle },
		WEB: { type: WEB, id: 'web', items: [], name: "Web Channel", level: 3, isShowInformation: false, typeToIcon: "proovIcon", sendEndpointLabel: true, isHideIconForItemList: true },
		DELETED: { type: DELETED.value, id: 'deleted', items: [], name: "Deleted", level: 2, className: css.largeIcon, itemFieldToDisplay: "name" }
	};

	filterChannels.forEach((c) => {
		switch (c.status) {
			case DELETED.value:
				if (c.type !== VPN && c.type !== SFTP) mappedChannel.DELETED.items.push(c);
				break;
			case FAILED:
			case READY:
				switch (c.type) {
					case VPN:
					case SFTP:
						break;
					case B_KPI:
						metrics.length ?
							mappedChannel.B_KPI.items = c.metrics || metrics
							: mappedChannel.LIVE.items.push(c);
						break;
					case CUSTOM_CHART:
						metricsChart.length ?
							mappedChannel.CUSTOM_CHART.items = c.metrics || metricsChart
							: mappedChannel.LIVE.items.push(c);
						break;
					case SAAS:
						const isvs = c.isvs.map((vendor) => {
							let endpoints = vendor.script ? vendor.endpoints.filter(ep => vendor.script.args.some(arg => arg.id === ep.id)) : []
							return { ...vendor, vendor_name: vendors.find(v => v.id == vendor.customer_id).name, endpoints, channelId: c.id, allEndpoints: vendor.endpoints }
						});
						mappedChannel.SAAS.items.push({ ...c, isvs });
						break;
					case WEB:
						const mappedIsvs = c.isvs.filter(isv => isv.script).map(isv => {
							return { ...isv, name: vendors.find(v => v.id == isv.customer_id).name }
						})
						mappedChannel.WEB.items.push({ ...c, isvs: mappedIsvs });
						break;
					case API && c.endpoints && c.endpoints.length > 0:
						mappedChannel.API.items.push({ ...c, typeToIcon: c.cloud_type ? c.cloud_type.toLowerCase() :"proovIcon"});
						break;
					default:
						if (Object.keys(mappedChannel).includes(c.type.toUpperCase())) {
							mappedChannel[c.type.toUpperCase()].items.push({ ...c, typeToIcon: c.cloud_type ? c.cloud_type.toLowerCase() : "proovIcon" });
						}
				}
		}
	});

	const handleFilterChanged = (event) => {
		const text = event.target.value;
		setSearchText(text);
		if (text == "")
			setChannels(props.channels)
		let filtered = channels.map((c) => {
			if (c.endpoints) {
				const filteredEndpoint = c.endpoints.filter(e => e.toLowerCase().includes(text.toLowerCase()))
				if (filteredEndpoint.length) {
					return { ...c, endpoints: filteredEndpoint };
				}
			}
			if (c.isvs) {
				const filterISV = c.isvs.filter((isv) => isv.vendor_name && isv.vendor_name.toLowerCase().includes(text.toLowerCase()))
				if (filterISV.length)
					return { ...c, isvs: filterISV };
			}
			if (c.type == B_KPI) {
				c.metrics = metrics.filter(m => m.name.toLowerCase().includes(text.toLowerCase()))
				mappedChannel.B_KPI.items = c.metrics;
				if (c.metrics.length > 0) return c;
			}
			if (c.type == CUSTOM_CHART) {
				c.metrics = metricsChart.filter(m => m.label.toLowerCase().includes(text.toLowerCase()))
				mappedChannel.CUSTOM_CHART.items = c.metrics;
				if (c.metrics.length > 0) return c;
			}
			if (c.name && c.name.toLowerCase().includes(text.toLowerCase()))
				return c;
		})
			.filter(c => c);
		setChannels(filtered)
	}

	return (
		<React.Fragment>
			<SearchBox
				onTextChanged={handleFilterChanged}
				placeholder="Search"
			/>
			<div className={css.root}>
				{Object.entries(mappedChannel).map(
					channel => {
						const key = channel[0];
						const channelData = channel[1];
						const { className, id, items, name, itemCategoryStyle, itemFieldToDisplay, type, level, withMetrics, sendEndpointLabel, isNoSpace, iconWrapperStyle, isHideIconForItemList, groupIconStyle, typeToIcon, isShowInformation } = channelData;
						if (level == 1 && items.length > 0) {
							return <ItemsExplorer
								className={css.channelExplorer}
								items={items}
								allowHighlight
								onItemSelected={onSetChannel}
								selectedItem={items.filter((c) => c.id === channelId)[0]}
								renderItem={(item) => (
									<span title={item.name} className={css.itemName}>{item.name}</span>
								)}
								isNoSpace={true}
								itemCategoryClassName={css.liveChannelItemCategory}
							/>

						}
						if (level === 2) {
							if (items.length > 0) {
								return <ItemsExplorer
									icon={{ type, className }}
									key={id}
									className={cn(css.channelExplorer, css.apiChannelExplorer, { [css.deleted]: key === DELETED.value.toUpperCase() })}
									itemsListClassName={css.categoriesList}
									categoryHeaderClassName={css.apiNameWrapper}
									items={items}
									allowHighlight
									onItemSelected={(value) => withMetrics ? onSetChannel(channelData, value) : onSetChannel(value)}
									categorized
									isNoSpace={isNoSpace}
									iconWrapperStyle={iconWrapperStyle}
									getItemCategory={(item) => name}
									selectedItem={
										items.filter((metric) => {
											return withMetrics ?
												endpointLabel && metric.id === endpointLabel.id && id === channelId :
												metric.id === channelId
										})[0]
									}
									renderItem={(item) => (
										<span title={item[itemFieldToDisplay]} className={css.itemName}>{item[itemFieldToDisplay]}</span>
									)}
									renderCategory={(category) => (
										<span className={cn(css.itemName, css.apiName)}>
											{name}
										</span>
									)}
									expandAllWhileSearching
									searchText={searchText}
									itemCategoryClassName={itemCategoryStyle}
								/>
							}
						}

						if (level === 3 && items.length > 0) {
							return <ParentCategory
								icon={{ type, className }}
								categoryHeaderClassName={css.apiNameWrapper}
								renderCategory={(category) => (
									<span className={cn(css.itemName, css.apiName)}>{category}</span>
								)}
								accordionClassName={css.accordionIcon}
								keyParent={key}
								categorized={items}
								renderItem={(item) => {
									const name = item.name ? item.name : item;
									return <span title={name} className={css.itemName}>{name}</span>

								}}
								isShowInformation={isShowInformation}
								channelId={channelId}
								channels={filterChannels}
								allowHighlight
								getMappedItemsByCategory={(items) => {
									return (items.map(i => {
										return i.endpoints ?
											i.endpoints.map(ep => { return { "id": i.id, "category": i.name, "name": ep, "typeIcon": i.typeToIcon } })
											: i.isvs.map(isv => { return { "isvId": isv.id, "id": isv.customer_id, "category": i.name, "name": isv.name, "type": i.type, "channelId": i.id, "scriptId": isv.script.id } })
											;
									})).reduce((acc, curVal) => {
										return acc.concat(curVal)
									}, []);
								}}
								getIconByCategory={(typeToIcon) => { return typeToIcon ? { type: typeToIcon, className: css[typeToIcon] } : null }}
								onClick={onClickWebChannel}
								getKpi={(items) => {
									return items.filter(i => i.isvs)
								}}
								getMappedSelectedObj={(item) =>
									item}
								isSelectedItem={sendEndpointLabel && ((selectedItem, item) => {
									return selectedItem && selectedItem.channelId === item.channelId && selectedItem.id === item.id;
								})}
								endpointLabelChannelId={endpointLabel && endpointLabel.channel_id}
								endpointLabel={sendEndpointLabel && endpointLabel}
								onItemSelected={onSetChannel}
								isHideIconForItemList={isHideIconForItemList}
							/>
						}
						else if (key === SAAS.toUpperCase() && items.length > 0) {
							return <React.Fragment>
								<Accordion
									key="SAAS CANNELS"
									isActive={false}
									header={
										<CategoryHeader
											icon={{ type, className }}
											className={css.apiNameWrapper}
											accordionClassName={css.accordionIcon}>
											<span className={cn(css.itemName)}>SaaS</span>
										</CategoryHeader>
									}
									headerActiveClassName={css.categoryHeaderOpened}
									details={items.map((item) =>
										<ParentCategory
											getMappedSelectedObj={(item) => {
												return {
													id: item.id,
													vendorId: item.customer_id,
													script: {
														...item.script,
														channelId: item.channelId,
														vendor: { ...item, endpoints: item.allEndpoints }
													}
												}
											}}
											className={css.subCategory}
											icon={{ type: 'proovIcon', className: css.proovIcon }}
											keyParent={item.name}
											categorized={item.isvs}
											onItemSelected={onSetChannel}
											categoryHeaderClassName={css.apiNameWrapper}
											renderCategory={(category, alwaysExpanded) => (
												<span className={cn(css.itemName, !alwaysExpanded ? css.apiName : "")}>{category}</span>

											)}
											onClick={onClickISV}
											getKpi={(items) => {
												return items.filter(i => i.script)
											}}
											getMappedItemsByCategory={(items) => {
												return (items.map(i => {
													if (i.endpoints.length)
														return i.endpoints.map((ep, index) => { return { "key": i.id + index, "id": i.id, "category": i.vendor_name, "name": ep.endpoint, "ep_id": ep.id } })
													else if (i.script) return { "key": i.id, "id": i.id, "category": i.vendor_name, "alwaysExpanded": true, name: "lock" }
												})).reduce((acc, curVal) => {
													return acc.concat(curVal)
												}, []).filter(saas => saas);
											}}
											renderItem={(item) => {
												const name = item.name ? item.name : item;
												return <span title={name} className={css.itemName}>{name}</span>

											}}
											allowHighlight
											accordionClassName={groupIconStyle}
											groupIconStyle={css.subGroupIconStyle}
											endpointLabel={endpointLabel}
											isSelectedItem={(selectedItem, item) => {
												return selectedItem && selectedItem.id === item.ep_id;
											}}
										/>)}
								/>
							</React.Fragment>
						}
					})
				}
			</div>
		</React.Fragment>
	)
};

ChannelsMenu.propTypes = {
	channels: PropTypes.array.isRequired,
	onSetChannel: PropTypes.func,
	endpointLabel: PropTypes.string,
	channelId: PropTypes.string,
};

export default ChannelsMenu;