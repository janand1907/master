import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';

import * as dashboardActions from 'ducks/admin/dashboard/actions';
import * as analyticsActions from 'ducks/admin/analytics/charts/actions';
import { checkVendorMetric } from 'ducks/admin/analytics/metrics/actions';
import * as chartI18n from 'i18n/en/charts.json';
import EditIcon from 'components/ui/Icons/EditIcon';
import { getMetricView } from 'ducks/admin/analytics/metrics/selectors';
import { showModal } from 'ducks/modal/actions';
import ToolBarContainer from 'components/admin/pilotView/client/analytics/ToolBar/ToolBarContainer';
import { NewSpinner } from 'components/ui/NewSpinner';
import Matrix from './Matrix';
import { DATA_RESOLUTION } from 'constants/dataResolution';
import css from './Matrix.scss';
import * as i18n from 'i18n/en/pilotView.json';
import { spinnerWrapper } from './Feed.scss';


function MatrixContainer({
	data,
	selectedMetric,
	selectedVendors,
	pending,
	vendorToColorMap,
	resolution,
	metrics,
	actions,
	metricView,
	metricId,
	handleShowAll,
	pilotId,
	history
}) {

	React.useEffect(() => {
		if (resolution === DATA_RESOLUTION.ARCHIVE) {
			actions.stopLiveData(metricId);
			actions.getArchivePeriodic(metricId);
		} else {
			actions.stopLiveData(metricId);
			actions.getLiveData(metricId);
		}

		() => {
			if (resolution === DATA_RESOLUTION.LIVE) {
				actions.stopLiveData(metricId);
			}
		};
	}, [resolution, metricId]);

	const handleEditMetric = () => {
		history.push(
			`/admin/pilot/${pilotId}/analytics/edit-metric/${selectedMetric.id}`
		);
	}

	const selectedVendorData = data.filter(({ company_id }) =>
		selectedVendors.includes(company_id)
	);

	const isNotActive = resolution === DATA_RESOLUTION.LIVE && (selectedMetric.status === 'failed' || (!selectedMetric.script && selectedMetric.draft));

	if (pending) {
		return <NewSpinner wrapperClassName={spinnerWrapper} size="m" />;
	}

	return (
		<React.Fragment>
			<ToolBarContainer
				handleShowAll={handleShowAll}
				selectedMetric={selectedMetric}
				metricView={metricView}
				metrics={metrics}
				id={selectedMetric.id}
				metricId={metricId}
				type="matrix"
			/>
			{isNotActive ? (
				<div className={css.notActive}> <p onClick={handleEditMetric}>{chartI18n.messages.isnotactive}</p> <EditIcon className={css.editIcon} onClick={handleEditMetric} /> </div>
			) : <Matrix
				data={selectedVendorData}
				resolution={resolution}
				metricView={metricView}
				selectedVendors={selectedVendors}
				selectedMetric={selectedMetric}
				colorMap={vendorToColorMap}
			/>}
		</React.Fragment>
	);
}

MatrixContainer.propTypes = {
	/**
 	* @ignore react-router
 	*/
	history: PropTypes.shape({
		push: PropTypes.func.isRequired,
	}).isRequired,
	data: PropTypes.array.isRequired,
	actions: PropTypes.object.isRequired,
	error: PropTypes.string,
	showModal: PropTypes.func,
	pending: PropTypes.bool,
	vendorToColorMap: PropTypes.object.isRequired,
	metrics: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
	selectedMetric: PropTypes.object,
	selectedVendors: PropTypes.array,
	resolution: PropTypes.string,
	metricView: PropTypes.string,
	metricId: PropTypes.string,
	handleShowAll: PropTypes.func,
};

function mapStateToProps(state, ownProps) {
	return {
		id: ownProps ? ownProps.id : undefined,
		metricView: getMetricView(state),
		metricId: ownProps.id || ownProps.selectedMetric.id
	};
}

function mapDispatchToProps(dispatch, ownProps) {
	let actions;
	if (ownProps.metricView === 'analytics') {
		actions = analyticsActions;
	} else {
		actions = dashboardActions;
	}
	return {
		dispatch: dispatch,
		actions: bindActionCreators({ ...actions, checkVendorMetric, showModal }, dispatch),
	};
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(MatrixContainer));
