import React from 'react';
import PropTypes from 'prop-types';
import Console from 'components/ui/Console/Console';
import NoDataMessage from 'components/admin/common/charts/NoDataMessage/NoDataMessage';
import * as css from 'components/admin/pilotView/client/analytics/AnalyticsSection.scss';
import * as style from './Feed.scss';

class Feed extends React.Component {
	constructor(props) {
		super(props);

		this.style =
			this.props.metricView === 'analytics'
				? style.analyticsRow
				: style.dashboardRow;
	}

	render() {
		const {
			data,
			resolution,
			vendors,
			selectedMetric,
			metricView,
			selectedVendors,
			colorMap,
		} = this.props;

		const values = data[0] && data[0].values[0];

		if (resolution === 'archive') {
			return <NoDataMessage type="archive" className={style.noData} />;
		}

		if (!values || !values.samples || !values.samples.length || !values.samples[0].y) {
			return <NoDataMessage type="nodata" className={style.noData} />;
		}
		return (
			<div
				className={
					metricView === 'analytics'
						&& css.feedWrapper
				}
			>
				<Console
					data={values.samples}
					selectedVendors={selectedVendors && selectedVendors[0] ? selectedVendors[0] : selectedVendors}
					rowClassName={this.style}
					vendors={vendors}
					resolution={resolution}
					metric={selectedMetric}
					colorMap={colorMap}
				/>
			</div>
		);
	}
}

Feed.propTypes = {
	data: PropTypes.array,
	vendors: PropTypes.array,
	selectedVendors: PropTypes.array,
	selectedMetric: PropTypes.object,
	colorMap: PropTypes.object,
	resolution: PropTypes.string,
	metricView: PropTypes.string,
};

export default Feed;
