import * as PARAM_TYPES from 'constants/admin';
import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { debounce } from 'lodash';
import * as i18n from 'i18n/en/pilotView.json';
import { NewSpinner } from 'components/ui/NewSpinner';
import { SearchBox } from 'components/ui/SearchBox';
import TestResult from 'components/admin/common/script/TestResult/TestResult';
import MetricsGridView from 'components/admin/common/script/MetricsGridView/MetricsGridView';
import LeftIcon from 'components/ui/Icons/LeftIcon';
import RightIcon from 'components/ui/Icons/RightIcon';
import TrashIcon from 'components/ui/Icons/TrashIcon';
import { getItemToInject } from 'ducks/admin/analytics/customMetric/selectors';
import IconWithTooltip from 'components/ui/Icons/IconWithTooltip';
import {
	getParamsFromText,
	transformChannels,
	getSelectedChannelValue,
	isMetricReadyForCreate
} from 'components/admin/common/script/utils';
import cn from 'utils/classNames';
import ChannelSelect from '../ChannelSelect/ChannelSelect';
import AddCustomParam from '../AddCustomParam/AddCustomParam';
import css from './Script.scss';
import CreateScriptForm from 'components/admin/common/script/CreateScriptForm/CreateScriptForm';

class Script extends React.Component {
	constructor(props) {
		super(props);
		this.handleEditorChange = this.handleEditorChange.bind(this);
		this.handleItemSelect = this.handleItemSelect.bind(this);
		this.handleSearchChanged = this.handleSearchChanged.bind(this);
		this.handleSearchChangedDebounced = debounce(
			this.handleSearchChangedDebounced.bind(this),
			500
		);
		this.state = {
			itemNameToInject: null,
			searchText: '',
			codeEditorValue: null,
			isDisplayCustomParmas: true,
			tested: false
		};
	}
	toggleCustomParams() {
		this.setState({ isDisplayCustomParmas: !this.state.isDisplayCustomParmas });
	}
	handleItemSelect(item) {
		let channelName = null;
		if (item.param_type === PARAM_TYPES.STANDARD) {
			channelName = this.props.environment.find(env => env.id === item.channel_id).name;
		} else {
			channelName =
				item.param_type === PARAM_TYPES.CUSTOM ? 'Script Parameters' : 'Vendor List';
		}
		this.props.setItemToInject(`\${${channelName}->${item.name}}`);
	}

	handleSearchChangedDebounced(value) {
		this.setState({ searchText: value });
	}

	handleSearchChanged(e) {
		this.handleSearchChangedDebounced(e.target.value);
	}

	handleEditorChange(input, val) {
		input.onChange(val);
		this.setState({
			...this.state,
			codeEditorValue: val,
			tested: false
		})
		this.updateData(val, this.props);
	}

	updateData(val, props) {
		const script = typeof val === 'object' ? val.target.value : val;
		const match = getParamsFromText(
			script,
			props.parameters,
			props.environment,
			props.vendors
		);
		props.onUpdateUsedParams(match, val);
	}

	render() {
		const {
			form,
			environment,
			selectedChannelId,
			selectedEndPoint,
			parameters,
			onSelect,
			onChannelChanged,
			customMetricValidation,
			model,
			pendingCreate,
			pendingDraft,
			parameterPending,
			handleEdit,
			handleShowDetails,
			handleDelete,
			mode,
			onTest,
			handleEditParamClick,
			onDeleteDraft,
			metric,
			subscription,
			onExpressionTypeChange,
			scriptCodeToInject
		} = this.props;

		const allowedChannels = {
			Custom: {
				type: 'custom',
				channelType: 'custom',
				channelId: 'Custom',
				id: 'Custom',
				name: 'Custom Parameters'
			},
			Vendor: {
				type: 'vendor',
				channelType: 'vendor',
				channelId: 'Vendor',
				id: 'Vendor',
				name: 'Vendor List'
			},
			...transformChannels(environment)
		};

		const disabled = parameterPending || !model.script || pendingCreate;
		const isNewDraft = metric && !metric.script;
		const TrashDisabled = mode === 'create' || metric && !metric.draft;
		const isLimit = subscription && subscription.limit && (subscription.usage >= subscription.limit);
		const isDraft = mode === 'edit' && !metric.script;
		const isUpdateDraft = metric && metric.draft && metric.id
		return (
			<div className={css.editor}>

				<div className={cn(css.testZone, !this.state.isDisplayCustomParmas && css.open)} >

					<CreateScriptForm
						onEditorChange={this.handleEditorChange}
						form={this.props.form}
						mode={mode}
						value={mode === 'edit' ? metric.script : this.state.codeEditorValue || this.props.form && this.props.form.props.initialValues.script}
						onChangeLanguage={onExpressionTypeChange}
						modelName='customMetric'
						scriptCodeToInject={scriptCodeToInject}

					/>
					<TestResult
						disabled={disabled}
						pending={customMetricValidation.pending}
						error={customMetricValidation.error}
						result={customMetricValidation.result}
						className={css.testResult}
					/>

					<div className={css.buttonWrapper}>
						<button
							type="button"
							disabled={pendingDraft}
							className={css.btnDraft}
							onClick={(e) => form && form.submit(e, { type: "Draft" })}>
							{pendingDraft && <NewSpinner size="s" className={css.spinner} />}
							{' '}{isUpdateDraft ? 'Update Draft' : 'Save Draft'}
						</button>
						<button
							type="button"
							disabled={disabled || customMetricValidation.pending}
							className={css.btnTest}
							onClick={() => {
								if (form.validate()) {
									this.setState({
										...this.state,
										tested: true
									});
									onTest()
								}
							}
							} >
							{customMetricValidation.pending ? <NewSpinner size="s" className={css.spinner} /> : 'Test'}
						</button>

						<button
							type="button"
							className={css.btnCreate}
							disabled={
								!this.state.tested ||
								!isMetricReadyForCreate(model) ||
								pendingCreate ||
								!customMetricValidation.result ||
								isDraft && isLimit

							}
							onClick={() => form && form.submit()}
						>
							{pendingCreate && <NewSpinner size="s" className={css.spinner} />}{' '}
							{mode === 'create' || isNewDraft ? 'Create' : 'Update'}
						</button>
						<IconWithTooltip className={css.tooltipWrapper} icon={<TrashIcon onClick={() => {
							!TrashDisabled &&
								onDeleteDraft(isNewDraft)
						}} className={cn(css.trashIcon, {
							[css.disabled]: TrashDisabled
						})} />} placement="right" textToDisplay="Discard Draft" />

					</div>
				</div>
				<div className={css.wrapperToggle}>
					<div hidden={!this.state.isDisplayCustomParmas} className={css.kpiList}>
						<div className={css.kpiPickListWrapper}>
							<div className={css.kpiPickListHeader}>
								<ChannelSelect
									options={allowedChannels}
									type="script"
									onChange={onChannelChanged}
									value={getSelectedChannelValue(selectedChannelId, selectedEndPoint)}
								/>

								<SearchBox
									className={css.searchBox}
									disabled={!parameters || parameters.length === 0}
									onTextChanged={this.handleSearchChanged}
									placeholder={i18n.client.placeholder.searchBox}
								/>

							</div>

							<MetricsGridView
								selectedChannelId={selectedChannelId}
								selectedEndPoint={selectedEndPoint}
								parameterPending={parameterPending}
								searchText={this.state.searchText}
								parameters={parameters}
								onSelect={this.handleItemSelect}
								className={css.metricsGridView}
								handleEdit={handleEdit}
								handleDelete={handleDelete}
								handleShowDetails={handleShowDetails}
								expressionType={'script'}
								handleEditParamClick={handleEditParamClick}
								plusTooltipText={i18n.client.tooltips.plusIcon}
							/>
							{selectedChannelId === 'Custom' && <AddCustomParam onSelect={onSelect} />}

						</div>

					</div>
					<div className={css.customParamsWrapper} >

						<div className={css.customParams} >{this.state.isDisplayCustomParmas ? <RightIcon className={css.arrowIcon} onClick={() => this.toggleCustomParams()} /> :
							<LeftIcon className={css.arrowIcon} onClick={() => this.toggleCustomParams()} />}
							<span className={css.titleCustomParams}>Script Parameters</span> </div>
					</div>
				</div>
			</div>
		);
	}
}

Script.propTypes = {
	environment: PropTypes.array,
	parameters: PropTypes.array,
	selectedChannelId: PropTypes.string,
	selectedEndPoint: PropTypes.string,
	form: PropTypes.object,
	onSelect: PropTypes.func,
	onChannelChanged: PropTypes.func,
	customMetricValidation: PropTypes.object,
	model: PropTypes.object,
	pendingCreate: PropTypes.bool,
	parameterPending: PropTypes.bool,
	onTest: PropTypes.func,
	handleEdit: PropTypes.func,
	handleShowDetails: PropTypes.func,
	handleDelete: PropTypes.func,
	mode: PropTypes.string,
	handleEditParamClick: PropTypes.func,
	scriptCodeToInject: PropTypes.object
};

const mapStateToProps = (state) => {
	return {
		scriptCodeToInject: getItemToInject(state)
	}
}

export default connect(mapStateToProps, null)(Script);
