import React from 'react';
import PropTypes from 'prop-types';
import css from './CustomParamToolTip.scss';

const Db = ({ locator }) => {
	return (
		<ul className={css.list}>
			<li>
				<span className={css.locatorLabel}>DB Name</span>
				<span className={css.locatorValue}>{locator.db_name}</span>
			</li>
			<li>
				<span className={css.locatorLabel}>Type</span>
				<span className={css.locatorValue}>{locator.db_type}</span>
			</li>
			<li>
				<span className={css.locatorLabel}>Query</span>
				<span className={css.locatorValue}>{locator.query}</span>
			</li>
		</ul>
	);
};

Db.propTypes = {
	locator: PropTypes.object
};

export default Db;
