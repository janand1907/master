import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import { Form, Error, Field, FormGroup } from 'components/common/Forms';
import { Alert } from 'components/ui/Alert';
import { ErrorIcon } from 'components/ui/Icons';
import { Spinner } from 'components/ui/Spinner';
import { GridView } from 'components/ui/GridView';
import { isApiParamReadyForCreate } from 'components/admin/common/script/utils';
import _ from 'lodash';
import validators from '../validations';
import TestResult from 'components/admin/common/script/TestResult/TestResult';
import ApiBasicFields from './../fields/ApiBasicFields';
import HttpHeadersFields from '../fields/httpHeaders/HttpHeadersFields';
import SoapFields from './../fields/SoapFields';
import RestFields from './../fields/RestFields';
import AuthFields from './../fields/AuthFields';
import css from '../CreateCustomParam.scss';

const config = {
	form: 'createApiParam',
	validators: pick(validators, [
		'label',
		'locator.url',
		'locator.body',
		'locator.method',
		'locator.optional_headers',
		'auth.client_id',
		'auth.client_secret',
		'auth.username',
		'auth.password',
		'auth.token_url',
		'auth.add_to',
		'auth.value',
		'auth.key',
		'auth.key',
		'auth.body'
	])
};

function CreateCustomApiParam(props) {
	const [tested, setTested] = React.useState(false);
	
	const getGridViewConfig = () => {
				return [
					{
						title: 'KPI Name',
						value: ({ name }) => <div title={name}>{name}</div>,
					},
					{
						title: 'PoC Name',
						value: (kpiId) =>
							<a href={`/admin/pilot/${kpiId.poc.id}/details/overview`}>{kpiId.poc.name}</a>,
					},
				]
	}

	const {
		initialValues,
		customParamValidation,
		formRef,
		form,
		model,
		onSubmit,
		onCancel,
		pendingCreateParam,
		onTest,
		isEditMode,
		isViewMode
	} = props;

	const { auth, locator } = model;
	const isRest = locator && locator.type === 'api.rest';
	const isSoap = locator && locator.type === 'api.soap';
	const isPutOrPost = locator && ["POST", "PUT"].includes(locator.method);
	return (
		<div className={css.modal}>
			<div className={css.header}>
				<h2>{isViewMode ? `${initialValues.label} Details` : isEditMode ? 'EDIT API PARAMETER': 'NEW API PARAMETER'}</h2>
			</div>
			<div className={css.content}>
				<Form
					{...config}
					ref={formRef}
					className={css.form}
					initialValues={initialValues}
					onSubmit={onSubmit}
					onChange={() => setTested(false)}
				>
					<Error
						name=""
						component={({ error }) => (
							<Alert type="error">
								<ErrorIcon className={css.errorIcon} />
								<span>{error}</span>
							</Alert>
						)}
					/>

					{isViewMode && <table className={css.table}>
						<thead>
							<tr>
								<th>API Type</th>
								<th>Status</th>
								<th>Response Type</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>{initialValues.type}</td>
								<td className={css[initialValues.status]}>{initialValues.status === 'ready' ? 'active' : initialValues.status}</td>
								<td>{initialValues.resp_type}</td>
							</tr>
						</tbody>
					</table>}

					<FormGroup className={css.hidden}>
						<Field
							name="id"
							component="input"
							type="text"
							className="form-control"
							maxLength="40"
							value={initialValues.id}
						/>
					</FormGroup>

					<ApiBasicFields type={locator && locator.type} disabled={!locator || locator.type === 'api.rest' && !locator.method} isViewMode={isViewMode} />

					{isSoap && <SoapFields isViewMode={isViewMode} />}

					{isRest && <RestFields method={locator.method} isViewMode={isViewMode} />}

					<HttpHeadersFields key="locator.optional_headers" fieldName="locator.optional_headers" type={locator && locator.type} disabled={!locator || locator.type === 'api.rest' && !locator.method} isViewMode={isViewMode} items={initialValues.locator.optional_headers}/>

					{isRest && isPutOrPost && <FormGroup label="Body" mandatory>
						<Field
							name="locator.body"
							component="textarea"
							type="text"
							className="form-control"
							maxLength="2083"
							disabled={isViewMode}
						/>
						<Error sticky name="locator.body" />
					</FormGroup>}

					<AuthFields auth={isViewMode ? initialValues.auth : auth} isRest={isRest} disabled={isRest && locator.method} isViewMode={isViewMode} />
				</Form>
			</div>

			<div className={css.footer}>
				<TestResult
					disabled={pendingCreateParam}
					placeholder="RESPONSE"
					pending={customParamValidation.pending}
					error={customParamValidation.error}
					result={customParamValidation.result || initialValues.resp_example}
				/>
				{!isViewMode && <div className={css.buttons}>
					<button
						type="button"
						disabled={pendingCreateParam || customParamValidation.pending}
						className={css.btnTest}
						onClick={() => { setTested(true); onTest(); }}
					>
						{customParamValidation.pending ? <Spinner className={css.spinner} /> : 'Test'}
					</button>
					<button
						type="button"
						className={css.btnCreate}
						disabled={!tested || !isApiParamReadyForCreate(model) || pendingCreateParam || !customParamValidation.result}
						onClick={() => form && form.submit()}
					>
						{pendingCreateParam && <Spinner className={css.spinner} />}
						{isEditMode ? "Update" : "Create"}
					</button>
					<button
						type="button"
						className={css.btnCancel}
						disabled={pendingCreateParam}
						onClick={onCancel}
					>
						Cancel
					</button>
				</div>}
				{isViewMode && <div className={css.bkpiWrapper}>
					<span className={css.bkpiTitle}>Related Business KPI</span>
					{initialValues.related_bkpi_ids.length ?
						<GridView
							data={initialValues.related_bkpi_ids}
							className={css.gridView}
							config={getGridViewConfig()}
						/> : <div className={css.value}>none</div>
					}
				</div>}
			</div>
		</div>
	);
}

CreateCustomApiParam.propTypes = {
	onSubmit: PropTypes.func.isRequired,
	onCancel: PropTypes.func.isRequired,
	form: PropTypes.object,
	formRef: PropTypes.func.isRequired,
	customParamValidation: PropTypes.object,
	initialValues: PropTypes.object.isRequired,
	model: PropTypes.object.isRequired,
	pendingCreateParam: PropTypes.bool,
	onTest: PropTypes.func,
	isEditMode: PropTypes.bool
};

export default CreateCustomApiParam;
