import React from 'react';
import PropTypes from 'prop-types';
import { GridView } from 'components/ui/GridView';
import { isJson } from 'components/admin/common/script/utils';
import cx from 'utils/classNames';
import * as style from './CustomParamDetails.scss';

const CustomParamDetails = ({
	name,
	status,
	locator,
	resp_example,
	resp_type,
	type,
	related_bkpi_ids
}) => {
	let data = resp_example ? resp_example.data[0][0] : null;
	let result = null;
	if (resp_type === 'value') {
		const config = () => {
			if (resp_example) {
				resp_example.meta.map((value, i) => ({
					title: value.name,
					value: (value) => value[i],
				}));
			}
		};
		result = (
			<GridView
				config={config}
				data={resp_example ? resp_example.data : (isJson(data) ? JSON.stringify(JSON.parse(data), undefined, 4) : data)}
				//className={style.gridView}
				rowClassName={resp_type === 'value' && resp_example ? resp_example.meta[0].type : resp_type}
			/>
		);
	} else {
		result = isJson(data)
			? JSON.stringify(JSON.parse(data), undefined, 4)
			: data;
	}
	const setGridViewConfig = (type) => {
		switch (type) {
			case 'headers':
				return [
					{
						title: 'Key',
						value: ({ key }) => <div>{key}</div>,
					},
					{
						title: 'Value',
						value: ({ value }) => <div>{value}</div>
					},
				];
			case 'related_bkpi':
				return [
					{
						title: 'KPI Name',
						value: ({ name }) => <div title={name}>{name}</div>,
					},
					{
						title: 'PoC Name',
						value: (kpiId) =>
							<a href={`/admin/pilot/${kpiId.poc.id}/details/overview`}>{kpiId.poc.name}</a>,
					},
				]
		}

	}
	return (
		<div className={style.modal}>
			<div className={style.header}>PARAMETER DETAILS</div>
			<div className={style.content}>
				<div className={style.row}>
					<span className={style.label}>Name</span>
					<span className={style.value}>{name}</span>
				</div>

				{status && (
					<div className={style.row}>
						<span className={style.label}>Status</span>
						<span className={style.value}>
							{status === 'failed' && (
								<span className={style.failed}>{'Failed'}</span>
							)}
							{status === 'draft' && (
								<span className={style.draft}>{'Draft'}</span>
							)}
							{status === 'ready' && (
								<span className={style.ready}>{'Active'}</span>
							)}
						</span>
					</div>
				)}
				<div className={style.row}>
					<span className={style.label}>Type</span>
					<span className={style.value}>
						{resp_type === 'value' && resp_example ? resp_example.meta[0].type : resp_type}
					</span>
				</div>
				{locator.method && <div className={style.row}>
					<span className={style.label}>Method</span>
					<span className={style.value}>
						{locator.method}
					</span>
				</div>}
				<div className={style.row}>
					<div className={style.label}>Source</div>
					<div className={style.value}>
						{type !== 'db' ? locator.url : locator.query}
					</div>
				</div>
				<div className={cx(style.row, style.relatedBkpi)}>
					<div className={style.label}>Headers</div>
					{locator.headers && Object.keys(locator.headers).length > 0 ?
						<GridView
							data={Object.keys(locator.headers).map(header => { return { key: header, value: locator.headers[header] } })}
							className={style.gridView}
							config={setGridViewConfig('headers')}
						/>
						: <div className={style.value}>none</div>
					}
				</div>
				<div className={style.row}>
					<div className={style.label}>Value</div>
					<div className={style.value}>
						<pre className={style.result}>{result}</pre>
					</div>
				</div>
				<div className={cx(style.row, style.relatedBkpi)}>
					<div className={style.label}>Related Business KPI</div>

					{related_bkpi_ids.length ?
						<GridView
							data={related_bkpi_ids}
							className={style.gridView}
							config={setGridViewConfig('related_bkpi')}
						/> : <div className={style.value}>none</div>
					}
				</div>
			</div>
		</div>
	);
};

CustomParamDetails.propTypes = {
	name: PropTypes.string,
	locator: PropTypes.object,
	resp_example: PropTypes.object,
	resp_type: PropTypes.string,
	type: PropTypes.string,
};

export default CustomParamDetails;
