import React from 'react';
import { FormGroup, Field, Error,Password } from 'components/common/Forms';
import css from './../CreateCustomParam.scss';

const UsernamePasswordField = ({isViewMode}) => {
	return (
		<div className={css.authArea}>
			<FormGroup label="Username" mandatory className={css.field}>
				<Field name="auth.username" component="input" type="text" autoComplete="off" maxLength={110} className="form-control" disabled={isViewMode}/>
				<Error sticky name="auth.username" />
			</FormGroup>
			<FormGroup label="Password" mandatory className={css.field}>
			<Password
				fieldProps={{ name: "auth.password", component: "input", 
				className: "form-control", placeholder: "",autoComplete:"off",
				maxLength:"200"  }}
				isForm={true}
				disabled={isViewMode}
			/>

				<Error sticky name="auth.password" />
			</FormGroup>
		</div>
	);
};

export default UsernamePasswordField;
