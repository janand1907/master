import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { getCharts } from 'ducks/admin/analytics/customChart/actions';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { getMetrics, setMetric, setMetrics, getEndpointData, resetEndpointData } from 'ducks/admin/analytics/metrics/actions';
import { stopLiveData } from 'ducks/admin/analytics/charts/actions';
import * as chartsSelectors from 'ducks/admin/analytics/charts/selectors';
import { B_KPI, CUSTOM_CHART, WEB } from 'constants/channel/channelType';
import { getEndpointLabel, getMetricsSection } from 'ducks/admin/analytics/metrics/selectors';
import ChannelsMenu from './ChannelsMenu';

function ChannelsMenuContainer(props) {
	const {
		pilotId,
		channelId,
		endpointLabel,
		environment,
		actions,
		metrics,
		metricsChart,
		selectedMetric,
		selectedVendors,
		vendors,
		resolution
	} = props;
	useEffect(() => {
		return () => {
			actions.stopLiveData();
		};
	}, []);
	const handleSelectChannel = (value, endpointLabel) => {
		actions.stopLiveData();
		if (value.type === CUSTOM_CHART) {
			if (!selectedMetric || !selectedMetric.id)
				actions.getCharts({ pilotId, channelId: value.id, endpointLabel });
			else if (selectedMetric.id != value.id) {
				if (channelId !== value.id) {
					actions.getCharts({ pilotId, channelId: value.id, endpointLabel });
				} else actions.setMetric(
					endpointLabel.id,
					resolution,
					vendors.length ? vendors[0].id : null,
					endpointLabel
				);
			}
		}
		else if (value.type == B_KPI) {
			if (!selectedMetric || !selectedMetric.id)
				actions.getMetrics({ pilotId, channelId: value.id, endpointLabel });
			else if (!endpointLabel || selectedMetric.id != endpointLabel.id) {
				if (channelId !== value.id)
					actions.getMetrics({ pilotId, channelId: value.id, endpointLabel });
				else {
					actions.setMetric(
						endpointLabel.id,
						resolution,
						vendors.length ? vendors[0].id : null,
						endpointLabel
					);
				}

			}

		}
		else if (value.type == WEB) {
			let isv;
			 if (selectedMetric.channel_id !== value.channelId) {
				props.actions.resetEndpointData()
				const channel = props.environment.find(env => env.id === value.channelId);
				isv = channel && channel.isvs.find((m) => m.customer_id == value.id);
				actions.setMetrics([channel], null, resolution || 'live', value.channelId);
			}
			else {
				isv = props.channel && props.channel.isvs.find(m => m.customer_id === value.id);
				actions.setMetrics([props.channel], null, resolution || 'live', channelId);
			}
			const selectedEndpoint = { name: isv && isv.script.args.length && isv.script.args[0].endpoints && isv.script.args[0].endpoints[0] }
			actions.setMetric(
				value.channelId,
				resolution,
				null,
				{ ...value, selectedEndpoint: selectedEndpoint }
			);
			const { isvId, scriptId } = value;
			let res = window.location.href.split('/').slice(-1)[0];
			selectedEndpoint.name && props.actions.getEndpointData({ pilotId, channelId: isvId, endpointLabel: selectedEndpoint.name, bizKpiId: scriptId, res });
		}
		else actions.getMetrics({ pilotId, channelId: value.id, endpointLabel });



	};
	const handleClickISV = (data) => {
		const { script, vendorId } = data;
		if (!selectedMetric.id)
			actions.setMetric(
				script.id,
				'live',
				vendorId,
				script
			);
		if (selectedVendors && vendorId !== selectedVendors[0] || script.vendor.channelId !== selectedMetric.channelId) {
			actions.stopLiveData();
		}
		actions.setMetrics([script], vendorId, resolution || 'live');

	}

	const handleClickWebChannel = data => {
		if (data.id !== selectedMetric.id) {
			actions.stopLiveData();
		}
		actions.getMetrics({ pilotId, channelId: data.id });
	}

	const channels = [
		{ id: null, name: "Business KPI", status: 'ready', type: "b_kpi" },
		{ id: 'customChart', name: 'Custom Chart', status: 'ready', type: "customChart" }
	].concat(environment);

	return (
		<ChannelsMenu
			channels={channels}
			onClickISV={handleClickISV}
			onClickWebChannel={handleClickWebChannel}
			onSetChannel={handleSelectChannel}
			channelId={channelId}
			endpointLabel={endpointLabel}
			metrics={metrics}
			vendors={vendors}
			metricsChart={metricsChart}
		/>
	);
}

ChannelsMenuContainer.propTypes = {
	pilotId: PropTypes.string.isRequired,
	environment: PropTypes.array.isRequired,
	channelId: PropTypes.string,
	endpointLabel: PropTypes.string,
	actions: PropTypes.object.isRequired,
	metrics: PropTypes.array,
	selectedMetric: PropTypes.object,
	channel: PropTypes.object
};

function mapStateToProps(state) {
	const { id, status, environment, vendors } = getAdminPilot(state);
	const { selectedMetric, metricsBKPI, channelId, metricsChart, selectedVendors } = getMetricsSection(state);
	const channel = environment.find(({ id }) => id == channelId);
	return {
		pilotId: id,
		pilotStatus: status,
		environment: environment,
		channelId: channelId,
		channel: channel,
		endpointLabel: getEndpointLabel(state),
		metrics: metricsBKPI,
		metricsChart: metricsChart,
		selectedMetric: selectedMetric,
		vendors: vendors,
		selectedVendors: selectedVendors,
		resolution: chartsSelectors.getResolution(state)
	};
}

function mapDispatchToProps(dispatch) {
	return {
		dispatch: dispatch,
		actions: bindActionCreators(
			{ getCharts, getMetrics, stopLiveData, setMetric, setMetrics, getEndpointData, resetEndpointData },
			dispatch
		),
	};
}

export default withRouter(
	connect(mapStateToProps, mapDispatchToProps)(ChannelsMenuContainer)
);
