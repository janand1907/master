import React from 'react';
import PropTypes from 'prop-types';
import { Switch, Route, Redirect, Link } from 'react-router-dom';
import { findKey, invert } from 'lodash';
import asyncComponent from 'utils/asyncComponent';
import cn from 'utils/classNames';
import { Tabs } from 'components/ui/Tabs';
import * as i18n from 'i18n/en/pilotView.json';
import Permission from 'components/Permission';
import css from './AnalyticsSection.scss';

const routeTabMap = {
	live: 'LIVE ANALYTICS',
	archive: 'ARCHIVE',
	simulation: 'SIMULATION',
};

const routeToTab = (route) => routeTabMap[route];

const tabToRoute = (tab) => {
	return findKey(routeTabMap, (value) => value === tab);
};

// Lazy Components
const Analytics = asyncComponent(() =>
	import(
		/* webpackChunkName: "admin-analytics" */ 'components/admin/pilotView/client/analytics/analyticsView/AnalyticsContainer'
	)
);

const Simulation = asyncComponent(() =>
	import(
		/* webpackChunkName: "admin-analytics-simulation" */ 'components/admin/pilotView/client/analytics/SimulationTab/SimulationTabContainer'
	)
);

class AnalyticsSection extends React.Component {
	constructor(props) {
		super(props);
		this.handleTabChange = this.handleTabChange.bind(this);
		this.handleShowCustomChart = this.handleShowCustomChart.bind(this);
		let urlParts = window.location.href.split('/');
		this.state = {
			activeTab: routeToTab(urlParts.slice(-1)[0]) || routeTabMap.live,
		};
	}

	UNSAFE_componentWillReceiveProps() {
		this.setActiveTab();
	}

	setActiveTab() {
		let urlParts = window.location.href.split('/');
		this.setState({ activeTab: routeToTab(urlParts.slice(-1)[0]) });
	}

	handleShowCustomChart() {
		this.props.showCustomChartModal();
	}

	handleTabChange(tab) {
		const { history, match } = this.props;
		const route = tabToRoute(tab);
		history.push(`${match.url}/${route}`);
		this.setActiveTab();
	}

	setTabList(selectedMetric) {
		if (selectedMetric.param_type === 'standard_kpi') {
			return ['LIVE ANALYTICS', 'ARCHIVE', 'SIMULATION'];
		} else {
			return ['LIVE ANALYTICS', 'ARCHIVE'];
		}
	}

	isLimit() {
		return this.props.businessKpiSubscription.limit &&
			(this.props.businessKpiSubscription.usage >=
				this.props.businessKpiSubscription.limit);
	}

	render() {
		const {
			selectedMetric,
			isCustomMetric,
			isCustomChart,
			handleGoToCreateMetric,
			channelId,
			hasMetrics,
			match,
			error,
			pilot,
		} = this.props;

		const NewBusinessKpi = () => (
			<Permission
				alias="NewBusinessKpi"
				component={
					<button
						className={css.noKpisBtn}
						disabled={pilot.status === 'completed' || this.isLimit()}
						onClick={handleGoToCreateMetric}
					>
						New Business KPI
					</button>
				}
			/>
		);

		const NewCustomChart = () => (
			<Permission
				alias="NewCustomChart"
				component={
					<button
						className={css.noKpisBtn}
						disabled={pilot.status === 'completed'}
						onClick={this.handleShowCustomChart}
					>
						New Custom Chart
					</button>
				}
			/>
		);

		if (!channelId && !hasMetrics) {
			return (
				<div className={css.noItemsLayout}>
					{globalize.parseString(i18n.client.analyticsSection.noMetricsCreated)}
					<Link to={`${this.props.match.url}/new-metric`}>
						<NewBusinessKpi />
					</Link>
				</div>
			);
		}

		if (isCustomChart && !hasMetrics) {
			return (
				<div className={css.noItemsLayout}>
					{globalize.parseString(i18n.client.analyticsSection.noChartsCreated)}
					<NewCustomChart />
				</div>
			);
		}

		if (!hasMetrics) {
			return (
				<div className={css.noItemsLayout}>
					<p>{i18n.client.analyticsSection.noMetrics}</p>
				</div>
			);
		}

		if (error) {
			return (
				<div className={css.noItemsLayout}>
					<p>{this.props.error}</p>
				</div>
			);
		}

		return (
			<div className={css.tabsContainer}>
				<div className={css.buttons}>
					{isCustomMetric && (
						<Link to={`${this.props.match.url}/new-metric`}>
							<NewBusinessKpi />
						</Link>
					)}
					{isCustomChart && <NewCustomChart />}
				</div>

				<Tabs
					className={cn({ [css.tabsDisabled]: this.props.periodicPending })}
					tabList={this.setTabList(selectedMetric)}
					activeTab={	this.state.activeTab || routeTabMap.live}
					onChange={this.handleTabChange}
				>
					<Switch>
						<Route
							key="live"
							exact
							path={`${match.path}/live`}
							render={() => (
								<Analytics
									resolution={invert(routeTabMap)[this.state.activeTab]}
								/>
							)}
						/>
						<Route
							key="archive"
							exact
							path={`${match.path}/archive`}
							render={() => (
								<Analytics
									resolution={invert(routeTabMap)[this.state.activeTab]}
								/>
							)}
						/>
						{!isCustomMetric && !isCustomChart && (
							<Route
								key="simulation"
								path={`${match.path}/simulation`}
								component={Simulation}
							/>
						)}
						<Redirect to={`${match.url}/live`} />
					</Switch>
				</Tabs>
			</div>
		);
	}
}

AnalyticsSection.propTypes = {
	/**
	 * @ignore react-router
	 */
	history: PropTypes.shape({
		push: PropTypes.func.isRequired,
	}).isRequired,

	/**
	 * @ignore react-router
	 */
	match: PropTypes.shape({
		params: PropTypes.object.isRequired,
		url: PropTypes.string.isRequired,
	}).isRequired,
	isCustomChart: PropTypes.bool,
	handleGoToCreateMetric: PropTypes.func.isRequired,
	isCustomMetric: PropTypes.bool,
	selectedMetric: PropTypes.object,
	hasMetrics: PropTypes.bool,
	periodicPending: PropTypes.bool,
	error: PropTypes.string,
	pilot: PropTypes.object,
	channelId: PropTypes.string,
	showCustomChartModal: PropTypes.func,
};

export default AnalyticsSection;
