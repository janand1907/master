import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import Db from './Db';
import Rest from './Rest';
import Soap from './Soap';
import css from './CustomParamToolTip.scss';

const CustomParamToolTip = ({ locator, targetClassName }) => {
	return (
		<TooltipTarget
			className={targetClassName}
			tooltip={
				<Tooltip placement="left" className={css.root}>
					{ locator.type === 'db' && <Db locator={locator} />}
					{ locator.type === 'api.rest' && <Rest locator={locator} />}
					{ locator.type === 'api.soap' && <Soap locator={locator} />}
				</Tooltip>}>
			<InfoIcon className={css.infoIcon} />
		</TooltipTarget>
	);
};

CustomParamToolTip.propTypes = {
	locator: PropTypes.object,
	targetClassName: PropTypes.string,
};

export default CustomParamToolTip;
