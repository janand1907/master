import { API } from 'constants/channel/channelType';
import React from 'react';
import PropTypes from 'prop-types';
import { Select } from 'components/ui/Select';
import { CLOUD_TYPE_TO_ICON, SUPPORTED_CLOUD_CHANNEL_TYPE } from 'constants/channel/cloudType';
import { ProovStampIcon } from 'components/ui/Icons';
import cx from 'utils/classNames';
import css from './ChannelSelect.scss';

class ChannelSelect extends React.PureComponent {

	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
		this.renderLabel = this.renderLabel.bind(this);
	}

	renderLabel(item) {
		const channelTypeToProovIcon = ['web', 'blockchain', 'saas'];
		if (item.type === 'endpoint') {
			return (
				<p title={item.name} className={css.endpoint}>
					{item.name}
				</p>
			);
		} else {
			const Icon = SUPPORTED_CLOUD_CHANNEL_TYPE.includes(item.channelType) && item.cloud_type && CLOUD_TYPE_TO_ICON[item.cloud_type].icon || channelTypeToProovIcon.includes(item.channelType) && ProovStampIcon;
			return (
				<p title={item.name} className={css.channel}>
					{Icon && <Icon className={cx(css.cloudTypeIcon, item.cloud_type && css[item.cloud_type.toLowerCase()])} />}
					{item.name}
				</p>
			);
		}
	}

	handleChange(value) {
		const channel = this.props.options[value];
		if (
			channel.type === 'endpoint' ||
			(channel.type === 'channel' && channel.channelType !== API) ||
			channel.type === 'custom' ||
			channel.type === 'vendor' ||
			channel.type === 'saas'
		) {
			this.props.onChange(value);
		}
	}

	filterOptions(options) {
		let disabled = [];
		Object.values(options).forEach(o => {
			if (o.channelType === API && o.type !== 'endpoint') disabled.push(o);
		});

		return disabled;
	}

	render() {
		return (
			<Select
				{...this.props}
				// disabledOptions={this.filterOptions(this.props.options)}
				wrapperClassName={css.selectChannelWrapper}
				menuClassName={css.selectChannelMenu}
				optionClassName={css.selectedValue}
				className={css.selectChannel}
				onChange={this.handleChange}
				getValue={item => item.id}
				getLabel={this.renderLabel}
				required
			/>
		);
	}
}

ChannelSelect.propTypes = {
	type: PropTypes.string,
	options: PropTypes.object,
	onChange: PropTypes.func
};

export default ChannelSelect;
