import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import css from './HeaderTooltip.scss';

const HeaderTooltip = ({ type }) => {
	return (
		<TooltipTarget tooltip={
			<Tooltip className={css.root}>
				<p className={css.p}>Each request includes the following headers as default:</p>
				<p className={css.indent}><strong>User-Agent</strong>: Apache-HttpClient/4.1.1 (java 1.5)</p>
				<p className={css.indent}><strong>Connection</strong>: Keep-Alive</p>
				<p className={css.p}>Unless specified otherwise, the following headers will be set:</p>
				{type === "api.soap" ?
					<React.Fragment>
						<p className={css.indent}><strong>Content-Type</strong>: “text/xml; charset=utf-8”</p>
						<p className={css.indent}><strong>SOAP Action</strong>: put your action name here</p>
					</React.Fragment>
					: <p className={css.indent}><strong>Put your custom headers here</strong>: undefined</p>
				}
			</Tooltip>}>
			<InfoIcon className={css.infoIcon} />
		</TooltipTarget>
	);
};

HeaderTooltip.propTypes = {
	type: PropTypes.string.isRequired
};

export default HeaderTooltip;
