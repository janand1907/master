import React from 'react';
import { Field, FormGroup, Error } from 'components/common/Forms';
import HeaderTooltip from './tooltips/HeaderTooltip';
import PathTooltip from './tooltips/PathTooltip';
import css from './../CreateCustomParam.scss';
import HttpHeaders from './HttpHeaders';

const SoapFields = props => {
	return (
		<div className={css.authArea}>
			<FormGroup className={css.fullWidthField} label="Envelope">
				<Field
					name="locator.body"
					component="textarea"
					type="text"
					className="form-control"
					maxLength="2083"
					disabled={props.isViewMode}
				/>
			</FormGroup>
			<FormGroup
				className={css.fullWidthField}
				label={
					<span>
						xPath <PathTooltip type="soap" />
					</span>
				}
			>
				<Field
					name="locator.path"
					component="input"
					type="text"
					className="form-control"
					maxLength="2083"
					disabled={props.isViewMode}
				/>
				<Error sticky name="locator.path" />
			</FormGroup>
		</div>
	);
};

export default SoapFields;
