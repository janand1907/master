import React from 'react';
import PropTypes from 'prop-types';
import { GridView } from 'components/ui/GridView';
import NoDataMessage from 'components/admin/common/charts/NoDataMessage/NoDataMessage';
import cn from 'utils/classNames';
import * as css from 'components/admin/pilotView/client/analytics/AnalyticsSection.scss';
import * as style from './Matrix.scss';

class Matrix extends React.Component {
	constructor(props) {
		super(props);

		this.style =
			this.props.metricView === 'analytics'
				? style.tableAnalyticsView
				: style.tableDashboardView;
	}
	render() {
		const { id, selectedMetric, data, resolution, metricView } = this.props;
		const tableConfig = selectedMetric.resp_example.meta.map((value, i) => ({
			title: (value.name || value.type || value[0]).toUpperCase(),
			value: (value) => value[i],
		}));
		const values = data[0] && data[0].values[0];

		if (resolution === 'archive') {
			return <NoDataMessage type="archive" className={style.noData} />;
		}

		if (!values || !values.samples || !values.samples.length || !values.samples[0].y) {
			return <NoDataMessage type="nodata" className={style.noData} />;
		}
		return (
			<div
				key={id}
				className={
					cn(style.gridViewWrapper, metricView === 'analytics'
						&& css.analyticsWrapper)
				}
			>
				<GridView
					config={tableConfig}
					data={values.samples[0].y}
					className={this.style}
					selectedMetric={selectedMetric}
				/>
			</div>
		);
	}
}

Matrix.propTypes = {
	id: PropTypes.string,
	data: PropTypes.array,
	selectedMetric: PropTypes.object,
	colorMap: PropTypes.object,
	resolution: PropTypes.string,
	metricView: PropTypes.string,
};

export default Matrix;
