import React from 'react';
import cn from 'utils/classNames';
import { Field, FormGroup, Error, Password } from 'components/common/Forms';
import LookupSelect from 'components/common/Lookups/LookupSelect';
import DBName from 'components/admin/common/channels/ChannelForm/common/commonFields/DBName';
import css from './../CreateCustomParam.scss';
import CodeEditor from 'components/admin/common/script/CodeEditor/CodeEditor';

const DbFields = (props) => {
	const initialCode = props.initialValues && props.initialValues.locator && props.initialValues.locator.query;

	return (
		<React.Fragment>
			{!props.isViewMode && <FormGroup label="Parameter Name" mandatory>
				<Field
					name="label"
					component="input"
					type="text"
					className="form-control"
					maxLength="25"
				/>
				<Error sticky name="label" />
			</FormGroup>}
			<FormGroup>
				<Field name="auth.type" type="hidden" component="input" />
			</FormGroup>
			<FormGroup>
				<Field name="locator.type" type="hidden" component="input" />
			</FormGroup>
			<div className={cn(css.authArea, css.dbDetailsArea)}>
				<DBName key="dbName" fieldName="locator.db_name" disabled={props.isViewMode} value={props.isViewMode && props.initialValues.locator.db_name} className={css.dbName}/>
				<FormGroup className={css.fieldWrapper} label="Database Type" mandatory>
					<Field
						name="locator.db_type"
						validateOn={['blur', 'change']}
						onChange={props.isViewMode ? null : props.onChange}
						component={({ input }) => (
							<LookupSelect
								lookupType="db_type"
								transformOptions={(v) =>
									v.label === 'MySQL' || v.label === 'Postgres'
								}
								getLabel="label"
								{...input}
								value={props.isViewMode ? props.initialValues.locator.db_type : input.value}
								lazy={false}
								defaultOption="Select one..."
								disabled={props.isViewMode}
							/>
						)}
					/>
					<Error sticky name="locator.db_type" />
				</FormGroup>

				<FormGroup className={css.fieldWrapper} label="IP Address" mandatory>

					<Field
						name="locator.host"
						component="input"
						type="text"
						className="form-control"
						defaultValue={props.isViewMode && props.initialValues.locator.host}
						maxLength="2083"
						disabled={props.isViewMode}
					/>

					<Error sticky name="locator.host" />
				</FormGroup>

				<FormGroup className={css.fieldWrapper} label="Port" mandatory>
					<Field
						name="locator.port"
						component="input"
						type="text"
						className="form-control"
						maxLength="5"
						defaultValue={props.isViewMode && props.initialValues.locator.port}
						disabled={props.isViewMode}
					/>
					<Error sticky name="locator.port" />
				</FormGroup>

				<FormGroup className={css.fieldWrapper} label="Username" mandatory>
					<Field
						name="auth.username"
						component="input"
						type="text"
						className="form-control"
						maxLength="110"
						defaultValue={props.isViewMode && props.initialValues.auth.username}
						disabled={props.isViewMode}
					/>

					<Error sticky name="auth.username" />
				</FormGroup>

				<FormGroup className={css.fieldWrapper} label="Password" mandatory>
					<Password
						fieldProps={{ name: "auth.password", component: "input", className: "form-control", placeholder: "" }}
						isForm={true}
						value={props.isViewMode && props.initialValues.auth.password}
						disabled={props.isViewMode}
					/>
					<Error sticky name="auth.password" />
				</FormGroup>
			</div>

			<FormGroup className={css.formGroup} label="Query Builder" mandatory>

				<Field
					name="locator.query"
					component={({ input }) => (
						<div className={cn(css.scriptEditorWrapper, {[css.disableEvents]: props.isViewMode})}>
							<CodeEditor
								lng={'sql'}
								value={input.value || initialCode}
								onChange={(val) => { props.onChange(); input.onChange(val); }}
								readonly={false}
							/>
						</div>
					)}
				/>
				<Error sticky name="locator.query" />
			</FormGroup>

		</React.Fragment>
	);
};

export default DbFields;
