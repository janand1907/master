import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import { Form, Error, Field, FormGroup } from 'components/common/Forms';
import { Spinner } from 'components/ui/Spinner';
import { Alert } from 'components/ui/Alert';
import { ErrorIcon } from 'components/ui/Icons';
import validators from '../validations';
import css from '../CreateCustomParam.scss';
import TestResult from 'components/admin/common/script/TestResult/TestResult';
import DbFields from './../fields/DbFields';
import { isDbParamReadyForCreate } from 'components/admin/common/script/utils';
import * as i18n from 'i18n/en/customMetricValidation.json';

const config = {
	form: 'createDbParam',
	validators: pick(validators, [
		'label',
		'locator.db_name',
		'locator.db_type',
		'locator.host',
		'locator.port',
		'auth.username',
		'auth.password',
		'locator.query'
	]),
	initialValues: { auth: { type: 'basic' }, locator: { type: 'db' } }
};

function CreateCustomDbParam({
	formRef,
	form,
	model,
	customParamValidation,
	onCancel,
	onSubmit,
	pendingCreateParam,
	onTest,
	initialValues,
	isEditMode,
	isViewMode
}) {
	const [tested, setTested] = React.useState(false);
	return (
		<div className={css.modal}>
			<div className={css.header}>
				<h2>{isViewMode ? `${initialValues.label} Details` : isEditMode ? 'EDIT DB PARAMETER' : 'NEW DB PARAMETER'}</h2>
			</div>

			<div className={css.content}>
				<Form
					{...config}
					ref={formRef}
					className={css.form}
					onSubmit={onSubmit}
					onChange={() => setTested(false)}
					initialValues={{ ...initialValues, ...config.initialValues }}
				>
					<Error
						name=""
						component={({ error }) => {
							if (error.includes("The web server")) {
								error = i18n.db_connection_error;
							}
							(
								<Alert type="error">
									<ErrorIcon className={css.errorIcon} />
									<span>{error}</span>
								</Alert>
							)
						}}
					/>

					{isViewMode && <table className={css.table}>
						<thead>
							<tr>
								<th>API Type</th>
								<th>Status</th>
								<th>Response Type</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>{initialValues.type}</td>
								<td className={css[initialValues.status]}>{initialValues.status === 'ready' ? 'active' : initialValues.status}</td>
								<td>{initialValues.resp_type}</td>
							</tr>
						</tbody>
					</table>}

					<FormGroup className={css.hidden}>
						<Field
							name="id"
							component="input"
							type="text"
							className="form-control"
							maxLength="40"
							value={initialValues.id}
						/>
					</FormGroup>


					<DbFields onChange={() => setTested(false)} initialValues={initialValues} isViewMode={isViewMode} />
				</Form>
			</div>

			<div className={css.footer}>
				<TestResult
					disabled={pendingCreateParam}
					pending={customParamValidation.pending}
					error={customParamValidation.error}
					result={customParamValidation.result || initialValues.resp_example}
				/>
				{!isViewMode && <div className={css.buttons}>
					<button
						type="button"
						disabled={pendingCreateParam || customParamValidation.pending}
						className={css.btnTest}
						onClick={() => {
							if (form.validate()) {
								setTested(true);
								onTest()
							}
						}}
					>

						{customParamValidation.pending ? <Spinner className={css.spinner} /> : 'Test'}
					</button>
					<button
						type="button"
						className={css.btnCreate}
						disabled={!tested || !isDbParamReadyForCreate(model) || pendingCreateParam || !customParamValidation.result}
						onClick={() => form && form.submit()}
					>
						{pendingCreateParam && <Spinner className={css.spinner} />}
						{isEditMode ? "Update" : "Create"}
					</button>


					<button
						type="button"
						className={css.btnCancel}
						disabled={pendingCreateParam}
						onClick={onCancel}
					>
						Cancel
					</button>


				</div>}
				{isViewMode && <div className={css.bkpiWrapper}>
					<span className={css.bkpiTitle}>Related Business KPI</span>
					{initialValues.related_bkpi_ids.length ?
						<GridView
							data={initialValues.related_bkpi_ids}
							className={css.gridView}
							config={getGridViewConfig()}
						/> : <div className={css.value}>none</div>
					}
				</div>}
			</div>
		</div>
	);
}

CreateCustomDbParam.propTypes = {
	customParamValidation: PropTypes.object,
	model: PropTypes.object.isRequired,
	form: PropTypes.object,
	onTest: PropTypes.func,
	onSubmit: PropTypes.func.isRequired,
	onCancel: PropTypes.func.isRequired,
	formRef: PropTypes.func.isRequired,
	pendingCreateParam: PropTypes.bool,
	isEditMode: PropTypes.bool
};

export default CreateCustomDbParam;
