import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getDashboardPending } from 'ducks/admin/dashboard/selectors';
import { removeItem } from 'ducks/admin/dashboard/actions';
import { hideModal } from 'ducks/modal/actions';
import { NewSpinner } from 'components/ui/NewSpinner';
import * as i18n from 'i18n/en/dashboard.json';
import style from './RemoveDashboardItem.scss';

class RemoveDashboardItem extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleCancel = this.handleCancel.bind(this);
		this.handleConfirm = this.handleConfirm.bind(this);
	}

	handleConfirm() {
		this.props.removeItem(this.props.pilotId, this.props.id);
	}

	handleCancel() {
		this.props.hideModal();
	}

	render() {
		if (this.props.pending) {
			return (
				<div className={style.root}>
					<NewSpinner wrapperClassName={style.spinner} />
				</div>
			);
		}

		return (
			<div className={style.root}>
				<h4>{i18n.deleteMessage}</h4>
				<p> {globalize.parseString(i18n.removeDashboardItem.deleteInfo)}</p>
				<button
					type="button"
					className={style.btnCancel}
					onClick={this.handleCancel}
				>
					No
				</button>
				<button
					type="button"
					className={style.btnConfirm}
					onClick={this.handleConfirm}
				>
					Yes, delete data
				</button>
			</div>
		);
	}
}

RemoveDashboardItem.propTypes = {
	pending: PropTypes.bool,
	pilotId: PropTypes.string.isRequired,
	id: PropTypes.string.isRequired,
	removeItem: PropTypes.func,
	hideModal: PropTypes.func,
};

function mapStateToProps(state) {
	return {
		pending: getDashboardPending(state).set,
	};
}

export default connect(mapStateToProps, { removeItem, hideModal })(
	RemoveDashboardItem
);
