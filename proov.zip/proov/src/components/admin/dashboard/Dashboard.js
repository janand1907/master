import React from 'react';
import PropTypes from 'prop-types';
import { TimeLeft } from 'components/common/TimeLeft';
import { getNextStage } from 'utils/stagesUtils';
import DashboardCardContainer from './DashboardCard/DashboardCardContainer';
import css from './Dashboard.scss';

export default function Dashboard({ pilot, lastUpdate, order }) {
	const nextStage = getNextStage(pilot.stages, pilot.status);
	const currentStage = pilot.stages[pilot.status];
	return (
		<div>
			<div className={css.header}>
				<div className={css.nameAndLastUpdateWrapper}>
					<h1 title={pilot.name} className={css.pilotName}>
						{pilot.name}
					</h1>
					<span>{`Last Update:  ${lastUpdate || ''}`}</span>
				</div>
				<TimeLeft
					startTime={currentStage ? currentStage.start_date : pilot.start_time}
					endTime={
						nextStage ? pilot.stages[nextStage].start_date : pilot.end_time
					}
					joinable={pilot.joinable}
					status={pilot.status}
					nextStage={!!nextStage}
				/>
			</div>

			<div className={css.itemsList}>
				{order.map((id) => (
					<DashboardCardContainer key={id} id={id} />
				))}
			</div>
		</div>
	);
}

Dashboard.propTypes = {
	order: PropTypes.array,
	pilot: PropTypes.object,
	lastUpdate: PropTypes.string,
};
