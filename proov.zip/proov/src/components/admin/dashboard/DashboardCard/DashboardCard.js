import React from 'react';
import PropTypes from 'prop-types';
import MetricDescriptionForDashboard from 'components/admin/common/charts/MetricDescription/MetricDescriptionForDashboard';
import FeedContainer from 'components/admin/pilotView/client/analytics/analyticsView/FeedContainer';
import ChartContainer from 'components/admin/pilotView/client/analytics/analyticsView/ChartContainer';
import MatrixContainer from 'components/admin/pilotView/client/analytics/analyticsView/MatrixContainer';
import WebContainer from 'components/admin/pilotView/client/analytics/analyticsView/WebContainer';

import { Tabs } from 'components/ui/Tabs';
import IconWrapper from 'components/admin/common/channels/icons/IconWrapper';
import { TrashIcon } from 'components/ui/Icons';
import cn from 'utils/classNames';
import Permission from 'components/Permission';
import VendorsGridContainer from 'components/admin/pilotView/client/analytics/ToolBar/VendorsGrid/VendorsGridContainer';
import style from './DashboardCard.scss';

const TABS = {
	live: 'LIVE',
	archive: 'ARCHIVE',
};

function DashboardCard({
	channel,
	item,
	id,
	pilotId,
	onSelectTab,
	onRemoveItem,
	vendorToColorMap,
	onReorder,
}) {
	const cardRef = React.useRef(null);
	const handleDragStart = React.useCallback((e) => {
		e.dataTransfer.setData('text', e.target.id);
	}, []);

	const handleDragOver = React.useCallback((e) => {
		e.preventDefault();
	}, []);

	const handleDrop = React.useCallback((e, el) => {
		e.preventDefault();
		let dropTarget = el;
		let dragTargetId = e.dataTransfer.getData('text');
		let dragTarget = document.getElementById(dragTargetId);
		// tmp is only for swapping
		let tmp = document.createElement('div');
		tmp.className = 'hide';
		dropTarget.before(tmp);
		dragTarget.before(dropTarget);
		tmp.replaceWith(dragTarget);
		const newOrder = Object.values(dragTarget.parentNode.children).map(
			(child) => child.id
		);
		onReorder(newOrder);
	}, []);

	const handleSelectTab = React.useCallback((tab) => {
		const tabKey = Object.keys(TABS).filter((key) => TABS[key] === tab)[0];
		onSelectTab(tabKey, id);
	}, []);

	const type = item.selectedMetric && item.selectedMetric.resp_type;
	let metricType = null;
	if (type === 'value') {
		metricType =
			item.selectedMetric.resp_example.meta[0].type === 'number'
				? 'chart'
				: 'feed';
	} else if (type === 'table') {
		metricType = 'matrix';
	} else if (type === 'vector') {
		metricType = 'feed';
	}else if (item.type === 'web') {
		metricType = 'web';
	} 
	 else {
		metricType = 'chart';
	}

	const title =
		item.type === 'custom_chart'
			? 'Custom Charts'
			: channel
				? channel.name
				: item.selectedMetric.channelId
					? 'SaaS'
					: 'Business KPIs';

	return (
		<div
			ref={(ref) => (cardRef.current = ref)}
			className={style.root}
			draggable="true"
			id={id}
			onDragOver={handleDragOver}
			onDragStart={handleDragStart}
			onDrop={(e) => handleDrop(e, cardRef.current)}
		>
			<div className={style.header}>
				{channel && <IconWrapper {...channel} />}
				<h3 title={title} className={style.channelName}>
					{title}
				</h3>
				<Permission
					alias="DashboardCard#delete"
					component={
						<TrashIcon className={style.trashIcon} onClick={onRemoveItem} />
					}
				/>
			</div>

			<Tabs
				tabList={Object.values(TABS)}
				activeTab={TABS[item.resolution]}
				className={cn(style.tabs, {
					[style.tabsDisabled]: item.pending,
				})}
				onChange={handleSelectTab}
			/>

			{(() => {
				switch (metricType) {
					case 'chart':

						return (
							<ChartContainer
								key={id}
								id={id}
								pilotId={pilotId}
								movingAvg={item.selectedMetric.movingAvg}
								vendorToColorMap={vendorToColorMap}
								metricView="dashboard"
								{...item}
							/>
						);
					case 'web':
						return (
							<WebContainer
								key={id}
								id={id}
								pilotId={pilotId}
								movingAvg={item.selectedMetric.movingAvg}
								vendorToColorMap={vendorToColorMap}
								metricView="dashboard"
								{...item}
							/>
						);
					case 'matrix':
						return (
							<MatrixContainer
								key={id}
								id={id}
								pilotId={pilotId}
								vendorToColorMap={vendorToColorMap}
								metricView="dashboard"
								{...item}
							/>
						);
					case 'feed':
						return (
							<FeedContainer
								key={id}
								id={id}
								pilotId={pilotId}
								vendorToColorMap={vendorToColorMap}
								metricView="dashboard"
								{...item}
							/>
						);
					default:
						// serial-metric
						// custom-chart
						return (
							<ChartContainer
								key={id}
								id={id}
								pilotId={pilotId}
								vendorToColorMap={vendorToColorMap}
								metricView="dashboard"
								{...item}
							/>
						);
				}
			})()}
		
			<MetricDescriptionForDashboard metric={item.selectedMetric} />
			<VendorsGridContainer
				data={item.data}
				selectedGraphs={item.selectedGraphs}
				selectedVendors={item.selectedVendors}
				itemId={id}
				channelId={item.channelId}
				metricView="dashboard"
				metricType={metricType} 
				className={style.vendorsGrid}
				classVendorCell={style.vendorCell}
				/>
		</div>
	);
}

DashboardCard.propTypes = {
	item: PropTypes.object,
	id: PropTypes.string,
	pilotId: PropTypes.string,
	channel: PropTypes.object,
	vendorToColorMap: PropTypes.object,
	vendors: PropTypes.array,
	onSetVendors: PropTypes.func,
	onRemoveItem: PropTypes.func,
	onSelectTab: PropTypes.func,
	onReorder: PropTypes.func,
	pending: PropTypes.bool,
	error: PropTypes.object,
};

export default DashboardCard;
