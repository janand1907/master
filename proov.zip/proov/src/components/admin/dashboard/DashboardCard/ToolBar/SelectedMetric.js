import React from 'react';
import PropTypes from 'prop-types';
import Permission from 'components/Permission';
import { TrashIcon, ChevronSmallIcon } from 'components/ui/Icons';
import cn from 'utils/classNames';
import style from 'components/admin/pilotView/client/analytics/ToolBar/ToolBar.scss';
import FuncTooltip from './FuncTooltip';

const SelectedMetric = props => {
	const { selectedMetric, onRemoveMetric, onToggle } = props;
	const { label, category } = selectedMetric;

	return (
		<div className={style.selectedMetric} onClick={onToggle}>
			<span className={style.selectedLabel}>{label}</span>
			<div
				className={cn(style.actions, {
					[style.actionsCustomMetric]: category === 'Business KPI'
				})}
			>
				{category === 'Business KPI' && (
					<Permission
						alias="SelectedMetric#delete"
						component={
							<button onClick={onRemoveMetric} className={style.removeMetricButton}>
								<TrashIcon className={style.trashIcon} />
							</button>
						}
					/>
				)}
				{category === 'Business KPI' && <FuncTooltip metric={selectedMetric} />}
				<ChevronSmallIcon className={style.chevronIcon} />
			</div>
		</div>
	);
};

SelectedMetric.propTypes = {
	selectedMetric: PropTypes.object.isRequired,
	onRemoveMetric: PropTypes.func,
	onToggle: PropTypes.func
};

export default SelectedMetric;
