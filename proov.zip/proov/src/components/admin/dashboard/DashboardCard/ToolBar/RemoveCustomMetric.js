import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { deleteMetric } from 'ducks/admin/analytics/metrics/actions';
import { hideModal } from 'ducks/modal/actions';
import { getPending } from 'ducks/admin/analytics/metrics/selectors';
import { Spinner } from 'components/ui/Spinner';
import cn from 'utils/classNames';
import * as i18n from 'i18n/en/dashboard.json';
import style from './RemoveCustomMetric.scss';

class RemoveCustomMetric extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleCancel = this.handleCancel.bind(this);
		this.handleConfirm = this.handleConfirm.bind(this);
	}

	handleConfirm() {
		this.props.actions.deleteMetric(this.props.pilotId, this.props.metric.id);
	}

	handleCancel() {
		this.props.actions.hideModal();
	}

	render() {
		if (this.props.pendingDelete) {
			return (
				<div className={cn(style.root, style.progressRoot)}>
					<Spinner className={style.spinner} />
				</div>
			);
		}

		return (
			<div className={style.root}>
				<h4>{i18n.deleteMessage}</h4>
				<p>{globalize.parseString(i18n.toolBar.removeMetric.deleteInfo)}</p>
				<button type="button" className={style.btnCancel} onClick={this.handleCancel}>
					No
				</button>
				<button type="button" className={style.btnConfirm} onClick={this.handleConfirm}>
					Yes, delete data
				</button>
			</div>
		);
	}
}

RemoveCustomMetric.propTypes = {
	actions: PropTypes.object,
	pendingDelete: PropTypes.bool,
	pilotId: PropTypes.string.isRequired,
	metric: PropTypes.object.isRequired
};

function mapStateToProps(state) {
	const pendingDelete = getPending(state).deleteMetric;

	return {
		pendingDelete
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators({ deleteMetric, hideModal }, dispatch)
	};
}

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(RemoveCustomMetric);
