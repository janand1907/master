import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import css from './FuncTooltip.scss';

const FuncTooltip = (props) => {
	const { metric } = props;
	if (!metric.expression) return null;
	return (
		<TooltipTarget tooltip={<Tooltip placement="bottom" className={css.funcTooltip}>{metric.expression_to_display}</Tooltip>}>
			<InfoIcon className={css.infoIcon} />
		</TooltipTarget>
	);
};

FuncTooltip.propTypes = {
	metric: PropTypes.object,
};

export default FuncTooltip;
