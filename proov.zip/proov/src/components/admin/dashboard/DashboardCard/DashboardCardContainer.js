import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { showModal } from 'ducks/modal/actions';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import * as dashboardActions from 'ducks/admin/dashboard/actions';
import { getDashboardItem } from 'ducks/admin/dashboard/selectors';
import DashboardCard from './DashboardCard';

function DashboardCardContainer({ id, item, pilot, actions }) {
	const handleRemoveItem = React.useCallback(() => {
		actions.showModal('RemoveDashboardItem', {
			pilotId: pilot.id,
			id: id,
		});
	}, []);

	const handleReorder = React.useCallback((newOrder) => {
		actions.reorderItems(pilot.id, newOrder);
	}, []);

	let channel = null;

	if (item.type === 'custom_chart')
		channel = { type: item.type };
	else if (item.channelId)
		channel = pilot.environment.filter((env) => env.id === item.channelId)[0];
	else if (item.endpointLabel && item.endpointLabel.script_type === 'js_saas')
		channel = { type: 'saas' };
	else
		channel = { type: 'B_KPI' };

	return (
		<DashboardCard
			key={id}
			id={id}
			pilotId={pilot.id}
			vendorToColorMap={pilot.vendorToColorMap}
			item={item}
			channel={channel}
			vendors={pilot.vendors}
			onRemoveItem={handleRemoveItem}
			onReorder={handleReorder}
			onSelectTab={actions.selectTab}
		/>
	);
}

DashboardCardContainer.propTypes = {
	actions: PropTypes.object.isRequired,
	pilot: PropTypes.object,
	item: PropTypes.object,
	id: PropTypes.string,
	getMetrics: PropTypes.func,
	showModal: PropTypes.func,
	reorderItems: PropTypes.func,
};

const mapStateToProps = (state, ownProps) => {
	return {
		pilot: getAdminPilot(state),
		item: getDashboardItem(state, ownProps.id),
	};
};

function mapDispatchToProps(dispatch) {
	return {
		dispatch: dispatch,
		actions: bindActionCreators(
			{
				...dashboardActions,
				showModal,
			},
			dispatch
		),
	};
}

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(DashboardCardContainer);
