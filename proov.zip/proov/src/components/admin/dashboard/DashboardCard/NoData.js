import React from 'react';
import PropTypes from 'prop-types';
import { NewSpinner } from 'components/ui/NewSpinner';
import NoDataMessage from 'components/admin/common/charts/NoDataMessage/NoDataMessage';
import css from './DashboardCard.scss';

class NoData extends React.PureComponent {
	render() {
		if (this.props.error) {
			return (
				<NoDataMessage
					type="nodata"
					wrapperClassName={css.noDataMessageWrapper}
					className={css.noDataMessage}
				/>
			);
		} else if (this.props.pending) {
			return <NewSpinner wrapperClassName={css.chartSpinner} />;
		} else {
			return null;
		}
	}
}

NoData.propTypes = {
	pending: PropTypes.bool,
	error: PropTypes.string
};

export default NoData;
