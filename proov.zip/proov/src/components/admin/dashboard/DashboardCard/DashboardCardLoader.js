import React from 'react';
import PropTypes from 'prop-types';
import ContentLoader from 'react-content-loader';
import css from './DashboardCard.scss';

class DashboardCardLoader extends React.PureComponent {
	render() {
		return (
			<ContentLoader
				speed={1}
				margin-top="10px"
				width="49.5%"
				viewBox="0 0 600 600"
				backgroundColor="#f3f3f3"
				foregroundColor="#ecebeb"
				{...this.props}
			>
				<rect x="29" y="142" rx="2" ry="2" width="102" height="19" />
				<rect x="28" y="201" rx="2" ry="2" width="539" height="252" />
				<rect x="30" y="54" rx="0" ry="0" width="75" height="70" />
				<rect x="136" y="142" rx="2" ry="2" width="102" height="19" />
				<rect x="29" y="168" rx="2" ry="2" width="328" height="27" />
				<rect x="123" y="56" rx="2" ry="2" width="102" height="9" />
				<rect x="123" y="72" rx="2" ry="2" width="173" height="12" />
				<rect x="123" y="92" rx="2" ry="2" width="173" height="12" />
				<rect x="28" y="463" rx="2" ry="2" width="539" height="27" />
				<rect x="28" y="515" rx="2" ry="2" width="539" height="15" />
				<rect x="28" y="539" rx="2" ry="2" width="539" height="17" />
				<rect x="456" y="168" rx="2" ry="2" width="111" height="27" />
			</ContentLoader>
		);
	}
}

export default DashboardCardLoader;
