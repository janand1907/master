import React from 'react';
import PropTypes from 'prop-types';
import { Popover } from 'components/ui/Popover';
import { MultiSelect } from 'components/ui/MultiSelect';
import ItemsList from 'components/ui/ItemsExplorer/ItemsList';
import css from './VendorSelect.scss';

class SelectPopover extends React.Component {
	render() {
		const {
			vendors,
			selectedVendors,
			isMultiSelect,
			colorsMap,
			onSetVendors
		} = this.props;

		return (
			<Popover {...this.props} className={css.selectVendorPopover}>
				{isMultiSelect ? (
					<MultiSelect
						className={css.selectionsList}
						options={vendors}
						selected={selectedVendors}
						getValue={item => item.id}
						getContent={item => (
							<div className={css.selectItemContent}>
								<div
									className={css.bullet}
									style={{ backgroundColor: [colorsMap[item.id]] }}
								/>
								<span title={item.name} className={css.vendorName}>
									{item.name}
								</span>
							</div>
						)}
						onSet={selectedIds => onSetVendors(selectedIds)}
					/>
				) : (
					<ItemsList
						items={vendors}
						itemClassName={css.itemList}
						renderItem={item => {
							return (
								<div
									style={{
										paddingLeft: '0px',
										borderLeft: `5px solid ${this.props.colorsMap[item.id]}`
									}}
								>
									<span style={{ marginLeft: '10px' }} title={item.name}>
										{item.name}
									</span>
								</div>
							);
						}}
						className={css.selectionsList}
						onItemSelected={vendor => onSetVendors([vendor.id])}
						allowHighlight={true}
						selectedItem={selectedVendors}
					/>
				)}
			</Popover>
		);
	}
}

SelectPopover.propTypes = {
	vendors: PropTypes.array,
	colorsMap: PropTypes.object,
	isMultiSelect: PropTypes.bool,
	selectedVendors: PropTypes.array,
	onSetVendors: PropTypes.func
};

export default SelectPopover;
