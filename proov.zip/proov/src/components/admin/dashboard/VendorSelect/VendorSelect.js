import React from 'react';
import PropTypes from 'prop-types';
import { ChevronSmallIcon } from 'components/ui/Icons';
import ClickOutsideListener from 'components/ui/ClickOutsideListener/ClickOutsideListener';
import cn from 'utils/classNames';
import SelectedVendorsTooltip from './SelectedVendorsTooltip/SelectedVendorsTooltip';
import SelectPopover from './SelectPopover';
import css from './VendorSelect.scss';
import toolTipCss from './SelectedVendorsTooltip/SelectedVendorsTooltip.scss';

class VendorSelect extends React.Component {
	constructor(props) {
		super(props);
		this.handleToggleAddCustom = this.handleToggleAddCustom.bind(this);
		this.state = { selectIsVisible: false };
	}

	handleToggleAddCustom() {
		this.setState({ selectIsVisible: !this.state.selectIsVisible });
	}

	render() {
		const { selectedVendors } = this.props;
		return (
			<div className={css.root}>
				<div
					ref={ref => (this.selectVendorsView = ref)}
					className={css.header}
					onClick={() => this.handleToggleAddCustom()}
				>
					{selectedVendors.length > 0 ? (
						<ul className={cn(toolTipCss.list, css.selectedList)}>
							{this.props.vendors.map(vendor => {
								if (!selectedVendors.some(s => s === vendor.id)) return null;
								return (
									<li key={vendor.id} className={toolTipCss.listItem}>
										<div
											className={css.bullet}
											style={{ backgroundColor: [this.props.colorsMap[vendor.id]] }}
										/>
										<span className={toolTipCss.vendorName}>{vendor.name}</span>
									</li>
								);
							})}
						</ul>
					) : (
						<span className={css.noVendorsMessage}>Please select vendors</span>
					)}
					<ChevronSmallIcon className={css.chevronIcon} />
				</div>
				<SelectedVendorsTooltip
					itemId={this.props.itemId}
					vendors={this.props.vendors.filter(({ id }) => selectedVendors.includes(id))}
					colorsMap={this.props.colorsMap}
				/>
				<ClickOutsideListener >
					{this.state.selectIsVisible && (
						<SelectPopover
							isMultiSelect={this.props.isMultiSelect}
							{...this.props}
							key={`SelectVendorPopover${this.props.itemId}`}
							onSetVendors={this.props.onSetVendors}
							target={this.selectVendorsView}
							deltaY={130}
							targetStartPosition="bottomleft"
						/>
					)}
				</ClickOutsideListener>
			</div>
		);
	}
}

VendorSelect.propTypes = {
	itemId: PropTypes.string,
	isMultiSelect: PropTypes.bool,
	onSetVendors: PropTypes.func,
	colorsMap: PropTypes.object,
	selectedVendors: PropTypes.array,
	vendors: PropTypes.array
};

export default VendorSelect;
