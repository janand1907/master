import React from 'react';
import PropTypes from 'prop-types';
import { flatten } from 'lodash';
import { connect } from 'react-redux';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { setSelectedVendors } from 'ducks/admin/dashboard/actions';
import { getDashboardItem } from 'ducks/admin/dashboard/selectors';
import VendorSelect from './VendorSelect';

class VendorSelectContainer extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleSetVendors = this.handleSetVendors.bind(this);
		this.authorizeVendors = this.authorizeVendors.bind(this);
	}

	UNSAFE_componentWillMount() {
		if (
			this.props.item.type === 'web'
		) {
			this.props.setSelectedVendors(this.props.item.selectedVendors, this.props.itemId);
		}
		else if (
			this.props.item.type === 'chart'||
			this.props.item.type === 'serial_metric'
		) {
			const ids = this.authorizeVendors(this.props.vendors).map(({ id }) => id);
			this.props.setSelectedVendors(ids, this.props.itemId);
		} else if (this.props.item.type === 'custom_chart' && this.props.item.selectedMetric.config) {
			const ids = this.authorizeVendors(this.props.vendors).map(
				({ id, name }) => ({
					id: id,
					name: name,
				})
			);
			let selectedVendors = [];
			this.props.item.selectedMetric.config.forEach((m) => {
				ids.forEach((v) => {
					const cId = v.id + '_' + m.channel_id;
					selectedVendors.push(cId);
				});
			});

			this.props.setSelectedVendors(selectedVendors, this.props.itemId);
		} else {
			const ids = this.authorizeVendors(this.props.vendors).map(({ id }) => id);
			this.props.setSelectedVendors([ids[0]], this.props.itemId);
		}
	}

	handleSetVendors(ids) {
		this.props.setSelectedVendors(ids, this.props.itemId);
	}

	authorizeVendors(vendors) {
		const { environment, item } = this.props;
		const channel =
			item.channelId && environment.find(({ id }) => id === item.channelId);
		let selectedVendorAccessRights;

		if (channel && channel.status === 'ready') {
			if (!channel.is_dedicated) {
				selectedVendorAccessRights = channel.isv_access;
			} else {
				const mapped = channel.servers || channel.isvs;
				selectedVendorAccessRights = flatten(
					mapped.map((server) => server.isv_access)
				);
			}

			if (selectedVendorAccessRights) {
				selectedVendorAccessRights=	selectedVendorAccessRights.filter((s)=>s)
				return (
					vendors &&
					vendors.filter((vendor) =>
						selectedVendorAccessRights.some(({ id }) => id === vendor.id)
					)
				);
			}
		}
		return vendors;
	}

	render() {
		let { item, itemId, pilot } = this.props;
		let vendors = [],
			selectedVendors = [],
			vendorToColorMap = {};
		const ids = this.authorizeVendors(this.props.vendors).map(
			({ id, name }) => ({
				id: id,
				name: name,
			})
		);
		if (item.type === 'custom_chart' && item.selectedMetric.config) {
			item.selectedMetric.config.forEach((m) => {
				ids.forEach((v) => {
					const cId = v.id + '_' + m.channel_id;
					const channel = pilot.environment.find((e) => e.id === m.channel_id);
					vendors.push({
						...v,
						id: cId,
						name:
							channel && channel.name ? channel.name + '/' + v.name : v.name,
					});
					vendorToColorMap[cId] = pilot.vendorToColorMap[v.id];
					selectedVendors.push(cId);
				});
			});
		} else {
			selectedVendors = item.selectedVendors;
			vendors = ids;
			vendorToColorMap = pilot.vendorToColorMap;
		}

		const type = item.selectedMetric && item.selectedMetric.resp_type;
		let metricType = null;
		if (type === 'value') {
			metricType =
				item.selectedMetric.resp_example.meta[0].type === 'number'
					? 'chart'
					: 'feed';
		} else if (type === 'table') {
			metricType = 'matrix';
		} else if (type === 'vector') {
			metricType = 'feed';
		} else {
			metricType = 'chart';
		}

		return (
			<VendorSelect
				isMultiSelect={metricType === 'chart'}
				itemId={itemId}
				vendors={vendors}
				colorsMap={vendorToColorMap}
				selectedVendors={item.selectedVendors}
				onSetVendors={this.handleSetVendors}
			/>
		);
	}
}

VendorSelectContainer.propTypes = {
	vendorToColorMap: PropTypes.object,
	itemId: PropTypes.string,
	item: PropTypes.object,
	pilot: PropTypes.object,
	environment: PropTypes.array,
	vendors: PropTypes.array,
	setSelectedVendors: PropTypes.func,
};

const mapStateToProps = (state, ownProps) => {
	const pilot = getAdminPilot(state);
	return {
		pilot,
		vendors: pilot && pilot.vendors,
		vendorToColorMap: pilot && pilot.vendorToColorMap,
		environment: pilot && pilot.environment,
		item: getDashboardItem(state, ownProps.itemId),
	};
};

export default connect(mapStateToProps, { setSelectedVendors })(
	VendorSelectContainer
);
