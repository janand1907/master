import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import css from './../VendorSelect.scss';
import toolTipCss from './SelectedVendorsTooltip.scss';

const SelectedVendorsTooltip = props => {
	return (
		<TooltipTarget
			tooltip={
				<Tooltip placement="top" className={toolTipCss.root}>
					<span className={toolTipCss.label}>Selected vendors:</span>
					<ul className={toolTipCss.list}>
						{props.vendors.map(vendor => {
							return (
								<li key={`${props.itemId}${vendor.id}`} className={toolTipCss.listItem}>
									<div
										className={css.bullet}
										style={{ backgroundColor: [props.colorsMap[vendor.id]] }}
									/>
									<span className={toolTipCss.vendorName}>{vendor.name}</span>
								</li>
							);
						})}
					</ul>
				</Tooltip>
			}
		>
			<InfoIcon className={toolTipCss.infoIcon} />
		</TooltipTarget>
	);
};

SelectedVendorsTooltip.propTypes = {
	vendors: PropTypes.array,
	colorsMap: PropTypes.object,
	itemId: PropTypes.string
};

export default SelectedVendorsTooltip;
