import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import * as selectors from 'ducks/admin/dashboard/selectors';
import * as i18n from 'i18n/en/dashboard.json';
import { bindActionCreators } from 'redux';
import {
	getItems,
	resetDashboard,
	getStandardKpis,
	getBusinessKpis,
	getCustomCharts,
} from 'ducks/admin/dashboard/actions';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { setMetricView } from 'ducks/admin/analytics/metrics/actions';
import { NewSpinner } from 'components/ui/NewSpinner';
import Dashboard from './Dashboard';
import css from './Dashboard.scss';
import { Link } from 'react-router-dom';

function DashboardContainer({
	actions,
	pendingCustomCharts,
	pendingStandardKPis,
	pendingBusinessKPis,
	pilot,
	order,
	items,
	lastUpdate,
}) {
	React.useEffect(() => {
		actions.getStandardKpis();
		actions.getBusinessKpis();
		actions.getCustomCharts();
	}, []);

	if (pendingCustomCharts || pendingStandardKPis || pendingBusinessKPis) {
		return <NewSpinner size="m" />;
	} /*else if (pilot.vendors.length === 0) {
		return (
			<div className={css.noItemsMessage}>
				<h2>{i18n.noItemsMessage}</h2>
			</div>
		);
	}*/ else if (!Object.keys(items).length) {
		return (
			<div className={css.noItemsMessage}>
				<h2>{globalize.parseString(i18n.noItemsTitle)}</h2>
				<h2>
					{globalize.parseString(i18n.goBack)}
					<Link to={`/admin/pilot/${pilot.id}/analytics`}>
						{globalize.parseString(i18n.analyticsAndSimulation)}
					</Link>
					{globalize.parseString(i18n.pinGraph)}</h2>
			</div>
		);
	}

	return (
		<Dashboard
			pilot={pilot}
			order={order}
			items={items}
			lastUpdate={lastUpdate}
		/>
	);
}

DashboardContainer.propTypes = {
	resetDashboard: PropTypes.func,
	getStandardKpis: PropTypes.func,
	getBusinessKpis: PropTypes.func,
	pendingCustomCharts: PropTypes.bool,
	pendingStandardKPis: PropTypes.bool,
	pendingBusinessKPis: PropTypes.bool,
	order: PropTypes.array,
	pilot: PropTypes.object,
	getCustomCharts: PropTypes.func,
	getMetrics: PropTypes.func,
	items: PropTypes.object,
	lastUpdate: PropTypes.string,
};

const mapStateToProps = (state) => {
	return {
		pilot: getAdminPilot(state),
		order: selectors.getDashboardOrder(state),
		items: selectors.getDashboardItems(state),
		pendingCustomCharts: selectors.getDashboardPending(state).customCharts,
		pendingStandardKPis: selectors.getDashboardPending(state).standardKpis,
		pendingBusinessKPis: selectors.getDashboardPending(state).businessKpis,
		lastUpdate: selectors.getDashboardLastUpdate(state),
	};
};

function mapDispatchToProps(dispatch) {
	return {
		dispatch: dispatch,
		actions: bindActionCreators(
			{
				getItems,
				resetDashboard,
				getStandardKpis,
				getBusinessKpis,
				getCustomCharts,
				setMetricView,
			},
			dispatch
		),
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(DashboardContainer);
