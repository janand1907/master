import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { UnControlled as CodeMirror } from 'react-codemirror2';
import { CopyToClipboard } from "react-copy-to-clipboard";
import 'codemirror/lib/codemirror.css';
import 'codemirror/theme/material.css';
import 'codemirror/mode/javascript/javascript';
import 'codemirror/mode/python/python';
import 'codemirror/mode/sql/sql';
import CopyIcon from 'components/ui/Icons/CopyIcon';
import IconWithTooltip from 'components/ui/Icons/IconWithTooltip';
import * as i18n from 'i18n/en/common.json';
import css from './style.scss';
import { TEMPLATES } from 'constants/templates';

const CodeEditor = ({ lng, value, onChange, mode, readonly, scriptCodeToInject, isEvaluationScript, editorClassName }) => {

    const getTemplateCode = () => isEvaluationScript && lng === 'javascript' ? TEMPLATES['javascriptForScript'] : TEMPLATES[lng];
    const [editorValue, setEditorValue] = useState(value || getTemplateCode());
    const [cursor, setCursor] = useState(null);
    const [isFirstTimeModeChange, setIsFirstTimeModeChange] = useState(false);
    const [flag, setFlag] = useState(false);
    const [isEnterRow, setIsEnterRow] = useState(false);

    useEffect(() => {
        if (mode === 'create')
            setEditorValue(getTemplateCode());
    }, [lng]);

    useEffect(() => {
        if (mode !== 'edit' && value !== null && scriptCodeToInject.value) {
            const location = getCursorLocation(value, cursor !== null ? cursor : { line: 0, ch: 0 });

            if (value === undefined) setEditorValue(scriptCodeToInject.value);
            else setEditorValue(value.substr(0, location)
                .concat(scriptCodeToInject.value)
                .concat(value.substr(location, value.length - location)));
        }
    }, [scriptCodeToInject.toggle]);

    useEffect(() => {
        if (mode) {
            setEditorValue(value);
            if (!flag && mode === 'draft') {
                setFlag(true);
                setIsFirstTimeModeChange(true);
            } else setIsFirstTimeModeChange(false);
        }
    }, [mode]);

    useEffect(() => {
        if (isFirstTimeModeChange) {
            setEditorValue(value);
            setIsFirstTimeModeChange(false);
        }
    }, [value]);

    const isEnterChar = (text) => {
        return text.length === 2 && text[0] === "" && text[1] === "";
    }

    const getCursorLocation = (value, cursor) => {
        let index = 0;
        let chLinesCursor = 0;
        let pos = 0;
        let stringValue = value;

        while (pos < cursor.line) {
            index = stringValue.indexOf('\n') + 1;
            chLinesCursor = chLinesCursor + index;
            stringValue = stringValue.substr(index, stringValue.length);
            pos++;
        }

        return chLinesCursor + cursor.ch;
    }

    const addTabToValue = () => {
        setIsEnterRow(false);
        setCursor({ line: cursor.line + 1, ch: 3 });
        const location = getCursorLocation(value, cursor !== null ? { line: cursor.line + 1, ch: 0 } : { line: 0, ch: 0 });
        if (value !== undefined)
            setEditorValue(value.substr(0, location)
                .concat("\t")
                .concat(value.substr(location + 2, value.length - location)));
    }

    return <div className={css.codeMirrorWrapper}>
        <CodeMirror
            value={editorValue}
            options={{
                mode: lng,
                theme: 'material',
                lineNumbers: true,
                readOnly: readonly
            }}
            onChange={(editor, data, valueCode) => {
                if (isEnterRow && data.text[0] === '  ') {
                    addTabToValue()
                }
                if (isEnterChar(data.text))
                    setIsEnterRow(true);
                    
                onChange(valueCode, data.text);
            }}
            onCursor={(editor, data) => {
                setCursor({
                    line: data.line, ch: data.ch
                })
            }}
            cursor={cursor ? { line: cursor.line, ch: cursor.ch + 1 } : null}
            className={editorClassName}
        />
        <CopyToClipboard text={value}>
            <span><IconWithTooltip className={css.tooltipWrapper} icon={<CopyIcon className={css.copyIcon} />} textToDisplay={i18n.tooltipText.copyAll} /></span>
        </CopyToClipboard>

    </div>
}

CodeEditor.propTypes = {
    lng: PropTypes.string,
    value: PropTypes.string,
    onChange: PropTypes.func,
    scriptCodeToInject: PropTypes.object
}

CodeEditor.defaultProps = {
    scriptCodeToInject: {}
}

export default CodeEditor;