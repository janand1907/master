/* eslint-disable camelcase */
import isLength from 'validator/lib/isLength';
import isIP from 'validator/lib/isIP';
import isInt from 'validator/lib/isInt';
import isURL from 'validator/lib/isURL';
import { createScriptExpression } from 'utils';
import * as i18n from 'i18n/en/customMetricValidation.json';

const isExist = value => !!value;
const str = value => (value || '').toString().trim();
const validator = (validate, message) => value =>
	!validate(value) ? message : undefined;
const projectIdPattern = /^[A-Za-z0-9\!\-\"\']{4,30}$/;

const validators = {
	label: validator(val => val === "" || isLength(str(val), { min: 2, max: 40 }), i18n.name),
	description: validator(
		val => isLength(str(val), { min: 2, max: 100 }),
		i18n.description
	),
	'locator.db_type': validator(val => isExist(val), i18n.db_type),
	'locator.db_name': (val, { db_type }) => {
		if (db_type === 'bigquery') {
			const strVal = str(val);
			if (!isLength(strVal, { min: 4, max: 30 })) {
				return i18n.db_name.invalidLength1;
			}
			if (!strVal.match(projectIdPattern)) {
				return i18n.db_name.invalidProjectID;
			}
			if (!isLength(str(val), { min: 2, max: 128 })) {
				return i18n.db_name.invalidLength2;
			}
		} else if (!isLength(str(val), { min: 2, max: 128 })) {
			return i18n.db_name.invalidLength2;
		}
	},
	'locator.host': validator(val => {
		const valStr = str(val);
		return (
			(isIP(valStr) || isURL(valStr, { allow_underscores: true })) &&
			isLength(str(valStr), { min: 4, max: 2083 })
		);
	}, i18n.host),
	'locator.port': validator(val => isInt(str(val)) && val <= 65535, i18n.port),
	'auth.username': validator(
		val => isLength(str(val), { min: 2, max: 110 }),
		i18n.username
	),
	'auth.password': value => {
		if (value && typeof value === 'object') return;
		if (!isLength(str(value), { min: 2, max: 200 })) {
			return i18n.password;
		}
	},
	'locator.query': validator(val => isExist(val), i18n.query),
	'locator.url': validator(
		val =>
			isLength(str(val), { min: 4, max: 2083 }) &&
			isURL(val, { allow_underscores: true }),
		i18n.url
	),
	'locator.path': validator(val => isExist(val), i18n.path),
	'auth.client_id': validator(val => isExist(val), i18n.client_id),
	'auth.client_secret': validator(val => isExist(val), i18n.client_secret),
	'auth.token_url': validator(
		val =>
			isLength(str(val), { min: 4, max: 2083 }) &&
			isURL(val, { allow_underscores: true }),
		i18n.token_url
	),
	formula: val => {
		if (!isExist(createScriptExpression(val))) return i18n.expression_formula;
	},
	script: val => {
		if (!isExist(val)) return i18n.expression_script.empty_script;
		if (!isExist(createScriptExpression(val))) return i18n.expression_formula;
		if (str(val).match(/`/g)) return i18n.expression_script.invalid_script;
	}
};

export default validators;
