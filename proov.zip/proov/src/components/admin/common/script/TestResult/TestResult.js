import React from 'react';
import PropTypes from 'prop-types';
import CopyToClipboard from 'react-copy-to-clipboard';
import cn from 'utils/classNames';
import { isJson } from 'components/admin/common/script/utils';
import CopyIcon from 'components/ui/Icons/CopyIcon';
import * as i18n from 'i18n/en/common.json';
import IconWithTooltip from 'components/ui/Icons/IconWithTooltip';
import css from './TestResult.scss';

function TestResult({ placeholder, error, result, pending, disabled, className }) {
	function renderOutput(result) {
		const { data = [], type = null, meta = null } = result
			? result
			: { result: undefined };

		switch (type) {
			case 'Table':
				return JSON.stringify(data);
			case 'Value':
				if (meta[0].type !== 'number') {
					return isJson(data[0][0])
						? JSON.stringify(JSON.parse(data[0][0]), undefined, 4)
						: data;
				} else {
					return data;
				}
			case 'Vector':
				return JSON.stringify(data[0]);
			default:
				return placeholder;
		}
	}

	const output = renderOutput(result);

	return (

		<div className={cn(css.root, className)}>
			<textarea
				value={pending ? '' : error || output}
				disabled
				className={cn(css.testResult, { [css.error]: error }, { [css.success]: result })}
			/>
			<CopyToClipboard text={pending ? '' : error || output}>
				<span><IconWithTooltip className={css.tooltipWrapper} icon={<CopyIcon className={css.copyIcon} />} textToDisplay={i18n.tooltipText.copyAll} /></span>
			</CopyToClipboard>
		</div>
	);
}

TestResult.propTypes = {
	disabled: PropTypes.oneOfType([PropTypes.bool, PropTypes.func]),
	pending: PropTypes.bool,
	result: PropTypes.object,
	error: PropTypes.string,
	placeholder: PropTypes.string
};

TestResult.defaultProps = {
	disabled: false,
	pending: false,
	result: '',
	error: '',
	placeholder: 'RESULT'
};

export default TestResult;
