import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { modelSelector } from 'ducks/forms/selectors';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import { getParameters } from 'ducks/admin/analytics/customMetric/selectors';
import { Field, FormGroup, Error } from 'components/common/Forms';
import cn from 'utils/classNames';
import { TEMPLATES } from 'constants/templates';
import CodeEditor from 'components/admin/common/script/CodeEditor/CodeEditor';
import css from './style.scss';

class CreateScriptForm extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleLangChange = this.handleLangChange.bind(this);

		let isIE = false; // Internet explorer flag for css hack
		if (
			navigator.userAgent.indexOf('Edge') > -1 ||
			navigator.userAgent.indexOf('Trident/7.0') > -1
		) {
			isIE = true;
		}

		this.state = {
			lng: props.model.expression_type || 0,
			isIE,
			isEnabledChangeTab: props.mode === 'create'
		};
	}

	componentDidMount() {
		this.props.form && this.props.form.clearErrors('script');
	}

	componentDidUpdate() {
		const selectedLanguage = this.props.model.expression_type;
		selectedLanguage && this.setState({ lng: selectedLanguage });
	}

	handleLangChange(lng) {
		if (lng !== this.state.lng) {
			this.props.form && this.props.form.change('expression_type', lng);
			this.setState({ lng });
		}
	}

	render() {
		const languages =
			this.state.isEnabledChangeTab ?
				{ 'javascript': 'JavaScript', 'python': 'Python' } :
				this.props.model.expression_type === 'javascript' ? { 'javascript': 'JavaScript' } : { 'python': 'Python' };

		return (
			<div className={css.scriptForm}>
				<FormGroup className={css.expressionType}>
					<Field name="expression_type" type="hidden" component="input" />
				</FormGroup>
				<div className={css.languages}>
					{Object.keys(languages).map(lng => {
						const active = lng === this.state.lng ? css.active : null;
						return (
							<React.Fragment key={lng}>
								<div
									className={cn(css.lang, active)}
									onClick={e =>
										Object.keys(languages).length > 1
											? this.handleLangChange(e.target.getAttribute('value'))
											: null
									}
									value={lng}
								>
									{languages[lng]} 
								</div>
							</React.Fragment>
						);
					})}
					{this.props.mode === 'edit' && <div className={css.detail}>Go to Draft to edit the Script</div>}
				</div>
				<FormGroup className={css.scriptFormGroup}>
					<Field
						className={css.scriptArea}
						name="script"
						required
						defaultValue=""
						validateOn={['blur', 'change']}
						component={({ input }) => (
							<div className={css.scriptEditorWrapper}>
								{this.props.model.expression_type && (
									<CodeEditor
										lng={this.state.lng}
										onChange={val => {
											if (this.props.mode !== 'edit') {
												this.props.onEditorChange(input, val);
												this.setState({
													...this.state,
													isEnabledChangeTab: Object.values(TEMPLATES).indexOf(val) > -1 && this.props.mode === 'create'
												});
											}
										}}
										value={this.props.value}
										mode={this.props.mode}
										readonly={this.props.mode === 'edit'}
										scriptCodeToInject={this.props.scriptCodeToInject}
										isEvaluationScript={this.props.isEvaluationScript}
										editorClassName={this.props.mode === 'edit' ? 'active' : ''}
									/>
								)}
							</div>
						)}
					/>
					<Error className={css.scriptError} sticky name="script" />
				</FormGroup>
			</div>
		);
	}
}

CreateScriptForm.propTypes = {
	form: PropTypes.object,
	onResetSelection: PropTypes.func,
	onResetItemToDelete: PropTypes.func,
	onEditorChange: PropTypes.func,
	itemsToDelete: PropTypes.string,
	model: PropTypes.object,
	vendors: PropTypes.array,
	onTest: PropTypes.func,
	script: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
	environment: PropTypes.array,
	usedParameters: PropTypes.array,
	value: PropTypes.string,
	scriptCodeToInject: PropTypes.object,
	isEvaluationScript: PropTypes.bool
};

function mapStateToProps(state, props) {
	const { environment, vendors } = getAdminPilot(state);
	return {
		model: modelSelector(state, props.modelName) || {},
		vendors,
		environment,
		usedParameters: getParameters(state).used
	};
}

export default connect(mapStateToProps)(CreateScriptForm);
