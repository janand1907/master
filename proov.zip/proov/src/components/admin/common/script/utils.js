/* eslint-disable arrow-parens */
import * as PARAM_TYPES from 'constants/admin';
import { uniqWith, isEqual } from 'lodash';
import { transformErrorData } from 'utils';

/**
 * @export
 * @param {object} err - error got from server
 * @returns {object} normalized error
 */
export function transformError(err) {
	let newErrorData = transformErrorData(err.errorData);

	if (newErrorData.hasOwnProperty('optional_headers')) {
		newErrorData.httpHeaderKey = newErrorData.optional_headers;
		newErrorData.httpHeaderValue = '';
		delete newErrorData.optional_headers;
	}

	return newErrorData;
}

/**
 * @export
 * @param {array} parameters available parameters to search from
 * @param {string} selectedChannelId - id of the selected channel
 * @param {string} selectedEndPoint - label of the selected Endpoint (if exists)
 * @param {string} searchText the text to filter by
 * @param {string} expressionType - the expression type (formula/script)
 * @returns {array} filtered parameters
 */
export function filterResult(
	parameters,
	selectedChannelId,
	selectedEndPoint,
	searchText,
	expressionType
) {
	const text = searchText.toLowerCase();
	let newParams = parameters.filter((parameter) => {
		if (selectedChannelId === 'Custom') {
			return parameter.param_type === 'custom_param';
		} else if (selectedChannelId === 'Vendor') {
			return parameter.param_type === 'vendor';
		} else if (selectedEndPoint) {
			return (
				parameter.channel_id === selectedChannelId &&
				parameter.endpoint_label === selectedEndPoint
			);
		} else if (selectedChannelId === 'Saas') {
			return parameter.endpoints !== null;
		} else {
			return parameter.channel_id === selectedChannelId;
		}
	});

	return newParams.filter((parameter) => {
		let searchPredicate = false;

		if (expressionType === 'formula') {
			searchPredicate = parameter.name.toLowerCase().indexOf(text) !== -1;
		}

		if (expressionType === 'script') {
			if (selectedChannelId === 'Saas') {
				searchPredicate = parameter.endpoint && parameter.endpoint.toLowerCase().indexOf(text) !== -1;
			} else {

				searchPredicate = parameter.label && parameter.label.toLowerCase().indexOf(text) !== -1 || parameter.name.toLowerCase().indexOf(text) !== -1;
			}
		}

		return searchPredicate;
	});
}

/**
 * @export
 * @param {array} channels channels to transform
 * @returns {object} transformed channels contained with endpoints
 */
export function combineParameters(parameters, vendors) {
	const vendorsParameters = vendors.map((vendor) => ({
		...vendor,
		param_type: 'vendor',
	}));
	return [...parameters, ...vendorsParameters];
}

/**
 * @export
 * @param {array} channels channels to transform
 * @returns {object} transformed channels contained with endpoints
 */
export function transformChannels(channels) {
	return channels.reduce((accum, channel, index) => {
		accum[channel.id] = {
			type: 'channel',
			channelType: channel.type,
			channelId: channel.id,
			id: channel.id,
			name: channel.name,
			cloud_type: channel.cloud_type
		};
		if (channel.type === 'api') {
			channel.endpoints.forEach(
				(ep) =>
				(accum[`${channel.id}_${ep}`] = {
					type: 'endpoint',
					channelType: channel.type,
					channelId: channel.id,
					id: `${channel.id}_${ep}`,
					name: ep
				})
			);
		}
		return accum;
	}, {});
}

/**
 * @export
 * @param {string} allowedChannelId - the allowed channel id to use
 * @param {array} parameters - the parameters to filter from
 * @param {array} environment - the list of environment to filter from
 * @returns {object} object with allowed channels, transfomed by transformChannels helper
 */
export function getAllowedChannels(allowedChannelId, parameters, environment) {
	const allowedParams = allowedChannelId
		? parameters.filter((p) => p.channel_id === allowedChannelId)
		: parameters;
	const filtered = environment.filter((e) =>
		allowedParams.some((p) => p.channel_id === e.id)
	);
	return transformChannels(filtered);
}

/**
 * @export
 * @param {object} model contains fields of form
 * @returns {boolean} whether test is relevant based on fields filled
 */
export function isMetricReadyForCreate(model) {
	const { label, script, formula, expression_type } = model;
	return expression_type === 'formula'
		? !!formula && formula.length > 0 && !!label && label.length > 0
		: !!script && !!label && label.length > 0;
}

/**
 * @export
 * @param {object} model contains fields of form
 * @returns {boolean} whether test is relevant based on fields filled
 */
export function isEvaluationScriptReadyForCreate(model) {
	const { name, script, expression_type } = model;
	return !!script
}

/**
 * @export
 * @param {object} model contains fields of form
 * @returns {boolean} whether test is relevant based on fields filled
 */
export function isDbParamReadyForCreate(model) {
	const { label, locator, auth } = model;
	return (
		locator &&
		Object.keys(locator).filter((v) => !!locator[v]).length === 6 &&
		auth &&
		Object.keys(auth).filter((v) => !!auth[v]).length === 3 &&
		!!label
	);
}

/**
 * @export
 * @param {object} model contains fields of form
 * @returns {boolean} whether test is relevant based on fields filled
 */
export function isApiParamReadyForCreate(model) {
	const { label, locator, auth } = model;
	let apiFilled = locator && !!locator.url;
	let authFilled = false;
	if (auth) {
		switch (auth.type) {
			case 'none':
				authFilled = true;
				break;
			case 'basic':
				authFilled = !!auth.username && !!auth.password;
				break;
			case "bearer":
				authFilled = !!auth.body && !!auth.token_url && !!auth.key;
				break;
			case 'oauth2':
				if (auth.grant_type === 'client_credentials') {
					authFilled =
						!!auth.client_id && !!auth.client_secret && !!auth.token_url;
				} else {
					authFilled =
						!!auth.username &&
						!!auth.password &&
						!!auth.client_id &&
						!!auth.client_secret &&
						!!auth.token_url;
				}
				break;
		}
	}

	return apiFilled && authFilled && !!label && label.length > 0;
}

/**
 * @export
 * @param {array} formula formula expression
 * @param {function} joinFormula formula as string
 */
export function joinFormula(formula) {
	let joinFormula = formula.map((arg) =>
		typeof arg === 'string' ? arg : arg.variable
	);
	return joinFormula.join('');
}

// /**
//  * @export
//  * @param {array} expression expression to extract parameters from
//  * @param {array} usedParameters parameters from editor
//  * @param {string} expressionType type of the expression
//  * @param {function} cleanExpression expression clean from syntax
//  */
export function cleanExpressionFromSyntax(
	expression,
	usedParameters,
	environment
) {
	let cleanExpression = expression;
	let scriptParams = expression.match(/\${(.+?)->(.+?)}/g) || []; // ${channel_name -> param_name}
	if (scriptParams.length) {
		scriptParams.map((scriptParam) => {
			const usedParam = scriptParam.match(/\${(.+?)->(.+?)}/);
			const paramName = usedParam[2];
			const channelName = usedParam[1];

			const arg = usedParameters.find((param) => {
				const channel = environment.find(
					(env) => env.name === channelName && env.status === 'ready'
				);
				const channelId = channel ? channel.id : null;
				const anchor = param.variable.lastIndexOf('_');
				const [variable, id] = [
					param.variable.slice(0, anchor),
					param.variable.slice(anchor + 1, param.variable.length),
				];

				if (channelId === null) {
					return param.id === id && variable === paramName;
				}
				return channelId === id && variable === paramName;
			});
			if (arg) {
				const anchor = arg.variable.lastIndexOf('_');
				const variable = arg.variable.slice(0, anchor);
				if (arg.type === PARAM_TYPES.CUSTOM) {
					cleanExpression = cleanExpression.replace(
						scriptParam,
						`${variable}_${arg.id}`
					);
				} else if (arg.type === PARAM_TYPES.VENDOR) {
					cleanExpression = cleanExpression.replace(scriptParam, `"${arg.id}"`);
				} else {
					cleanExpression = cleanExpression.replace(
						scriptParam,
						`${variable}_${arg.channel_id}`
					);
				}
			}
		});
	}

	return cleanExpression;
}

/**
 * @export
 * @param {array} expressionType type of expression formula/script
 * @param {array} formula parameters used within formula
 * @param {array} script parameters used within script
 * @param {function} usedParameters parameters used within script
 */
export function transformParams(usedParameters) {
	const filteredParameters = usedParameters.filter(
		(item) => typeof item === 'object' && item.type !== 'vendor'
	);
	return uniqWith(filteredParameters, isEqual).map((param) => {
		const { id, variable, type, channel_id = null } = param;
		return {
			id,
			type,
			channel_id,
			variable,
		};
	});
}

/**
 * @export
 * @param {array} matchedParams matched parameters found in the script editor
 * @param {array} parameters available parameters to search from
 * @param {function} onUpdateUsedParams updating the new array of parameters in the store
 */
export function updateUsedParams(
	matchedParams,
	parameters,
	onUpdateUsedParams
) {
	let objArr = matchedParams.reduce((accum, param, matchedParams) => {
		const itemToPush = parameters.filter(
			(p) => p.name === param.name && p.channel_id === param.channel_id
		)[0];
		accum.push(itemToPush);
		return accum;
	}, []);

	onUpdateUsedParams(objArr);
}

/**
 * @export
 * @param {string} script script from editor
 * @param {array} params available parameters to match from
 * @param {array} usedParams already used parameters
 * @param {object} selectedParam if selected by clicking the item in the item explorer, then it will be an object, null elsewhere
 * @returns {array} parameters to update
 */
export function getParamsFromText(script, params, environment, vendors) {
	let scriptParams = [];
	if (script) {
		let matchedParams = script.match(/\${(.+?)->(.+?)}/gm); // ${channel_name -> param_name}
		if (matchedParams && matchedParams.length && params && params.length) {
			scriptParams = matchedParams.map((match) => {
				const usedParam = match.match(/\${(.+?)->(.+?)}/);
				const channelName = usedParam[1];
				const paramName = usedParam[2];
				const channel = environment.find((env) => env.name === channelName);
				const channelId = channel ? channel.id : null;

				const paramDetails = params.find((param) => {
					if (channelName === 'Script Parameters') {
						return param.name === paramName;
					} else if (channelName === 'Vendor List') {
						return param.name === paramName;
					} else {
						return param.name === paramName && param.channel_id === channelId;
					}
				});

				if (paramDetails) {
					const { id, channel_id, name, param_type } = paramDetails;
					return {
						id,
						type: param_type,
						variable: `${name}_${channel_id || id}`,
						channel_id: channel_id || null,
					};
				}
			});
		}
		return scriptParams;
	}
}

/**
 * @export
 * @param {string} script script from editor
 * @param {string} channelId id of the channel
 * @param {array} endpoints endpoints
 * @return {array} parameter to updtae
 */
export function getEndpointsFromText(script, channelId, endpoints, lng) {
	let scriptStr = script;
	let match = [];
	while (scriptStr.match(/endpoint:/) || scriptStr.match(/endpoint":"/)) {
		const matchEndpoint = lng === 'python' ? scriptStr.match(/endpoint":"/) && scriptStr.match(/endpoint":"/).index + 11 : scriptStr.match(/endpoint:/) && scriptStr.match(/endpoint:/).index + 10
		scriptStr = scriptStr.substring(matchEndpoint, scriptStr.length - 1);
		const lastIndex = lng === 'python' ? scriptStr.indexOf('"') : scriptStr.indexOf("'");
		const endpoint = scriptStr.substring(0, lastIndex);

		const selectedEndpoint = endpoints.find(end => end.endpoint === endpoint);
		if (selectedEndpoint) {
			const usedParam = { id: selectedEndpoint.id, channelId: channelId, type: "standard_kpi", variable: `${selectedEndpoint.id}_${channelId}` };
			match = [...match, usedParam];
		}
	}
	return match
}

/**
 * @export
 * @param {string} channelId id of channel to get te name of
 * @param {array} environment array of channels to search from
 * @returns {string} the name of the channel
 */
export function getChannelName(channelId, environment) {
	return channelId
		? environment.filter((ch) => ch.id === channelId)[0].name
		: 'Custom';
}

/**
 * @export
 * @param {array} metrics - metrics to sort by category
 * @returns {array} sorted metrics
 */
export function sortByCategory(metrics) {
	return metrics.sort((a, b) => {
		return a.category.localeCompare(b.category);
	});
}

/**
 * @export
 * @param {string} selectedChannelId - id of the selected channel
 * @param {string} selectedEndPoint - id of the selected endpoint (when endpoint is selected)
 * @returns {string} the channel id of the selected channel
 */
export function getSelectedChannelValue(selectedChannelId, selectedEndPoint) {
	if (selectedEndPoint) return `${selectedChannelId}_${selectedEndPoint}`;
	else if (selectedChannelId) return selectedChannelId;
	else return 'Custom';
}

export function isJson(data) {
	try {
		JSON.parse(data);
	} catch (e) {
		return false;
	}
	return true;
}

/**
 * helper function for transformScriptToFormula
 * @param {string} transformed formula expression
 * @returns {array} transformed formula
 * */
function swapOperatorsPositionRec(transformed) {
	if (transformed.length < 2) {
		return transformed;
	}

	return [transformed[1], transformed[0]].concat(
		swapOperatorsPositionRec(transformed.slice(2))
	);
}

/**
 * @export
 * @param {string} script formula expression
 * @param {array} args the BKPI metric args
 * @returns {string} formula
 */
export function transformScriptToFormula(script, args) {
	let formula = [];
	let transformed = script.trim().replace(/\s/g, '');

	for (let i = 0; i < transformed.length; i++) {
		if (transformed[i].match(/[-+\/*()]/)) {
			formula.push(transformed[i]);
		} else {
			const variable = transformed
				.substring(i, transformed.length)
				.match(/^[^-+\/*()]+/);
			formula.push(variable[0]);
			i += variable[0].length - 1;
		}
	}

	formula = formula.filter((element) => element !== '');

	// injects parameters
	formula = formula.map((el) => {
		// eslint-disable-next-line arrow-parens
		let newEl = args.find((arg) => el === arg.variable);

		if (newEl === undefined) {
			return el;
		}

		return newEl;
	});

	return formula;
}

/**
 * @see http://werxltd.com/wp/2010/05/13/javascript-implementation-of-javas-string-hashcode-method/
 * @param {string} str string to generate hash from
 * @returns {string} hash
 * */
function bitwise(str) {
	let hash = 0;
	if (str.length == 0) return hash;
	for (let i = 0; i < str.length; i++) {
		let ch = str.charCodeAt(i);
		hash = (hash << 5) - hash + ch;
		hash = hash & hash; // Convert to 32bit integer
	}
	return hash;
}

/**
 * convert 10 binary to customized, max is 62
 * @param {integer} integer
 * @param {string} binary
 * @returns {string} customized binary string representation
 * */
function binaryTransfer(integer, binary) {
	binary = binary || 62;
	let stack = [];
	let num;
	let result = '';
	let sign = integer < 0 ? '-' : '';

	function table(num) {
		let t = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		return t[num];
	}

	integer = Math.abs(integer);

	while (integer >= binary) {
		num = integer % binary;
		integer = Math.floor(integer / binary);
		stack.push(table(num));
	}

	if (integer > 0) {
		stack.push(table(integer));
	}

	for (let i = stack.length - 1; i >= 0; i--) {
		result += stack[i];
	}

	return sign + result;
}

/**
 *  why choose 61 binary, because we need the last element char to replace the minus sign
 * eg: -aGtzd will be ZaGtzd
 * @param {string} text to generate hash code from
 * @returns {string} id persistent shortid hash code
 */
export function unique(text) {
	let id = binaryTransfer(bitwise(text), 61).replace('-', 'Z');
	return id;
}
