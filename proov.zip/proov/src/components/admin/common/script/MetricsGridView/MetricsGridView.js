import * as PARAM_TYPES from 'constants/admin';
import React from 'react';
import PropTypes from 'prop-types';
import { GridView } from 'components/ui/GridView';
import { NewSpinner } from 'components/ui/NewSpinner';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import PlusIcon from 'components/ui/Icons/PlusIcon';
import EditIcon from 'components/ui/Icons/EditIcon';
import IconWithTooltip from 'components/ui/Icons/IconWithTooltip';
import * as i18n from 'i18n/en/pilotView.json';
import cn from 'utils/classNames';
import { InfoIcon, TrashIcon } from 'components/ui/Icons';
import { filterResult } from 'components/admin/common/script/utils';
import css from './MetricsGridView.scss';

const paramType = {
	db: 'DB',
	rest: 'REST',
	soap: 'SOAP',
};

class MetricsGridView extends React.Component {
	setGridViewConfig(type) {
		switch (type) {
			case 'Custom':
				return [
					{
						title: '',
						value: (row) => {
							const isDisabed = row.status === "failed";
							return <IconWithTooltip
								className={css.plusIconWrapper}
								icon={<PlusIcon onClick={isDisabed ? null : () => { this.handlePlusIconClick(row) }} className={cn(css.plusIcon, { [css.disableColor]: isDisabed })} />}
								textToDisplay={row.status !== "failed" ? this.props.plusTooltipText : i18n.client.tooltips.editIcon} />
						},
						headerClassName: css.plusIconColumn
					},
					{
						title: 'Name',
						value: ({ name }) => <div title={name}>{name}</div>,
					},
					{
						title: 'Source',
						value: (value) => (
							<div className={css.type}>
								<span>{paramType[value.type]}</span>
							</div>
						),
					},
					{
						title: 'Type',
						value: (value) => {
							const { resp_example, resp_type } = value;
							return (
								<div className={css.type}>
									<span>
										{resp_type === 'value' && resp_example ? resp_example.meta[0].type : resp_type}
									</span>
								</div>
							);
						},
					},
					{
						title: 'Info',
						value: (value) => (
							<TooltipTarget
								tooltip={
									<Tooltip placement="right">
										<span className={css.tooltip}>{i18n.client.kpiDetailes.infoIconTooltip}</span>
									</Tooltip>
								}
							>
								<InfoIcon
									onClick={(e) => {
										e.stopPropagation();
										this.props.handleShowDetails(value);
									}}
									className={css[value.status]}
								/>
							</TooltipTarget>
						),
					},
					{
						value: (value) => {
							const isDisabed = value.status !== 'failed' && !value.related_bkpi_ids.length;
							return value.param_type === PARAM_TYPES.CUSTOM && (
								<TooltipTarget
									tooltip={
										<Tooltip placement="right">
											<span className={css.tooltip}>{isDisabed ? 'TBD' : 'Edit'}</span>
										</Tooltip>
									}
								>
									<EditIcon
										onClick={isDisabed ? null : (e) => { e.stopPropagation(); this.props.handleEditParamClick(value) }}
										className={cn(css.editIcon, { [css.disableColor]: isDisabed })}
									/>
								</TooltipTarget>
							)
						}
					},
					{
						value: (value) => {
							const isDisabed = !value.related_bkpi_ids.length;
							return value.param_type === PARAM_TYPES.CUSTOM && (
								<TooltipTarget
									tooltip={
										<Tooltip placement="right">
											<span className={css.tooltip}>{isDisabed ? 'TBD' : 'Delete'}</span>
										</Tooltip>
									}
								>
									<TrashIcon
										onClick={isDisabed ? null : (e) => {
											e.stopPropagation();
											this.props.handleDelete(value);
										}}
										className={cn(css.deleteIcon, { [css.disableColor]: isDisabed })}
									/>
								</TooltipTarget>
							)
						}
					},
				];
			case 'Vendor':
				return [
					{
						title: '',
						value: (row) => <IconWithTooltip className={css.plusIconWrapper} icon={<PlusIcon onClick={() => { this.handlePlusIconClick(row) }} className={css.plusIcon} />} textToDisplay={this.props.plusTooltipText} />,
						headerClassName: css.plusIconColumn
					},
					{
						title: 'Name',
						value: ({ name }) => <div title={name}>{name}</div>,
					},
					{
						title: 'id',
						value: ({ id }) => <div title={id}>{id}</div>,
					},
				];
			case 'Saas':
				return [
					{
						title: '',
						value: (row) =>
							<IconWithTooltip
								icon={<PlusIcon className={css.plusIcon} onClick={() => { this.props.handleEndpointItemSelected(row) }} />}
								placement="left"
								textToDisplay={this.props.plusTooltipText} />,
						headerClassName: css.plusIconColumn
					},
					{
						title: 'Name',
						value: ({ endpoint }) => <div title={endpoint}>{endpoint}</div>,
					},
					{
						title: 'Info',
						value: (row) => (
							<IconWithTooltip
								className={css.infoWrapper}
								icon={
									<InfoIcon
										className={cn(css.infoIcon, css.saasInfoIcon)}
										onClick={() => this.props.onEndpointInfoClick(row)}
									/>
								}
								placement="left"
								textToDisplay={i18n.client.tooltips.infoIcon} />
						),
					}
				];
			default:
				return [
					{
						title: '',
						value: (row) => <IconWithTooltip className={css.plusIconWrapper} icon={<PlusIcon onClick={() => { this.handlePlusIconClick(row) }} className={css.plusIcon} />} textToDisplay={i18n.client.tooltips.plusIcon} />,
						headerClassName: css.plusIconColumn
					},
					{
						title: 'Name',
						value: ({ name }) => <div title={name}>{name}</div>,
					},
					{
						title: 'Description',
						value: ({ label }) => <div title={label}>{label}</div>,
					},
					{ title: 'Units', value: ({ unit }) => unit },
				];
		}
	}

	handleIsRowClick(row) {
		if (this.props.expressionType === 'formula') {
			return row.resp_type === 'value';
		}

		return true;
	}

	handleRowStyle(row) {
		if (
			row.param_type === PARAM_TYPES.CUSTOM &&
			this.props.expressionType === 'formula'
		) {
			if (
				row.resp_type != 'table' &&
				row.resp_type != 'vector' &&
				row.resp_type != 'value'
			) {
				return cn(css.metric, css.disabled);
			}
		}

		return !row.id ? css.category : css.metric;
	}

	handlePlusIconClick(row) {
		if (row.id) {
			this.props.onSelect(row);
		}
	}

	render() {
		const {
			parameterPending,
			parameters,
			selectedChannelId,
			selectedEndPoint,
			searchText,
			className,
			expressionType,
		} = this.props;

		const filteredParams = filterResult(
			parameters,
			selectedChannelId,
			selectedEndPoint,
			searchText,
			expressionType
		);

		const sortParameters = (collection) => {
			return [...collection.sort((a, b) => a.id.localeCompare(b.id))];
		};

		if (parameterPending) {
			return <NewSpinner size="m" />;
		}

		return parameters.length === 0 ? (
			<p className={css.noParamMessage}>{i18n.client.noParamMessage}</p>
		) : (
			<div className={css.kpiListWrapper}>
				<div className={cn(css.root, className)}>
					<GridView
						data={sortParameters(filteredParams)}
						className={css.gridView}
						config={this.setGridViewConfig(selectedChannelId)}
						isRowClickable={(row) => this.handleIsRowClick(row)}
						rowClassName={(row) => this.handleRowStyle(row)}
					/>
				</div>
			</div>
		);
	}
}

MetricsGridView.propTypes = {
	searchText: PropTypes.string,
	selectedChannelId: PropTypes.string,
	selectedEndPoint: PropTypes.string,
	onSelect: PropTypes.func,
	parameterPending: PropTypes.bool,
	parameters: PropTypes.array,
	className: PropTypes.string,
	handleEdit: PropTypes.func,
	handleDelete: PropTypes.func,
	handleShowDetails: PropTypes.func,
	expressionType: PropTypes.string,
	handleEditParamClick: PropTypes.func
};

export default MetricsGridView;
