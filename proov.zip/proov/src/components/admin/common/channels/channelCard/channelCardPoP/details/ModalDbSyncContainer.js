import { ENTER } from 'constants/keyCodes';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import hljs from 'highlight.js/lib/highlight';
import moment from 'moment';
import {
	getSqlArchive,
	setSqlArchive,
	resetSqlArchive
} from 'ducks/repository/syncArchive/actions';
import {
	getSyncArchivePending,
	getSqlArchivePending,
	getSqlArchiveData,
	getSqlArchiveError,
	getSqlArchiveSuccess
} from 'ducks/repository/syncArchive/selectors';
import { GridView } from 'components/ui/GridView';
import { InfiniteScroll } from 'components/ui/InfiniteScroll';
import { Alert } from 'components/ui/Alert';
import { NewSpinner } from 'components/ui/NewSpinner';
import SearchBar from 'components/ui/SearchBar/SearchBar';
import { getVendors } from 'ducks/admin/pilot/channel/selectors';
import cn from 'utils/classNames';
import css from './modalSync.scss';

//TODO Container + functional component ???

['sql'].forEach(langName => {
	hljs.registerLanguage(langName, require(`highlight.js/lib/languages/${langName}`));
});

moment.updateLocale(moment.locale(), { invalidDate: 'N/A' });

class ModalDbSyncContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleLoadMore = this.handleLoadMore.bind(this);
		this.handleSearch = this.handleSearch.bind(this);
		this.handleChangeSearch = this.handleChangeSearch.bind(this);
		this.handleKeyPress = this.handleKeyPress.bind(this);
		this.handleCheckAll = this.handleCheckAll.bind(this);
		this._configTable = this._configTable.bind(this);

		this.state = {
			checked: null,
			keyword: '',
			skip: 0,
			error: null,
			checkedAll: false,
			success: null
		};
	}

	static getDerivedStateFromProps(nextProps, prevState) {
		if (
			(nextProps.data &&
				prevState.checked &&
				prevState.checked.length !== nextProps.data.length) ||
			(nextProps.data && !prevState.checked) ||
			(nextProps.data && nextProps.error !== prevState.error) ||
			(nextProps.data && nextProps.success !== prevState.success)
		) {
			const allChecked = prevState.checked && prevState.checked.every(el => el === true);
			return {
				checked: nextProps.data.map((_, i) =>
					allChecked ? allChecked : (prevState.checked && prevState.checked[i]) || false
				),
				skip: nextProps.data.length,
				error: nextProps.error,
				success: nextProps.success,
				checkedAll: allChecked
			};
		}

		return null;
	}

	componentDidMount() {
		!this.props.data && this.props.getSqlArchive(this.props.envId, 0, this.state.keyword);
	}

	componentWillUnmount() {
		this.props.resetSqlArchive();
	}

	_configTable() {
		return [
			{
				title: (
					<input
						className="form-control"
						type="checkBox"
						onChange={this.handleCheckAll}
						checked={this.state.checkedAll}
					/>
				),
				value: '',
				format: (_, index) => (
					<React.Fragment>
						<input
							className="form-control"
							type="checkbox"
							data-index={index}
							onChange={this.handleChange}
							checked={this.state.checked && this.state.checked[index]}
						/>
					</React.Fragment>
				)
			},
			{
				title: 'SQL Statement',
				value: ({ query }) => ({ query }),
				format: ({ query }) => (
					<span
						dangerouslySetInnerHTML={{ __html: hljs.highlight('sql', query).value }}
					/>
				)
			},
			{
				title: 'Event time',
				value: ({ timestamp }) => ({ timestamp }), // eslint-disable-line
				format: ({ timestamp }) =>
					moment(timestamp)
						.utc()
						.format('MM/DD/YYYY HH:mm:ss UTC')
			},
			{
				title: 'Vendor',
				value: ({ isv_id }) => ({ isv_id }), // eslint-disable-line
				format: ({ isv_id }) => {
					// eslint-disable-line
					const vendor = this.props.vendors.find(v => v.id === isv_id); // eslint-disable-line
					return vendor ? vendor.name : '';
				}
			}
		];
	}

	handleChange(e) {
		const newChecked = Array.from(this.state.checked);
		newChecked[e.target.dataset.index] = !newChecked[e.target.dataset.index];
		this.setState({
			...this.state,
			checked: newChecked,
			checkedAll: newChecked.every(el => el === true)
		});
	}

	handleSubmit() {
		const data = this.props.data.reduce((acc, cur, index) => {
			if (this.state.checked[index]) {
				acc.push({
					db_user: cur.isv_db_user,
					query: window.btoa(cur.query),
					isv_id: cur.isv_id
				}); // eslint-disable-line
			}
			return acc;
		}, []);

		this.props.setSqlArchive(this.props.envId, data);
	}

	handleLoadMore() {
		this.props.getSqlArchive(this.props.envId, this.state.skip, this.state.keyword);
	}

	handleSearch() {
		this.props.resetSqlArchive();
		this.props.getSqlArchive(this.props.envId, this.state.skip, this.state.keyword, true);
	}

	handleKeyPress(e) {
		if (e.which === ENTER) {
			this.handleSearch();
		}
	}

	handleChangeSearch(keyword) {
		this.setState({ keyword, skip: 0 });
	}

	handleCheckAll(e) {
		const newChecked = Array.from(this.state.checked).map(el => e.target.checked);
		this.setState({
			...this.state,
			checked: newChecked,
			checkedAll: newChecked.every(el => el === true)
		});
	}

	render() {
		const { pendingArchive, pendingCommit, data } = this.props;
		const { error, checked, keyword, success } = this.state;
		const disableButton = !checked || (checked && !checked.some(v => v === true));

		return (
			<div className={css.modal}>
				<div className={css.header}>
					<h2>prooV SafeZone DB ACTIVITY</h2>
				</div>

				<div className={css.content}>
					<SearchBar
						onSearch={this.handleSearch}
						onChange={this.handleChangeSearch}
						onKeyPress={this.handleKeyPress}
						keyword={keyword}
					/>
					{data && (
						<InfiniteScroll
							className={css.listContainer}
							hasNext={true}
							isPending={pendingArchive}
							next={this.handleLoadMore}
						>
							<GridView
								className={css.table}
								config={this._configTable()}
								data={data}
								rowClick={this.handleRowToggle}
							/>
						</InfiniteScroll>
					)}
				</div>
				<div className={cn(css.footer, data ? css.disabled : css.enabled)}>
					{error && (
						<Alert type="error" className={css.error}>
							{error}
						</Alert>
					)}
					{success && (
						<Alert type="success" className={css.success}>
							{success}
						</Alert>
					)}
					{pendingArchive && (
						<div className={css.spinnerWrapper}>
							<NewSpinner size="s" />
							<div className={css.loading}>Loading activity...</div>
						</div>
					)}
					{pendingCommit && (
						<div className={css.spinnerWrapper}>
							<NewSpinner size="s" />
							<div className={css.loading}>Commit activity...</div>
						</div>
					)}
					<button
						type="button"
						onClick={this.handleSubmit}
						className={css.btnCreate}
						disabled={pendingArchive || disableButton}
					>
						COMMIT TO CUSTOMER ENVIRONMENT
					</button>
				</div>
			</div>
		);
	}
}

ModalDbSyncContainer.propTypes = {
	type: PropTypes.string.isRequired, // channelType
	envId: PropTypes.string.isRequired,
	pendingArchive: PropTypes.bool.isRequired,
	data: PropTypes.array,
	error: PropTypes.string,
	success: PropTypes.string,
	vendors: PropTypes.array.isRequired,
	pendingCommit: PropTypes.bool,
	getSqlArchive: PropTypes.func.isRequired,
	setSqlArchive: PropTypes.func.isRequired,
	resetSqlArchive: PropTypes.func.isRequired
};

function mapStateToProps(state) {
	return {
		pendingCommit: getSqlArchivePending(state),
		pendingArchive: getSyncArchivePending(state),
		data: getSqlArchiveData(state),
		vendors: getVendors(state),
		error: getSqlArchiveError(state),
		success: getSqlArchiveSuccess(state)
	};
}

export default connect(
	mapStateToProps,
	{ getSqlArchive, setSqlArchive, resetSqlArchive }
)(ModalDbSyncContainer);
