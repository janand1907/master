import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import Lookup from 'components/common/Lookups/Lookup';
import ChannelStatus from '../../../ChannelStatus/ChannelStatus';
import style from './style.scss';
import * as i18n from 'i18n/en/channelCard.json';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';
const DISTRIBUTIONS = {
	windows: {
		win_2012: 'Windows 2012 Server',
		win_2016: 'Windows 2016 Server',
		win_2019: 'Windows 2019 Server'
	},
	linux: { ubuntu: 'Ubuntu Server 20.04 LTS', redhat: 'Red Hat Enterprise Linux 8', amazon: 'Amazon Linux 2 AMI' }
};

const Server = ({
	customer,
	aws_instance,
	ip_address,
	os,
	os_dist,
	username,
	password,
	port,
	password_file,
	password_file_name,
	is_user_owned,
	status,
	bm,
	is_assingning_credentials,
	credentials,
	cloud_type
}) => {
	const ServerCredentials = password
		? { Password: password }
		: { PEM: { label: password_file_name, href: password_file } };

	// Add bm related fields in case bm is enabled
	const bmFields =
		bm && bm.enabled
			? {
				'Behavior mirroring': 'Enabled',
				'Original host': bm.original_ips,
				'Pcap File': (
					<Link to="/repository/my-pcaps" className={style.enabled}>
						<span title={bm.file_name || bm.file_id}>{bm.file_name || bm.file_id}</span>
					</Link>
				)
			}
			: null;

	const base = {
		...(cloud_type) && {'Cloud-based':CLOUD_TYPE_TO_ICON[cloud_type].label},
		IP: ip_address,
		Port: port,
		Username:username,
		...ServerCredentials,
		...bmFields
	};

	// Add Instance field in case of proov environment
	const fields = is_user_owned
		? base
		: {
			Distribution: os && <div>{DISTRIBUTIONS[os][os_dist]}</div>,
			Instance: <Lookup lookupType="aws_instance_type" lookupKey={aws_instance} cloudType={cloud_type!== 'AWS' && cloud_type} lookupKeyWithCloudType={true}/>,
			...base
		};

	const assignedCredentials =
		is_assingning_credentials && credentials && credentials.length !== 0 ? credentials : null;

	return (
		<dl className={style.terms}>
			{customer &&
				customer.name && (
					<p className={style.dFlex}>
						<ChannelStatus className={style.channelStatus} status={status} removeText={true} /><strong>{customer.name}</strong>
					</p>
				)}
			{Object.keys(fields).map((item, index) => {
				return (
					<div key={index}>
						<dt className={style.title}>{item}&#32;</dt>
						<dd className={style.label}>
							{is_user_owned || status !== CHANNEL_STATUS.IN_PROGRESS.value ? item === 'PEM' ? (
								<a href={password_file} title={password_file_name} target="_blank">
									Download
								</a>
							) : (
								fields[item]
							) : (
								<span className={style.inProgress}>
									{item === 'Instance' || item === 'Distribution' || item === 'Cloud-based' ? fields[item] :
										<span className={style.inProgress}>{i18n.status.inProgress}</span>
									}

								</span>
							)}
						</dd>
					</div>
				);
			})}

			<br />

			{status === CHANNEL_STATUS.READY.value &&
				assignedCredentials && (
					<div className={style.credentials}>
						<div className={style.assignedCredentials}>ASSIGNED CREDENTIALS</div>
						<div className={style.credentialsRow}>
							<div className={style.credentialField}>Username</div>
							{password ? (
								<div className={style.credentialField}>Password</div>
							) : (
								<div className={style.credentialField}>PEM File</div>
							)}
							<div className={style.credentialField}>Assignee</div>
						</div>

						{assignedCredentials.map((item, index) => {
							return (
								<div className={style.credentialsRow} key={index}>
									<React.Fragment>
										<div className={style.credentialField} title={item.username}>
											{item.username ? item.username : ''}
										</div>
									</React.Fragment>
									{password ? (
										<React.Fragment>
											<div className={style.credentialField} title={item.password}>
												{item.password ? item.password : ''}
											</div>
										</React.Fragment>
									) : (
										<React.Fragment>
											<div className={style.credentialField} title={item.password_file_name}>
												{item.password_file_name ? item.password_file_name : ''}
											</div>
										</React.Fragment>
									)}
									<React.Fragment>
										<div className={style.credentialField} title={item.assignee}>
											{item.assignee ? item.assignee : ''}
										</div>
									</React.Fragment>
								</div>
							);
						})}
					</div>
				)}
		</dl>
	);
};

export default Server;

Server.propTypes = {
	aws_instance: PropTypes.string,
	is_user_owned: PropTypes.bool,
	ip_address: PropTypes.string,
	username: PropTypes.string,
	password: PropTypes.string,
	password_file: PropTypes.string,
	password_file_name: PropTypes.string,
	is_assingning_credentials: PropTypes.bool,
	port: PropTypes.number,
	status: PropTypes.oneOf([
		CHANNEL_STATUS.DELETED.value,
		CHANNEL_STATUS.READY.value,
		CHANNEL_STATUS.IN_PROGRESS.value,
		CHANNEL_STATUS.DEPLOYING_DATASET.value,
		CHANNEL_STATUS.FAILED.value
	]),
	file: PropTypes.string,
	credentials: PropTypes.array
};
