/* eslint-disable no-nested-ternary */
/* eslint-disable complexity */
/* eslint-disable camelcase */
import * as DATABASE_TYPE from 'constants/channel/databaseType';
import * as PILOT_STATUS from 'constants/pilotStatus';
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import cx from 'utils/classNames';
import Permission from 'components/Permission';
import ChannelStatus from '../../../ChannelStatus/ChannelStatus';
import DatabaseActions from '../DatabaseActions';
import style from './style.scss';

const Database = ({
	status,
	safe_zone,
	user_owned,
	bm,
	username,
	password,
	pilotStatus,
	db_type,
	db_name,
	dataset,
	onOpenModal,
	credentials,
	is_assingning_credentials,
	openSyncModal,
}) => {
	const assignedCredentials =
		is_assingning_credentials && credentials && credentials.length !== 0
			? credentials
			: null;

	const isDeployable =
		(pilotStatus === PILOT_STATUS.ACTIVE ||
			pilotStatus === PILOT_STATUS.JOINING ||
			pilotStatus === PILOT_STATUS.PREPARATION ||
			pilotStatus === PILOT_STATUS.EXECUTION ||
			pilotStatus === PILOT_STATUS.EVALUATION) &&
		status === CHANNEL_STATUS.READY.value &&
		(db_type === DATABASE_TYPE.MYSQL || db_type === DATABASE_TYPE.POSTGRES);

	const isPopActive = safe_zone && safe_zone.active;
	const isUserOwnedActive = user_owned && user_owned.active;

	const isInProgress = () => {
		return status === CHANNEL_STATUS.IN_PROGRESS.value;
	};

	const isReady = () => {
		return status === CHANNEL_STATUS.READY.value;
	};

	return (
		<React.Fragment>
			<div key="user_details_scheme_id" className={style.popContainer}>
				<div
					className={cx(
						style.type,
						isPopActive ? style.active : style.disabled
					)}
				>
					<h3>prooV SafeZone</h3>
					{isPopActive && <ChannelStatus status={status} />}

					{bm && bm.enabled && (
						<div>
							<ChannelStatus bmStatus={bm.status} />
						</div>
					)}

					<div className={style.content}>
						<dl className={style.dl}>
							<dt className={style.title}>DB Name&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? db_name
											? db_name
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? db_name
										? db_name
										: 'Not set yet'
									: 'In Progress'}
							</dd>
							<dt className={style.title}>IP&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? safe_zone && safe_zone.ip_address
											? safe_zone.ip_address
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? safe_zone && safe_zone.ip_address
										? safe_zone.ip_address
										: 'Not set yet'
									: 'In Progress'}
							</dd>
							<dt className={style.title}>Port&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? safe_zone && safe_zone.port
											? safe_zone.port
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? safe_zone && safe_zone.port
										? safe_zone.port
										: 'Not set yet'
									: 'In Progress'}
							</dd>

							<dt className={style.title}>Username&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? username
											? username
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? username
										? username
										: 'Not set yet'
									: 'In Progress'}
							</dd>

							<dt className={style.title}>Password&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? password
											? password
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? password
										? password
										: 'Not set yet'
									: 'In Progress'}
							</dd>
						</dl>

						<div className={style.buttons}>
							<DatabaseActions
								is_user_owned={user_owned}
								dataset={dataset}
								isDeployable={isDeployable}
								openModal={onOpenModal}
							/>
							<Permission
								alias="SyncDataSet"
								component={
									<button
										disabled={
											!isPopActive ||
											!isReady() ||
											!(user_owned && user_owned.ip_address)
										}
										type="button"
										className={style.syncBtn}
										onClick={openSyncModal}
									>
										Sync
									</button>
								}
							/>
						</div>
					</div>
				</div>

				<div
					className={cx(
						style.type,
						isPopActive ? style.disabled : style.active
					)}
				>
					<h3>Customer Environment</h3>

					{isUserOwnedActive && <ChannelStatus status={status} />}

					{bm && bm.enabled && (
						<div>
							<ChannelStatus bmStatus={bm.status} />
						</div>
					)}

					<div className={style.content}>
						<dl className={cx(style.dl, style.userOwnedDl)}>
							<dt className={style.title}>DB Name&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? db_name
											? db_name
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? db_name
										? db_name
										: 'Not set yet'
									: 'In Progress'}
							</dd>
							<dt className={style.title}>IP&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? user_owned && user_owned.ip_address
											? user_owned.ip_address
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? user_owned && user_owned.ip_address
										? user_owned.ip_address
										: 'Not set yet'
									: 'In Progress'}
							</dd>
							<dt className={style.title}>Port&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? user_owned && user_owned.port
											? user_owned.port
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? user_owned && user_owned.port
										? user_owned.port
										: 'Not set yet'
									: 'In Progress'}
							</dd>

							<dt className={style.title}>Username&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? username
											? username
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? username
										? username
										: 'Not set yet'
									: 'In Progress'}
							</dd>

							<dt className={style.title}>Password&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? password
											? password
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? password
										? password
										: 'Not set yet'
									: 'In Progress'}
							</dd>
						</dl>
					</div>
				</div>
			</div>

			{status === CHANNEL_STATUS.READY.value && assignedCredentials && (
				<div className={style.credentials}>
					<div className={style.assignedCredentials}>ASSIGNED CREDENTIALS</div>
					<div className={style.credentialsRow}>
						<div className={style.credentialField}>Username</div>
						<div className={style.credentialField}>Password</div>
						<div className={style.credentialField}>Assignee</div>
					</div>

					{assignedCredentials.map((item, index) => {
						return (
							<div className={style.credentialsRow} key={index}>
								<React.Fragment>
									<div className={style.credentialField} title={item.username}>
										{item.username ? item.username : ''}
									</div>
								</React.Fragment>
								<React.Fragment>
									<div className={style.credentialField} title={item.password}>
										{item.password ? item.password : ''}
									</div>
								</React.Fragment>
								<React.Fragment>
									<div className={style.credentialField} title={item.assignee}>
										{item.assignee ? item.assignee : ''}
									</div>
								</React.Fragment>
							</div>
						);
					})}
				</div>
			)}
		</React.Fragment>
	);
};

export default Database;

Database.propTypes = {
	safe_zone: PropTypes.object,
	user_owned: PropTypes.object,
	status: PropTypes.string,
	active: PropTypes.string,
};
