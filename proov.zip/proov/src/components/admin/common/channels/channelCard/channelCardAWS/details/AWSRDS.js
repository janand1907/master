import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import style from './style.scss';

const AWSRDS = ({ data, display }) => {
	const fields = {
		...pick(data, [
			'name',
			'url',
			'security_groups',
			'arn',
			'vpc_id',
			'subnet_id',
			'port',
			'username',
			'password',
			'engine',
			'db_name',
			'instance_type'
		])
	};

	return Object.keys(fields).map(key => {
		return (
			<React.Fragment key={key}>
				<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
				<dd className={style.label}>
					{fields[key] && typeof fields[key] !== 'object' && fields[key].toString()}
					{fields[key] && typeof fields[key] === 'object' && display(fields[key])}
				</dd>
			</React.Fragment>
		);
	});
};

export default AWSRDS;

AWSRDS.propTypes = {
	data: PropTypes.object
};
