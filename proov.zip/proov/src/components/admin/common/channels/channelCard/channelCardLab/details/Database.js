/*eslint camelcase: 0*/
import * as DB_TYPE from 'constants/channel/databaseType';
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import * as i18n from 'i18n/en/channelCard.json';
import style from './style.scss';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';

const Database = ({
	ip_address,
	port,
	db_name,
	status,
	is_user_owned,
	db_type,
	auth_db,
	db_version,
	username,
	password,
	credentials,
	credentials_file,
	credentials_file_name,
	is_assingning_credentials,
	cloud_type
}) => {
	let fields = {};
	// DB details list cater for following sceniros:
	// redshift type: DB name, JDBC, username, password
	// bigquery type: projectId, credentials
	// all other types: DB name, host, port, username, password

	if (db_type === DB_TYPE.REDSHIFT) {
		fields = {
			[i18n.Database.fields.db_name]: db_name,
			...(cloud_type) && { [i18n.Database.fields.cloud_type]:  CLOUD_TYPE_TO_ICON[cloud_type].label },
			[i18n.Database.fields
				.jdbc_url]: `jdbc:redshift:${ip_address}:${port}/${db_name}`,
			[i18n.Database.fields.username]: username,
			[i18n.Database.fields.password]: password,
		};
	} else if (db_type === DB_TYPE.BIGQUERY) {
		fields = {
			[i18n.Database.fields.project_id]: db_name,
			...(cloud_type) && { [i18n.Database.fields.cloud_type]:  CLOUD_TYPE_TO_ICON[cloud_type].label },
			[i18n.Database.fields.credentials]: {
				credentials_file_name,
				credentials_file,
			},
		};
	} else {
		fields = {
			[i18n.Database.fields.db_name]: db_name,
			...(!is_user_owned) && { [i18n.Database.fields.db_version]: db_version },
			...(cloud_type) && { [i18n.Database.fields.cloud_type]:  CLOUD_TYPE_TO_ICON[cloud_type].label },
			[i18n.Database.fields.ip]: ip_address,
			[i18n.Database.fields.port]: port,
			[i18n.Database.fields.username]: username,
			[i18n.Database.fields.password]: password,
		};


		if (is_user_owned && db_type === 'mongodb') {
			fields[i18n.Database.fields.auth_db] = auth_db;
		}
	}

	const assignedCredentials =
		is_assingning_credentials && credentials && credentials.length !== 0
			? credentials
			: null;

	return (
		<dl className={style.terms}>
			{Object.keys(fields).map((item, index) => {
				return (
					<div key={index} className={style.group}>
						<dt className={style.title}>{item}&#32;</dt>
						<dd className={style.label}>
							{
								is_user_owned ||
									status !== CHANNEL_STATUS.IN_PROGRESS.value ||
									status === CHANNEL_STATUS.DEPLOYING_DATASET.value ? (
									fields[item] && typeof fields[item] === 'object' ? (
										<a href={fields[item].credentials_file} target="_blank">
											{fields[item].credentials_file_name}
										</a>
									) : (
										fields[item]
									)
								) : (
									<span className={style.inProgress}>
										{item === i18n.Database.fields.db_version || item === i18n.Database.fields.db_name || item === i18n.Database.fields.cloud_type ? fields[item] :
											<span className={style.inProgress}>{i18n.status.inProgress}</span>
										}

									</span>
								)}


						</dd>
					</div>
				);
			})}
			<br />

			{status === CHANNEL_STATUS.READY.value && assignedCredentials && (
				<div className={style.credentials}>
					<div className={style.credentialsRow}>
						<div className={style.assignedCredentials}>
							{' '}
							ASSIGNED CREDENTIALS
						</div>
						<div className={style.credentialField}>Username</div>
						<div className={style.credentialField}>Password</div>
						<div className={style.credentialField}>Assignee</div>
					</div>
					{assignedCredentials.map((item, index) => {
						return (
							<div className={style.credentialsRow} key={index}>
								<React.Fragment>
									<div className={style.credentialField} title={item.username}>
										{item.username ? item.username : ''}
									</div>
								</React.Fragment>
								<React.Fragment>
									<div className={style.credentialField} title={item.password}>
										{item.password ? item.password : ''}
									</div>
								</React.Fragment>
								<React.Fragment>
									<div className={style.credentialField} title={item.assignee}>
										{item.assignee ? item.assignee : ''}
									</div>
								</React.Fragment>
							</div>
						);
					})}
				</div>
			)}
		</dl>
	);
};

export default Database;

Database.propTypes = {
	is_user_owned: PropTypes.bool,
	ip_address: PropTypes.string,
	port: PropTypes.number,
	db_name: PropTypes.string,
	db_type: PropTypes.string,
	username: PropTypes.string,
	password: PropTypes.string,
	credentials_file: PropTypes.string,
	credentials_file_name: PropTypes.string,
	status: PropTypes.oneOf([
		CHANNEL_STATUS.READY.value,
		CHANNEL_STATUS.IN_PROGRESS.value,
		CHANNEL_STATUS.DEPLOYING_DATASET.value,
		CHANNEL_STATUS.FAILED.value,
	]),
	credentials: PropTypes.array,
};
