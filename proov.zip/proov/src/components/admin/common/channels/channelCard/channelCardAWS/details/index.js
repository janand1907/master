import AWSDynamoDB from './AWSDynamoDB';
import AWSSQS from './AWSSQS';
import AWSEC2 from './AWSEC2';
import AWSLambda from './AWSLambda';
import AWSRDS from './AWSRDS';
import AWSS3Bucket from './AWSS3Bucket';
import AWSSNS from './AWSSNS';
import AWSEMR from './AWSEMR';

export { AWSDynamoDB, AWSSQS, AWSEC2, AWSLambda, AWSRDS, AWSS3Bucket, AWSSNS, AWSEMR };
