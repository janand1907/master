import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import EditIcon from 'components/ui/Icons/EditIcon';
import cx from 'utils/classNames';
import style from './DetailsWrapper.scss';
import { Database, Server, API } from './';

const channelTypeComponent = {
	'server': Server,
	'db': Database,
	'api': API,
};

const DetailsWrapper = ({ data, isVisible, onOpenModal, pilotStatus, editChannel, openSyncModal }) => {
	// map channel type to channel component
	const ChannelComp = channelTypeComponent[data.type];
	const isShowEditBtn = (data.status === CHANNEL_STATUS.READY.value || data.status === CHANNEL_STATUS.FAILED.value) && (data.type !== 'db' && data.type !== 'api');

	return (
		<div className={cx(data.type !== 'db' && data.type !== 'api' && style.layout, { [style.hide]: !isVisible })}>

			{
				isShowEditBtn &&
				<span key={'edit' + data.id} className={style.edit} onClick={() => editChannel(data)}>
					<EditIcon className={style.editIcon} /> Edit
					 </span>
			}

			<ChannelComp {...data} onOpenModal={onOpenModal} openSyncModal={openSyncModal} pilotStatus={pilotStatus} />
		</div>
	);
};

DetailsWrapper.propTypes = {
	data: PropTypes.object.isRequired,
	editChannel: PropTypes.func,
	onOpenModal: PropTypes.func,
	isVisible: PropTypes.bool,
	pilotStatus: PropTypes.string,
	openSyncModal: PropTypes.func
};

export default DetailsWrapper;
