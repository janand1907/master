import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import cx from 'utils/classNames';
import style from './DetailsWrapper.scss';
import {
	AWSDynamoDB,
	AWSSQS,
	AWSEC2,
	AWSLambda,
	AWSRDS,
	AWSS3Bucket,
	AWSSNS,
	AWSEMR
} from './';

const channelTypeComponent = {
	aws_dynamo_db: AWSDynamoDB,
	aws_sqs: AWSSQS,
	aws_ec2: AWSEC2,
	aws_lambda: AWSLambda,
	aws_rds: AWSRDS,
	aws_s3: AWSS3Bucket,
	aws_sns: AWSSNS,
	aws_emr: AWSEMR
};
const DetailsWrapper = ({ data, isVisible }) => {
	const ChannelComp = channelTypeComponent[data.type];
	function displayJSON(data) {
		return <pre className={style.json}>{JSON.stringify(data, undefined, 4)}</pre>;
	}
	return (
		<div className={cx(style.layout, { [style.hide]: !isVisible })}>
			{(data.status === CHANNEL_STATUS.READY.value ||
				data.status === CHANNEL_STATUS.FAILED.value) && (
				<ChannelComp data={data} display={displayJSON} />
			)}
		</div>
	);
};

export default DetailsWrapper;

DetailsWrapper.propTypes = {
	data: PropTypes.object.isRequired,
	isVisible: PropTypes.bool
};
