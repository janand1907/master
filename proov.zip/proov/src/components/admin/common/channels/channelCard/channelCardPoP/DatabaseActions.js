import * as DEPLOYMENT_STATUS from 'constants/dataset/deploymentStatus';
import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { NewSpinner } from 'components/ui/NewSpinner';
import { getDatasets } from 'ducks/repository/deepMirroring/selectors';
import EditIcon from 'components/ui/Icons/EditIcon';
import WarningIcon from 'components/ui/Icons/WarningIcon';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import * as i18n from 'i18n/en/channelCard.json';
import Permission from 'components/Permission';
import style from './DatasetActions.scss';

const DatabaseActions = ({
	is_user_owned,
	dataset,
	isDeployable,
	openModal,
	isPending,
}) => {
	if (dataset) {
		const isDeployed = dataset.deployment_status !== DEPLOYMENT_STATUS.FAIL;

		return (
			<div className={style.dataset}>
				{isDeployed ? (
					<Link to="/repository/my-datasets" className={style.enabled}>
						<span title={dataset.name}>{dataset.name}</span>
					</Link>
				) : (
					<span className={style.error}>
						<TooltipTarget
							tooltip={
								<Tooltip className={style.tooltipMargin} placement="top">
									{i18n.Tooltip.deploymentFailed}
								</Tooltip>
							}
						>
							<WarningIcon className={style.warningIcon} />
						</TooltipTarget>
						<span className={style.disabled}>{dataset.name}</span>
					</span>
				)}
				{isDeployable && !is_user_owned && (
					<Permission
						alias="EditDataSet"
						component={
							<EditIcon className={style.editIcon} onClick={openModal} />
						}
					/>
				)}
			</div>
		);
	} else {
		return (
			!is_user_owned && (
				<Permission
					alias="AddDataSet"
					component={
						<button
							type="button"
							className={style.datasetBtn}
							disabled={!isDeployable && !is_user_owned}
							onClick={openModal}
						>
							{!isPending ? '+ Add Dataset' : <NewSpinner />}
						</button>
					}
				/>
			)
		);
	}
};

function mapStateToProps(state) {
	return {
		/* Q. Why we need pending from datasets here?
		   A. To avoid scenario when user tried to add dataset to DB channel,
		      But the list of datasets is being fetched, pending = true.
		*/
		isPending: getDatasets(state).pending,
	};
}

export default connect(mapStateToProps)(DatabaseActions);

DatabaseActions.propTypes = {
	is_user_owned: PropTypes.bool,
	dataset: PropTypes.object,
	isDeployable: PropTypes.bool,
	openModal: PropTypes.func,
	isPending: PropTypes.bool,
};
