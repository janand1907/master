import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import style from './style.scss';

const AWSS3Bucket = ({ data, display }) => {
	const fields = {
		...pick(data, ['id', 'name', 'arn', 'is_public', 'credentials']),
	};

	return Object.keys(fields).map((key) => {
		const isString = fields[key] && typeof fields[key] !== 'object';
		return (
			<React.Fragment key={key}>
				<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
				<dd className={style.label}>
					{isString ? fields[key] : display(fields[key])}
				</dd>
			</React.Fragment>
		);
	});
};

export default AWSS3Bucket;

AWSS3Bucket.propTypes = {
	data: PropTypes.object,
};
