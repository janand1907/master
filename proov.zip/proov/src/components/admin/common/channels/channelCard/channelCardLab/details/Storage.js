import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import style from './style.scss';
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';

const Storage = ({
	status,
	is_user_owned,
	aws,
	azure,
	gcp,
	ip_address,
	username,
	password,
	port,
	cloud_type
}) => {

	let storageFields = {};
	let urlDetails = {
		'Cloud-based': cloud_type && CLOUD_TYPE_TO_ICON[cloud_type].label,
		'IP': 'sftp://' + ip_address,
		'Port': port,
		'Username': username,
		'Password': password,
	};

	if (is_user_owned) {
		let cloudDetails;
		if (aws) {
			cloudDetails = {
				'AWS Access Key': aws.access_key,
				'AWS Region': aws.region,
				'AWS Path': aws.bucket_path
			};
		}
		else if (azure) {
			cloudDetails = {
				'Azure Account Key': azure.account_key,
				'Azure Account Name': azure.account_name,
				'Azure Continer Name': azure.container_name
			};
		}
		else if (gcp) {
			cloudDetails = {
				'Bucket Name': gcp.bucket_name,
				'JSON Url': gcp.title,
			};
		}


		storageFields = { ...urlDetails, ...cloudDetails };
	} else {
		storageFields = { ...urlDetails };
	}

	const scheme = [
		(Object.keys(storageFields).length > 0 &&
			<div key="user_details_scheme_id" className={style.dlData}>
				{Object.keys(storageFields).map((item, index) => {
					return (
						<div key={index}>
							<dt className={style.title}>{item}&#32;</dt>
							<dd className={style.label}>
								{status === CHANNEL_STATUS.IN_PROGRESS.value && item !== 'Cloud-based' ?
									<span>In Progress</span>
									: item === 'JSON Url' ?
										<a href={gcp.url}>
											{gcp.title}
										</a>
										: storageFields[item]}{'\r'}
							</dd>
						</div>);
				})}
			</div>),

	];

	return (
		<dl>{scheme}</dl>
	);
};

export default Storage;

Storage.propTypes = {
	status: PropTypes.string,
	is_user_owned: PropTypes.bool,
	aws: PropTypes.object,
	ip_address: PropTypes.string,
	username: PropTypes.string,
	password: PropTypes.string,
	port: PropTypes.number
};
