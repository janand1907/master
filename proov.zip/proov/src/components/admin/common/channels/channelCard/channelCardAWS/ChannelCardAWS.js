import * as PILOT_STATUS from 'constants/pilotStatus';
import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { ChevronSmallIcon } from 'components/ui/Icons';
import cx from 'utils/classNames';
import Permission from 'components/Permission';
import { showModal } from 'ducks/modal/actions';
import IconWrapper from '../../icons/IconWrapper';
import ChannelStatus from '../../ChannelStatus/ChannelStatus';
import DetailsWrapper from './details/DetailsWrapper';
import style from './ChannelCardAWS.scss';

function ChannelCardAWS({ data, pilotStatus, edit, showModal }) {
	const [isCollapsed, setIsCollapsed] = React.useState(false);

	function editChannel(environment) {
		edit(environment);
	}

	function openDeployModal() {
		showModal('DeployTemplate');
	}

	function toggle() {
		setIsCollapsed(!isCollapsed);
	}

	function renderDetailsWrapper(data) {
		return (
			<DetailsWrapper
				data={data}
				isVisible={isCollapsed}
				pilotStatus={pilotStatus}
			/>
		);
	}

	return (
		<div className={style.outline}>
			<div className={style.header}>
				<div className={style.headerBadge}>
					<IconWrapper {...data} />
				</div>
				<div className={style.headerInfo}>
					<h3>{data.name}</h3>
					<div className={style.channelProp}>
						<ChannelStatus {...data} />
					</div>
				</div>
				{data && (
					<Permission
						alias="ChevronSmallIcon"
						component={
							<div id="toggle" className={style.headerColl} onClick={toggle}>
								<ChevronSmallIcon
									className={cx(style.chevronIcon, {
										[style.chevronIconDown]: isCollapsed,
									})}
								/>
							</div>
						}
					/>
				)}
			</div>

			{renderDetailsWrapper(data)}
		</div>
	);
}

export default connect(null, { showModal })(ChannelCardAWS);

ChannelCardAWS.propTypes = {
	data: PropTypes.object,
	pilotStatus: PropTypes.oneOf([
		PILOT_STATUS.ACTIVE,
		PILOT_STATUS.COMPLETED,
		PILOT_STATUS.FUTURE,
		PILOT_STATUS.PREPARATION,
		PILOT_STATUS.EXECUTION,
		PILOT_STATUS.CONFIGURATION,
		PILOT_STATUS.DEPLOYMENT,
		PILOT_STATUS.EVALUATION,
		PILOT_STATUS.JOINING,
	]),
	edit: PropTypes.func,
	showModal: PropTypes.func,
	actions: PropTypes.object,
	isEditable: PropTypes.bool,
};

ChannelCardAWS.defaultProps = {
	isEditable: true, // channel cards on the last step of pilot wizard are not editable
};
