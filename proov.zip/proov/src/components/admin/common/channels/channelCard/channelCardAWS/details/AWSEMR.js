import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import style from './style.scss';

const AWSEMR = ({ data, display }) => {
	const fields = {
		...pick(data, [
			'id',
			'name',
			'applications',
			'subnet_id',
			'emr_version',
			'arn',
			'cluster_id',
			'password_file_name',
			'password_file',
			'credentials'
		])
	};

	return Object.keys(fields).map(key => {
		if (key === 'password_file') {
			return (
				<React.Fragment key={key}>
					<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
					<dd className={style.label}>
						<a href={fields[key]} title={fields[key]}>
							Download
						</a>
					</dd>
				</React.Fragment>
			);
		}
		if (key === 'password_file_name') {
			return (
				<React.Fragment key={key}>
					<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
					<dd className={style.label}>{fields[key]}</dd>
				</React.Fragment>
			);
		}

		return (
			<React.Fragment key={key}>
				<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
				<dd className={style.label}>
					{fields[key] && typeof fields[key] !== 'object' && fields[key].toString()}
					{fields[key] && typeof fields[key] === 'object' && display(fields[key])}
				</dd>
			</React.Fragment>
		);
	});
};

export default AWSEMR;

AWSEMR.propTypes = {
	data: PropTypes.object
};
