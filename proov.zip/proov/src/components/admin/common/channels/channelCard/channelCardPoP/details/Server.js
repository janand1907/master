/* eslint-disable camelcase */
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import ChannelStatus from '../../../ChannelStatus/ChannelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import style from './style.scss';

const Server = ({
	customer,
	ip_address,
	username,
	password,
	port,
	password_file,
	password_file_name,
	is_user_owned,
	status,
	bm,
	is_assingning_credentials,
	credentials
}) => {
	const ServerCredentials = password
		? { Password: password }
		: { PEM: { label: password_file_name, href: password_file } };

	// Add bm related fields in case bm is enabled
	const bmFields =
		bm && bm.enabled
			? {
				'Behavior mirroring': 'Enabled',
				'Original host': bm.original_ips,
				'Pcap File': (
					<Link to="/repository/my-pcaps" className={style.enabled}>
						<span title={bm.file_name || bm.file_id}>{bm.file_name || bm.file_id}</span>
					</Link>
				)
			  }
			: null;

	const base = {
		IP: ip_address,
		Port: port,
		Username: username,
		...ServerCredentials,
		...bmFields
	};

	// Add Instance field in case of proov environment
	const fields = base;

	const assignedCredentials =
		is_assingning_credentials && credentials && credentials.length !== 0
			? credentials
			: null;
	return (
		<dl className={style.terms}>
			{customer && customer.name && (
				<p className={style.dFlex}>
				<strong>{customer.name}</strong><ChannelStatus className={style.channelStatus} status={status} removeText={true} />
			</p>
			)}
			{Object.keys(fields).map((item, index) => {
				return (
					<div key={index}>
						<dt className={style.title}>{item}&#32;</dt>
						<dd className={style.label}>
							{is_user_owned || status === CHANNEL_STATUS.READY.value ? (
								item === 'PEM' ? (
									<a href={password_file} title={password_file_name} target="_blank">
										Download
									</a>
								) : (
									fields[item]
								)
							) : (
								<span className={style.inProgress}>
									{item === 'Instance'
										? fields[item]
										: status === CHANNEL_STATUS.FAILED.value
											? 'Failed'
											: 'In Progress'}
								</span>
							)}
						</dd>
					</div>
				);
			})}

			<br />

			{status === CHANNEL_STATUS.READY.value && assignedCredentials && (
				<div className={style.credentials}>
					<div className={style.assignedCredentials}>ASSIGNED CREDENTIALS</div>
					<div className={style.credentialsRow}>
						<div className={style.credentialField}>Username</div>
						{password ? (
							<div className={style.credentialField}>Password</div>
						) : (
							<div className={style.credentialField}>PEM File</div>
						)}
						<div className={style.credentialField}>Assignee</div>
					</div>

					{assignedCredentials.map((item, index) => {
						return (
							<div className={style.credentialsRow} key={index}>
								<React.Fragment>
									<div className={style.credentialField} title={item.username}>
										{item.username ? item.username : ''}
									</div>
								</React.Fragment>
								{password ? (
									<React.Fragment>
										<div className={style.credentialField} title={item.password}>
											{item.password ? item.password : ''}
										</div>
									</React.Fragment>
								) : (
									<React.Fragment>
										<div
											className={style.credentialField}
											title={item.password_file_name}
										>
											{item.password_file_name ? item.password_file_name : ''}
										</div>
									</React.Fragment>
								)}
								<React.Fragment>
									<div className={style.credentialField} title={item.assignee}>
										{item.assignee ? item.assignee : ''}
									</div>
								</React.Fragment>
							</div>
						);
					})}
				</div>
			)}
		</dl>
	);
};

export default Server;

Server.propTypes = {
	aws_instance: PropTypes.string,
	is_user_owned: PropTypes.bool,
	ip_address: PropTypes.string,
	bm: PropTypes.object,
	is_assingning_credentials: PropTypes.bool,
	username: PropTypes.string,
	password: PropTypes.string,
	password_file: PropTypes.string,
	password_file_name: PropTypes.string,
	port: PropTypes.number,
	status: PropTypes.oneOf([
		CHANNEL_STATUS.READY.value,
		CHANNEL_STATUS.IN_PROGRESS.value,
		CHANNEL_STATUS.DEPLOYING_DATASET.value,
		CHANNEL_STATUS.FAILED.value
	]),
	file: PropTypes.string,
	credentials: PropTypes.array
};
