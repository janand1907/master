import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import cx from 'utils/classNames';
import * as i18n from 'i18n/en/channelCard.json';
import style from './style.scss';

const API = ({ api_type, api_url, auth, status, is_user_owned, har_file_name, cloud_type }) => {
	let authFields = {};
	if (auth && auth.type && auth.type === i18n.API.authType.BASIC) {
		authFields = {
			[i18n.API.authFields.username]: auth.username,
			[i18n.API.authFields.password]: auth.password
		};
	} else if (auth && auth.type && auth.type === i18n.API.authType.OAUTH2) {
		authFields = {
			[i18n.API.authFields.grant_type]: auth.grant_type,
			[i18n.API.authFields.client_id]: auth.client_id,
			[i18n.API.authFields.client_secret]: auth.client_secret,
			[i18n.API.authFields.token_url]: auth.token_url
		};
		if (auth.grant_type === i18n.API.authFields.password) {
			// extend for oAuth2.0 password grant
			authFields = {
				...authFields,
				[i18n.API.authFields.username]: auth.username,
				[i18n.API.authFields.password]: auth.password
			};
		}
	}

	const isInProgress = () => {
		return is_user_owned || status!== CHANNEL_STATUS.IN_PROGRESS.value;
	};

	return (
		<dl className={style.terms}>
			{api_url && (
				<div>
					<dt className={style.title}>Base URL&#32;</dt>
					<dd className={style.label}>
						{isInProgress() ? (
							<a href={api_url} target="_blank" rel="noopener noreferrer">
								{api_url}
							</a>
						) : (
							<span className={style.inProgress}>{i18n.status.inProgress}</span>
						)}
					</dd>
				</div>
			)}
			{cloud_type &&
			<div>
				<dt className={style.title}>{i18n.API.cloud_type}&#32;</dt>
				<dt className={cx(style.label, style.capitalize)}>{ CLOUD_TYPE_TO_ICON[cloud_type].label}</dt>
			</div>
			}
			{auth && auth.type !== i18n.API.authType.NONE && (
				<div>
					<dt className={style.title}>{i18n.API.title}&#32;</dt>
					<dt className={cx(style.label, style.capitalize)}>{auth.type}</dt>
				</div>

			)}
			{auth && auth.type !== i18n.API.authType.NONE && authFields && (
				<div>
					{Object.keys(authFields).map((item, index) => {
						return (
							<div key={index}>
								<dt className={style.title}>{item}&nbsp;</dt>
								<dd className={style.label}>
									{isInProgress() ? (
										authFields[item]
									) : (
										<span className={style.inProgress}>{i18n.status.inProgress}</span>
									)}
								</dd>
							</div>
						);
					})}
				</div>
			)}
			{har_file_name && (
				<div>
					<dt className={style.title}>HAR File</dt>
					<Link to="/repository/har" className={style.enabled}>
						<dd className={style.label}>
							{isInProgress() ? (
								har_file_name
							) : (
								<span className={style.inProgress}>{i18n.status.inProgress}</span>
							)}
						</dd>
					</Link>
				</div>
			)}
		</dl>
	);
};

export default API;

API.propTypes = {
	api_type: PropTypes.oneOf(['rest', 'soap']),
	api_url: PropTypes.string,
	auth: PropTypes.object,
	har_file_name: PropTypes.string,
	status: PropTypes.oneOf([
		CHANNEL_STATUS.READY.value,
		CHANNEL_STATUS.IN_PROGRESS.value,
		CHANNEL_STATUS.DEPLOYING_DATASET.value,
		CHANNEL_STATUS.FAILED.value
	]),
	is_user_owned: PropTypes.bool
};
