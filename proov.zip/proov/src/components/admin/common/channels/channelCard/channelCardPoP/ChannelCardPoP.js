import * as PILOT_STATUS from 'constants/pilotStatus';
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { ChevronSmallIcon, EditIcon } from 'components/ui/Icons';
import cx from 'utils/classNames';
import Permission from 'components/Permission';
import NewSpinner from 'components/ui/NewSpinner/NewSpinner';
import IconWrapper from '../../icons/IconWrapper';
import ChannelStatus from '../../ChannelStatus/ChannelStatus';
import DetailsWrapper from './details/DetailsWrapper';
import ChannelCardHeaderBlock from './ChannelCardHeaderBlock';
import style from './ChannelCard.scss';

function ChannelCardPoP({ data, actions, pilotStatus, pending, isEditable }) {
	const [isCollapsed, setIsCollapsed] = React.useState(false);

	function editChannel(environment) {
		edit(environment);
	}

	function openDeployModal() {
		actions.showModal('DeployDataset', {
			envId: data.id,
			// display message ONLY when user attempt to redeploy dataset
			isRedeploy: !!(data.dataset && data.dataset.deployment_status !== 'fail'),
		});
	}

	function openSyncModal() {
		actions.showModal(data.type + 'Sync', { envId: data.id, type: data.type });
	}

	function toggle() {
		setIsCollapsed(!isCollapsed);
	}

	function renderDetailsWrapper(data) {
		return (
			<DetailsWrapper
				data={data}
				isVisible={isCollapsed}
				onOpenModal={openDeployModal}
				pilotStatus={pilotStatus}
				editChannel={editChannel}
				openSyncModal={openSyncModal}
			/>
		);
	}

	return (
		<div className={style.outline}>
			<div className={style.header}>
				<div className={style.headerBadge}>
					<IconWrapper {...data} />
				</div>
				<div className={style.headerInfo}>
					<h3>{data.name}</h3>
					<div className={style.channelProp}>
						{data.type !== 'db' &&
							data.type !== 'api' &&
							ChannelStatus({ ...data })}
						<ChannelCardHeaderBlock
							data={data}
							pilotStatus={pilotStatus}
							onOpenModal={openDeployModal}
						/>
					</div>
					{(data.type === 'db' || data.type === 'api') &&
						(data.status === CHANNEL_STATUS.READY.value ||
							data.status === CHANNEL_STATUS.FAILED.value) &&
						isEditable &&
						isCollapsed && (
							<Permission
								alias="Channel#edit"
								component={
									<span
										className={style.edit}
										onClick={() => editChannel(data)}
									>
										<EditIcon className={style.editIcon} /> Edit
									</span>
								}
							/>
						)}
				</div>
				<Permission
					alias="ChevronSmallIcon"
					component={
						<div id="toggle" className={style.headerColl} onClick={toggle}>
							{pending !== data.id ? (
								<ChevronSmallIcon
									className={cx(style.chevronIcon, {
										[style.chevronIconDown]: isCollapsed,
									})}
								/>
							) : (
								<NewSpinner s="m" />
							)}
						</div>
					}
				/>
			</div>

			{renderDetailsWrapper(data)}
		</div>
	);
}

export default ChannelCardPoP;

ChannelCardPoP.propTypes = {
	data: PropTypes.object,
	pending: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
	pilotStatus: PropTypes.oneOf([
		PILOT_STATUS.ACTIVE,
		PILOT_STATUS.COMPLETED,
		PILOT_STATUS.FUTURE,
		PILOT_STATUS.PREPARATION,
		PILOT_STATUS.EXECUTION,
		PILOT_STATUS.EVALUATION,
		PILOT_STATUS.JOINING,
	]),
	edit: PropTypes.func,
	actions: PropTypes.object,
	isEditable: PropTypes.bool,
	pilotType: PropTypes.string,
};

ChannelCardPoP.defaultProps = {
	isEditable: true, // channel cards on the last step of pilot wizard are not editable
};
