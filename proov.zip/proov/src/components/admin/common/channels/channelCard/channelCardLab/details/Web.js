import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { getVendors } from 'ducks/admin/pilot/channel/selectors';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import ChannelStatus from 'components/admin/common/channels/ChannelStatus/ChannelStatus';
import IconWithTooltip from 'components/ui/Icons/IconWithTooltip';
import TrashIcon from 'components/ui/Icons/TrashIcon';
import { GridView } from 'components/ui/GridView';
import {SOCIAL_OPTIONS} from 'components/admin/common/commonFields/SocialOptions';
import { showModal } from 'ducks/modal/actions';
import * as i18n from 'i18n/en/channelCard.json';
import style from './style.scss';

const Web = (props) => {
    const isChannelHasIsvs = props.isvs && props.isvs.length;

    const handleRemoveItem = React.useCallback((channel) => {
        props.actions.showModal('DeleteWebChannelDetails', {
            pilotId: props.pilotId,
            channel
        });
    }, []);

    const getVendorName = (id) => {
        return props.vendors.filter(vendor => vendor.id === id).map(vendor => vendor.name)[0]
    }

    const getAuthType = (type) => {
        switch (type) {
            case 'socials':
                return 'social Login';
            case 'credentials':
                return 'basic';
            default:
                return type;
        }
    }

    const gridConfig = () => {
        return [
            {
                title: 'Username',
                value: ({ username }) => <div title={username}>{username}</div>,
            },
            {
                title: 'Password',
                value: ({ password }) => <div title={password}>{password}</div>,
            }
        ];
    }
    const renderSocialItem = (item) => {
        const optionItem = SOCIAL_OPTIONS.find(option => option.id === item);
        const Component = optionItem.icon;
        return <li className={style.socialItem}>
            {<Component className={style.iconSocial} />}
            <p className={style.firstLetterUppercase}>{optionItem.label}</p>
        </li>
    }

    return (

        <dl className={style.terms}>
            {!isChannelHasIsvs ?
                <p key="waiting" className={style.waiting}>
                    {i18n.Details.waiting}
                </p>
                : <div>
                    {props.isvs.map(vendor =>
                        <div className={style.vendorsWrapper} key={vendor.customer_id}>
                            <div className={style.vendorName}>
                                {vendor.status && <ChannelStatus {...vendor} removeText={true} className={style.channelStatus} />}
                                {getVendorName(vendor.customer_id)}
                            </div>

                            {!vendor.auth ?
                                <div><p className={style.isvWaitingMessage}>{i18n.web.waiting}</p></div>
                                :
                                <div>
                                    <div className={style.webFieldRow} key={'website'}>
                                        <dt>{i18n.web.website}</dt>
                                        <dd><a href={vendor.ip_address} target={'_blank'}>URL</a></dd>
                                    </div>
                                    <div className={style.webFieldRow} key={'auth'}>
                                        <dt>{i18n.web.auth}</dt>
                                        <dd className={style.firstLetterUppercase}>{getAuthType(vendor.auth.type)}</dd>
                                    </div>
                                    {vendor.auth.type === 'credentials'
                                        && <GridView
                                            config={gridConfig()}
                                            data={vendor.auth.users}
                                            className={style.table}
                                            titleClassName={style.gridTitle}
                                            rowClassName={(row) => style.gridRow}
                                        />
                                    }

                                    {vendor.auth.type === 'socials'
                                        && <ul className={style.socialList}>
                                            {vendor.auth.socials.map(item => renderSocialItem(item))}
                                        </ul>
                                    }

                                    <div className={style.plusParamWrapper}>
                                        <IconWithTooltip
                                            className={style.tooltipWrapper}
                                            icon={
                                                <TrashIcon
                                                    className={style.trashIcon}
                                                    onClick={() => handleRemoveItem(vendor)} />}
                                            textToDisplay={i18n.web.deleteTooltip}
                                            placement="right" />
                                    </div>
                                </div>
                            }
                        </div>
                    )}
                </div>}
        </dl >
    );
};

Web.propTypes = {
    pilotId: PropTypes.string,
    vendors: PropTypes.array,
    isvs: PropTypes.array
};

function mapStateToProps(state) {
    const pilot = getAdminPilot(state);
    const vendors = pilot ? getVendors(state) : [];
    return {
        pilotId: pilot ? pilot.id : null,
        vendors: vendors
    };
}
function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators({ showModal }, dispatch),
    };
}
export default withRouter(connect(
    mapStateToProps,
    mapDispatchToProps
)(Web));
