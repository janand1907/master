import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import style from './style.scss';

const AWSEC2 = ({ data, display }) => {
	const fields = {
		...pick(data, [
			'name',
			'arn',
			'port',
			'public_ip',
			'username',
			'password',
			'instance_type',
			'password_file_name',
			'password_file'
		])
	};

	return Object.keys(fields).map(key => {
		if (key === 'password_file') {
			return (
				<React.Fragment key={key}>
					<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
					<dd className={style.label}>
						<a href={fields[key]} title={fields[key]}>
							Download
						</a>
					</dd>
				</React.Fragment>
			);
		}
		if (key === 'password_file_name') {
			return (
				<React.Fragment key={key}>
					<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
					<dd className={style.label}>{fields[key]}</dd>
				</React.Fragment>
			);
		}

		return (
			<React.Fragment key={key}>
				<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
				<dd className={style.label}>
					{fields[key] && typeof fields[key] !== 'object' && fields[key].toString()}
					{fields[key] && typeof fields[key] === 'object' && display(fields[key])}
				</dd>
			</React.Fragment>
		);
	});
};

export default AWSEC2;

AWSEC2.propTypes = {
	data: PropTypes.object
};
