import React from 'react';
import PropTypes from 'prop-types';
import style from './style.scss';

const VPN = ({
	vpn_type,
	ip_address,
	port,
	username,
	password
}) => {

	return 		(
		<dl className={style.terms}>
			<dt className={style.title}>Type&#32;</dt>
			<dd className={style.label}>{vpn_type}</dd>

			<dt className={style.title}>IP&#32;</dt>
			<dd className={style.label}>{ip_address}</dd>

			<dt className={style.title}>Port&#32;</dt>
			<dd className={style.label}>{port}</dd>

			<dt className={style.title}>Username&#32;</dt>
			<dd className={style.label}>{username}</dd>

			<dt className={style.title}>Password&#32;</dt>
			<dd className={style.label}>{password}</dd>
		</dl>
	);
};

export default VPN;

VPN.propTypes = {
	vpn_type: PropTypes.string,
	ip_address: PropTypes.string,
	port: PropTypes.number,
	username: PropTypes.string,
	password: PropTypes.string
};
