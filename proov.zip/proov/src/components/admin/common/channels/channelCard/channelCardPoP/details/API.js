/* eslint-disable no-nested-ternary */
/* eslint-disable camelcase */
/* eslint-disable complexity */
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import cx from 'utils/classNames';
import * as i18n from 'i18n/en/channelCard.json';
import Permission from 'components/Permission';
import ChannelStatus from '../../../ChannelStatus/ChannelStatus';
import style from './style.scss';

const API = ({ auth, status, har_file_name, safe_zone, user_owned, openSyncModal }) => {

	let authFields = {};

	if (auth && auth.type && auth.type === globalize.parseString(i18n.API.authType.BASIC)) {
		authFields = {
			[globalize.parseString(i18n.API.authFields.username)]: auth.username,
			[globalize.parseString(i18n.API.authFields.password)]: auth.password
		};
	}

	const isInProgress = () => {
		return status === CHANNEL_STATUS.IN_PROGRESS.value;
	};

	const isReady = () => {
		return status === CHANNEL_STATUS.READY.value;
	};

	const isPopActive = safe_zone && safe_zone.active;
	const isUserOwnedActive = user_owned && user_owned.active;

	return (
		<React.Fragment>
			<div key="user_details_scheme_id" className={style.popContainer}>
				<div className={cx(style.type, isPopActive ? style.active : style.disabled)}>
					<h3>prooV SafeZone</h3>
					{isPopActive && <ChannelStatus status={status} />}

					<div className={style.content}>
						<dl className={style.dl}>
							<dt className={style.title}>PATH&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? safe_zone && safe_zone.ip_address
											? safe_zone.ip_address
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? safe_zone && safe_zone.ip_address
										? safe_zone.ip_address
										: 'Not set yet'
									: 'In Progress'}
							</dd>
						</dl>
						<Permission
							alias="SyncDataSet"
							component={
								<div className={style.buttons}>
									<button
										disabled={
											!isPopActive || !isReady() || !(user_owned && user_owned.ip_address)
										}
										type="button"
										className={style.syncBtn}
										onClick={openSyncModal}
									>
										Sync
									</button>
								</div>
							}
						/>
					</div>
				</div>

				<div className={cx(style.type, isPopActive ? style.disabled : style.active)}>
					<h3>Customer Environment</h3>

					{isUserOwnedActive && <ChannelStatus status={status} />}

					<div className={style.content}>
						<dl className={style.dl}>
							<dt className={style.title}>PATH&#32;</dt>
							<dd
								className={style.label}
								title={
									!isInProgress()
										? user_owned && user_owned.ip_address
											? user_owned.ip_address
											: 'Not set yet'
										: 'In Progress'
								}
							>
								{!isInProgress()
									? user_owned && user_owned.ip_address
										? user_owned.ip_address
										: 'Not set yet'
									: 'In Progress'}
							</dd>
						</dl>
					</div>
				</div>
			</div>

			{auth && auth.type !== globalize.parseString(i18n.API.authType.NONE) && (
				<dl className={cx(style.terms, style.commonApiFields)}>
					<div>
						<dt className={style.title}>{globalize.parseString(i18n.API.title)}&#32;</dt>
						<dt className={cx(style.label, style.capitalize)}>{auth.type}</dt>
					</div>
				</dl>
			)}

			{auth && auth.type !== globalize.parseString(i18n.API.authType.NONE) && authFields && (
				<dl className={cx(style.terms, style.commonApiFields)}>
					<div>
						{Object.keys(authFields).map((item, index) => {
							return (
								<div key={index}>
									<dt className={style.title}>{item}&nbsp;</dt>
									<dd className={style.label}>
										{!isInProgress() ? (
											authFields[item]
										) : (
											<span className={style.inProgress}>
												{globalize.parseString(i18n.status.inProgress)}
											</span>
										)}
									</dd>
								</div>
							);
						})}
					</div>
				</dl>
			)}

			{har_file_name && (
				<dl className={cx(style.terms, style.commonApiFields)}>

					<div>
						<dt className={style.title}>HAR File</dt>
						<Link to="/repository/har" className={style.enabled}>
							<dd className={style.label}>
								{!isInProgress()
									?
									(har_file_name)
									:
									(<span className={style.inProgress}>{globalize.parseString(i18n.status.inProgress)}</span>)
								}
							</dd>
						</Link>
					</div>
				</dl>

			)}

		</React.Fragment>
	);
};

export default API;

API.propTypes = {
	auth: PropTypes.object,
	status: PropTypes.oneOf([
		CHANNEL_STATUS.READY.value,
		CHANNEL_STATUS.IN_PROGRESS.value,
		CHANNEL_STATUS.DEPLOYING_DATASET.value,
		CHANNEL_STATUS.FAILED.value
	]),
	har_file_name: PropTypes.string,
	safe_zone: PropTypes.object,
	user_owned: PropTypes.object,
	openSyncModal: PropTypes.func
};
