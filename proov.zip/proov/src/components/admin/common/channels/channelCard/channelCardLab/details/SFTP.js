import React from 'react';
import PropTypes from 'prop-types';
import style from './style.scss';

const SFTP = ({
	ip_address,
	port,
	username,
	password,
	password_file,
	password_file_name
}) => {
	return (
		<dl className={style.terms}>
			<dt className={style.title}>IP&#32;</dt>
			<dd className={style.label}>{ip_address}</dd>
			<dt className={style.title}>Port&#32;</dt>
			<dd className={style.label}>{port}</dd>
			<dt className={style.title}>Username&#32;</dt>
			<dd className={style.label}>{username}</dd>
			{password_file ? (
				<div>
					<dt className={style.title}>Credential File&#32;</dt>
					<dd className={style.label}>
						<a title="credentials file" href={password_file} title={password_file_name}>
							Download
						</a>
					</dd>
				</div>
			) : (
				<div>
					<dt className={style.title}>Password&#32;</dt>
					<dd className={style.label}>{password}</dd>
				</div>
			)}
		</dl>
	);
};

export default SFTP;

SFTP.propTypes = {
	ip_address: PropTypes.string,
	port: PropTypes.number,
	username: PropTypes.string,
	password: PropTypes.string,
	password_file: PropTypes.string,
	password_file_name: PropTypes.string
};
