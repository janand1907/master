import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Lookup from 'components/common/Lookups/Lookup';
import style from './style.scss';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';
import UploadMediaFile from 'components/admin/common/commonFields/UploadMediaFile';
import Switch from 'components/ui/Switch/Switch';
import { FileUpload } from 'components/common/FileUpload';
import { getVendors } from 'ducks/admin/pilot/channel/selectors';
const Docker = ({
	customer,
	aws_instance,
	ip_address,
	username,
	password,
	port,
	password_file,
	password_file_name,
	is_user_owned,
	status,
	is_assingning_credentials,
	credentials,
	cloud_type,
	docker_info,
	vendors
}) => {
	const ServerCredentials = password
		? { Password: password }
		: { PEM: { label: password_file_name, href: password_file } };

	const base = {
		'Cloud-based': cloud_type && CLOUD_TYPE_TO_ICON[cloud_type].label,
		IP: ip_address,
		Port: port,
		Username: username,
		...ServerCredentials,
	};

	// Add Instance field in case of proov environment
	const fields = is_user_owned
		? base
		: {
			Instance: <Lookup lookupType="aws_instance_type" lookupKey={aws_instance} cloudType={cloud_type !== 'AWS' && cloud_type} lookupKeyWithCloudType={true} />,
			...base
		};

	const assignedCredentials =
		is_assingning_credentials && credentials && credentials.length !== 0
			? credentials
			: null;

	return (
		<dl className={style.terms}>
			{customer && customer.name && (
				<p>
					<strong>{customer.name}</strong>
				</p>
			)}
			{Object.keys(fields).map((item, index) => {
				return (
					<div key={index}>
						<dt className={style.title}>{item}&#32;</dt>
						<dd className={style.label}>
							{is_user_owned || status !== CHANNEL_STATUS.IN_PROGRESS.value ? (
								item === 'PEM' ? (
									<a href={password_file} title={password_file_name} target="_blank">
										Download
									</a>
								) : (
									fields[item]
								)
							) : (
								<span className={style.inProgress}>
									{item === 'Instance' || item === 'Cloud-based'
										? fields[item]
										: 'In Progress'}
								</span>
							)}
						</dd>
					</div>
				);
			})}

			<br />

			{status === CHANNEL_STATUS.READY.value && assignedCredentials && (
				<div className={style.credentials}>
					<div className={style.assignedCredentials}>ASSIGNED CREDENTIALS</div>
					<div className={style.credentialsRow}>
						<div className={style.credentialField}>Username</div>
						{password ? (
							<div className={style.credentialField}>Password</div>
						) : (
							<div className={style.credentialField}>PEM File</div>
						)}
						<div className={style.credentialField}>Assignee</div>
					</div>

					{assignedCredentials.map((item, index) => {
						return (
							<div className={style.credentialsRow} key={index}>
								<React.Fragment>
									<div className={style.credentialField} title={item.username}>
										{item.username ? item.username : ''}
									</div>
								</React.Fragment>
								{password ? (
									<React.Fragment>
										<div className={style.credentialField} title={item.password}>
											{item.password ? item.password : ''}
										</div>
									</React.Fragment>
								) : (
									<React.Fragment>
										<div
											className={style.credentialField}
											title={item.password_file_name}
										>
											{item.password_file_name ? item.password_file_name : ''}
										</div>
									</React.Fragment>
								)}
								<React.Fragment>
									<div className={style.credentialField} title={item.assignee}>
										{item.assignee ? item.assignee : ''}
									</div>
								</React.Fragment>
							</div>
						);
					})}

				</div>
			)}

			{vendors.map((vendor) => {
				if (docker_info && docker_info[vendor.id]) {
					return docker_info[vendor.id] && <React.Fragment>
						<b>{vendor.name}</b><br />
						<dt className={style.title}>Docker Compose&#32;</dt>
						<dd className={style.label}><Switch
							className={style.switch}
							name="is_docker_compose"
							toggled={true}
							disabled={true}
						/>
						</dd>
						<FileUpload
							classNameWrapper={style.fileAttached}
							fieldName={`docker_info[${vendor.id}]`}
							selectedFiles={[docker_info[vendor.id]]}
							extensions={['yml', 'yaml']}
							allowView={true}
							blockAdd={true}
							blockDelete={true}
						/>
					</React.Fragment>
				}
			})


			}
		</dl>
	);
};


Docker.propTypes = {
	aws_instance: PropTypes.string,
	is_user_owned: PropTypes.bool,
	ip_address: PropTypes.string,
	username: PropTypes.string,
	password: PropTypes.string,
	password_file: PropTypes.string,
	password_file_name: PropTypes.string,
	is_assingning_credentials: PropTypes.bool,
	port: PropTypes.number,
	status: PropTypes.oneOf([
		CHANNEL_STATUS.READY.value,
		CHANNEL_STATUS.IN_PROGRESS.value,
		CHANNEL_STATUS.DEPLOYING_DATASET.value,
		CHANNEL_STATUS.FAILED.value
	]),
	file: PropTypes.string,
	credentials: PropTypes.array,
	vendors: PropTypes.array,
	docker_info: PropTypes.object
};

function mapStateToProps(state) {
	const vendors = getVendors(state);
	return { vendors }
}
export default connect(mapStateToProps, null)(Docker);

