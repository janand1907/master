import { ENTER } from 'constants/keyCodes';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
	getApiArchive,
	setApiArchive,
	resetApiArchive
} from 'ducks/repository/syncArchive/actions';
import {
	getSyncArchivePending,
	getApiArchivePending,
	getApiArchiveData,
	getApiArchiveError,
	getApiArchiveSuccess
} from 'ducks/repository/syncArchive/selectors';
import { InfiniteScroll } from 'components/ui/InfiniteScroll';
import { NewSpinner } from 'components/ui/NewSpinner';
import SearchBar from 'components/ui/SearchBar/SearchBar';
import { Alert } from 'components/ui/Alert';
import { getVendors } from 'ducks/admin/pilot/channel/selectors';
import { WebLogTable } from 'components/repository/httpArchive/modalHttpViewer/webLogTable';
import cn from 'utils/classNames';
import css from './modalSync.scss';

class ModalApiSyncContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleLoadMore = this.handleLoadMore.bind(this);
		this.handleSearch = this.handleSearch.bind(this);
		this.handleChangeSearch = this.handleChangeSearch.bind(this);
		this.handleKeyPress = this.handleKeyPress.bind(this);

		this.state = { checked: null, keyword: '', skip: 0, error: null, success: null };
	}

	static getDerivedStateFromProps(nextProps, prevState) {
		if (
			(nextProps.data &&
				prevState.checked &&
				prevState.checked.length !== nextProps.data.length) ||
			(nextProps.data && !prevState.checked) ||
			(nextProps.data && nextProps.error !== prevState.error) ||
			(nextProps.data && nextProps.success !== prevState.success)
		) {
			return {
				checked: nextProps.data.map((_, i) => {
					return prevState.checked && prevState.checked[i] >= 0
						? Number(prevState.checked[i])
						: false;
				}),
				skip: nextProps.data.length,
				error: nextProps.error,
				success: nextProps.success
			};
		}

		return null;
	}

	componentDidMount() {
		!this.props.data && this.props.getApiArchive(this.props.envId, 0, this.state.keyword);
	}

	componentWillUnmount() {
		this.props.resetApiArchive();
	}

	handleChange(checked) {
		this.setState({ checked });
	}

	handleSubmit() {
		this.props.setApiArchive(
			this.props.envId,
			this.state.checked.filter(c => c !== false).map(i => this.props.data[i]._id.$oid)
		);
	}

	handleLoadMore() {
		this.props.getApiArchive(this.props.envId, this.state.skip, this.state.keyword);
	}

	handleSearch() {
		this.props.resetApiArchive();
		this.props.getApiArchive(this.props.envId, this.state.skip, this.state.keyword, true);
	}

	handleChangeSearch(keyword) {
		this.setState({ keyword, skip: 0 });
	}

	handleKeyPress(e) {
		if (e.which === ENTER) {
			this.handleSearch();
		}
	}

	render() {
		const { pendingArchive, pendingCommit, data } = this.props;
		const { error, checked, keyword, success } = this.state;
		const disableButton = !checked || (checked && !checked.some(v => v !== false));

		return (
			<div className={css.modal}>
				<div className={css.header}>
					<h2>prooV SafeZone API ACTIVITY</h2>
				</div>

				<div className={css.content}>
					<SearchBar
						onSearch={this.handleSearch}
						onChange={this.handleChangeSearch}
						onKeyPress={this.handleKeyPress}
						keyword={keyword}
					/>
					{data && (
						<InfiniteScroll
							className={css.listContainer}
							hasNext={true}
							isPending={pendingArchive}
							next={this.handleLoadMore}
						>
							<WebLogTable log={data} withButton={false} onChange={this.handleChange} />
						</InfiniteScroll>
					)}
				</div>

				<div className={cn(css.footer, data ? css.disabled : css.enabled)}>
					{error && (
						<Alert type="error" className={css.error}>
							{error}
						</Alert>
					)}
					{success && (
						<Alert type="success" className={css.success}>
							{success}
						</Alert>
					)}
					{pendingArchive && (
						<div className={css.spinnerWrapper}>
							<NewSpinner size="s" />
							<div className={css.loading}>Loading activity...</div>
						</div>
					)}
					{pendingCommit && (
						<div className={css.spinnerWrapper}>
							<NewSpinner size="s" />
							<div className={css.loading}>Commit activity...</div>
						</div>
					)}
					<button
						type="button"
						onClick={this.handleSubmit}
						className={css.btnCreate}
						disabled={pendingArchive || disableButton}
					>
						COMMIT TO CUSTOMER ENVIRONMENT
					</button>
				</div>
			</div>
		);
	}
}

ModalApiSyncContainer.propTypes = {
	type: PropTypes.string.isRequired, // channelType
	envId: PropTypes.string.isRequired,
	pendingArchive: PropTypes.bool.isRequired,
	data: PropTypes.array,
	error: PropTypes.string,
	vendors: PropTypes.array.isRequired,
	success: PropTypes.string,
	pendingCommit: PropTypes.bool,
	getApiArchive: PropTypes.func.isRequired,
	setApiArchive: PropTypes.func.isRequired,
	resetApiArchive: PropTypes.func.isRequired
};

function mapStateToProps(state) {
	return {
		pendingCommit: getApiArchivePending(state),
		pendingArchive: getSyncArchivePending(state),
		data: getApiArchiveData(state),
		vendors: getVendors(state),
		error: getApiArchiveError(state),
		success: getApiArchiveSuccess(state)
	};
}

export default connect(
	mapStateToProps,
	{ getApiArchive, setApiArchive, resetApiArchive }
)(ModalApiSyncContainer);
