import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import EditIcon from 'components/ui/Icons/EditIcon';
import cx from 'utils/classNames';
import Permission from 'components/Permission';
import style from './DetailsWrapper.scss';
import {
	Server,
	Database,
	API,
	SFTP,
	VPN,
	Storage,
	Blockchain,
	Docker,
	Saas,
	Web
} from './';

const channelTypeComponent = {
	server: Server,
	db: Database,
	api: API,
	vpn: VPN,
	sftp: SFTP,
	storage: Storage,
	blockchain: Blockchain,
	docker: Docker,
	saas: Saas,
	web: Web
};

const DetailsWrapper = ({ data, isEditable, editClick, isVisible }) => {
	// map channel type to channel component
	const ChannelComp = channelTypeComponent[data.type];
	return (
		<div className={cx(style.layout, { [style.hide]: !isVisible })}>
			{(data.status === CHANNEL_STATUS.READY.value ||
				data.status === CHANNEL_STATUS.FAILED.value) &&
				isEditable && (
					<Permission
						alias="Channel#edit"
						component={
							<span className={style.edit} onClick={() => editClick(data)}>
								<EditIcon className={style.editIcon} /> Edit
							</span>
						}
					/>
				)}
			<ChannelComp {...data} />
		</div>
	);
};

export default DetailsWrapper;

DetailsWrapper.propTypes = {
	data: PropTypes.object.isRequired,
	isEditable: PropTypes.bool,
	editClick: PropTypes.func,
	isVisible: PropTypes.bool,
};
