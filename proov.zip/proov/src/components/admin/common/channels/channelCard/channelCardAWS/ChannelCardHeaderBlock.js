import * as CHANNEL_TYPE from 'constants/channel/channelType';
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import * as DATABASE_TYPE from 'constants/channel/databaseType';
import * as PILOT_STATUS from 'constants/pilotStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import cx from 'utils/classNames';
import style from './ChannelCardHeaderBlock.scss';
import DatabaseActions from './DatabaseActions';

const ChannelCardHeaderBlock = ({ data, pilotStatus, onOpenModal }) => {
	if (data.type === CHANNEL_TYPE.API) {
		return (
			<div className={style.resources}>
				{data.file_resource && (
					<Link
						key="dataset"
						className={cx(style.apiSpec, {
							[style.disabled]: data.status !== CHANNEL_STATUS.READY.value,
						})}
						to={{ pathname: data.file_resource.url }}
						target="_blank"
					>
						{data.file_resource.label}
					</Link>
				)}
			</div>
		);
	} else if (data.type === CHANNEL_TYPE.DB) {
		// dataset is deployable when:
		//- Pilot is active, and
		//- Channel status is ready, and
		//- DB type: mySQL or Postgres
		const isDeployable =
			(pilotStatus === PILOT_STATUS.ACTIVE ||
				pilotStatus === PILOT_STATUS.JOINING ||
				pilotStatus === PILOT_STATUS.PREPARATION ||
				pilotStatus === PILOT_STATUS.EXECUTION ||
				pilotStatus === PILOT_STATUS.EVALUATION) &&
			data.status === CHANNEL_STATUS.READY.value &&
			(data.db_type === DATABASE_TYPE.MYSQL ||
				data.db_type === DATABASE_TYPE.POSTGRES ||
				data.db_type === DATABASE_TYPE.MONGODB);

		return (
			<DatabaseActions
				is_user_owned={data.is_user_owned}
				dataset={data.dataset}
				isDeployable={isDeployable}
				openModal={onOpenModal}
			/>
		);
	} else if (data.type === CHANNEL_TYPE.STORAGE) {
		return data.is_read_only ? (
			<span className={style.details}>Read Only</span>
		) : null;
	} else {
		return null;
	}
};

export default ChannelCardHeaderBlock;

ChannelCardHeaderBlock.propTypes = {
	data: PropTypes.object,
	onOpenModal: PropTypes.func,
	pilotStatus: PropTypes.oneOf([
		PILOT_STATUS.ACTIVE,
		PILOT_STATUS.COMPLETED,
		PILOT_STATUS.FUTURE,
		PILOT_STATUS.PREPARATION,
		PILOT_STATUS.CONFIGURATION,
		PILOT_STATUS.DEPLOYMENT,
		PILOT_STATUS.EXECUTION,
		PILOT_STATUS.EVALUATION,
		PILOT_STATUS.JOINING,
	]),
};
