import * as PILOT_STATUS from 'constants/pilotStatus';
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { ChevronSmallIcon, EditIcon } from 'components/ui/Icons';
import cx from 'utils/classNames';
import * as i18n from 'i18n/en/channelCard.json';
import Permission from 'components/Permission';
import NewSpinner from 'components/ui/NewSpinner/NewSpinner';
import { CLOUD_TYPE_TO_ICON, SUPPORTED_CLOUD_CHANNEL_TYPE } from 'constants/channel/cloudType';
import IconWrapper from '../../icons/IconWrapper';
import ChannelStatus from '../../ChannelStatus/ChannelStatus';
import DetailsWrapper from './details/DetailsWrapper';
import ChannelCardHeaderBlock from './ChannelCardHeaderBlock';
import style from './ChannelCard.scss';
import css from './details/DetailsWrapper.scss';

const DEDICATED_STATUSES_SUPPORTED_EDIT = [CHANNEL_STATUS.READY.value, CHANNEL_STATUS.FAILED.value, CHANNEL_STATUS.PENDING.value];
function ChannelCardLab({
	data,
	pending,
	pilotStatus,
	isEditable,
	actions,
	edit,
}) {
	const [isCollapsed, setIsCollapsed] = React.useState(false);
	const isNoIsvs = (data.type == "saas" || data.type == "web") && !data.isvs || (data.isvs && data.isvs.length === 0);
	const isNoServers = data.type == "server" && !data.servers || (data.servers && data.servers.length === 0);
	function editChannel(environment) {
		edit(environment);
	}

	function openDeployModal() {
		actions.showModal('DeployDataset', {
			envId: data.id,
			// display message ONLY when user attempt to redeploy dataset
			isRedeploy: !!(data.dataset && data.dataset.deployment_status !== 'fail'),
		});
	}

	function toggle() {
		setIsCollapsed(!isCollapsed);
	}

	function renderDetailsWrapper(servers, data) {
		if (data.is_dedicated && data.type !== 'saas' && data.type !== 'web') {
			let res = [];
			if (
				isCollapsed &&
				(DEDICATED_STATUSES_SUPPORTED_EDIT.includes(data.status))
			) {
				const isNoServers = !data.servers || (data.servers && data.servers.length === 0);
				if (isNoServers) {
					res.push(
						<p key="waiting" className={style.waiting}>
							{i18n.Details.waiting}
						</p>
					);
				}
			}
			if (data.servers && data.servers.length > 0) {
				servers
					.filter(({ status }) => status !== CHANNEL_STATUS.DELETED.value)
					.forEach((srv) => {
						res.push(
							<DetailsWrapper
								key={'srv' + srv.id}
								data={{ ...srv, type: 'server' }}
								isVisible={isCollapsed}
								isEditable={false}
							/>
						);
					});
			}
			return res;
		} else {

			return (
				<DetailsWrapper
					data={data}
					isVisible={isCollapsed}
					isEditable={isEditable}
					editClick={editChannel}
					pilotStatus={pilotStatus}
				/>
			);
		}
	}
	const supportChannel = SUPPORTED_CLOUD_CHANNEL_TYPE.includes(data.type)
	const Icon = supportChannel ? data.cloud_type ? CLOUD_TYPE_TO_ICON[data.cloud_type].icon : null : CLOUD_TYPE_TO_ICON.DEFAULT.icon;

	return (
		<div className={style.outline}>
			<div className={style.header}>
				<div className={style.headerBadge}>
					<IconWrapper {...data} />

				</div>
				<div className={style.headerInfo}>
					<span
						key={'edit' + data.id}
						className={cx(css.edit, {[css.disabledEditIcon]: data.status === 'in_progress' && data.type !== 'saas'} )}
						onClick={() => {(data.status !== 'in_progress' || data.type === 'saas')  && editChannel(data)}}
					>
						{' '}
						<EditIcon className={css.editIcon} /> Edit

					</span>	<h3>{data.name}</h3>

					{Icon && <Icon className={cx(css.cloudTypeIcon, css[supportChannel ? data.cloud_type : 'DEFAULT'])} />}
					<div className={style.channelProp}>
						<ChannelStatus {...data} />
						{data.is_dedicated && (isNoServers || isNoIsvs) && <span key="waiting" className={style.waiting}>
							{i18n.Details.waiting}
						</span>}
						<ChannelCardHeaderBlock
							data={data}
							pilotStatus={pilotStatus}
							onOpenModal={openDeployModal}
						/>
					</div>
				</div>
				<Permission
					alias="ChevronSmallIcon"
					component={
						<div id="toggle" className={style.headerColl}
							onClick={!(data.is_dedicated && (isNoServers || isNoIsvs)) && toggle}
						>
							{pending !== data.id ? (
								<ChevronSmallIcon
									className={cx(style.chevronIcon, {
										[style.chevronIconDown]: isCollapsed,
									})}
								/>
							) : (
								<NewSpinner s="m" />
							)}
						</div>
					}
				/>
			</div>
			{/* { !data.servers ||  data.servers.length === 0} */}
			{renderDetailsWrapper(data.servers, data)}
		</div>
	);
}

export default ChannelCardLab;

ChannelCardLab.propTypes = {
	data: PropTypes.object,
	pending: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
	pilotStatus: PropTypes.oneOf([
		PILOT_STATUS.ACTIVE,
		PILOT_STATUS.COMPLETED,
		PILOT_STATUS.FUTURE,
		PILOT_STATUS.PREPARATION,
		PILOT_STATUS.CONFIGURATION,
		PILOT_STATUS.DEPLOYMENT,
		PILOT_STATUS.EXECUTION,
		PILOT_STATUS.EVALUATION,
		PILOT_STATUS.JOINING,
	]),
	edit: PropTypes.func,
	actions: PropTypes.object,
	isEditable: PropTypes.bool,
};

ChannelCardLab.defaultProps = {
	isEditable: false, // channel cards on the last step of pilot wizard are not editable
};
