import * as CHANNEL_TYPE from 'constants/channel/channelType';
import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import * as PILOT_STATUS from 'constants/pilotStatus';
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import cx from 'utils/classNames';
import style from './ChannelCardHeaderBlock.scss';

const ChannelCardHeaderBlock = ({ data }) => {
	if (data.type === CHANNEL_TYPE.API) {
		return (
			<div className={style.resources}>
				{data.file_resource && (
					<Link
						className={cx(style.apiSpec, {
							[style.disabled]: data.status !== CHANNEL_STATUS.READY.value
						})}
						to={{ pathname: data.file_resource.url }}
						target="_blank"
					>
						{data.file_resource.label}
					</Link>
				)}
			</div>
		);
	} else {
		return null;
	}
};

export default ChannelCardHeaderBlock;

ChannelCardHeaderBlock.propTypes = {
	data: PropTypes.object,
	onOpenModal: PropTypes.func,
	pilotStatus: PropTypes.oneOf([
		PILOT_STATUS.ACTIVE,
		PILOT_STATUS.COMPLETED,
		PILOT_STATUS.FUTURE,
		PILOT_STATUS.PREPARATION,
		PILOT_STATUS.EXECUTION,
		PILOT_STATUS.EVALUATION,
		PILOT_STATUS.JOINING
	])
};
