import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { Link, withRouter } from 'react-router-dom';
import { getVendors } from 'ducks/admin/pilot/channel/selectors';
import { getAdminPilot } from 'ducks/admin/pilot/selectors';
import IconWithTooltip from 'components/ui/Icons/IconWithTooltip';
import PlusIcon from 'components/ui/Icons/PlusIcon';
import EditIcon from 'components/ui/Icons/EditIcon';
import TrashIcon from 'components/ui/Icons/TrashIcon';
import ChannelStatus from 'components/admin/common/channels/ChannelStatus/ChannelStatus';
import { showModal } from 'ducks/modal/actions';
import * as i18n from 'i18n/en/channelCard.json';
import style from './style.scss';

const Saas = (props) => {
    const isChannelHasIsvs = props.isvs && props.isvs.length;
    const handleRemoveItem = React.useCallback((channel) => {
        props.actions.showModal('DeleteApiSpecSaaS', {
            pilotId: props.pilotId,
            channel
        });
    }, []);
    const handleGoToCreateMetric = (vendor) => {
        const { history, pilotId } = props;
        const endpoint = vendor.script ?
            `/admin/pilot/${pilotId}/environment/${props.id}/edit-evaluation/${vendor.script.id}`
            : `/admin/pilot/${pilotId}/environment/${props.id}/new-evaluation`;
        history.push(endpoint, vendor);
    }

    const getVendorName = (id) => {
        return props.vendors.filter(vendor => vendor.id === id).map(vendor => vendor.name)[0]
    }
    const renderAPIKey = (auth) => {
        const fields = ["type", "username", "password"];
        return <React.Fragment>
            {Object.keys(auth).map((field) => {
                return !fields.includes(field) && <div className={style.fieldRow}>
                    <dt>{field}&#32;</dt>
                    <dd>{auth[field]}{'\r'}</dd>
                </div>
            })}
        </React.Fragment>
    }
    const renderUsernamePassword = (username, password) => {
        return <React.Fragment>
            <div className={style.fieldRow}>
                <dt>{i18n.saas.username}&#32;</dt>
                <dd>{username}{'\r'}</dd>
            </div>
            <div className={style.fieldRow}>
                <dt>{i18n.saas.password}&#32;</dt>
                <dd>{password}{'\r'}</dd>
            </div></React.Fragment>
    }
    return (

        <dl className={style.terms}>
            {!isChannelHasIsvs ?
                <p key="waiting" className={style.waiting}>
                    {i18n.Details.waiting}
                </p>
                :
                props.isvs.map(vendor =>
                    <div className={style.vendorsWrapper} key={vendor.customer_id}>
                        <div className={style.vendorName}>
                            {vendor.status && <ChannelStatus {...vendor} removeText={true} className={style.channelStatus} />}
                            {getVendorName(vendor.customer_id)}
                        </div>

                        {!vendor.auth ?
                            <div><p className={style.isvWaitingMessage}>{i18n.saas.saasWaiting}</p></div>
                            :

                            <div>
                                <div className={style.fieldRow} key={'auth'}>
                                    <dt>{i18n.saas.auth}&#32;</dt>
                                    <dd>{vendor.auth.type}{'\r'}</dd>
                                </div>

                                {renderAPIKey(vendor.auth)}
                                {(vendor.auth.type === "basic" || vendor.auth.type === "oauth2.0" && vendor.auth.grant_type == "password")
                                    && renderUsernamePassword(vendor.auth.username, vendor.auth.password)}
                                <div className={style.plusParamWrapper}>

                                    <button className={style.plusParamButton} type="button" onClick={(e) => handleGoToCreateMetric(vendor)}>
                                        {vendor.script ?
                                            <React.Fragment>
                                                <EditIcon className={style.editIcon} />
                                                <span className={style.plusParam}>{i18n.saas.editScript}</span>
                                            </React.Fragment>
                                            : <React.Fragment>
                                                <PlusIcon className={style.plusIcon} />
                                                <span className={style.plusParam}>{i18n.saas.addScript}</span>
                                            </React.Fragment>
                                        }
                                    </button>
                                    <IconWithTooltip className={style.tooltipWrapper} icon={<TrashIcon className={style.trashIcon} onClick={() => handleRemoveItem(vendor)} />} textToDisplay={i18n.saas.deleteTooltip} placement="right" />
                                </div>
                            </div>
                        }
                    </div>
                )
            }
        </dl>
    );
};

Saas.propTypes = {
    pilotId: PropTypes.string,
    vendors: PropTypes.array,
    isvs: PropTypes.array
};

function mapStateToProps(state) {
    const pilot = getAdminPilot(state);
    const vendors = pilot ? getVendors(state) : [];
    return {
        pilotId: pilot ? pilot.id : null,
        vendors: vendors
    };
}
function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators({ showModal }, dispatch),
    };
}
export default withRouter(connect(
    mapStateToProps,
    mapDispatchToProps
)(Saas));
