import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import style from './style.scss';

const AWSLambda = ({ data, display }) => {
	const fields = {
		...pick(data, ['name', 'arn', 'credentials'])
	};

	return Object.keys(fields).map(key => {
		return (
			<React.Fragment key={key}>
				<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
				<dd className={style.label}>
					{fields[key] && typeof fields[key] !== 'object' && fields[key].toString()}
					{fields[key] && typeof fields[key] === 'object' && display(fields[key])}
				</dd>
			</React.Fragment>
		);
	});
};

export default AWSLambda;

AWSLambda.propTypes = {
	data: PropTypes.object
};
