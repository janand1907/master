import React from 'react';
import PropTypes from 'prop-types';
import { pick } from 'lodash';
import style from './style.scss';

const AWSSNS = ({ data, display }) => {
	const fields = {
		...pick(data, ['id', 'name', 'arn', 'credentials'])
	};

	return Object.keys(fields).map(key => {
		return (
			<React.Fragment key={key}>
				<dt className={style.title}>{key.replace(/_/g, ' ')}&nbsp;</dt>
				<dd className={style.label}>
					{fields[key] && typeof fields[key] !== 'object' && fields[key].toString()}
					{fields[key] && typeof fields[key] === 'object' && display(fields[key])}
				</dd>
			</React.Fragment>
		);
	});
};

export default AWSSNS;

AWSSNS.propTypes = {
	data: PropTypes.object
};
