import React from 'react';
import PropTypes from 'prop-types';
import style from './style.scss';

const Blockchain = ({
	status,
	ip_address,
	blockchain_type,
	port,
	account,
	password,
}) => {

	const fields = {
		'IP': ip_address,
		'Port': port,
		'type': blockchain_type,
		'Account': account,
		'Password': password
	};

	const scheme = [
		(Object.keys(fields).length > 0 &&
			<div key="proov_details_scheme_id" className={style.dlData}>
				{Object.keys(fields).map((item, index) => {
					return (
						<div key={index}>
							<dt className={style.title}>{item}&#32;</dt>
							<dd className={style.label}>
								{status === 'pending' ?
									<span>In Progress</span>
									:
									fields[item]}{'\r'}
							</dd>
						</div>
					);
				})}
			</div>),

	];

	return (<dl>{scheme}</dl>);
};

Blockchain.propTypes = {
	blockchain_type: PropTypes.string,
	status: PropTypes.string,
	ip_address: PropTypes.string,
	port: PropTypes.number,
	account: PropTypes.string,
	password: PropTypes.string
};

export default Blockchain;
