import * as CHANNEL_STATUS from 'constants/channel/channelStatus';
import * as BM_CHANNEL_STATUS from 'constants/channel/bmChannelStatus';
import React from 'react';
import PropTypes from 'prop-types';
import cn from 'utils/classNames';
import style from './ChannelStatus.scss';

const ChannelStatus = ({ status, bm, className,removeText }) => {
	if (!status) return null; //Create Pilot with bm
	const channelStatus = [
		status && (
			<div key="dlData1" className={style.statusWrapper}>
				<div className={style[status]} />
				<div className={style.text} hidden={removeText}>{CHANNEL_STATUS[status.toUpperCase()].label}</div>
			</div>
		),
		bm && bm.enabled && (
			<div key="dlData2" className={style.statusWrapper}>
				<div className={style[status]} />
				<div className={style.text} hidden={removeText} >
					{BM_CHANNEL_STATUS[bm.status.toUpperCase()].label}
				</div>
			</div>
		)
	];

	return (
		<div className={cn(style.envStatus, className)}>
			{channelStatus.map((status, idx) => {
				return <React.Fragment key={idx}>{status}</React.Fragment>;
			})}
		</div>
	);
};

ChannelStatus.propTypes = {
	status: PropTypes.string,
	className: PropTypes.string,
	bm: PropTypes.object,
	type: PropTypes.string
};

export default ChannelStatus;
