import React from 'react';
import SftpIcon from 'components/ui/Icons/SftpIcon_v2';
import style from './style.scss';

const SftpBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<SftpIcon className={style.channelIcon} />
			</div>
			<span className={style.type}>SFTP</span>
		</div>);
};

export default SftpBadge;
