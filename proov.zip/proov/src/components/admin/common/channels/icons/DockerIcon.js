/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import DockerIcon from 'components/ui/Icons/DockerIcon';
import ProovStampIcon from 'components/ui/Icons/ProovStampIcon';
import cx from 'utils/classNames';
import style from './style.scss';

const DockerBadge = ({ is_user_owned, isHideText,className }) => {
	return (
		<div  className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<DockerIcon className={style.dockerIcon} />
				{!is_user_owned && <ProovStampIcon className={style.proovIcon} />}
			</div>
			{!isHideText && <span className={style.type}>Docker</span>}
		</div>
	);
};

export default DockerBadge;

DockerBadge.propTypes = {
	is_user_owned: PropTypes.bool
};
