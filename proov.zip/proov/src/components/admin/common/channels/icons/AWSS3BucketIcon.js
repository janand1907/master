import React from 'react';
import AWSS3BucketIcon from 'components/ui/Icons/AWSS3BucketIcon';
import style from './style.scss';

const AWSS3BucketBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSS3BucketIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS S3 Bucket</span> */}
		</div>
	);
};

export default AWSS3BucketBadge;
