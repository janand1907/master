import React from 'react';
import AWSSQSIcon from 'components/ui/Icons/AWSSQSIcon';
import style from './style.scss';

const AWSSQSBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSSQSIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS SQS</span> */}
		</div>
	);
};

export default AWSSQSBadge;
