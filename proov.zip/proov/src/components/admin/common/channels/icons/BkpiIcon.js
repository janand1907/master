import React from 'react';
import PropTypes from 'prop-types';
import BkpiIcon from 'components/ui/Icons/BkpiIcon';
import cx from 'utils/classNames';
import style from './style.scss';

const BkpiBadge = ({ className, isHideText }) => {

	return (
		<div className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<BkpiIcon className={style.channelIcon} />
			</div>
			{!isHideText && <span className={style.type}>
				Business KPI
			</span>}
		</div>
	);
};

export default BkpiBadge;

BkpiBadge.propTypes = {
	className: PropTypes.string,
	isHideText: PropTypes.bool
};
