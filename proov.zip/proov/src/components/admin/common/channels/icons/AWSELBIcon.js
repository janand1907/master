import React from 'react';
import AWSELBIcon from 'components/ui/Icons/AWSELBIcon';
import style from './style.scss';

const AWSELBBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSELBIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS ELB</span> */}
		</div>
	);
};

export default AWSELBBadge;
