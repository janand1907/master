import React from 'react';
import AWSCloudTrailIcon from 'components/ui/Icons/AWSCloudTrailIcon';
import style from './style.scss';

const AWSCloudTrailBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSCloudTrailIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS Cloud Trail</span> */}
		</div>
	);
};

export default AWSCloudTrailBadge;

