import React from 'react';
import AWSSNSIcon from 'components/ui/Icons/AWSSNSIcon';
import style from './style.scss';

const AWSSNSBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSSNSIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS SNS</span> */}
		</div>
	);
};

export default AWSSNSBadge;
