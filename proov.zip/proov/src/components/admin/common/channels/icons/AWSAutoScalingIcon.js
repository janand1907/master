import React from 'react';
import AWSCloudFormationIcon from 'components/ui/Icons/AWSCloudFormationIcon';
import style from './style.scss';

const AWSCloudFormationBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSCloudFormationIcon className={style.awsChannelIcon} />
			</div>
			{/* <span className={style.type}>AWS Auto Scaling</span> */}
		</div>
	);
};

export default AWSCloudFormationBadge;

