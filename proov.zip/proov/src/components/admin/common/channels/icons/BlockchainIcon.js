import React from 'react';
import BlockchainIcon from 'components/ui/Icons/BlockchainIcon';
import ProovStampIcon from 'components/ui/Icons/ProovStampIcon';
import cx from 'utils/classNames';
import style from './style.scss';

const BlockchainBadge = ({isHideText, className}) => {
	return (
		<div  className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<BlockchainIcon className={style.channelIcon} />
				<ProovStampIcon className={style.proovIcon} />
			</div>
			{!isHideText && <span className={style.type}>Blockchain</span>}
		</div>
	);
};

export default BlockchainBadge;
