import React from 'react';
import AWSCloudWatchIcon from 'components/ui/Icons/AWSCloudWatchIcon';
import style from './style.scss';

const AWSCloudWatchnBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSCloudWatchIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS Cloud Watch</span> */}
		</div>
	);
};

export default AWSCloudWatchnBadge;
