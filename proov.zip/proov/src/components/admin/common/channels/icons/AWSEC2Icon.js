import React from 'react';
import AWSEC2Icon from 'components/ui/Icons/AWSEC2Icon';
import style from './style.scss';

const AWSEC2IconBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSEC2Icon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS EC2</span> */}
		</div>
	);
};

export default AWSEC2IconBadge;
