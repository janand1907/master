import React from 'react';
import VpnIcon from 'components/ui/Icons/VpnIcon';
import style from './style.scss';

const VpnBadge = () => {
	return (<div className={style.iconWrapper}>
		<div className={style.icons}>
			<VpnIcon className={style.channelIcon} />
		</div>
		<span className={style.type}>VPN</span>
	</div>);
};

export default VpnBadge;
