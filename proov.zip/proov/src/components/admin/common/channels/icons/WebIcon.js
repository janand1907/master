/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import ProovStampIcon from 'components/ui/Icons/ProovStampIcon';
import WebIcon from 'components/ui/Icons/WebIcon';
import cx from 'utils/classNames';
import style from './style.scss';

const WebBadge = ({ is_user_owned, isHideText, className }) => {
	return (
		<div className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<WebIcon className={style.channelIcon} />
				{!is_user_owned && <ProovStampIcon className={style.proovIcon} />}
			</div>
			{!isHideText &&<span className={style.type}>
				Web
			</span>}
		</div>
	);
};

export default WebBadge;

WebBadge.propTypes = {
	is_user_owned: PropTypes.bool
};