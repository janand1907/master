/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import ProovStampIcon from 'components/ui/Icons/ProovStampIcon';
import SaasIcon from 'components/ui/Icons/SaasIcon';
import Lookup from 'components/common/Lookups/Lookup';
import cx from 'utils/classNames';
import style from './style.scss';

const SaasBadge = ({ is_user_owned, isHideText, className }) => {
	return (
		<div className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<SaasIcon className={style.channelIcon} />
				{!is_user_owned && <ProovStampIcon className={style.proovIcon} />}
			</div>
			{!isHideText && <span className={style.type}>
				SaaS
			</span>}
		</div>
	);
};

export default SaasBadge;

SaasBadge.propTypes = {
	is_user_owned: PropTypes.bool,
	isHideText: PropTypes.bool,
	className: PropTypes.string
};