import React from 'react';
import AWSIAMIcon from 'components/ui/Icons/AWSIAMIcon';
import style from './style.scss';

const AWSIAMBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSIAMIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS IAM</span> */}
		</div>
	);
};

export default AWSIAMBadge;

