import React from 'react';
import AWSDynamoDBIcon from 'components/ui/Icons/AWSDynamoDBIcon';
import style from './style.scss';

const AWSDynamoDBBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSDynamoDBIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS Dynamo DB</span> */}
		</div>
	);
};

export default AWSDynamoDBBadge;
