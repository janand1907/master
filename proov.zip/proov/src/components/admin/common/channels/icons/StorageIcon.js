import React from 'react';
import PropTypes from 'prop-types';
import StorageIcon from 'components/ui/Icons/StorageIcon';
import ProovStampIcon from 'components/ui/Icons/ProovStampIcon';
import cx from 'utils/classNames';
import style from './style.scss';

const StorageBadge = ({ is_user_owned, isHideText, className }) => {
	return (
		<div  className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<StorageIcon className={style.channelIcon} />
				{!is_user_owned && <ProovStampIcon className={style.proovIcon} />}
			</div>
			{!isHideText && <span className={style.type}>Storage</span>}
		</div>
	);
};

export default StorageBadge;

StorageBadge.propTypes = {
	is_user_owned: PropTypes.bool
};
