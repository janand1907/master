import React from 'react';
import ServerIcon from './ServerIcon';
import SftpIcon from './SftpIcon';
import DatabaseIcon from './DatabaseIcon';
import ApiIcon from './ApiIcon';
import VpnIcon from './VpnIcon';
import StorageIcon from './StorageIcon';
import BlockchainIcon from './BlockchainIcon';
import DockerIcon from './DockerIcon';
import AWSDynamoDBIcon from './AWSDynamoDBIcon';
import AWSSQSIcon from './AWSSQSIcon';
import AWSCloudFormationIcon from './AWSCloudFormationIcon';
import AWSEC2Icon from './AWSEC2Icon';
import AWSLambdaIcon from './AWSLambdaIcon';
import AWSRDSIcon from './AWSRDSIcon';
import AWSS3BucketIcon from './AWSS3BucketIcon';
import AWSSNSIcon from './AWSSNSIcon';
import AWSEMRIcon from './AWSEMRIcon';
import SaasIcon from './SaasIcon';
import WebIcon from './WebIcon';
import BkpiIcon from './BkpiIcon';
import CustomChartIcon from './CustomChartIcon';

const IconWrapper = data => {
	switch (data.type) {
		case 'server':
			return <ServerIcon os={data.os} is_user_owned={data.is_user_owned} className={data.className} />;
		case 'db':
			return <DatabaseIcon db_type={data.db_type} is_user_owned={data.is_user_owned} className={data.className} />;
		case 'api':
			return <ApiIcon api_type={data.api_type} is_user_owned={data.is_user_owned} className={data.className} isHideText={data.isHideText}/>;
		case 'sftp':
			return <SftpIcon />;
		case 'vpn':
			return <VpnIcon />;
		case 'storage':
			return <StorageIcon is_user_owned={data.is_user_owned} isHideText={data.isHideText} className={data.className} />;
		case 'blockchain':
			return <BlockchainIcon isHideText={data.isHideText} className={data.className} />;
		case 'docker':
			return <DockerIcon is_user_owned={data.is_user_owned} isHideText={data.isHideText} className={data.className} />;
		case 'saas':
			return <SaasIcon is_user_owned={data.is_user_owned} className={data.className} isHideText={data.isHideText}/>;
		case 'web':
			return <WebIcon is_user_owned={data.is_user_owned} isHideText={data.isHideText} className={data.className} />;
		case 'aws_dynamo_db':
			return <AWSDynamoDBIcon />;
		case 'aws_sqs':
			return <AWSSQSIcon />;
		case 'aws_cloud_formation':
			return <AWSCloudFormationIcon />;
		case 'aws_ec2':
			return <AWSEC2Icon />;
		case 'aws_emr':
			return <AWSEMRIcon />;
		case 'aws_lambda':
			return <AWSLambdaIcon />;
		case 'aws_rds':
			return <AWSRDSIcon />;
		case 'aws_s3':
			return <AWSS3BucketIcon />;
		case 'aws_sns':
			return <AWSSNSIcon />;
		case 'B_KPI':
			return <BkpiIcon className={data.className} isHideText={data.isHideText}/>;
		case 'custom_chart':
			return <CustomChartIcon className={data.className} isHideText={data.isHideText}/>;
		default:
			return null;
	}
};

export default IconWrapper;
