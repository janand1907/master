import React from 'react';
import AWSIoTIcon from 'components/ui/Icons/AWSIoTIcon';
import style from './style.scss';

const AWSIoTBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSIoTIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS IoT</span> */}
		</div>
	);
};

export default AWSIoTBadge;
