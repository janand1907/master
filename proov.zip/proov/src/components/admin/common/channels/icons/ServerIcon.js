/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import ServerIcon from 'components/ui/Icons/ServerIcon';
import ProovStampIcon from 'components/ui/Icons/ProovStampIcon';
import Lookup from 'components/common/Lookups/Lookup';
import cx from 'utils/classNames';
import style from './style.scss';

const ServerBadge = ({ is_user_owned, os, className }) => {
	return (
		<div  className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<ServerIcon className={style.channelIcon} />
				{!is_user_owned && <ProovStampIcon className={style.proovIcon} />}
			</div>
			<span className={style.type}>
				<Lookup lookupType="operating_system" lookupKey={os} />
			</span>
		</div>
	);
};

export default ServerBadge;

ServerBadge.propTypes = {
	is_user_owned: PropTypes.bool,
	os: PropTypes.string,
};
