import React from 'react';
import PropTypes from 'prop-types';
import CustomChartIcon from 'components/ui/Icons/CustomChartIcon';
import cx from 'utils/classNames';
import style from './style.scss';

const CustomChartBadge = ({ className, isHideText }) => {

	return (
		<div className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<CustomChartIcon className={style.channelIcon} />
			</div>
			{!isHideText && <span className={style.type}>
				Custom Chart
			</span>}
		</div>
	);
};

export default CustomChartBadge;

CustomChartBadge.propTypes = {
	className: PropTypes.string,
	isHideText: PropTypes.bool,
};
