import React from 'react';
import PropTypes from 'prop-types';
import ApiIcon from 'components/ui/Icons/ApiIcon_v2';
import ProovStampIcon from 'components/ui/Icons/ProovStampIcon';
import cx from 'utils/classNames';
import style from './style.scss';

const ApiBadge = ({ className, is_user_owned, isHideText, api_type }) => {

	return (
		<div className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<ApiIcon className={style.channelIcon} />
				{!is_user_owned && <ProovStampIcon className={style.proovIcon} />}
			</div>
			{!isHideText && <span className={style.type}>
			{api_type ? api_type.toUpperCase() : 'API'}</span>}
		</div>
	);
};

export default ApiBadge;

ApiBadge.propTypes = {
	api_type: PropTypes.string,
	is_user_owned: PropTypes.bool,
	isHideText: PropTypes.bool,
	is_user_owned: PropTypes.bool
};
