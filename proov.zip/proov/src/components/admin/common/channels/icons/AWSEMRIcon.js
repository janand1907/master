import React from 'react';
import AWSEMRIcon from 'components/ui/Icons/AWSEMRIcon';
import style from './style.scss';

const AWSEMRIconBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSEMRIcon className={style.awsChannelIcon} />
			</div>
			{/* <span className={style.type}>AWS EMR</span> */}
		</div>
	);
};

export default AWSEMRIconBadge;
