/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import DataBaseIcon from 'components/ui/Icons/DataBaseIcon';
import ProovStampIcon from 'components/ui/Icons/ProovStampIcon';
import Lookup from 'components/common/Lookups/Lookup';
import cx from 'utils/classNames';
import style from './style.scss';

const DatabaseBadge = ({ db_type, is_user_owned, className }) => { //eslint-disable-line camelcase

	return (
		<div  className={cx(style.iconWrapper, className)}>
			<div className={style.icons}>
				<DataBaseIcon className={style.channelIcon} />
				{!is_user_owned && <ProovStampIcon className={style.proovIcon} />}
			</div>
			<span className={style.type}>
				<Lookup lookupType="db_type" lookupKey={db_type} lookupValue={v => v.label} />
			</span>
		</div>
	);
};

export default DatabaseBadge;

DatabaseBadge.propTypes = {
	db_type: PropTypes.string,
	is_user_owned: PropTypes.bool,
};
