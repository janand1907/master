import React from 'react';
import AWSRDSIcon from 'components/ui/Icons/AWSRDSIcon';
import style from './style.scss';

const AWSRDSBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSRDSIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS RDS</span> */}
		</div>
	);
};

export default AWSRDSBadge;
