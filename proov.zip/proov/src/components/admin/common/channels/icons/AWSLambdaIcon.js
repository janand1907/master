import React from 'react';
import AWSLambdaIcon from 'components/ui/Icons/AWSLambdaIcon';
import style from './style.scss';

const AWSLambdaBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSLambdaIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS Lambda</span> */}
		</div>
	);
};

export default AWSLambdaBadge;

