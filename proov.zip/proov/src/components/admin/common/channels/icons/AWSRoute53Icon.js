import React from 'react';
import AWSRoute53Icon from 'components/ui/Icons/AWSRoute53Icon';
import style from './style.scss';

const AWSRoute53Badge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSRoute53Icon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS Route 53</span> */}
		</div>
	);
};

export default AWSRoute53Badge;
