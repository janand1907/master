import React from 'react';
import AWSECSIcon from 'components/ui/Icons/AWSECSIcon';
import style from './style.scss';

const AWSECSBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSECSIcon className={style.awsChannelIcon}/>
			</div>
			{/* <span className={style.type}>AWS ECS</span> */}
		</div>
	);
};

export default AWSECSBadge;
