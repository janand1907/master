import React from 'react';
import AWSAPIGatewayIcon from 'components/ui/Icons/AWSAPIGatewayIcon';
import style from './style.scss';

const AWSAPIGatewayBadge = () => {
	return (
		<div className={style.iconWrapper}>
			<div className={style.icons}>
				<AWSAPIGatewayIcon className={style.awsChannelIcon} />
			</div>
			{/* <span className={style.type}>AWS API Gateway</span> */}
		</div>
	);
};

export default AWSAPIGatewayBadge;
