import { LAB, SAFEZONE, AWS_SC } from 'constants/pilotTypes';
import { DELETED as CHANNEL_DELETED } from 'constants/channel/channelStatus';
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Link } from 'react-router-dom';
import {
	getAdminPilot,
	getAdminPilotPending,
} from 'ducks/admin/pilot/selectors';
import { getChannels } from 'ducks/admin/pilot/channel/selectors';
import { getSubscription } from 'ducks/myAccount/selectors';
import { showModal } from 'ducks/modal/actions';
import { createToast } from 'ducks/toaster/actions';
import infoImage from 'assets/images/create_pilot.png';
import Spinner from 'components/ui/Spinner/Spinner';
import * as i18n from 'i18n/en/pilotView.json';
import Permission from 'components/Permission';
import SearchBox from 'components/ui/SearchBox/SearchBox';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import AWSTemplateContainer from '../../pilotView/client/environment/awsTemplate/AWSTemplateContainer';
import ChannelList from './ChannelList';
import style from './ChannelListContainer.scss';


function ChannelContainer({
	actions,
	dispatch,
	environment,
	pilotStatus,
	pilotType,
	pilotId,
	pendingUpdate,
	subscription,
}) {

	const [searchText, setSearchText] = useState("");

	const handleAdd = React.useCallback(() => {
		const instanceLimitExceeded =
			subscription.instance.usage === subscription.instance.limit;
		const serverLimitExceeded =
			subscription.server.usage === subscription.server.limit;
		const dbLimitExceeded = subscription.db.usage === subscription.db.limit;
		const apiLimitExceeded = subscription.api.usage === subscription.api.limit;
		const storageLimitExceeded =
			subscription.storage.usage === subscription.storage.limit;
		const blockchainLimitExceeded =
			subscription.blockchain.usage === subscription.blockchain.limit;
		const dockerLimitExceeded =
			subscription.docker.usage === subscription.docker.limit;

		if (
			instanceLimitExceeded &&
			serverLimitExceeded &&
			dbLimitExceeded &&
			apiLimitExceeded &&
			storageLimitExceeded &&
			blockchainLimitExceeded &&
			dockerLimitExceeded
		) {
			actions.createToast(
				{ message: `Subscription Limit Exceeded` },
				{ type: 'error' }
			);
		} else {
			dispatch(showModal('CreateChannel', { pilotType }));
		}
	}, [subscription, dispatch, actions]);

	const handleFilterChanged = (e) => {
		setSearchText(e.target.value);
	}

	const getEnvironment = () => {
		const notSearchableKeys = ['password_file', 'id', 'isv_access', 'password_file', 'version'];
		const notSearchableValue = [true, false, null];
		const environmentNotDeleted = environment.filter((item) => item.status !== CHANNEL_DELETED.value);
		if (searchText === "")
			return environmentNotDeleted;
		return environmentNotDeleted.filter(env => {
			const newEnv = env.status === 'ready' ? { ...env, status: 'active' } : env;
			return Object.entries(newEnv)
				.filter(arr =>
					!(notSearchableKeys.includes(arr[0]))
					&& !(notSearchableValue.includes(arr[1])))
				.map(arr => arr[1])
				.filter(i => i && (i).toString().toLowerCase().includes(searchText.toLowerCase()))
				.length > 0;
		})
	}

	const pocEnvironmentTooltipText = () => {
		switch (pilotType) {
			case LAB: return 'Cloud Lab'; break;
			case SAFEZONE: return 'SafeZone'; break;
			case AWS_SC: return 'Red Cloud'; break;
		}
	}

	const handleEdit = React.useCallback(
		(channel) => {
			dispatch(showModal('EditChannel', { channelId: channel.id, pilotType }));
		},
		[dispatch]
	);

	if (!environment) {
		return <Spinner className={style.Spinner} />;
	}

	const filteredEnvironments = getEnvironment();
	return (
		<div className={style.channelList}>
			{pilotType === AWS_SC && <AWSTemplateContainer />}

			<header className={style.header}>
				<TooltipTarget
					tooltip={<Tooltip placement={'left'}>{pocEnvironmentTooltipText()}</Tooltip>}
					className={style.iconTooltipWrapper}
				>
					<img src={infoImage} className={style.envDescriptionImg} />
				</TooltipTarget>
				<SearchBox
					className={style.searchBox}
					onTextChanged={handleFilterChanged}
					placeholder={'Search'}
				/>
				<div className={style.newChannelWrapper}><Permission
					alias="Channel#create"
					component={
						<button
							className={style.newChannelBtn}
							onClick={handleAdd}
							disabled={
								pilotStatus === 'terminated' || pilotStatus === 'completed'
							}
						>
							New Channel
						</button>
					}
				/></div>
			</header>
			{searchText !== "" && <span className={style.numOfInstances}>{filteredEnvironments.length} INSTANCES</span>}
			{!filteredEnvironments.length && <div className={style.noItemsLayout}><p >{globalize.parseString(i18n.client.noEnvironmentLayout)}</p></div>}
			<ChannelList
				className={style.proovEnvironmentList}
				channels={filteredEnvironments}
				pending={pendingUpdate}
				pilotStatus={pilotStatus}
				pilotType={pilotType}
				actions={actions}
				onEdit={handleEdit}
			/>
			{pilotType === SAFEZONE && !environment.length && (
				<p className={style.safeZone}>
					{globalize.parseString(i18n.client.safeZone.note)}
					<br />
					{'To do so, go to '}
					<Link to={`/admin/pilot/${pilotId}/details/safezone-installation`}>
						SafeZone Installation
					</Link>
				</p>
			)}
		</div>
	);
}

function mapStateToProps(state) {
	const pilot = getAdminPilot(state);
	const pending = getAdminPilotPending(state);
	const environment = getChannels(state);
	const subscription = getSubscription(state);

	return {
		pilotId: pilot.id,
		subscription: subscription.total,
		environment: environment,
		pilotStatus: pilot.status,
		pilotType: pilot.pilot_type,
		pendingUpdate: pending.update,
	};
}

function mapDispatchToProps(dispatch) {
	return {
		dispatch: dispatch,
		actions: bindActionCreators({ showModal, createToast }, dispatch),
	};
}

ChannelContainer.propTypes = {
	subscription: PropTypes.object.isRequired,
	pilotStatus: PropTypes.string.isRequired,
	environment: PropTypes.array.isRequired,
	pilotId: PropTypes.string.isRequired,
	actions: PropTypes.object.isRequired,
	dispatch: PropTypes.func,
	pendingUpdate: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
	pilotType: PropTypes.string.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(ChannelContainer);
