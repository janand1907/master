import * as PILOT_STATUS from 'constants/pilotStatus';
import * as PILOT_TYPES from 'constants/pilotTypes';
import React from 'react';
import { groupBy } from 'lodash';
import PropTypes from 'prop-types';
import ChannelCardLab from './channelCard/channelCardLab/ChannelCardLab';
import ChannelCardAWS from './channelCard/channelCardAWS/ChannelCardAWS';
import ChannelCardPoP from './channelCard/channelCardPoP/ChannelCardPoP';
import * as style from './ChannelListContainer.scss';

const ChannelList = ({
	channels,
	pilotStatus /* used to condition dataset edit option*/,
	onEdit,
	actions,
	pending,
	pilotType,
	className,
}) => {
	let Component;
	switch (pilotType) {
		case PILOT_TYPES.SAFEZONE:
			Component = ChannelCardPoP;
			break;
		default:
			Component = ChannelCardLab;
			break;
	}

	const environments = groupBy(channels, ({ product_name }) => product_name);
	return Object.entries(environments).map((environment) => {
		const [productName, channels] = environment;
		const isServiceCatalogPortfolioTemplate = productName !== 'undefined';
		return (
			<div key={productName} className={className}>
				{pilotType === PILOT_TYPES.AWS_SC && (
					<div className={style.productId}>
						{isServiceCatalogPortfolioTemplate
							? `Product Name: ${productName}`
							: 'prooV Environment'}
					</div>
				)}
				{isServiceCatalogPortfolioTemplate
					? channels.map((channel) => (
						<ChannelCardAWS
							key={channel.id}
							data={channel}
							pilotStatus={pilotStatus}
						/>
					))
					: channels.map((channel) => (
						<Component
							key={channel.id}
							data={channel}
							pending={pending}
							pilotStatus={pilotStatus}
							actions={actions}
							edit={onEdit}
							pilotType={pilotType}
						/>
					))}
			</div>
		);
	});
};

export default ChannelList;

ChannelList.propTypes = {
	channels: PropTypes.array,
	pending: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
	className: PropTypes.string,
	pilotStatus: PropTypes.oneOf([
		PILOT_STATUS.ACTIVE,
		PILOT_STATUS.COMPLETED,
		PILOT_STATUS.FUTURE,
		PILOT_STATUS.PREPARATION,
		PILOT_STATUS.CONFIGURATION,
		PILOT_STATUS.DEPLOYMENT,
		PILOT_STATUS.EXECUTION,
		PILOT_STATUS.EVALUATION,
		PILOT_STATUS.JOINING,
	]),
	actions: PropTypes.object,
	onEdit: PropTypes.func,
	pilotType: PropTypes.string,
};
