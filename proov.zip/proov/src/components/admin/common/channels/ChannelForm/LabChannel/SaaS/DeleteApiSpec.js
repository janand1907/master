import React from 'react';
import PropTypes from 'prop-types';
import { Spinner } from 'components/ui/Spinner';
import { deletePilotChannel } from 'ducks/admin/pilot/channel/actions';
import { hideModal } from 'ducks/modal/actions';
import { connect } from 'react-redux';
import { Alert } from 'components/ui/Alert';
import * as i18n from 'i18n/en/channelForm.json';
import style from './DeleteApiSpec.scss';

const DeleteApiSpec = ({ channel, pending, pilotId, hideModal, deletePilotChannel }) => {
   const handleConfirm = () => {
        deletePilotChannel(
            pilotId,
            channel.id,
            channel.name,
            channel.type,
        )
    }

    return (
        <div className={style.root}>
            <h4 >{i18n.deleteSpec.areYouSure}</h4>
            <div>
                <p>{i18n.deleteSpec.deleteMessage}</p>
            </div>

            <div>
                <button type="button" className={style.btnCancel} onClick={() => hideModal()} >
                    {i18n.deleteSpec.cancel}
                </button>
                <button
                    type="button"
                    className={style.btnConfirm}
                    onClick={() => handleConfirm()}

                >
                    {i18n.deleteSpec.confirm} {pending && <Spinner />}
                </button>
            </div>
        </div>
    );
};

DeleteApiSpec.propTypes = {
    channel: PropTypes.object.isRequired,
    pending: PropTypes.bool.isRequired,
    error: PropTypes.string,
    onDelete: PropTypes.func.isRequired,
    onCancel: PropTypes.func.isRequired
};
export default connect(null, { hideModal, deletePilotChannel })(
    DeleteApiSpec
);