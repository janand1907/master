/* eslint-disable react/no-multi-comp */
import React from 'react';
import PropTypes from 'prop-types';
import DbForm from './edit/DbForm';
import ServerForm from './edit/ServerForm';
import ApiForm from './edit/ApiForm';
import style from './../../style.scss';


const EditChannelForm = props => {

	const editChannelFormFactory = props => {
		const { channel } = props;
		const forms = {
			db: DbForm,
			api: ApiForm,
			server: ServerForm
		};

		const Component = forms[channel.type];

		return React.createElement(Component, { ...props });
	};

	return editChannelFormFactory(props);

};

EditChannelForm.propTypes = {
	channel: PropTypes.object.isRequired,
};

export default EditChannelForm;
