/* eslint-disable react/no-multi-comp */
import React from 'react';
import PropTypes from 'prop-types';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import { Spinner } from 'components/ui/Spinner';
import BehaviorMirroringFields from '../../common/commonFields/BehaviorMirroringFields';
import DeleteChannelForm from '../DeleteChannelForm';
import ServerFields from './edit/ServerFields';
import DbFields from './edit/DbFields';
import ApiFields from './edit/ApiFields';
import ApiFieldsProov from './edit/ApiFieldsProov';
import VpnFields from './edit/VpnFields';
import SftpFields from './edit/SftpFields';
import StorageFields from './edit/StorageFields';
import style from './../../style.scss';

const renderFieldsForType = (model, data, isWizard, mediaPending, disabled) => {
	const authType = model.auth_type
		? model.auth_type
		: model.auth && model.auth.type
			? model.auth.type
			: undefined;

	switch (model.type) {
		case 'server':
			return (
				<ServerFields
					isWizard={isWizard}
					isProovOwned={model.is_proov_owned}
					channel={data}
					authType={authType}
					operatingSystem={model.os}
					isAssingningCredentials={model.is_assingning_credentials}
				/>
			);
		case 'db':
			return (
				<DbFields
					disabled={disabled}
					isProovOwned={model.is_proov_owned}
					dbType={model.db_type}
					restrictTables={model.restrict_tables}
					channel={data}
					isAssingningCredentials={model.is_assingning_credentials}
				/>
			);
		case 'api':
			return model.is_proov_owned ? (
				<ApiFieldsProov apiType={model.api_type} source={model.source} channel={data} />
			) : (
				<ApiFields
					apiType={model.api_type}
					authType={authType}
					mediaPending={mediaPending}
					channel={data}
				/>
			);
		case 'vpn':
			return <VpnFields />;
		case 'sftp':
			return <SftpFields />;
		case 'storage':
			return <StorageFields envData={data} />;
		// case 'blockchain': return <BlockchainFields envData={data} />; // RD-5292
		default: return null;
	}
};

class EditChannelForm extends React.Component {
	constructor() {
		super();
		this.handleCancel = this.handleCancel.bind(this);
		this.handleDelete = this.handleDelete.bind(this);
		this.handleClickDelete = this.handleClickDelete.bind(this);
		this.handleCancelDelete = this.handleCancelDelete.bind(this);
		this.state = { deleteView: false };
	}

	handleCancel() {
		this.props.onCancel();
	}

	handleDelete(channelId, channelName, channelType) {
		this.props.onDelete(channelId, channelName, channelType);
	}

	// Two functions for ClicklDelete?
	handleClickDelete(channel) {
		this.setState({ deleteView: true, channel });
	}

	handleCancelDelete() {
		this.setState({ deleteView: false, channel: null });
	}

	render() {
		const { model, pending, isWizard, formProps, onUploadApiFile, mediaPending, error, disabled } = this.props;
		return this.state.deleteView ?
			<DeleteChannelForm
				channel={this.state.channel}
				onDelete={this.handleDelete}
				onCancel={this.handleCancelDelete}
				hideModal={this.hideModal}
				pending={pending}
				error={error}
			/>
			:
			(<Form {...formProps}>
				<div ref={c => this.scrollArea = c} className={style.content}>
					<Field name="type" component="input" type="hidden" />
					<Field name="id" component="input" type="hidden" />
					<Field name="is_proov_owned" component="input" type="hidden" />
					{(model.type === 'server' || model.type === 'api') && <Field name="auth_type" component="input" type="hidden" />}
					{model.type === 'server' && <Field name="os" component="input" type="hidden" />}
					<FormGroup key="name" label="Connection Name" mandatory>
						<Field name="name" disabled={disabled} component="input" type="text" className="form-control" maxLength="35" placeholder="Enter a name for the connection" />
						<Error sticky name="name" />
					</FormGroup>
					{model.type === 'server' && model.is_proov_owned && !formProps.initialValues.is_dedicated && <BehaviorMirroringFields key="enableBehaviorMirroring" isEnabled={model.bm && model.bm.enabled} />}
					{model && renderFieldsForType(model, formProps.initialValues, isWizard, onUploadApiFile, mediaPending, disabled)}
				</div>
				<div className={style.footer}>
					<button type="button" disabled={pending} className={style.btnDelete} onClick={() => this.handleClickDelete(model)}>Delete</button>
					<button type="button" disabled={pending} className={style.btnCancel} onClick={this.handleCancel}>Cancel</button>
					<button type="submit" disabled={pending || mediaPending || disabled} className={style.btnCreate}>Update {pending && <Spinner />}</button>
				</div>
			</Form>);
	}
}

EditChannelForm.propTypes = {
	isWizard: PropTypes.bool,
	disabled: PropTypes.bool.isRequired,
	formProps: PropTypes.object.isRequired,
	pending: PropTypes.bool.isRequired,
	mediaPending: PropTypes.bool.isRequired,
	model: PropTypes.object,
	allowVPN: PropTypes.bool,
	onCancel: PropTypes.func.isRequired,
	onUploadApiFile: PropTypes.func.isRequired,
	onDelete: PropTypes.func.isRequired,
	error: PropTypes.string,
};


export default EditChannelForm;
