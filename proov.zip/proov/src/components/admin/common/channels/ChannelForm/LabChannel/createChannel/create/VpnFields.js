import React from 'react';
import LookupSelectField from '../../../commonFields/LookupSelectField';
import IPAndPortField from '../../../commonFields/IPAndPortField';
import UsernamePasswordField from '../../../commonFields/UsernamePasswordField';

const VPNFields = () => {
	return (
		<div>
			<LookupSelectField label="VPN Type" name="vpn_type" lookupSelectProps={{ lookupType: 'vpn_type', defaultOption: 'Select VPN type...' }} />
			<IPAndPortField ipName="ip_address" portName="port" />
			<UsernamePasswordField />
		</div>
	);
};

export default VPNFields;
