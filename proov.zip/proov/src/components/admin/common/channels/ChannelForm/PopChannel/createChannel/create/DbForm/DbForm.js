import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import cx from 'utils/classNames';
import { getAdminPilotProxy } from 'ducks/admin/pilot/selectors';
import SafeZoneProxy from 'components/admin/common/commonFields/SafeZoneProxy';
import LookupSelectField from 'components/admin/common/commonFields/LookupSelectField';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import style from '../../../../style.scss';
import DbUserOwnedFields from './DbUserOwnedFields';

const DbForm = ({ model, proxy, scrollBottom, commonFormsConfig }) => {
	return (
		<Form noValidate {...commonFormsConfig}>
			<Field name="type" component="input" type="hidden" />
			<Field name="is_user_owned" component="input" type="hidden" />

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			<SafeZoneProxy key="proxy" proxy={proxy} />

			<LookupSelectField
				key="dbType"
				label="Database Type"
				name="db_type"
				isPoP
				lookupSelectProps={{
					lookupType: 'db_type',
					defaultOption: 'Select database type...'
					// onFocus: scrollBottom
				}}
			/>

			<DbUserOwnedFields model={model} />

			<div key="user_details_scheme_id" className={style.popContainer}>
				<div className={cx(style.type, style.disabled)}>
					<FormGroup
						labelClassName={style.label}
						key="pop"
						label="prooV SafeZone"
						mandatory={
							model.user_owned && !Object.values(model.user_owned).some(v => !!v)
						}
					>
						<IPAndPortField
							fullWidth
							key="ipPortPop"
							ipName="safe_zone.ip_address"
							portName="safe_zone.port"
							mandatory={
								model.user_owned && !Object.values(model.user_owned).some(v => !!v)
							}
						/>
					</FormGroup>
				</div>

				<div className={cx(style.type, style.disabled)}>
					<FormGroup
						labelClassName={style.label}
						key="userOwned"
						label="Customer Environment"
						mandatory={model.safe_zone && !Object.values(model.safe_zone).some(v => !!v)}
					>
						<IPAndPortField
							fullWidth
							key="ipPortUserOwned"
							ipName="user_owned.ip_address"
							portName="user_owned.port"
							mandatory={model.safe_zone && !Object.values(model.safe_zone).some(v => !!v)}
						/>
					</FormGroup>
				</div>
			</div>
		</Form>
	);
};

DbForm.propTypes = {
	scrollBottom: PropTypes.func,
	model: PropTypes.object,
	proxy: PropTypes.string,
	commonFormsConfig: PropTypes.object
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.selectedForm) || {};
	const proxy = getAdminPilotProxy(state);
	return { model, proxy };
}

export default connect(
	mapStateToProps,
	null
)(DbForm);
