import React from 'react';
import PropTypes from 'prop-types';
import EnvStatus from 'components/admin/common/channels/ChannelStatus/ChannelStatus';
import IconWrapper from 'components/admin/common/channels/icons/IconWrapper';
import style from '../../style.scss';

const EditChannelFormHeader = ({ data }) => {
	return (
		<div className={style.editHeader}>
			<div className={style.iconContainer}>
				<IconWrapper {...data} />
			</div>
			<div className={style.dataContainer}>
				<p className={style.name}>{data.name}</p>
				{data.status && <EnvStatus status={data.status} />}
				{data.bm && data.bm.enabled && <div><EnvStatus bmStatus={data.bm.status} /></div>}
			</div>
		</div>
	);
};

EditChannelFormHeader.propTypes = {
	data: PropTypes.object
};

export default EditChannelFormHeader;
