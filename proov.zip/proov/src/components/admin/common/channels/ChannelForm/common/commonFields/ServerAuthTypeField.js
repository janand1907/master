import React from 'react';
import PropTypes from 'prop-types';
import cx from 'utils/classNames';
import { RadioGroup, Radio } from 'components/ui/RadioGroup';
import { Field, Error, FormGroup } from 'components/common/Forms';
import UsernameField from '../commonFields/UsernameField';
import UsernamePasswordField from '../commonFields/UsernamePasswordField';
import style from '../../style.scss';
import UploadFile from './UploadFile';

const ServerAuthTypeField = ({ authType, disabled }) => {
	const uploadFile = [
		<UsernameField key="username" fieldName="username" />,
		<UploadFile key="password" fileName="password_pem" allowedFiles={['pem']} label="">
			Drag and drop your PEM file here
			<br />
			or <span className={style.dropZoneLink}>upload</span> from your computer
		</UploadFile>
	];

	return (
		<div>
			<FormGroup>
				<Field
					key="authType"
					name="auth_type"
					validateOn="change"
					defaultValue="basic"
					component={({ input }) => (
						<RadioGroup
							name={input.name}
							selectedValue={input.value}
							onChange={input.onChange}
						>
							<label className={cx(style.authRadio, 'form-check-inline')}>
								<Radio disabled={disabled} value="basic" className="form-control" />
								Basic
							</label>
							<label className={cx(style.authRadio, 'form-check-inline')}>
								<Radio disabled={disabled} value="pem" className="form-control" />
								PEM
							</label>
						</RadioGroup>
					)}
				/>
				<Error sticky name="auth_type" />
			</FormGroup>
			{authType === 'basic' ? (
				<UsernamePasswordField />
			) : authType === 'pem' ? (
				uploadFile
			) : null}
		</div>
	);
};

ServerAuthTypeField.propTypes = {
	authType: PropTypes.string,
	disabled: PropTypes.bool
};

export default ServerAuthTypeField;
