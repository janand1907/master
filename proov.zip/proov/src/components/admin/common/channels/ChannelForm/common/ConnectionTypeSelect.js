import * as PILOT_TYPES from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
import Select from 'components/ui/Select/Select';
import { connect } from 'react-redux';
import style from './../style.scss';
import { getSubscription } from 'ducks/myAccount/selectors';

const ConnectionTypeSelect = ({ subscription, changeEndpointType, value, type, componentTypesOptions }) => {

	const componentTypesLab = {
		server: 'Server',
		docker: 'Docker',
		db: 'Database',
		api: 'API',
		saas: 'SaaS',
		sftp: 'SFTP',
		storage: 'Secured File Storage',
		blockchain: 'prooV Blockchain Lab',
		web: 'Web Channel'
		// vpn: 'VPN', // Temporarly depreciated: RD-5138
	};

	const componentTypesPop = {
		server: 'Server',
		db: 'Database',
		api: 'API'
	};

	const componentTypes = type => {
		switch (type) {
			case PILOT_TYPES.LAB:
				return componentTypesLab;

			case PILOT_TYPES.SAFEZONE:
				return componentTypesPop;
			default:
				return componentTypesLab;
		}
	};
	const getComponentTypes = (type, value) => {
		let typeSubscription;
		if (componentTypesOptions) {
			typeSubscription = componentTypesOptions;
		}
		else {
			let types = componentTypes(type);
			typeSubscription = Object.keys(types).filter(key => subscription[key] && subscription[key].usage < subscription[key].limit)
			typeSubscription = typeSubscription.reduce((obj, key) => {
				obj[key] = types[key];
				return obj;
			}, {});
		}
		if (!typeSubscription.hasOwnProperty(value)) {
			changeEndpointType(Object.keys(typeSubscription)[0]);
		}
		return sortObjectByAlphaBeta(typeSubscription);
	}
	const sortObjectByAlphaBeta = (obj) => {
		const filteredArr = Object.entries(obj).sort((a, b) => a[1].localeCompare(b[1]))
		return Object.assign(...filteredArr.map(([key, val]) => ({ [key]: val })))
	}
	return (
		<div style={{ margin: '20px 0' }}>
			<label className="form-group-label">
				Connection Type<span className="mandatory">*</span>
			</label>
			<Select
				required
				className={style.selectType}
				options={getComponentTypes(type, value)}
				onChange={changeEndpointType}
				value={value}
			/>
		</div>
	);
};

ConnectionTypeSelect.propTypes = {
	changeEndpointType: PropTypes.func,
	value: PropTypes.string,
	type: PropTypes.string,
	subscription: PropTypes.object
};
function mapStateToProps(state) {
	const subscription = getSubscription(state);

	return {
		subscription: subscription.total,
	};
}
export default connect(mapStateToProps, null)(ConnectionTypeSelect);
