import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';

const UsernameField = ({ fieldName, ...props }) => {
	return (
		<FormGroup label="Username" mandatory {...props}>
			<Field name={fieldName} component="input" type="text" autoComplete="off" maxLength={110} className="form-control" />
			<Error sticky name={fieldName} />
		</FormGroup>
	);
};

UsernameField.propTypes = {
	fieldName: PropTypes.string.isRequired
};

export default UsernameField;
