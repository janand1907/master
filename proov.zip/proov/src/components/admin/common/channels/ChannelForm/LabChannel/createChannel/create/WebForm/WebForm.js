import React from 'react';
import PropTypes from 'prop-types';
import { merge } from 'lodash';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';

const WebForm = ({ commonFormsConfig }) => {
	const apiFormConfig = {
		initialValues: {
			is_dedicated: true,
			is_user_owned: false
		}
	};
	const formConfig = merge(apiFormConfig, commonFormsConfig);

	return (
		<Form noValidate {...formConfig}>
			<Field name="type" component="input" type="hidden" />
			<Field name="is_user_owned" component="input" type="hidden" />
			<Field name="is_dedicated" component="input" type="hidden" />

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>
		</Form>
	);
};

WebForm.propTypes = {
	commonFormsConfig: PropTypes.object,
};

export default WebForm;