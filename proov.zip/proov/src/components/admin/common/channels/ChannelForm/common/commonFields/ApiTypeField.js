import React from 'react';
import PropTypes from 'prop-types';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import { FormGroup, Field, Error } from 'components/common/Forms';
import style from '../../style.scss';

const ApiTypeField = ({ ...props }) => {
	return (
		<FormGroup label={!props.hideLabel ? 'API Type' : ''} mandatory {...props}>
			<Field
				name="api_type"
				validateOn="change"
				component={({ input }) => (
					<RadioGroup name={input.name} selectedValue={input.value} onChange={input.onChange} className={style.controlPushMdWrapper}>
						<PushButton value="rest" className={style.controlPushMd}>REST</PushButton>
						<PushButton value="soap" className={style.controlPushMd}>SOAP</PushButton>
					</RadioGroup>
				)}
			/>
			<Error sticky name="api_type" />
		</FormGroup>
	);
};

ApiTypeField.propTypes = {
	hideLabel: PropTypes.bool
};

export default ApiTypeField;
