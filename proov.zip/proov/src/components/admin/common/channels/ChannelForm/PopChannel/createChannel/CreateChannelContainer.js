/* eslint-disable react/no-multi-comp */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
	getAdminPilot,
	getAdminPilotPending
} from 'ducks/admin/pilot/selectors';
import { modelSelector } from 'ducks/forms/selectors';
import {
	uploadMediaFile,
	addPilotChannel
} from 'ducks/admin/pilot/channel/actions';
import { hideModal } from 'ducks/modal/actions';
import { channelTransformInitialValue } from 'utils/transformEnvironment';
import { Spinner } from 'components/ui/Spinner';
import style from '../../style.scss';
import validate from './../validation';
import CreateChannelForm from './CreateChannelForm';

class CreateChannelContainer extends React.Component {
	constructor(props) {
		super(props);

		this.handleCancel = this.handleCancel.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
		this._formRef = this._formRef.bind(this);
		this.handleConnectionTypeChange = this.handleConnectionTypeChange.bind(
			this
		);
		this.handleScrollBottom = this.handleScrollBottom.bind(this);
		this.handleUploadMediaFile = this.handleUploadMediaFile.bind(this);

		this.state = {
			connectionType:
				props.isWizardEdit || props.channelType
					? (props.channel && props.channel.type) || props.channelType
					: 'server'
		};
	}

	// componentDidMount() {
	// 	// For wizard, set errors coming from server
	// 	if (this.props.errors) { this._form.setErrors(this.props.errors) }
	// }

	_formRef(node) {
		if (node) {
			this._form = node.getWrappedInstance();
		}
	}

	handleCancel() {
		this.props.hideModal();
	}

	handleUploadMediaFile(file, fieldName) {
		if (!file) return;

		const { connectionType } = this.state;
		this.props.uploadMediaFile(file, connectionType, fieldName);
	}

	handleConnectionTypeChange(newConnectionType) {
		if (newConnectionType === this.state.connectionType) return;

		this.setState({ connectionType: newConnectionType });
	}

	handleSubmit(values) {
		if (!this._form.validate()) return;

		this.props.addPilotChannel(this.props.pilotId, values, 'pop');
	}

	handleValidationFailed(errors) {
		for (let i = 0; i < Object.keys(errors).length; i++) {
			const errElm = document.getElementsByName(Object.keys(errors)[i])[0];
			if (errElm) {
				errElm.scrollIntoView();
				break;
			}
		}
	}

	/* eslint-disable camelcase */
	initialValues() {
		const { pilot } = this.props;
		const { connectionType } = this.state;
		return {
			type: connectionType,
			auth: { type: 'none', grant_type: 'client_credentials' },
			is_user_owned: true,
			is_direct_access: !!pilot.proxy_ip,
			is_assingning_credentials: false
		};
	}
	/* eslint-enable camelcase */

	handleScrollBottom() {
		this.scrollArea.scrollTop = this.scrollArea.scrollHeight;
	}

	// submitLabel(isWizard, isWizardEdit) {
	// 	if (isWizard) {
	// 		return (isWizardEdit && 'Update') || 'Add';
	// 	} else {
	// 		return 'Create';
	// 	}
	// }

	render() {
		const { pending } = this.props;
		const { connectionType } = this.state;

		const commonFormsConfig = {
			form: connectionType,
			ref: this._formRef,
			preserve: true,
			onSubmit: this.handleSubmit,
			onSubmitValidationFail: this.handleValidationFailed,
			initialValues: this.initialValues(),
			validators: validate
		};

		return (
			<div className={style.modal}>
				<div className={style.header}>
					<h2>New Environment</h2>
				</div>

				<div ref={c => (this.scrollArea = c)} className={style.content}>
					<CreateChannelForm
						onConnectionTypeChange={this.handleConnectionTypeChange}
						selectedForm={connectionType}
						commonFormsConfig={commonFormsConfig}
						onUploadApiFile={this.handleUploadMediaFile}
						onCancel={this.handleCancel}
						pending={pending.update || pending.fields}
						mediaPending={pending.media}
						scrollBottom={this.handleScrollBottom}
						formRef={this._form}
					/>
				</div>

				<div className={style.footer}>
					<button
						type="button"
						disabled={pending.update || pending.fields}
						className={style.btnCancel}
						onClick={this.handleCancel}
					>
						Cancel
					</button>
					<button
						type="submit"
						disabled={pending.update || pending.fields || pending.media}
						className={style.btnCreate}
						onClick={() => this._form.submit()}
					>
						Create
						{(pending.update || pending.fields) && <Spinner />}
					</button>
				</div>
			</div>
		);
	}
}

CreateChannelContainer.propTypes = {
	// //wizard
	channel: PropTypes.object,
	// onSave: PropTypes.func,
	// errors: PropTypes.object, // Errors for wizard
	// isWizard: PropTypes.bool,
	isWizardEdit: PropTypes.bool,

	//mapStateToProps
	pilot: PropTypes.object,
	pilotId: PropTypes.string, // AddChannel flow
	pending: PropTypes.object.isRequired,
	isDedicatedAllowed: PropTypes.bool,
	channelType: PropTypes.string,

	//mapDispatchToProps
	hideModal: PropTypes.func,
	uploadMediaFile: PropTypes.func,
	addPilotChannel: PropTypes.func
};

function mapStateToProps(state) {
	// let environment, channel;

	const pilot = getAdminPilot(state);
	const pending = getAdminPilotPending(state);
	const pilotId = pilot ? pilot.id : null;

	// if (ownProps.isWizard) {
	// 	environment = modelSelector(state, 'createPilot', 'environment') || [];
	// 	channel = ownProps.channelIndex >= 0 ? environment[ownProps.channelIndex] : null;
	// } else {
	// 	environment = pilot.environment;
	// }

	return { pilot, pending, pilotId };
}

function mapDispatchToProps(dispatch) {
	return {
		hideModal: () => dispatch(hideModal()),
		uploadMediaFile: (file, formName, fieldName) =>
			dispatch(uploadMediaFile(file, formName, fieldName)),
		addPilotChannel: (pilotId, values, type) =>
			dispatch(addPilotChannel(pilotId, values, type))
	};
}

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(CreateChannelContainer);
