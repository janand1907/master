/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { merge } from 'lodash';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import Select from 'components/ui/Select/Select';
import style from '../../../../style.scss';

const BlockchainForm = ({ commonFormsConfig }) => {

	const blockchain_types = {
		ethereum: 'Ethereum'
	};

	const blockchainFormConfig = {
		initialValues: {
			node_num: 2,
			init_balance: 0,
			blockchain_type: 'ethereum',
		}
	};

	const formConfig = merge(blockchainFormConfig, commonFormsConfig);

	return (
		<Form noValidate {...formConfig}>
			<Field name="type" component="input" type="hidden" />

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			<FormGroup key="blockchain_type" label="Blockchain Type" mandatory>
				<Field
					name="blockchain_type"
					validateOn={['blur', 'change']}
					component={({ input }) => (
						<Select options={blockchain_types} className={style.selectType} value={input.value} {...input} required />
					)}
				/>
				<Error sticky name="blockchain_type" />
			</FormGroup>

			<FormGroup key="node_num" label="Number of Nodes" mandatory>
				<Field
					type="number"
					name="node_num"
					component="input"
					placeholder="2 - 5"
					min="2"
					max="5"
					className="form-control"
					required
				/>
				<Error sticky name="node_num" />
			</FormGroup>

			<FormGroup key="init_balance" label="Initial Balance" mandatory>
				<Field
					type="number"
					name="init_balance"
					component="input"
					placeholder="0 - 1000000"
					min="0"
					max="1000000"
					className="form-control"
					required
				/>
				<Error sticky name="init_balance" />
			</FormGroup>

		</Form>
	);
};

//modal
BlockchainForm.propTypes = {
	commonFormsConfig: PropTypes.object,
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.selectedForm) || {};
	return { model };
}

export default connect(
	mapStateToProps,
	null
)(BlockchainForm);
