/* eslint-disable complexity */
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getAdminPilotProxy } from 'ducks/admin/pilot/selectors';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import SafeZoneProxy from 'components/admin/common/commonFields/SafeZoneProxy';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import CredentialsSwitch from 'components/admin/common/commonFields/credentials/CredentialsSwitch';
import CredentialsFields from 'components/admin/common/commonFields/credentials/CredentialsFields';
import style from '../../../style.scss';
import UsernameField from 'components/admin/common/commonFields/UsernameField';
import PasswordField from 'components/admin/common/commonFields/PasswordField';
import ServerAuthTypeField from 'components/admin/common/commonFields/ServerAuthTypeField';

const ServerForm = ({ commonFormsConfig, channel, disabled, proxy, model }) => {
	const authType = model.auth_type
		? model.auth_type
		: model.auth && model.auth.type
			? model.auth.type
			: undefined;

	let scheme = [
		<dl key="dl" className={style.dlData}>
			{channel.ip_address && <dt>Host</dt>}
			{channel.ip_address && (
				<dd>
					{channel.status === 'pending' ? <span>In Progress</span> : channel.ip_address}
				</dd>
			)}

			{channel.port && <dt>Port Number</dt>}
			{channel.port && (
				<dd>{channel.status === 'pending' ? <span>In Progress</span> : channel.port}</dd>
			)}

			{channel.username && <dt>Username</dt>}
			{channel.username && (
				<dd>
					{channel.status === 'pending' ? <span>In Progress</span> : channel.username}
				</dd>
			)}

			{!channel.password_file && channel.password ? <dt>Password</dt> : null}
			{!channel.password_file && channel.password ? (
				<dd>
					{channel.status === 'pending' ? <span>In Progress</span> : channel.password}
				</dd>
			) : null}

			{channel.password_file ? <dt>PEM</dt> : null}
			{channel.password_file ? (
				<dd>
					<a
						href={channel.password_file}
						rel="noopener noreferrer"
						target="_blank"
						title={
							channel.password_file_name
								? channel.password_file_name
								: channel.password_file
						}
					>
						Download
					</a>
				</dd>
			) : null}
		</dl>
	];

	return (
		<Form noValidate {...commonFormsConfig}>
			<Field name="type" component="input" type="hidden" />
			<Field name="id" component="input" type="hidden" />
			{scheme}

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					disabled={disabled}
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			<SafeZoneProxy key="proxy" proxy={proxy} />

			<IPAndPortField key="ipPort" ipName="ip_address" portName="port" />
			{channel.os === 'linux' ? (
				<ServerAuthTypeField
					disabled={true}
					key="serverAuthTypeField"
					authType={authType}
				/>
			) : (
				<React.Fragment>
					<UsernameField key="username" fieldName="username" />
					<PasswordField
						key="password"
						fieldName="password"
						allowFile={channel.os === 'linux'}
					/>
				</React.Fragment>
			)}

			<CredentialsSwitch
				key="is_assingning_credentials"
				fieldName="is_assingning_credentials"
			/>
			{model.is_assingning_credentials ? (
				<CredentialsFields
					key="credentials"
					mode="edit"
					authType={authType}
					fieldName="credentials"
				/>
			) : null}
		</Form>
	);
};

ServerForm.propTypes = {
	channel: PropTypes.object.isRequired,
	disabled: PropTypes.bool,
	commonFormsConfig: PropTypes.object,
	model: PropTypes.object,
	proxy: PropTypes.string
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.commonFormsConfig.form, '') || {};
	const proxy = getAdminPilotProxy(state);

	return { model, proxy };
}

export default connect(mapStateToProps)(ServerForm);
