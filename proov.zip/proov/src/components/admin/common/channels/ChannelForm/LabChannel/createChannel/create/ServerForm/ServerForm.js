import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getSubscription } from 'ducks/myAccount/selectors';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import Switch from 'components/ui/Switch/Switch';
import style from '../../../../style.scss';
import OSField from 'components/admin/common/commonFields/OSField';
import CloudTypeField from 'components/admin/common/commonFields/CloudTypeSelect';
import { getLookupsByCloudType } from 'ducks/lookups/actions';
import ServerProovOwnedFields from './ServerProovOwnedFields';
import ServerUserOwnedFields from './ServerUserOwnedFields';
const ServerForm = ({ scrollBottom, isDedicatedAllowed, commonFormsConfig, model, getLookupsByCloudType, isRequestToEnterprise }) => {

	const [cloudType, setCloudType] = useState(null);
	useEffect(() => {
		setCloudType(model.cloud_type),
		getLookupsByCloudType('aws_instance_type', model.cloud_type)
	}, [model.cloud_type]);
	return (
		<Form noValidate {...commonFormsConfig}>
			<Field name="type" component="input" type="hidden" />

			<FormGroup
				hidden={isRequestToEnterprise}
				className={style.prvServerSwitchWrapper}
				label={<span className={style.biggerLabel}>Use prooV’s Server</span>}
			>
				<Field
					name="is_proov_owned"
					component={({ input }) => (
						<Switch
							className={style.switch}
							name={input.name}
							onToggle={input.onChange}
							toggled={input.value}
						/>
					)}
				/>
			</FormGroup>

			<FormGroup  key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			{model.is_proov_owned && <CloudTypeField />}
			<div>
				<OSField
					key="os"
					fieldName="os"
					label="Server Type"
					os={model.os}
					isProovOwned={model.is_proov_owned}
					disabled={model.is_proov_owned && !cloudType}
					cloudType={cloudType}
					scrollBottom={scrollBottom}
				/>
				{model.is_proov_owned ? (
					<ServerProovOwnedFields
						isBm={model.bm && model.bm.enabled}
						isProovOwned={model.is_proov_owned}
						scrollBottom={scrollBottom}
						isDedicatedAllowed={isDedicatedAllowed}
						isDedicated={model.is_dedicated}
						lookupType={cloudType ? 'aws_instance_type' : ""}
						disabled={!cloudType}
						isRequestToEnterprise={isRequestToEnterprise}
					/>
				) : (
					<ServerUserOwnedFields
						operatingSystem={model.os}
						authType={model.auth_type}
						isAssingningCredentials={model.is_assingning_credentials}
					/>
				)}
			</div>
		</Form>
	);
};

ServerForm.propTypes = {
	commonFormsConfig: PropTypes.object,
	isSelectedFormProovServerTypes: PropTypes.bool,
	model: PropTypes.object,
	isDedicatedAllowed: PropTypes.bool,
	scrollBottom: PropTypes.func,
	getLookupsByCloudType: PropTypes.func
};

function mapStateToProps(state, ownProps) {
	const isDedicatedAllowed = getSubscription(state).config.dedicated.limit;
	const model = modelSelector(state, ownProps.selectedForm) || {};
	return { model, isDedicatedAllowed };
}

export default connect(mapStateToProps, { getLookupsByCloudType })(ServerForm);
