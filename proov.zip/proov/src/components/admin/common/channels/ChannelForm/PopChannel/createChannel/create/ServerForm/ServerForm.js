import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getSubscription } from 'ducks/myAccount/selectors';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import { getAdminPilotProxy } from 'ducks/admin/pilot/selectors';
import SafeZoneProxy from 'components/admin/common/commonFields/SafeZoneProxy';
import OSField from 'components/admin/common/commonFields/OSField';
import ServerUserOwnedFields from './ServerUserOwnedFields';

const ServerForm = ({ commonFormsConfig, model, proxy }) => {
	return (
		<Form noValidate {...commonFormsConfig}>
			<Field name="type" component="input" type="hidden" />
			<Field name="is_user_owned" component="input" type="hidden" />

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			<SafeZoneProxy key="proxy" proxy={proxy} />

			<OSField key="os" fieldName="os" label="Server Type" />

			<ServerUserOwnedFields
				operatingSystem={model.os}
				authType={model.auth_type}
				isAssingningCredentials={model.is_assingning_credentials}
			/>
		</Form>
	);
};

ServerForm.propTypes = {
	commonFormsConfig: PropTypes.object,
	isSelectedFormProovServerTypes: PropTypes.bool,
	model: PropTypes.object,
	proxy: PropTypes.string,
	isDedicatedAllowed: PropTypes.bool,
	scrollBottom: PropTypes.func
};

function mapStateToProps(state, ownProps) {
	const isDedicatedAllowed = getSubscription(state).config.dedicated.limit;
	const model = modelSelector(state, ownProps.selectedForm) || {};
	const proxy = getAdminPilotProxy(state);

	return { model, isDedicatedAllowed, proxy };
}

export default connect(
	mapStateToProps,
	null
)(ServerForm);
