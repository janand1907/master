/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import style from '../../../style.scss';

const BlockchainFields = ({ envData }) => {

	const { node_num } = envData;

	const scheme = [
		<dl key="dlData" className={style.dlData}>
			<dt>Number of Nodes</dt>
			<dd>{node_num}</dd>
		</dl>
	];

	return <div>{scheme}</div>;
};

BlockchainFields.propTypes = {
	envData: PropTypes.object.isRequired
};

export default BlockchainFields;
