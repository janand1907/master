import React, { useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { merge } from 'lodash';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import Switch from 'components/ui/Switch/Switch';
import CloudTypeField from 'components/admin/common/commonFields/CloudTypeSelect';
import { CLOUD_TYPE } from 'constants/channel/cloudType';
import { FileUpload } from 'components/common/FileUpload';
import style from '../../../../style.scss';

const StorageForm = ({ model, commonFormsConfig, isRequestToEnterprise, mediaPending, onUploadApiFile }) => {
	let formEl = useRef(null);
	const proovStorageScheme = [
		// switch button for read only
		<FormGroup
			hidden={isRequestToEnterprise}
			key="is_read_only"
			className={style.prvServerSwitchWrapper}
			label={<span className={style.biggerLabel}>Read Only</span>}>
			<Field
				name="is_read_only"
				component={({ input }) => (
					<Switch
						className={style.switch}
						name={input.name}
						onToggle={input.onChange}
						toggled={input.value}
					/>
				)}
			/>
		</FormGroup>
	];

	const awsScheme = [
		<FormGroup key="access_key" label="AWS Access Key" mandatory>
			<Field name="aws.access_key" component="input" type="text" maxLength={20} className="form-control" />
			<Error sticky name="aws.access_key" />
		</FormGroup>,
		<FormGroup key="secret_key" label="AWS Secret Key" mandatory>
			<Field name="aws.secret_key" component="input" type="text" maxLength={40} className="form-control" />
			<Error sticky name="aws.secret_key" />
		</FormGroup>,
		<FormGroup key="region" label="AWS Region" mandatory>
			<Field name="aws.region" component="input" type="text" maxLength={14} className="form-control" />
			<Error sticky name="aws.region" />
		</FormGroup>,
		<FormGroup key="bucket_path" label="AWS Bucket" mandatory>
			<Field name="aws.bucket_path" component="input" type="text" maxLength={255} className="form-control" />
			<Error sticky name="aws.bucket_path" />
		</FormGroup>
	];
	const azureScheme = [
		<FormGroup key="account_name" label="Account Name" mandatory>
			<Field
				name="azure.account_name"
				component="input"
				type="text"
				className="form-control"
				maxLength="35"
				placeholder="Account Name"
			/>
			<Error sticky name="azure.account_name" />
		</FormGroup>,
		<FormGroup key="account_key" label="Account key" mandatory>
			<Field
				name="azure.account_key"
				component="input"
				type="text"
				className="form-control"
				maxLength="35"
				placeholder="Account Key"
			/>
			<Error sticky name="azure.account_key" />
		</FormGroup>,
		<FormGroup key="container_name" label="Container Name" mandatory>
			<Field
				name="azure.container_name"
				component="input"
				type="text"
				className="form-control"
				maxLength="35"
				placeholder="Container Name"
			/>
			<Error sticky name="azure.container_name" />
		</FormGroup>
	];
	const gcpScheme = [
		<FormGroup key="bucket_name" label="GCP Bucket" mandatory>
			<Field name="gcp.bucket_name" component="input" type="text" maxLength={255} className="form-control" />
			<Error sticky name="gcp.bucket_name" />
		</FormGroup>,
		<FormGroup label="Upload JSON specification">
			<Field
				name="gcp.json_key"
				defaultValue={[]}
				component={({ input }) => (
					<FileUpload
						formRef={formEl}
						fieldName={input.name}
						onChange={input.onChange}
						selectedFiles={input.value}
						extensions={['json']}
						blockAdd={model.gcp && model.gcp.json_key.length > 0}
					/>
				)}
			/>
		</FormGroup>
	];

	const getSchemeByCloudType = {
		[CLOUD_TYPE.AWS]: awsScheme,
		[CLOUD_TYPE.AZURE]: azureScheme,
		[CLOUD_TYPE.GCP]: gcpScheme
	}

	/* eslint-disable camelcase */
	const storageFormConfig = {
		initialValues: {
			is_read_only: false,
		},
		ref: (node) => {
			if (node) {
				formEl = node.getWrappedInstance();
			}
		},
	};
	/* eslint-enable camelcase */

	const formConfig = merge(storageFormConfig, commonFormsConfig);

	return (
		<Form noValidate {...formConfig}>
			<Field name="type" component="input" type="hidden" />

			<FormGroup
				hidden={isRequestToEnterprise}
				className={style.prvServerSwitchWrapper}
				label={<span className={style.biggerLabel}>Use prooV’s Server</span>}
			>
				<Field
					name="is_proov_owned"
					component={({ input }) => (
						<Switch
							className={style.switch}
							name={input.name}
							onToggle={input.onChange}
							toggled={input.value}
						/>
					)}
				/>
			</FormGroup>

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			<CloudTypeField />
			<div>{
				model.is_proov_owned || !model.cloud_type ?
					proovStorageScheme
					: getSchemeByCloudType[model.cloud_type]
			}</div>
		</Form>
	);
};

StorageForm.propTypes = {
	scrollBottom: PropTypes.func,
	model: PropTypes.object,
	commonFormsConfig: PropTypes.object,
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.selectedForm) || {};
	return { model };
}

export default connect(mapStateToProps, null)(StorageForm);
