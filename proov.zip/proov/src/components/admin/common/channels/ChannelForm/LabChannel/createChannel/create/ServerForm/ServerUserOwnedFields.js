import React from 'react';
import PropTypes from 'prop-types';
import UsernameField from 'components/admin/common/commonFields/UsernameField';
import PasswordField from 'components/admin/common/commonFields/PasswordField';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import ServerAuthTypeField from 'components/admin/common/commonFields/ServerAuthTypeField';
import CredentialsSwitch from 'components/admin/common/commonFields/credentials/CredentialsSwitch';
import CredentialsFields from 'components/admin/common/commonFields/credentials/CredentialsFields';

const ServerUserOwnedFields = ({
	operatingSystem,
	authType,
	isAssingningCredentials
}) => {
	let scheme = [];

	scheme = [
		...scheme,
		<IPAndPortField key="ipPort" ipName="ip_address" portName="port" />
	];

	if (operatingSystem === 'linux') {
		scheme = [
			...scheme,
			<ServerAuthTypeField key="ServerAuthTypeField" authType={authType} />
		];
	} else if (operatingSystem === 'windows') {
		scheme = [
			...scheme,
			<UsernameField key="username" fieldName="username" />,
			<PasswordField
				key="password"
				fieldName="password"
				allowFile={operatingSystem === 'linux'}
			/>
		];
	}
	scheme = [
		...scheme,
		<CredentialsSwitch
			key="is_assingning_credentials"
			fieldName="is_assingning_credentials"
		/>
	];
	if (isAssingningCredentials) {
		scheme = [
			...scheme,
			<CredentialsFields key="credentials" authType={authType} fieldName="credentials" />
		];
	}

	return <div>{scheme}</div>;
};

ServerUserOwnedFields.propTypes = {
	isAssingningCredentials: PropTypes.bool,
	operatingSystem: PropTypes.string,
	authType: PropTypes.string
};

export default ServerUserOwnedFields;
