/* eslint-disable complexity */
import { SAFEZONE } from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { merge } from 'lodash';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import { getAdminPilotProxy } from 'ducks/admin/pilot/selectors';
import SafeZoneProxy from 'components/admin/common/commonFields/SafeZoneProxy';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import style from '../../../style.scss';

const ApiForm = ({ commonFormsConfig, channel, proxy, model, disabled }) => {
	// eslint-disable-next-line no-nested-ternary
	const activeServerPopOrUserOwned =
		channel.safe_zone && channel.safe_zone.active
			? SAFEZONE
			: channel.user_owned && channel.user_owned.active
				? 'user_owned'
				: null;

	const apiFormConfig = {
		initialValues: {
			active: activeServerPopOrUserOwned
		}
	};

	const formConfig = merge(apiFormConfig, commonFormsConfig);

	let authFields = {};
	if (channel && channel.auth && channel.auth.type && channel.auth.type === 'basic') {
		authFields = {
			Username: channel.auth.username,
			Password: channel.auth.password
		};
	}

	const scheme = [
		channel && channel.safe_zone && channel.safe_zone.ip_address && (
			<div key="dlData0" className={style.dlData}>
				<dt>prooV SafeZone</dt>
				<dd>{channel.safe_zone.ip_address}</dd>
			</div>
		),
		channel && channel.user_owned && channel.user_owned.ip_address && (
			<div key="dlData1" className={style.dlData}>
				<dt>Customer Environment</dt>
				<dd>{channel.user_owned.ip_address}</dd>
			</div>
		),
		channel && channel.auth && channel.auth.type !== 'none' && (
			<div key="dlData2" className={style.dlData}>
				<dt>Authentication</dt>
				<dt className={style.authType}>{channel.auth.type}</dt>
			</div>
		),
		channel &&
			channel.auth &&
			channel.auth.type !== 'none' &&
			Object.keys(authFields).length > 0 && (
			<div key="dlDataCredentials" className={style.credentials}>
				{Object.keys(authFields).map((item, index) => {
					return (
						<div key={index}>
							<dt>{item}</dt>
							<dd>{authFields[item]}</dd>
						</div>
					);
				})}
			</div>
		)
	];

	return (
		<Form noValidate {...formConfig}>
			<Field name="type" component="input" type="hidden" />
			<Field name="id" component="input" type="hidden" />

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					disabled={channel.status === 'failed'}
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>
			<SafeZoneProxy key="proxy" proxy={proxy} />
			<FormGroup key="active" label="Active server" style={{ margin: '1px -2px' }}>
				<Field
					name="active"
					validateOn="change"
					defaultValue={model.active}
					component={({ input }) => (
						<RadioGroup
							name={input.name}
							selectedValue={input.value}
							onChange={input.onChange}
							className={style.controlPushMdWrapper}
						>
							<PushButton
								disabled={disabled}
								value={SAFEZONE}
								className={style.controlPushMd}
							>
								prooV SafeZone
							</PushButton>
							<PushButton
								disabled={disabled}
								value="user_owned"
								className={style.controlPushMd}
							>
								Customer Environment
							</PushButton>
						</RadioGroup>
					)}
				/>
				<Error sticky name="active" />
			</FormGroup>

			{((channel && !channel.safe_zone) ||
				(channel.safe_zone && !channel.safe_zone.ip_address)) && (
				<IPAndPortField
					key="ipPort_safe_zone"
					ipName="safe_zone.ip_address"
					fullWidth
					disabled={disabled}
				/>
			)}

			{scheme}
		</Form>
	);
};

ApiForm.propTypes = {
	channel: PropTypes.object,
	commonFormsConfig: PropTypes.object,
	model: PropTypes.object,
	proxy: PropTypes.string,
	disabled: PropTypes.bool
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.commonFormsConfig.form, '') || {};
	const proxy = getAdminPilotProxy(state);

	return { model, proxy };
}

export default connect(mapStateToProps)(ApiForm);
