import { SAFEZONE } from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
import ConnectionTypeSelect from '../../common/ConnectionTypeSelect';
import DbForm from './create/DbForm/DbForm';
import ApiForm from './create/ApiForm/ApiForm';
import ServerForm from './create/ServerForm/ServerForm';

const CreateChannelForm = props => {
	const channelFormFactory = props => {
		const { selectedForm } = props;
		const forms = {
			db: DbForm,
			api: ApiForm,
			server: ServerForm
		};

		const Component = forms[selectedForm];

		return React.createElement(Component, { ...props });
	};

	const { onConnectionTypeChange, selectedForm } = props;
	return (
		<React.Fragment>
			<ConnectionTypeSelect
				key="connection"
				changeEndpointType={onConnectionTypeChange}
				value={selectedForm}
				type={SAFEZONE}
			/>

			{channelFormFactory(props)}
		</React.Fragment>
	);
};

CreateChannelForm.propTypes = {
	onConnectionTypeChange: PropTypes.func.isRequired,
	selectedForm: PropTypes.string.isRequired
};

export default CreateChannelForm;
