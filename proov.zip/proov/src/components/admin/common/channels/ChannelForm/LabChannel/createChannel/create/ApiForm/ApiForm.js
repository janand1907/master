import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { merge } from 'lodash';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import Switch from 'components/ui/Switch/Switch';
import CloudTypeField from 'components/admin/common/commonFields/CloudTypeSelect';
import style from '../../../../style.scss';
import ApiProovOwnedFields from './ApiProovOwnedFields';
import ApiUserOwnedFields from './ApiUserOwnedFields';

const ApiForm = ({
	model,
	onUploadApiFile,
	onCancel,
	mediaPending,
	commonFormsConfig,
}) => {
	const authType = model.auth_type || (model.auth && model.auth.type) || null;
	const grantType = model.auth && model.auth.grant_type;

	/* eslint-disable camelcase */
	const apiFormConfig = {
		initialValues: {
			is_dedicated: false,
			api_type: 'rest',
			api_spec_type: 'url',
			source: 'file',
		},
	};
	/* eslint-enable camelcase */

	const formConfig = merge(apiFormConfig, commonFormsConfig);

	return (
		<Form noValidate {...formConfig}>
			<Field name="type" component="input" type="hidden" />

			<FormGroup
				className={style.prvServerSwitchWrapper}
				label={<span className={style.biggerLabel}>Use prooV’s Server</span>}
			>
				<Field
					name="is_proov_owned"
					component={({ input }) => (
						<Switch
							className={style.switch}
							name={input.name}
							onToggle={input.onChange}
							toggled={input.value}
						/>
					)}
				/>
			</FormGroup>

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			{model.is_proov_owned &&<CloudTypeField />}

			<div>
				{model.is_proov_owned ? (
					<ApiProovOwnedFields
						authType={authType}
						apiType={model.api_type}
						dbType={model.db_settings && model.db_settings.db_type}
						source={model.source}
						onFileUpload={onUploadApiFile}
						mediaPending={mediaPending}
						fileResource={model.file_resource}
						hideModal={onCancel}
						cloudType={model.cloud_type}
					/>
				) : (
					<ApiUserOwnedFields
						authType={authType}
						apiType={model.api_type}
						grantType={grantType}
						onFileUpload={onUploadApiFile}
						mediaPending={mediaPending}
					/>
				)}
			</div>
		</Form>
	);
};

ApiForm.propTypes = {
	apiType: PropTypes.string,
	grantType: PropTypes.string,
	onUploadApiFile: PropTypes.func.isRequired,
	onCancel: PropTypes.func.isRequired,
	mediaPending: PropTypes.bool.isRequired,
	model: PropTypes.object,
	commonFormsConfig: PropTypes.object,
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.selectedForm) || {};
	return { model };
}

export default connect(mapStateToProps, null)(ApiForm);
