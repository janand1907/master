import React from 'react';
import PropTypes from 'prop-types';
import { Spinner } from 'components/ui/Spinner';
import { Alert } from 'components/ui/Alert';
import * as i18n from 'i18n/en/channelForm.json';
import style from './../style.scss';

const DeleteChannelForm = ({ channel, pending, onDelete, onCancel, error }) => {
	return (
		<div className={style.deleteChannelContainer}>
			{error && <Alert type="error">{error}</Alert>}
			<p className={style.medium}>{i18n.delete.areYouSure}</p>
			<div>
				<p>{i18n.delete.deleteEnv}</p>
				<p>
					{i18n.delete.allDataDelete}
					{channel.type === 'db' && (
						<span>
							<br />
							<span className={style.medium}>Note:</span> {i18n.delete.apiNote}
						</span>
					)}
				</p>
				<p>{i18n.delete.cannotBeUndone}</p>
			</div>

			<div className={style.btnWrapper}>
				<button type="button" onClick={onCancel} className={style.deleteChannelBtnCancel}>
					{i18n.delete.cancel}
				</button>
				<button
					type="button"
					onClick={() => onDelete(channel.id, channel.name, channel.type)}
					className={style.deleteChannelBtnDelete}
				>
					{i18n.delete.confirm} {pending && <Spinner />}
				</button>
			</div>
		</div>
	);
};

DeleteChannelForm.propTypes = {
	channel: PropTypes.object.isRequired,
	pending: PropTypes.bool.isRequired,
	error: PropTypes.string,
	onDelete: PropTypes.func.isRequired,
	onCancel: PropTypes.func.isRequired
};

export default DeleteChannelForm;
