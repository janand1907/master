import React from 'react';
import PropTypes from 'prop-types';
import UsernameField from 'components/admin/common/commonFields/UsernameField';
import PasswordField from 'components/admin/common/commonFields/PasswordField';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import ServerAuthTypeField from 'components/admin/common/commonFields/ServerAuthTypeField';
import OSField from 'components/admin/common/commonFields/OSField';
import LookupSelectField from 'components/admin/common/commonFields/LookupSelectField';
import CredentialsSwitch from 'components/admin/common/commonFields/credentials/CredentialsSwitch';
import CredentialsFields from 'components/admin/common/commonFields/credentials/CredentialsFields';
import style from '../../../style.scss';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';

const ServerFields = ({
	isWizard,
	isProovOwned,
	authType,
	operatingSystem,
	channel,
	isAssingningCredentials
}) => {
	let scheme = [];

	const envData = [
		<dl className={style.dlData}>
			{channel.cloud_type && <React.Fragment>
				<dt>Cloud-based</dt>

				<dd>
					{CLOUD_TYPE_TO_ICON[channel.cloud_type].label}
				</dd></React.Fragment>
			}
			{channel.ip_address && <dt>Host</dt>}
			{channel.ip_address && (
				<dd>
					{channel.status === 'pending' ? <span>In Progress</span> : channel.ip_address}
				</dd>
			)}

			{channel.port && <dt>Port Number</dt>}
			{channel.port && (
				<dd>{channel.status === 'pending' ? <span>In Progress</span> : channel.port}</dd>
			)}

			{channel.username && <dt>Username</dt>}
			{channel.username && (
				<dd>
					{channel.status === 'pending' ? <span>In Progress</span> : channel.username}
				</dd>
			)}

			{!channel.password_file && channel.password ? <dt>Password</dt> : null}
			{!channel.password_file && channel.password ? (
				<dd>
					{channel.status === 'pending' ? <span>In Progress</span> : channel.password}
				</dd>
			) : null}

			{channel.password_file ? <dt>PEM</dt> : null}
			{channel.password_file ? (
				<dd>
					<a
						href={channel.password_file}
						target="_blank"
						title={
							channel.password_file_name
								? channel.password_file_name
								: channel.password_file
						}
					>
						Download
					</a>
				</dd>
			) : null}
		</dl>
	];

	const envIsWizard = [
		<OSField key="os" fieldName="os" />,
		<LookupSelectField
			key="awsInstance"
			label="Instance Type"
			name="aws_instance"
			lookupSelectProps={{
				lookupType: 'aws_instance_type',
				defaultOption: 'Select instance type...'
			}}
		/>
	];

	if (isProovOwned) {
		scheme = [...scheme, isWizard ? envIsWizard : envData];
	} else {
		scheme = [
			...scheme,
			<IPAndPortField key="ipPort" ipName="ip_address" portName="port" />
		];

		if (operatingSystem === 'linux') {
			scheme = [
				...scheme,
				<ServerAuthTypeField
					disabled={true}
					key="serverAuthTypeField"
					authType={authType}
				/>
			];
		} else if (operatingSystem === 'windows') {
			scheme = [
				...scheme,
				<UsernameField key="username" fieldName="username" />,
				<PasswordField
					key="password"
					fieldName="password"
					allowFile={operatingSystem === 'linux'}
				/>
			];
		}
		scheme = [
			...scheme,
			<CredentialsSwitch
				key="is_assingning_credentials"
				fieldName="is_assingning_credentials"
			/>
		];

		if (isAssingningCredentials) {
			scheme = [
				...scheme,
				<CredentialsFields
					key="credentials"
					fieldName="credentials"
					mode="edit"
					authType={authType}
				/>
			];
		}
	}

	return <div>{scheme}</div>;
};

ServerFields.propTypes = {
	authType: PropTypes.string,
	isWizard: PropTypes.bool,
	operatingSystem: PropTypes.string,
	isProovOwned: PropTypes.bool,
	isAssingningCredentials: PropTypes.bool,
	channel: PropTypes.object.isRequired
};

export default ServerFields;
