import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import DropZone from 'components/ui/DropZone/DropZone';
import Shelf from 'components/ui/Rack/Shelf';
import { FileIcon } from 'components/ui/Icons';
import { readFileAsText } from 'utils';
import * as i18n from 'i18n/en/channelForm.json';
import DBName from 'components/admin/common/commonFields/DBName';
import RestrictTablesField from 'components/admin/common/commonFields/RestrictTablesField';
import UsernamePasswordField from 'components/admin/common/commonFields/UsernamePasswordField';
import CredentialsSwitch from 'components/admin/common/commonFields/credentials/CredentialsSwitch';
import CredentialsFields from 'components/admin/common/commonFields/credentials/CredentialsFields';
import style from '../../../../style.scss';

const DbUserOwnedFields = ({ model }) => {
	const bigQueryScheme = [
		<FormGroup key="projectId" label="Project ID" mandatory>
			<Field
				name="db_name"
				component="input"
				type="text"
				maxLength={128}
				className="form-control"
			/>
			<Error sticky name="db_name" />
		</FormGroup>,
		<FormGroup key="credentialsFile" label="Upload credentials file" mandatory>
			<Field
				name="credentials_file"
				validateOn="change"
				component={({ input }) => {
					return typeof input.value === 'object' ? (
						<Shelf
							value={input.value.name}
							renderValue={(v) => (
								<span>
									<FileIcon className={style.shelfIcon} />
									{v}
								</span>
							)}
							allowRemove
							allowEdit={false}
							onRemove={() => {
								input.onChange();
							}}
						/>
					) : (
						<DropZone
							types={['json']}
							onDropEnd={({ files }) =>
								readFileAsText(files[0], (e) => {
									input.onChange({
										name: files[0].name,
										contents: e.target.result,
									});
								})
							}
							maxFilesCount={1}
							maxFileSize={1}
							className={style.dropZone}
						>
							{globalize.parseString(i18n.upload.dropCredentials)}
						</DropZone>
					);
				}}
			/>
			<Error sticky name="credentials_file" />
		</FormGroup>,
		<RestrictTablesField
			key="restrictTables"
			label="Restrict datasets"
			showRack={model.restrict_tables}
		/>,
	];

	const otherDbTypeScheme = [
		<DBName key="dbName" fieldName="db_name" />,
		<UsernamePasswordField key="usernamePassword" />,
		<RestrictTablesField
			key="restrictTables"
			showRack={model.restrict_tables}
		/>,
		<CredentialsSwitch
			key="is_assingning_credentials"
			fieldName="is_assingning_credentials"
		/>,
	];

	const credentialsFields = [
		<CredentialsFields key="credentials" fieldName="credentials" />,
	];

	return (
		<div>
			{model.db_type === 'bigquery' ? bigQueryScheme : otherDbTypeScheme}

			{model.is_assingning_credentials && credentialsFields}
		</div>
	);
};

DbUserOwnedFields.propTypes = {
	model: PropTypes.object,
};

export default DbUserOwnedFields;
