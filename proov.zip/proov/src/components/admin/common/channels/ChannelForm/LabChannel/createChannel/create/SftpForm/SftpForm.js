import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import UsernameField from 'components/admin/common/commonFields/UsernameField';
import PasswordField from 'components/admin/common/commonFields/PasswordField';

const SftpForm = ({ commonFormsConfig }) => {

	return (
		<Form noValidate {...commonFormsConfig}>
			<Field name="type" component="input" type="hidden" />

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			<IPAndPortField key="ipPort" ipName="ip_address" portName="port" />
			<UsernameField key="username" fieldName="username" />
			<PasswordField key="password" fieldName="password" allowFile />
		</Form>
	);
};

SftpForm.propTypes = {
	commonFormsConfig: PropTypes.object,
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.selectedForm) || {};
	return { model };
}

export default connect(
	mapStateToProps,
	null
)(SftpForm);
