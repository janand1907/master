import React from 'react';
import PropTypes from 'prop-types';
import style from '../../../style.scss';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';
const StorageFields = ({ envData }) => {

	const {
		is_user_owned,
		aws,
		azure,
		ip_address,
		cloud_type,
		username,
		password,
		port,
	} = envData;

	let storageFields = {};
	let urlDetails = {
		'Cloud-based': cloud_type && CLOUD_TYPE_TO_ICON[cloud_type].label,
		'IP': 'sftp://' + ip_address,
		'Port': port,
		'Username': username,
		'Password': password
	};

	if (is_user_owned) {
		let cloudDetails;
		if (aws) {
			cloudDetails = {
				'AWS Access Key': aws.access_key,
				'AWS Region': aws.region,
				'AWS Path': aws.bucket_path
			};
		}
		else if(azure){
			cloudDetails = {
				'Azure Account Key': azure.account_key,
				'Azure Account Name': azure.account_name,
				'Azure Continer Name': azure.container_name
			};	
		}


		storageFields = { ...urlDetails, ...cloudDetails };
	} else {
		storageFields = { ...urlDetails };
	}

	const scheme = [
		(Object.keys(storageFields).length > 0 &&
			<div key="user_details_scheme_id" className={style.dlData}>
				{Object.keys(storageFields).map((item, index) => {
					return (
						<div key={index}>
							<dt className={style.title}>{item}&#32;</dt>
							<dd className={style.label}>{storageFields[item]}{'\r'}</dd>
						</div>);
				})}
			</div>),

	];

	return (
		<dl className={style.dl}>{scheme}</dl>
	);
};

StorageFields.propTypes = {
	envData: PropTypes.object
};

export default StorageFields;
