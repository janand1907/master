/* eslint-disable camelcase */
import { SAFEZONE } from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { merge } from 'lodash';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import { modelSelector } from 'ducks/forms/selectors';
import cx from 'utils/classNames';
import DBName from 'components/admin/common/commonFields/DBName';
import { getAdminPilotProxy } from 'ducks/admin/pilot/selectors';
import SafeZoneProxy from 'components/admin/common/commonFields/SafeZoneProxy';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import style from '../../../style.scss';
import RestrictTablesField from 'components/admin/common/commonFields/RestrictTablesField';
import CredentialsSwitch from 'components/admin/common/commonFields/credentials/CredentialsSwitch';
import CredentialsFields from 'components/admin/common/commonFields/credentials/CredentialsFields';

const DbForm = ({
	commonFormsConfig,
	channel,
	proxy,
	model,
	disabled,
	formRef,
}) => {
	// eslint-disable-next-line no-nested-ternary
	const activeServerPopOrUserOwned =
		channel.safe_zone && channel.safe_zone.active
			? SAFEZONE
			: channel.user_owned && channel.user_owned.active
			? 'user_owned'
			: null;

	const dbFormConfig = {
		initialValues: {
			active: activeServerPopOrUserOwned,
		},
	};

	const formConfig = merge(dbFormConfig, commonFormsConfig);

	const activeOnChange = (e, input) => {
		input.onChange(e.target.value);
		formRef.validate();
		if (e.target.value !== SAFEZONE) {
			formRef.clearErrors('safe_zone.port');
			formRef.clearErrors('safe_zone.ip_address');
		} else if (e.target.value !== 'user_owned') {
			formRef.clearErrors('user_owned.port');
			formRef.clearErrors('user_owned.ip_address');
		}
	};

	const isPopActive = model.active === SAFEZONE;
	const isUserOwnedActive = model.active === 'user_owned';

	const isPopConfiguredAlready = Boolean(
		channel.safe_zone && channel.safe_zone.ip_address
	);
	const isUserOwnedConfiguredAlready = Boolean(
		channel.user_owned && channel.user_owned.ip_address
	);

	const scheme = [
		<div key="user_details_scheme_id" className={style.popContainer}>
			<div
				className={cx(style.type, isPopActive ? style.active : style.disabled)}
			>
				<h3>prooV SafeZone</h3>

				<IPAndPortField
					key="ipPort_safe_zone"
					ipName="safe_zone.ip_address"
					portName="safe_zone.port"
					fullWidth
					disabled={disabled || isPopConfiguredAlready}
					mandatory={isPopActive}
				/>
			</div>

			<div
				className={cx(
					style.type,
					isUserOwnedActive ? style.active : style.disabled
				)}
			>
				<h3>Customer Environment</h3>

				<IPAndPortField
					key="ipPortUserOwned"
					ipName="user_owned.ip_address"
					portName="user_owned.port"
					fullWidth
					disabled={disabled || isUserOwnedConfiguredAlready}
					mandatory={isUserOwnedActive}
				/>
			</div>
		</div>,
	];

	return (
		<Form noValidate {...formConfig}>
			<Field name="type" component="input" type="hidden" />
			<Field name="id" component="input" type="hidden" />
			<Field key="dbType" name="db_type" component="input" type="hidden" />

			<Field key="username" name="username" component="input" type="hidden" />
			<Field key="password" name="password" component="input" type="hidden" />

			<Field name="safe_zone.active" component="input" type="hidden" />
			<Field name="user_owned.active" component="input" type="hidden" />

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					disabled={disabled}
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>
			<SafeZoneProxy key="proxy" proxy={proxy} />
			<DBName key="dbName" fieldName="db_name" />
			<FormGroup
				key="active"
				label="Active server"
				style={{ margin: '1px -2px' }}
			>
				<Field
					name="active"
					defaultValue={model.active}
					validateOn="change"
					component={({ input }) => (
						<RadioGroup
							name={input.name}
							selectedValue={input.value}
							onChange={(e) => activeOnChange(e, input)}
							className={style.controlPushMdWrapper}
						>
							<PushButton
								disabled={disabled}
								value={SAFEZONE}
								className={style.controlPushMd}
							>
								prooV SafeZone
							</PushButton>
							<PushButton
								disabled={disabled}
								value="user_owned"
								className={style.controlPushMd}
							>
								Customer Environment
							</PushButton>
						</RadioGroup>
					)}
				/>
				<Error sticky name="active" />
			</FormGroup>

			{scheme}

			<FormGroup>
				<RestrictTablesField
					key="restrictTables"
					disabled={disabled}
					showRack={model.restrict_tables}
				/>
			</FormGroup>
			<CredentialsSwitch
				key="is_assingning_credentials"
				fieldName="is_assingning_credentials"
			/>
			{model.is_assingning_credentials && (
				<CredentialsFields key="credentials" fieldName="credentials" />
			)}
		</Form>
	);
};

DbForm.propTypes = {
	commonFormsConfig: PropTypes.object,
	channel: PropTypes.object,
	model: PropTypes.object,
	proxy: PropTypes.string,
	disabled: PropTypes.bool,
	formRef: PropTypes.object,
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.commonFormsConfig.form, '') || {};
	const proxy = getAdminPilotProxy(state);

	return { model, proxy };
}

export default connect(mapStateToProps)(DbForm);
