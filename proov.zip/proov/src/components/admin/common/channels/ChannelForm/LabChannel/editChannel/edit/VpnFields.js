import React from 'react';
import { Field } from 'components/common/Forms';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import UsernamePasswordField from 'components/admin/common/commonFields/UsernamePasswordField';

const VPNFields = () => {
	return (
		<div>
			<Field name="vpn_type" component="input" type="hidden" />
			<IPAndPortField ipName="ip_address" portName="port" />
			<UsernamePasswordField />
		</div>
	);
};

export default VPNFields;
