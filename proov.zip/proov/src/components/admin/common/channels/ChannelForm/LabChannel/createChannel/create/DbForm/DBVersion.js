import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import versions from 'constants/channel/dbVersions';
import LookupSelectField from 'components/admin/common/commonFields/LookupSelectField';

const DBVersion = ({ dbType, scrollBottom, lookupType }) => {
	if (!dbType || !versions[dbType]) {
		return null;
	}

	return (
		<FormGroup  mandatory>
			<Field
				name="db_version"
				validateOn={['blur', 'change']}
				component={({ input }) => (
					<LookupSelectField
					key="dbVersion"
					label="Database Version"
					name="db_version"
					optionKey={dbType}
					lookupSelectProps={{
						lookupType: lookupType,
						defaultOption: 'Select database type...',
						onFocus: scrollBottom,
					}}
				/>
				)}
			/>
			<Error sticky />
		</FormGroup>
	);
};

DBVersion.propTypes = {
	model: PropTypes.object,
	scrollBottom: PropTypes.func,
	lookupType: PropTypes.string
};

export default DBVersion;
