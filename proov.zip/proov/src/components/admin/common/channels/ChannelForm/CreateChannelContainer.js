import * as PILOT_TYPES from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
// eslint-disable-next-line import/no-named-default
import { default as lab } from './LabChannel/createChannel/CreateChannelContainer';
// eslint-disable-next-line import/no-named-default
import { default as safezone } from './PopChannel/createChannel/CreateChannelContainer';

const CreateChannelContainer = props => {
	const CreateChannelFactory = ({ pilotType, channel }) => {
		const channelType = {
			[PILOT_TYPES.LAB]: lab,
			[PILOT_TYPES.AWS_SC]: lab,
			[PILOT_TYPES.SAFEZONE]: safezone
		};

		const Component = channelType[pilotType];

		return React.createElement(Component, { channelType: channel, ...props });
	};

	return CreateChannelFactory(props);
};

CreateChannelContainer.propTypes = {
	pilotType: PropTypes.string.isRequired,
	channel: PropTypes.string
};

export default CreateChannelContainer;
