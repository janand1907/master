/* eslint-disable react/no-multi-comp */
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { find, isEqual } from 'lodash';
import {
	getAdminPilotError,
	getAdminPilotPending,
	getAdminPilot
} from 'ducks/admin/pilot/selectors';
import * as actions from 'ducks/admin/pilot/channel/actions';
import { resetPilotError } from 'ducks/admin/pilot/actions';
import {
	channelTransformInitialValue,
	channelTransformShow,
	PoPChannelTransformUpdate
} from 'utils/transformEnvironment';
import { hideModal } from 'ducks/modal/actions';
import { resetSelectedMetric } from 'ducks/admin/analytics/metrics/actions';
import { Spinner } from 'components/ui/Spinner';
import { modelSelector } from 'ducks/forms/selectors';
import { getMetricsSection } from 'ducks/admin/analytics/metrics/selectors';
import style from '../../style.scss';
import DeleteChannelForm from '../DeleteChannelForm';
import validate from './../validation';
import EditChannelForm from './EditChannelForm';
import EditChannelFormHeader from './EditChannelFormHeader';

class EditChannelFormContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleCancel = this.handleCancel.bind(this);
		this.handleSave = this.handleSave.bind(this);
		this.handleDelete = this.handleDelete.bind(this);
		this.handleCancelDelete = this.handleCancelDelete.bind(this);
		this._formRef = this._formRef.bind(this);

		this.state = { deleteView: false };

		if (this.props.channel) {
			this.initialValues = channelTransformInitialValue({ ...this.props.channel });
		}
	}

	// Two functions for ClicklDelete?
	handleClickDelete(channel) {
		this.setState({ deleteView: true, channel });
	}

	handleCancelDelete() {
		this.setState({ deleteView: false, channel: null });
	}

	shouldComponentUpdate(nextProps, nextState) {
		// if channel deleted don`t rerender (EditChannelFormHeader)
		return !isEqual(nextProps && this.props);
	}

	_formRef(node) {
		if (node) {
			this._form = node.getWrappedInstance();
			this.setState({ t: 1 }); //Very Very bad hook to make re render in order to get form data in second render
		}
	}

	handleCancel() {
		this.props.dispatch(hideModal());
	}

	handleDelete(channelId, channelName, channelType) {
		this.props.dispatch(hideModal());
		this.props.dispatch(
			actions.deletePilotChannel(this.props.pilotId, channelId, channelName, channelType)
		);
		if(this.props.selectedChannelId !== null && channelId === this.props.selectedChannelId) {
			this.props.dispatch(resetSelectedMetric());
		}
	}

	handleSave(values) {
		if (this._form.validate()) {
			const transformedData = PoPChannelTransformUpdate(values);
			this.props.dispatch(
				actions.updatePilotChannel(
					this.props.pilotId,
					{ ...transformedData, version: this.props.channel.version },
					values.id,
					null,
					this.props.channel.type
				)
			);
		}
	}

	handleValidationFaild(errors) {
		for (let i = 0; i < Object.keys(errors).length; i++) {
			const errElm = document.getElementsByName(Object.keys(errors)[i])[0];
			if (errElm) {
				errElm.scrollIntoView();
				break;
			}
		}
	}

	render() {
		const { model, pending, channel, error } = this.props;
		const commonFormsConfig = {
			form: channel.type,
			ref: this._formRef,
			preserve: true,
			onSubmit: this.handleSave,
			onSubmitValidationFail: this.handleValidationFaild,
			initialValues: this.initialValues,
			validators: validate
		};

		return (
			//@Roy move buttons inside EditChannelForm??
			<div className={style.modal}>
				<EditChannelFormHeader data={channel} />

				{this.state.deleteView ? (
					<DeleteChannelForm
						channel={this.state.channel}
						onDelete={this.handleDelete}
						onCancel={this.handleCancelDelete}
						pending={pending.update || pending.fields}
						error={error}
					/>
				) : (
					<React.Fragment>
						<div ref={c => (this.scrollArea = c)} className={style.content}>
							<EditChannelForm
								model={model}
								disabled={channel.status === 'failed'}
								commonFormsConfig={commonFormsConfig}
								channel={channel}
								onCancel={this.handleCancel}
								onDelete={this.handleDelete}
								mediaPending={pending.media}
								error={error}
								formRef={this._form}
							/>
						</div>

						<div className={style.footer}>
							<button
								type="button"
								disabled={pending.update || pending.fields}
								className={style.btnDelete}
								onClick={() => this.handleClickDelete(channel)}
							>
								Delete
							</button>
							<button
								type="button"
								disabled={pending.update || pending.fields}
								className={style.btnCancel}
								onClick={this.handleCancel}
							>
								Cancel
							</button>
							<button
								type="submit"
								disabled={
									pending.update ||
									pending.fields ||
									pending.media ||
									channel.status === 'failed'
								}
								onClick={() => this._form.submit()}
								className={style.btnCreate}
							>
								Update {(pending.update || pending.fields) && <Spinner />}
							</button>
						</div>
					</React.Fragment>
				)}
			</div>
		);
	}
}

EditChannelFormContainer.propTypes = {
	//mapStateToProps
	pilotId: PropTypes.string.isRequired,
	model: PropTypes.object.isRequired,
	channel: PropTypes.object.isRequired,
	error: PropTypes.string,
	pending: PropTypes.object.isRequired,
	dispatch: PropTypes.func,
	selectedChannelId: PropTypes.string
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, 'channel', '') || {};
	const error = getAdminPilotError(state);
	const pending = getAdminPilotPending(state);
	const pilot = getAdminPilot(state);
	const channel = channelTransformShow(
		find(pilot.environment, o => o.id === ownProps.channelId)
	);
	const { channelId } = getMetricsSection(state);
	return { model, pending, channel, pilotId: pilot.id, error, selectedChannelId: channelId };
}

export default connect(mapStateToProps)(EditChannelFormContainer);
