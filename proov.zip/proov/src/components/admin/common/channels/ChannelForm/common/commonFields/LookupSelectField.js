import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import LookupSelect from 'components/common/Lookups/LookupSelect';

const LookupSelectField = ({
	name,
	label,
	lookupSelectProps,
	isProov,
	isPoP,
	optionKey
}) => {
	const getLabel = React.useCallback((lookupType) => {
		if (lookupType === 'db_type') {
			return (v) => v.label;
		} else {
			return null;
		}
	}, []);


	const getOptions = React.useCallback(({ isProov, isPoP }) => {
		if (isProov) {
			return (v) => v.is_proov;
		} else if (null || isPoP) {
			return (v) => v.label === 'MySQL' || v.label === 'Postgres';
		}
		return null;
	}, []);

	return (
		<FormGroup label={label} mandatory>
			<Field
				name={name}
				validateOn={['blur', 'change']}
				component={({ input }) => (
					<LookupSelect
						{...input}
						required
						lazy={false}
						defaultOption="Select one..."
						{...lookupSelectProps}
						getLabel={getLabel(lookupSelectProps.lookupType)}
						transformOptions={getOptions({ isProov, isPoP })}
						optionKey={optionKey}
					/>
				)}
			/>
			<Error sticky />
		</FormGroup>
	);
};

LookupSelectField.propTypes = {
	lookupKey: PropTypes.string,
	name: PropTypes.string.isRequired,
	label: PropTypes.string.isRequired,
	isProov: PropTypes.bool,
	isPoP: PropTypes.bool,
	lookupSelectProps: PropTypes.shape({
		lookupType: PropTypes.string.isRequired,
	}).isRequired,
};
export default LookupSelectField;
