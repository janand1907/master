/* eslint-disable react/no-multi-comp */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { find } from 'lodash';
import {
	getAdminPilotError,
	getAdminPilotPending,
	getAdminPilot,
} from 'ducks/admin/pilot/selectors';
import { modelSelector } from 'ducks/forms/selectors';
import { getMetricsSection } from 'ducks/admin/analytics/metrics/selectors';
import * as actions from 'ducks/admin/pilot/channel/actions';
import { resetPilotError } from 'ducks/admin/pilot/actions';
import { resetSelectedMetric } from 'ducks/admin/analytics/metrics/actions';
import {
	channelTransformShow,
	channelTransformUpdate,
	channelTransformInitialValue,
} from 'utils/transformEnvironment';
import { hideModal } from 'ducks/modal/actions';
import validate from '../../validation';
import style from '../../style.scss';
import EditChannelForm from './EditChannelForm';
import EditChannelFormHeader from './EditChannelFormHeader';

class EditChannelFormContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleCancel = this.handleCancel.bind(this);
		this.handleSave = this.handleSave.bind(this);
		this.handleDelete = this.handleDelete.bind(this);
		this.handleUploadMediaFile = this.handleUploadMediaFile.bind(this);
		this._formRef = this._formRef.bind(this);
		if (this.props.channel) {
			this.initialValues = channelTransformInitialValue({
				...this.props.channel,
			});
		}
	}

	componentWillUnmount() {
		this.props.dispatch(resetPilotError(this.props.pilotId));
	}

	shouldComponentUpdate(nextProps, nextState) {
		// if channel deleted don`t rerender (EditChannelFormHeader)
		return !!(nextProps.channel && nextProps.channel.id);
	}

	_formRef(node) {
		if (node) {
			this._form = node.getWrappedInstance();
		}
	}

	handleCancel() {
		this.props.dispatch(hideModal());
	}

	handleDelete(channelId, channelName, channelType) {
		this.props.dispatch(
			actions.deletePilotChannel(
				this.props.pilotId,
				channelId,
				channelName,
				channelType
			)
		);
		if(this.props.selectedChannelId !== null && channelId === this.props.selectedChannelId) {
			this.props.dispatch(resetSelectedMetric());
		}
	}

	handleUploadMediaFile(file, fieldName) {
		//TODO this._form.validate(fieldName); ????
		this.props.dispatch(actions.uploadMediaFile(file, 'channel', fieldName));
	}

	handleSave(values) {
		if (this._form.validate()) {
			const transformedData = channelTransformUpdate(values);
			this.props.dispatch(
				actions.updatePilotChannel(
					this.props.pilotId,
					{ ...transformedData, version: this.props.channel.version },
					values.id
				)
			);
		}
	}

	handleValidationFaild(errors) {
		for (let i = 0; i < Object.keys(errors).length; i++) {
			const errElm = document.getElementsByName(Object.keys(errors)[i])[0];
			if (errElm) {
				errElm.scrollIntoView();
				break;
			}
		}
	}

	render() {
		const { model, pending, channel, error } = this.props;
		const formProps = {
			form: 'channel',
			ref: this._formRef,
			preserve: true,
			onSubmit: this.handleSave,
			onSubmitValidationFail: this.handleValidationFaild,
			initialValues: this.initialValues,
			validators: validate,
		};
		return (
			<div className={style.modal}>
				<EditChannelFormHeader data={channel} />
				<EditChannelForm
					model={model}
					disabled={channel.status === 'failed'}
					formProps={formProps}
					onUploadApiFile={this.handleUploadMediaFile}
					onCancel={this.handleCancel}
					onDelete={this.handleDelete}
					pending={pending.update || pending.fields}
					mediaPending={pending.media}
					error={error}
				/>
			</div>
		);
	}
}

EditChannelFormContainer.propTypes = {
	//mapStateToProps
	pilotId: PropTypes.string.isRequired,
	channel: PropTypes.object.isRequired,
	model: PropTypes.object.isRequired,
	error: PropTypes.string,
	pending: PropTypes.object.isRequired,
	dispatch: PropTypes.func,
	selectedChannelId: PropTypes.string
};

function mapStateToProps(state, ownProps) {
	const error = getAdminPilotError(state);
	const pending = getAdminPilotPending(state);
	const pilot = getAdminPilot(state);
	const channel = channelTransformShow(
		find(pilot.environment, (o) => o.id === ownProps.channelId)
	);
	const model = modelSelector(state, 'channel', '') || {};
	const { channelId } = getMetricsSection(state);
	return { model, pending, channel, pilotId: pilot.id, error, selectedChannelId: channelId };
}

export default connect(mapStateToProps)(EditChannelFormContainer);
