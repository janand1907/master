import React from 'react';
import { Field } from 'components/common/Forms';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import UsernameField from 'components/admin/common/commonFields/UsernameField';
import PasswordField from 'components/admin/common/commonFields/PasswordField';

const SftpFields = () => {
	return (
		<div>
			<IPAndPortField key="ipPort" ipName="ip_address" portName="port" />
			<UsernameField key="username" fieldName="username" />
			<PasswordField key="password" fieldName="password" allowFile />
			<Field key="isUserOwned" name="is_proov_owned" component="input" type="hidden" />
		</div>
	);
};

export default SftpFields;
