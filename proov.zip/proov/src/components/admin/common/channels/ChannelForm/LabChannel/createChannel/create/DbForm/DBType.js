import React from 'react';
import PropTypes from 'prop-types';
import LookupSelectField from 'components/admin/common/commonFields/LookupSelectField';

const DBType = ({ isProovOwned, scrollBottom,disabled }) => {
	return (
		<LookupSelectField
			key="dbType"
			label="Database Type"
			name="db_type"
			isProov={isProovOwned}
			lookupSelectProps={{
				lookupType: 'db_type',
				defaultOption: 'Select database type...',
				onFocus: scrollBottom,
				disabled:disabled
			}}
		/>
	);
};

DBType.propTypes = {
	model: PropTypes.object,
};

export default DBType;
