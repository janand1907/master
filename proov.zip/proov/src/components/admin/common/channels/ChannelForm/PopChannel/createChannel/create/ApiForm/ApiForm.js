/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { merge } from 'lodash';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import HarFileSelector from 'components/common/FileUpload/HarFileSelector';
import { getAdminPilotProxy } from 'ducks/admin/pilot/selectors';
import SafeZoneProxy from 'components/admin/common/commonFields/SafeZoneProxy';
import UploadMediaFile from 'components/admin/common/commonFields/UploadMediaFile';
import ApiAuthTypeField from 'components/admin/common/commonFields/ApiAuthTypeField';
import ApiTypeField from 'components/admin/common/commonFields/ApiTypeField';

const ApiForm = ({ model, proxy, onUploadApiFile, mediaPending, commonFormsConfig }) => {
	const authType = model.auth_type || (model.auth && model.auth.type) || null;
	const grantType = model.auth && model.auth.grant_type;
	const apiFormConfig = {
		initialValues: {
			is_dedicated: false,
			api_type: 'rest',
			api_spec_type: 'url',
			source: 'file',
			auth: 'none',
			name:"api_form"
		}
	};

	const formConfig = merge(apiFormConfig, commonFormsConfig);

	return (
		<Form noValidate {...formConfig}>
			<Field name="type" component="input" type="hidden" />

			<Field name="is_user_owned" component="input" type="hidden" />

			<FormGroup key="name" label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			<SafeZoneProxy key="proxy" proxy={proxy} />

			<ApiTypeField key="apiType" name="api_type" />
			{model.api_type === 'soap' && (
				<UploadMediaFile
					key="specificationFile"
					allowedFiles={['wsdl']}
					fileName="file_resource"
					mandatory
					onUpload={onUploadApiFile}
					pending={mediaPending}
				>
					Upload WSDL specification to generate
					<br />a static API.
				</UploadMediaFile>
			)}
			{model.api_type === 'rest' && (
				<UploadMediaFile
					key="api_spec_file_url"
					allowedFiles={['json']}
					fileName="api_spec_file_url"
					mandatory
					onUpload={onUploadApiFile}
					pending={mediaPending}
				>
					Upload JSON specification to generate
					<br /> a static API
				</UploadMediaFile>
			)}
			<ApiAuthTypeField
				key="apiAuthTypeField2"
				authType={authType}
				grantType={grantType}
				hideOAuth
			/>

			<FormGroup key="ip_address_for_API" label="Host" mandatory>
				<Field
					name="ip_address_for_API"
					component="input"
					type="text"
					className="form-control"
					maxLength={2083}
				/>
				<Error sticky name="ip_address_for_API" />
			</FormGroup>

			<HarFileSelector key="HarFileSelector" fileType="har" />
		</Form>
	);
};

ApiForm.propTypes = {
	apiType: PropTypes.string,
	grantType: PropTypes.string,
	onUploadApiFile: PropTypes.func.isRequired,
	onCancel: PropTypes.func.isRequired,
	mediaPending: PropTypes.bool.isRequired,
	model: PropTypes.object,
	commonFormsConfig: PropTypes.object,
	proxy: PropTypes.string
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.selectedForm) || {};
	const proxy = getAdminPilotProxy(state);

	return { model, proxy };
}

export default connect(
	mapStateToProps,
	null
)(ApiForm);
