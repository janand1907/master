import React from 'react';
import PropTypes from 'prop-types';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import { FormGroup, Field, Error } from 'components/common/Forms';
import Select from 'components/ui/Select/Select';
import style from '../../style.scss';

const DISTRIBUTIONS = {
	windows: {
		win_2012: 'Windows 2012 Server',
		win_2016: 'Windows 2016 Server',
		win_2019: 'Windows 2019 Server'
	},
	linux: { ubuntu: 'Ubuntu Server 20.04 LTS', redhat: 'Red Hat Enterprise Linux 8', amazon: 'Amazon Linux 2 AMI' }
};

const OSField = ({ os, fieldName, label, isProovOwned }) => {
	return (
		<React.Fragment>
			<FormGroup label={label} mandatory>
				<Field
					name={fieldName}
					validateOn="change"
					component={({ input }) => (
						<RadioGroup
							name={input.name}
							selectedValue={input.value}
							onChange={input.onChange}
							className={style.controlPushMdWrapper}
						>
							<PushButton value="windows" className={style.controlPushMd}>
								Windows
							</PushButton>
							<PushButton value="linux" className={style.controlPushMd}>
								Linux
							</PushButton>
						</RadioGroup>
					)}
				/>

				<Error sticky name={fieldName} />
			</FormGroup>
			{isProovOwned && (
				<FormGroup label="OS Distribution" mandatory>
					<Field
						name="os_dist"
						validateOn={[ 'blur', 'change' ]}
						component={({ input }) => (
							<Select
								menuClassName={style.menuSelect}
								optionClassName={style.optionSelect}
								options={DISTRIBUTIONS[os]}
								{...input}
								value={input.value}
							/>
						)}
					/>

					<Error sticky name="os_dist" />
				</FormGroup>
			)}
		</React.Fragment>
	);
};

OSField.propTypes = {
	isProovOwned: PropTypes.bool,
	fieldName: PropTypes.string.isRequired,
	label: PropTypes.string,
	os: PropTypes.string
};

export default OSField;
