import React from 'react';
import PropTypes from 'prop-types';
import style from '../../../style.scss';

const APIFields = ({ channel }) => {

	let authFields = {};
	if (channel && channel.auth && channel.auth.type && channel.auth.type === 'basic') {
		authFields = {
			'Username': channel.auth.username,
			'Password': channel.auth.password
		};
	} else if (channel && channel.auth && channel.auth.type && channel.auth.type === 'oauth2.0') {
		authFields = {
			'Client ID': channel.auth.client_id,
			'Client Secret': channel.auth.client_secret,
			'Token URL': channel.auth.token_url,
			'Grant Type': channel.auth.grant_type
		};
		if (channel && channel.auth && channel.auth.grant_type && channel.auth.grant_type === 'password') {
			// extend for oAuth2.0 password grant
			authFields = {
				...authFields,
				'Username': channel.auth.username,
				'Password': channel.auth.password
			};
		}
	}

	const scheme = [
		channel && channel.api_url &&
		<div key="dlData" className={style.dlData}>
			<dt> Base URL</dt>
			<dd>{channel.api_url}</dd>
		</div>,
		channel && channel.auth && channel.auth.type !== 'none' &&
		<div key="dlData2" className={style.dlData}>
			<dt>Authentication</dt>
			<dt className={style.authType}>{channel.auth.type}</dt>
		</div>,
		channel && channel.auth && channel.auth.type !== 'none' && Object.keys(authFields).length > 0 &&
			<div key="dlDataCredentials" className={style.credentials}>
				{Object.keys(authFields).map((item, index) => {
					return (
						<div key={index}>
							<dt>{item}</dt>
							<dd>{authFields[item]}</dd>
						</div>);
				})}
			</div>
	];

	return (
		<dl>
			{scheme}
		</dl>
	);
};

APIFields.propTypes = {
	apiSpecType: PropTypes.string,
	authType: PropTypes.string,
	apiType: PropTypes.string,
	channel: PropTypes.object,
};

export default APIFields;
