/* eslint-disable camelcase */
import { pick } from 'lodash';
import isLength from 'validator/lib/isLength';
import isIP from 'validator/lib/isIP';
import isInt from 'validator/lib/isInt';
import isURL from 'validator/lib/isURL';
import * as i18n from 'i18n/en/channelFormValidation.json';

const isExist = (value) => !!value;
const str = (value) => (value || '').toString().trim();
const validator = (validate, message) => (value) =>
	!validate(value) ? message : undefined;

const projectIdPattern = /^[A-Za-z0-9\!\-\"\']{4,30}$/;

// Validators for environment component
const componentValidators = {
	// Common validators
	name: validator(
		(val) => isLength(str(val), { min: 1, max: 35 }),
		'Please specify a name for this endpoint (1-35 characters)'
	),
	type: validator((val) => isExist(val), 'Please select the endpoint type'),
	source: validator((val) => isExist(val), 'Please select the source type'),
	os: validator((val) => isExist(val), 'Please select a Server Type'),
	os_dist: validator((val) => isExist(val), 'Please select a OS distribution'),
	aws_instance: validator(
		(val) => isExist(val),
		'Please select an instance type'
	),
	db_version: validator((val) => isExist(val), 'Please select a DB version'),
	db_name: (val, { db_type }) => {
		if (db_type === 'bigquery') {
			const strVal = str(val);
			if (!isLength(strVal, { min: 4, max: 30 })) {
				return '4-30 characters';
			}
			if (!strVal.match(projectIdPattern)) {
				return 'Project ID has invalid characters';
			}
		} else {
			if (!isLength(str(val), { min: 2, max: 64 })) {
				return 'Name should include 2 - 64 characters';
			}
			if (!str(val).match(/^[a-z0-9_]+$/i)) {
				return 'Permitted characters [0-9,a-z,A-Z,_]';
			}

			if (val === 'postgresql' || val === 'mysql') {
				return 'Reserved words are not valid names';
			}
		}
	},
	db_type: validator((val) => isExist(val), 'Please select a database type'),
	credentials_file: validator(
		(val) => val && typeof val === 'object',
		'Please upload credentials file'
	),
	ip_address: validator((val) => {
		const valStr = str(val);
		return (
			(isIP(valStr) || isURL(valStr, { allow_underscores: true })) &&
			isLength(str(valStr), { min: 4, max: 2083 })
		);
	}, 'Please enter a valid IP'),
	port: validator((val) => isInt(str(val)) && val <= 65535, 'Port is invalid'),
	username: validator(
		(val) => isLength(str(val), { min: 2, max: 110 }),
		'2-110 characters'
	),
	password: (value) => {
		if (value && typeof value === 'object') return;
		if (!isLength(str(value), { min: 2, max: 200 })) {
			return 'Please specify a valid password (2-200 characters)';
		}
	},
	password_pem: (value) => {
		if (value && typeof value === 'object') return;
		if (!isLength(str(value), { min: 2, max: 200 })) {
			return 'Please specify a valid PEM file';
		}
	},
	bm: (obj) => {
		let err = {};
		if (obj && obj.enabled && !obj.file_id) {
			err['bm.file_id'] = 'Please select pcap file';
		}
		return err;
	},
	api_type: validator((val) => isExist(val), 'Please select an API type'),
	api_spec_file_url: (value) => {
		if (value && typeof value === 'object') return;
		if (!isLength(str(value), { min: 2, max: 200 })) {
			return 'Please specify a valid JSON file';
		}
	},
	api_url: validator(
		(val) =>
			isLength(str(val), { min: 4, max: 2083 }) &&
			isURL(val, { allow_underscores: true }),
		'4-2083 characters'
	),
	vpn_type: validator((val) => isExist(val), 'Please select a VPN type'),
	auth: (obj) => {
		let err = {};
		if (obj && obj.type === 'oauth2.0') {
			if (!isExist(obj) || !isExist(obj.client_id))
				err['auth.client_id'] = 'Please select a client id';
			if (
				!isExist(obj) ||
				(!isExist(obj.client_secret) && obj.grant_type === 'client_credentials')
			)
				err['auth.client_secret'] = 'Please select a client_secret';
			// if (!isExist(obj) || !(isLength(str(obj.auth_url), { min: 4, max: 2083 }) && isURL(obj.auth_url, { allow_underscores: true }))) err['auth.auth_url'] = '4-2083 characters';
			if (
				!isExist(obj) ||
				!(
					isLength(str(obj.token_url), { min: 4, max: 2083 }) &&
					isURL(obj.token_url, { allow_underscores: true })
				)
			)
				err['auth.token_url'] = '4-2083 characters';
			if (!isExist(obj) || !isLength(str(obj.password), { min: 2, max: 200 }))
				err['auth.password'] = '2-200 characters';
			if (!isExist(obj) || !isLength(str(obj.username), { min: 2, max: 110 }))
				err['auth.username'] = '2-110 characters';
		} else if (obj && obj.type === 'basic') {
			if (!isExist(obj) || !isLength(str(obj.password), { min: 2, max: 200 }))
				err['auth.password'] = '2-200 characters';
			if (!isExist(obj) || !isLength(str(obj.username), { min: 2, max: 110 }))
				err['auth.username'] = '2-110 characters';
		}
		return err;
	},
	db_settings: (obj) => {
		let err = {};
		if (!isExist(obj) || !isLength(str(obj.password), { min: 2, max: 200 }))
			err['db_settings.password'] = '2-200 characters';
		if (!isExist(obj) || !isLength(str(obj.username), { min: 2, max: 110 }))
			err['db_settings.username'] = '2-110 characters';
		const valStr = obj && obj.ip_address ? str(obj.ip_address) : '';
		if (
			!isExist(valStr) ||
			(!isIP(valStr) && !isURL(valStr, { allow_underscores: true }))
		)
			err['db_settings.ip_address'] = 'Please enter a valid IP';
		if (!isExist(obj) || !isInt(str(obj.port)) || obj.port > 65535)
			err['db_settings.port'] = 'Port is invalid';
		if (!isExist(obj) || !isExist(obj.db_type))
			err['db_settings.db_type'] = 'Please select a database type';
		if (!isExist(obj) || !isLength(str(obj.db_name), { min: 2, max: 128 }))
			err['db_settings.db_name'] = '2-128 characters';
		return err;
	},
	file_resource: validator(
		(val) => val && val.url && typeof val.url === 'string',
		'Please upload specification file'
	),
	aws: (obj) => {
		let err = {};
		if (!isExist(obj) || !(str(obj.access_key).length === 20))
			err['aws.access_key'] = 'Please enter a valid AWS Access Key';
		if (!isExist(obj) || !(str(obj.secret_key).length === 40))
			err['aws.secret_key'] = 'Please enter a valid AWS Secret Key';
		if (!isExist(obj) || !isLength(str(obj.region), { min: 9, max: 14 }))
			err['aws.region'] = 'Please enter a valid AWS Region name';
		if (!isExist(obj) || !isLength(str(obj.bucket_path), { min: 2, max: 255 }))
			err['aws.bucket_path'] = 'Please enter a valid AWS S3 Bucket name';
		return err;
	},
	azure: (obj) => {
		let err = {};
		if (!isExist(obj) ||!isExist(obj.account_key))
			err['azure.account_key'] = 'Please enter a valid Azure Account Key';
		if (!isExist(obj) ||!isExist(obj.container_name))
			err['azure.container_name'] = 'Please enter a valid Azure Container Name';
		if (!isExist(obj) ||!isExist(obj.account_name))
			err['azure.account_name'] = 'Please enter a valid Azure Account Name';
		return err;
	},
	// Blockchain validators
	node_num: validator(
		(val) => Number(val) >= 2 && Number(val) <= 5,
		'number nodes should be between 2 - 5'
	),
	init_balance: validator(
		(val) => Number(val) > 0 && Number(val) <= 1000000,
		'Please provide an initial balance'
	),
	blockchain_type: validator(
		(val) => isExist(val),
		'Please select a blockchain type'
	),

	credentials: validator((val) => val && val.length !== 0, i18n.credentials),
	// file_resource: validator((val) => isExist(val) , "Please Upload yaml File"),
	cloud_type: validator((val) => isExist(val) , i18n.cloud_type)
};

function getSchemeForComponent(comp) {
	const common = ['type', 'name'];
	switch (comp.type) {
		case 'server':
			return [
				...common,
				'cloud_type',
				'os',
				...(!comp.is_proov_owned
					? [
						'ip_address',
						'port',
						'username',
						'password',
						'password_pem',
						'auth',
						'is_assingning_credentials',
						...(!comp.is_proov_owned && comp.is_assingning_credentials
							? ['credentials']
							: []),
					]
					: ['aws_instance', 'username', 'password', 'bm']),
			];
		case 'docker':
			return [...common, 'os',
			(comp.is_docker_compose ?
				 'file_resource':''),
			'cloud_type', 'ip_address', 'port', 'username', 'password', 'aws_instance'];
		case 'db':
			return [
				...common,
				'cloud_type',
				'db_type',
				...(comp.db_type
					? comp.db_type === 'bigquery'
						? ['db_name', 'project_id', 'credentials_file']
						: [
							'ip_address',
							'port',
							'db_name',
							'username',
							'password',
							'is_assingning_credentials',
							'db_version',
							...(!comp.is_proov_owned && comp.is_assingning_credentials
								? ['credentials']
								: []),
						]
					: []),
			];
		case 'api':
			return [
				...common,
				'db_settings',
				'api_type',
				'auth',
				'username',
				'password',
				'source',
				'jar_file_url',
				'file_resource',
				'ip_address',
				'port',
				'cloud_type',
				...(!comp.is_proov_owned && comp.api_type === 'rest'
					? ['api_spec_file_url']
					: ['api_url']),
			];
		case 'vpn':
			return [
				...common,
				'vpn_type',
				'ip_address',
				'port',
				'username',
				'password',
			];
		case 'sftp':
			return [...common, 'ip_address', 'port', 'username', 'password'];
		case 'storage':
			return [...common, 'aws','azure', 'cloud_type'];
		case 'blockchain':
			return [...common, 'blockchain_type', 'node_num', 'init_balance'];
		case 'saas':
			return [...common]
		default:
			return [];
	}
}

function runValidators(data, validators) {
	let err,
		errors = {};
	Object.keys(validators).forEach((field) => {
		err = validators[field](data[field], data);
		if (typeof err === 'string') {
			errors[field] = err;
		} else if (typeof err === 'object') {
			errors = { ...errors, ...err };
		}
	});
	return errors;
}

export default function validate(values) {
	return runValidators(values, {
		...pick(componentValidators, getSchemeForComponent(values)),
	});
}
