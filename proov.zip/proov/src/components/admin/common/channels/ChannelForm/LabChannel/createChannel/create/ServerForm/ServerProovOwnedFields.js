import React from 'react';
import PropTypes from 'prop-types';
import LookupSelectField from 'components/admin/common/commonFields/LookupSelectField';
import DedicatedServerField from 'components/admin/common/commonFields/DedicatedServerField';
import BehaviorMirroringFields from 'components/admin/common/commonFields/BehaviorMirroringFields';

const ServerProovOwnedFields = ({
	isBm,
	scrollBottom,
	isDedicatedAllowed,
	isDedicated,
	lookupType,
	disabled,
	isRequestToEnterprise
}) => {

	let scheme = [];
	scheme.push(
		<LookupSelectField
			key="awsInstance"
			label="Instance Type"
			name="aws_instance"
			lookupSelectProps={{
				lookupType: lookupType,
				disabled: disabled,
				defaultOption: 'Select instance type...',
				onFocus: scrollBottom
			}}
		/>
	);
	isDedicatedAllowed
		? scheme.push(
			<DedicatedServerField key="dedicatedServer" isBmEnabled={isBm} />
		)
		: null;
	!isRequestToEnterprise && scheme.push(
		<BehaviorMirroringFields
			key="enableBehaviorMirroring"
			isEnabled={isBm}
			isDedicatedEnabled={isDedicated}
		/>
	);

	return (
		<div>{scheme}</div>
	);
};

ServerProovOwnedFields.propTypes = {
	isBm: PropTypes.bool,
	isDedicated: PropTypes.bool,
	isDedicatedAllowed: PropTypes.bool,
	scrollBottom: PropTypes.func
};

export default ServerProovOwnedFields;
