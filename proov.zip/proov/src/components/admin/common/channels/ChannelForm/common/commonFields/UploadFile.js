import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import DropZone from 'components/ui/DropZone/DropZone';
import Shelf from 'components/ui/Rack/Shelf';
import { FileIcon } from 'components/ui/Icons';
import { readFileAsText } from 'utils';
import style from '../../style.scss';

const UploadFile = ({ fileName, label, allowedFiles, ...props }) => {
	return (
		<FormGroup key={fileName} label={label} mandatory>
			<Field
				name={fileName}
				validateOn="change"
				component={({ input }) => {
					return typeof input.value === 'object'
						? <Shelf
							value={input.value.name}
							renderValue={v => (<span><FileIcon className={style.shelfIcon} />{v}</span>)}
							allowRemove
							allowEdit={false}
							onRemove={() => { input.onChange() }}
						  />
						: <DropZone
							types={allowedFiles}
							onDropEnd={({ files }) => readFileAsText(files[0], e => { input.onChange({ name: files[0].name, contents: e.target.result }) })}
							maxFilesCount={1}
							maxFileSize={1}
							className={style.dropZone}>
							<FileIcon className={style.dropZoneIcon} />
							{props.children}
						</DropZone>;
				}}
			/>
			<Error sticky name={fileName} />
		</FormGroup>
	);
};

UploadFile.propTypes = {
	fileName: PropTypes.string.isRequired,
	label: PropTypes.string,
	children: PropTypes.node,
	allowedFiles: PropTypes.array.isRequired,
};

export default UploadFile;
