import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import Rack from 'components/ui/Rack/Rack';

const RestrictTablesField = ({ disabled, label, showRack, ...props }) => {
	return (
		<FormGroup {...props}>
			<label className="form-check">
				<Field disabled={disabled} name="restrict_tables" component="input" type="checkbox" className="form-control" /> {label}
			</label>
			{showRack &&
				<Field
					disabled={disabled}
					name="tables"
					defaultValue={[]}
					validateOn="change"
					component={({ input }) => (
						<Rack items={input.value} onChange={input.onChange} />
					)} />}
			<Error sticky name="tables" />
		</FormGroup>
	);
};

RestrictTablesField.propTypes = {
	label: PropTypes.string,
	showRack: PropTypes.bool.isRequired,
	disabled: PropTypes.bool.isRequired
};

RestrictTablesField.defaultProps = {
	showRack: false,
	disabled: false,
	label: 'Permitted tables'
};

export default RestrictTablesField;
