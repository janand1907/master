import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getSubscription } from 'ducks/myAccount/selectors';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import Switch from 'components/ui/Switch/Switch';
import CloudTypeField from 'components/admin/common/commonFields/CloudTypeSelect';
import style from '../../../../style.scss';
import LookupSelectField from 'components/admin/common/commonFields/LookupSelectField';
import { getLookupsByCloudType } from 'ducks/lookups/actions';
import UploadMediaFile from 'components/admin/common/commonFields/UploadMediaFile';


const DockerForm = ({
	scrollBottom,
	commonFormsConfig,
	getLookupsByCloudType,
	isRequestToEnterprise,
	onUploadApiFile,
	model,
	isReviewRequest
}) => {

	const [cloudType, setCloudType] = useState(model.cloud_type);

	useEffect(() => {
		if (!cloudType && model.cloud_type) {
			setCloudType(model.cloud_type)
		}
	}, [commonFormsConfig]);

	return (
		<Form noValidate {...commonFormsConfig}>
			<Field name="type" component="input" type="hidden" />

			<FormGroup
				hidden={isRequestToEnterprise}
				className={style.prvServerSwitchWrapper}
				label={<span className={style.biggerLabel}>Use prooV’s Docker</span>}
			>
				<Field
					name="is_proov_owned"
					component={({ input }) => (
						<Switch
							className={style.switch}
							name={input.name}
							onToggle={input.onChange}
							toggled={true}
							disabled={true}
						/>
					)}
				/>
			</FormGroup>

			<FormGroup key="name" label="Connection Name"  mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			<CloudTypeField
				onChange={(type) => { cloudType !== type && (setCloudType(type), getLookupsByCloudType('aws_instance_type', type)) }}
			/>

			<LookupSelectField
				key="awsInstance"
				label="Instance Type"
				name="aws_instance"
				lookupSelectProps={{
					lookupType: cloudType ? 'aws_instance_type' : '',
					defaultOption: 'Select instance type...',
					onFocus: scrollBottom,
					disabled: !cloudType
				}}
			/>
			{(isRequestToEnterprise || isReviewRequest) && <React.Fragment>
				<FormGroup

					className={style.prvServerSwitchWrapper}
					label={<span className={style.biggerLabel}>Use Docker Compose</span>}
				>
					<Field
						name="is_docker_compose"
						component={({ input }) => (
							<Switch
								className={style.switch}
								name={input.name}
								onToggle={input.onChange}
								toggled={input.value}
								disabled={isReviewRequest}
							/>
						)}
					/>
				</FormGroup>
				{model.is_docker_compose &&

					<UploadMediaFile
						key="docker_compose_file_url"
						allowedFiles={['yaml', 'yml']}
						fileName="file_resource"
						mandatory
						onUpload={onUploadApiFile}
						allowView={true}
						disabledRemove={isReviewRequest}
					>
						Upload YAML file for Docker Compose
					</UploadMediaFile>}
			</React.Fragment>}
		</Form>

	);
};

DockerForm.propTypes = {
	commonFormsConfig: PropTypes.object,
	isSelectedFormProovServerTypes: PropTypes.bool,
	model: PropTypes.object,
	isDedicatedAllowed: PropTypes.bool,
	scrollBottom: PropTypes.func,
	getLookupsByCloudType: PropTypes.func
};


function mapStateToProps(state, ownProps) {
	const isDedicatedAllowed = getSubscription(state).config.dedicated.limit;
	const model = modelSelector(state, ownProps.selectedForm) || {};
	return { model, isDedicatedAllowed };
}

export default connect(mapStateToProps, { getLookupsByCloudType })(DockerForm);
