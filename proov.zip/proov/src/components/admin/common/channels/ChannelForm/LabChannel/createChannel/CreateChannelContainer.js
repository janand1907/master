/* eslint-disable react/no-multi-comp */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getAdminPilot, getAdminPilotPending } from 'ducks/admin/pilot/selectors';
import { modelSelector } from 'ducks/forms/selectors';
import { uploadMediaFile, addPilotChannel } from 'ducks/admin/pilot/channel/actions';
import { hideModal } from 'ducks/modal/actions';
import { channelTransformInitialValue } from 'utils/transformEnvironment';
import { Spinner } from 'components/ui/Spinner';
import validate from '../../validation';
import style from '../../style.scss';
import CreateChannelForm from './CreateChannelForm';

class CreateChannelContainer extends React.Component {
	constructor(props) {
		super(props);

		this.handleCancel = this.handleCancel.bind(this);
		this.handleSave = this.handleSave.bind(this);
		this.handleUploadMediaFile = this.handleUploadMediaFile.bind(this);
		this._formRef = this._formRef.bind(this);
		this.handleConnectionTypeChange = this.handleConnectionTypeChange.bind(this);
		this.initialValues = this.initialValues.bind(this);
		this.handleScrollBottom = this.handleScrollBottom.bind(this);

		this.state = {
			connectionType:
				props.isWizardEdit || props.isEdit || props.channelType
					? (props.channel && props.channel.type) || props.channelType
					: 'server'
		};
	}

	componentDidMount() {
		// For wizard, set errors coming from server
		if (this.props.errors) {
			this._form.setErrors(this.props.errors);
		}
	}

	_formRef(node) {
		if (node) {
			this._form = node.getWrappedInstance();
		}
	}

	handleCancel() {
		this.props.hideModal();
	}

	handleUploadMediaFile(file, fieldName) {
		if (!file) return;

		const { connectionType } = this.state;
		this.props.uploadMediaFile(file, connectionType, fieldName);
	}

	handleConnectionTypeChange(newConnectionType) {
		if (newConnectionType === this.state.connectionType) return;

		this.setState({ connectionType: newConnectionType });
	}

	async handleSave(values, done) {
		console.log("values", values);
		if (!this._form.validate()) return;

		if (this.props.isWizard || this.props.componentTypes || this.props.isReviewRequest) {
			if (this.props.errors) {
				Object.keys(this.props.errors).map(err => {
					this._form.clearErrors(this.props.errors[err]);
				});
			}
			this.props.onSave(values, done, true);
		} else {
			await this.props.addPilotChannel(this.props.pilotId, values);
		}
	}

	handleValidationFaild(errors) {
		for (let i = 0; i < Object.keys(errors).length; i++) {
			const errElm = document.getElementsByName(Object.keys(errors)[i])[0];
			if (errElm) {
				errElm.scrollIntoView();
				break;
			}
		}
	}

	/* eslint-disable camelcase */
	initialValues() {
		const { channel, isWizardEdit, initialValues, isEdit, vendorId, isReviewRequest } = this.props;
		const { connectionType } = this.state;

		const initialValuesObj = initialValues ? initialValues : {};
		if (isWizardEdit || isEdit ) {
			return {
				...channelTransformInitialValue({ ...channel }, vendorId,isReviewRequest),
				...initialValuesObj,
				type: connectionType
			};
		} else {
			return {
				type: connectionType,
				is_proov_owned: true,
				auth: { type: 'none', grant_type: 'client_credentials' },
				is_assingning_credentials: false,
				is_docker_compose: false,
				...initialValuesObj
			};
		}
	}
	/* eslint-enable camelcase */

	handleScrollBottom() {
		if (this.scrollArea)
			this.scrollArea.scrollTop = this.scrollArea.scrollHeight;
	}

	submitLabel(isWizard, isWizardEdit, isRequestToEnterprise, submitLabel) {
		if (submitLabel)
			return submitLabel;
		if (isWizard || isRequestToEnterprise)
			return (isWizardEdit && 'Update') || 'Add To List';
		return 'Create';
	}

	render() {
		const { pending, isWizard, isWizardEdit, componentTypes, submitLabel, isReviewRequest } = this.props;
		const { connectionType } = this.state;

		const commonFormsConfig = {
			form: connectionType,
			ref: this._formRef,
			preserve: true,
			onSubmit: this.handleSave,
			onSubmitValidationFail: this.handleValidationFaild,
			initialValues: this.initialValues(),
			validators: validate
		};

		return (
			<div className={style.modal}>
				<div className={style.header}>
					<h2>New Environment {this.props.isRequest && 'Request'} </h2>
				</div>

				<div ref={c => (this.scrollArea = c)} className={style.content}>
					<CreateChannelForm
						onConnectionTypeChange={this.handleConnectionTypeChange}
						selectedForm={connectionType}
						commonFormsConfig={commonFormsConfig}
						onUploadApiFile={this.handleUploadMediaFile}
						onCancel={this.handleCancel}
						pending={pending.update || pending.fields}
						mediaPending={pending.media}
						scrollBottom={this.handleScrollBottom}
						componentTypes={componentTypes}
						isReviewRequest={isReviewRequest}
					/>
				</div>

				<div className={style.footer}>
					<button
						type="button"
						disabled={pending.update || pending.fields}
						className={style.btnCancel}
						onClick={this.handleCancel}
					>
						Cancel
					</button>
					<button
						type="submit"
						disabled={pending.update || pending.fields || pending.media}
						className={style.btnCreate}
						onClick={() => this._form.submit()}
					>
						{this.submitLabel(isWizard, isWizardEdit, componentTypes, submitLabel)}
						{pending.update || (pending.fields && <Spinner />)}
					</button>
				</div>
			</div>
		);
	}
}

CreateChannelContainer.propTypes = {
	//wizard
	channel: PropTypes.object,
	onSave: PropTypes.func,
	errors: PropTypes.object, // Errors for wizard
	isWizard: PropTypes.bool,
	isWizardEdit: PropTypes.bool,

	//mapStateToProps
	pilotId: PropTypes.string, // AddChannel flow
	pending: PropTypes.object.isRequired,
	isDedicatedAllowed: PropTypes.bool,
	channelType: PropTypes.string,

	//mapDispatchToProps
	hideModal: PropTypes.func,
	uploadMediaFile: PropTypes.func,
	addPilotChannel: PropTypes.func
};

function mapStateToProps(state, ownProps) {
	let environment, channel;

	const pilot = getAdminPilot(state);
	const pending = getAdminPilotPending(state);
	const pilotId = pilot ? pilot.id : null;

	const getChannelWithProovOwned = (ch) => { return { ...ch, is_proov_owned: !ch.is_user_owned } }

	if (ownProps.isWizard) {
		environment = modelSelector(state, 'createPilot', 'environment') || [];
		channel = ownProps.channelIndex >= 0 ? environment[ownProps.channelIndex] : null;
	}
	else if (ownProps.isEdit) {
		environment = modelSelector(state, `requestsToEnterprise_${ownProps.vendor.id}`, 'environment') || [];
		channel = ownProps.channelIndex >= 0 ? getChannelWithProovOwned(environment[ownProps.channelIndex]) : null;
	}
	else {
		environment = pilot && pilot.environment;
	}

	return { pending, pilotId, channel, ...(ownProps.vendor) && { vendorId: ownProps.vendor.company_id } };
}

function mapDispatchToProps(dispatch) {
	return {
		hideModal: () => dispatch(hideModal()),
		uploadMediaFile: (file, channel, fieldName) =>
			dispatch(uploadMediaFile(file, channel, fieldName)),
		addPilotChannel: (pilotId, values) => dispatch(addPilotChannel(pilotId, values))
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(CreateChannelContainer);
