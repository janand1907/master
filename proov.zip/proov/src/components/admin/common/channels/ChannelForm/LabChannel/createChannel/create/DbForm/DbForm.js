import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { modelSelector } from 'ducks/forms/selectors';
import { Form, FormGroup, Field, Error } from 'components/common/Forms';
import Switch from 'components/ui/Switch/Switch';
import DBName from 'components/admin/common/commonFields/DBName';
import CloudTypeField from 'components/admin/common/commonFields/CloudTypeSelect';
import { getLookupsByCloudType } from 'ducks/lookups/actions';
import style from '../../../../style.scss';
import DbUserOwnedFields from './DbUserOwnedFields';
import DBVersion from './DBVersion';
import DBType from './DBType';

const DbForm = ({ model, scrollBottom, commonFormsConfig, getLookupsByCloudType, isRequestToEnterprise }) => {

	const [cloudType, setCloudType] = useState(null);

	useEffect(()=> {
		if(!cloudType && commonFormsConfig.initialValues.cloud_type){
			setCloudType(commonFormsConfig.initialValues.cloud_type)
		}
	},[commonFormsConfig]);

	return (
		<Form noValidate {...commonFormsConfig}>
			<Field name="type" component="input" type="hidden" />
			<FormGroup
				hidden={isRequestToEnterprise}
				className={style.prvServerSwitchWrapper}
				label={<span className={style.biggerLabel}>Use prooV’s Server</span>}
			>
				<Field
					name="is_proov_owned"
					component={({ input }) => (
						<Switch
							className={style.switch}
							name={input.name}
							onToggle={input.onChange}
							toggled={input.value}
						/>
					)}
				/>
			</FormGroup>
			<FormGroup key="name"  label="Connection Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					maxLength="35"
					placeholder="Enter a name for the connection"
				/>
				<Error sticky name="name" />
			</FormGroup>

			{model.is_proov_owned && <CloudTypeField
				onChange={(type) => { cloudType !== type && (setCloudType(type), getLookupsByCloudType('db_version', type)) }}
			/>}

			<DBType
				key="dbType"
				isProovOwned={model.is_proov_owned}
				scrollBottom={scrollBottom}
				disabled={model.is_proov_owned && !cloudType}
			/>
			<DBName  key="dbName" fieldName="db_name" />
			{model.db_type === 'mongodb' && !model.is_proov_owned && (
				<DBName
					key="dbAuth"
					dbName="Authentication DB Name"
					tooltip="The name of database where user is created"
					fieldName="auth_db"
				/>
			)}
			{model.is_proov_owned && (
				<DBVersion
					key="dbVersion"
					dbType={model.db_type}
					scrollBottom={scrollBottom}
					isProovOwned={model.is_proov_owned}
					lookupType={cloudType ? 'db_version' : ''}
				/>
			)}
			<div>{!model.is_proov_owned && <DbUserOwnedFields model={model} />}</div>
		</Form>
	);
};

DbForm.propTypes = {
	scrollBottom: PropTypes.func,
	model: PropTypes.object,
	commonFormsConfig: PropTypes.object,
};

function mapStateToProps(state, ownProps) {
	const model = modelSelector(state, ownProps.selectedForm) || {};
	return { model };
}

export default connect(mapStateToProps, { getLookupsByCloudType })(DbForm);
