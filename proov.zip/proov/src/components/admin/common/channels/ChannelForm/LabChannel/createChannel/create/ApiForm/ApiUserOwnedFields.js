import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import UploadMediaFile from 'components/admin/common/commonFields/UploadMediaFile';
import ApiAuthTypeField from 'components/admin/common/commonFields/ApiAuthTypeField';
import ApiTypeField from 'components/admin/common/commonFields/ApiTypeField';

const ApiUserOwnedFields = ({
	authType,
	apiType,
	grantType,
	mediaPending,
	onFileUpload
}) => {
	return (
		<div>
			<ApiTypeField key="apiType" name="api_type" />
			{apiType === 'soap' && (
				<FormGroup key="apiUrl" label="URL" mandatory={apiType !== 'rest'}>
					<Field
						name="api_url"
						component="input"
						type="text"
						maxLength="2083"
						className="form-control"
						placeholder="Enter Base or Resource URL"
					/>
					<Error sticky name="api_url" />
				</FormGroup>
			)}
			{apiType === 'rest' && (
				<UploadMediaFile
					key="api_spec_file_url"
					allowedFiles={['json']}
					fileName="api_spec_file_url"
					mandatory
					onUpload={onFileUpload}
					pending={mediaPending}
				>
					Upload JSON specification to generate
					<br /> a static API
				</UploadMediaFile>
			)}
			<ApiAuthTypeField
				key="apiAuthTypeField2"
				authType={authType}
				grantType={grantType}
			/>
		</div>
	);
};

ApiUserOwnedFields.propTypes = {
	authType: PropTypes.string,
	apiType: PropTypes.string,
	grantType: PropTypes.string,
	onFileUpload: PropTypes.func.isRequired,
	mediaPending: PropTypes.bool.isRequired
};

export default ApiUserOwnedFields;
