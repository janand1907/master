import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import style from '../../style.scss';

const OAuthFields = ({ grantType }) => {
	const scheme = [
		<FormGroup key="auth.grant_type" label="Grant Type" mandatory>
			<Field name="auth.grant_type" validateOn="change" defaultValue="client_credentials" component={({ input }) => (
				<RadioGroup name={input.name} selectedValue={input.value} onChange={input.onChange} className={style.controlPushMdWrapper}>
					<PushButton value="client_credentials" className={style.controlPushMd}>Client Credentials</PushButton>
					<PushButton value="password" className={style.controlPushMd}>Password</PushButton>
				</RadioGroup>
			)} />
			<Error sticky name="auth.grant_type" />
		</FormGroup>
	];

	const userNamePassword = [
		<FormGroup key="username" label="Username" mandatory>
			<Field name="auth.username" component="input" type="text" className="form-control" placeholder="" />
			<Error sticky name="auth.username" />
		</FormGroup>,
		<FormGroup key="password" label="Password" mandatory>
			<Field name="auth.password" component="input" type="password" className="form-control" placeholder="" />
			<Error sticky name="auth.password" />
		</FormGroup>
	];

	const commonFields = [
		<FormGroup key="clientId" label="Client ID" mandatory>
			<Field name="auth.client_id" component="input" type="text" className="form-control" placeholder="" />
			<Error sticky name="auth.client_id" />
		</FormGroup>,
		<FormGroup key="clientSecret" label="Client Secret" mandatory={grantType === 'client_credentials'}>
			<Field name="auth.client_secret" component="input" type="text" className="form-control" placeholder="" />
			<Error sticky name="auth.client_secret" />
		</FormGroup>,
		<FormGroup key="tokenUrl" label="Access Token URL" mandatory>
			<Field name="auth.token_url" component="input" type="text" className="form-control" placeholder="" />
			<Error sticky name="auth.token_url" />
		</FormGroup>
	];

	let schemeRender = scheme.concat(commonFields);
	if (grantType === 'password') { schemeRender = scheme.concat(userNamePassword, commonFields) }

	return (
		<div>
			{schemeRender}
		</div>
	);
};

OAuthFields.propTypes = {
	grantType: PropTypes.string
};

export default OAuthFields;
