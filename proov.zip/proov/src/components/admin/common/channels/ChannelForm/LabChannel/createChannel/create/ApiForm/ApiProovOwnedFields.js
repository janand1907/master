/* eslint-disable no-nested-ternary */
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import { FormGroup, Field, Error } from 'components/common/Forms';
import Select from 'components/ui/Select/Select';
import DBName from 'components/admin/common/commonFields/DBName';
import HarFileSelector from 'components/common/FileUpload/HarFileSelector';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import UploadMediaFile from 'components/admin/common/commonFields/UploadMediaFile';
import UsernamePasswordField from 'components/admin/common/commonFields/UsernamePasswordField';
import ApiTypeField from 'components/admin/common/commonFields/ApiTypeField';
import style from '../../../../style.scss';

const ApiProovOwnedFields = ({
	source,
	onFileUpload,
	apiType,
	dbType,
	mediaPending,
	fileResource,
	hideModal,
	cloudType
}) => {
	let scheme = [
		<Link
			key="link"
			to="/userguide/apiservice"
			target="_blank"
			className={style.faqLink}
		>
			How does it work?
		</Link>,
		<ApiTypeField key="apiType" name="api_type" 	disabled={!cloudType} />,
	];

	if (apiType === 'soap') {
		scheme = [
			...scheme,
			<Field key="apiSource" name="source" component="input" type="hidden" />,
		];
	} else if (apiType === 'rest') {
		scheme = [
			...scheme,
			<FormGroup key="apiSource" label="API Source" mandatory>
				<Field
					name="source"
					validateOn="change"
					component={({ input }) => {
						return (
							<RadioGroup
								name={input.name}
								disabled={!cloudType}
								selectedValue={input.value}
								onChange={input.onChange}
								className={style.controlPushMdWrapper}
							>
								<PushButton value="file" className={style.controlPushMd}>
									JSON or JAR
								</PushButton>
								<PushButton value="db" className={style.controlPushMd}>
									Database
								</PushButton>
							</RadioGroup>
						);
					}}
				/>
				<Error sticky name="source" />
			</FormGroup>,
		];
	}

	const proovSpecificationSchemeSoap = [
		<UploadMediaFile
			key="specificationFile"
			allowedFiles={['jar', 'wsdl']}
			fileName="file_resource"
			mandatory
			onUpload={onFileUpload}
			pending={mediaPending}
		>
			Upload WSDL specification to generate
			<br />a static API or JAR file to include your business logic.
		</UploadMediaFile>,
	];

	const proovSpecificationSchemeRest = [
		<UploadMediaFile
			key="specificationFile"
			allowedFiles={['jar', 'json']}
			fileName="file_resource"
			mandatory
			onUpload={onFileUpload}
			pending={mediaPending}
		>
			Upload JSON specification to generate
			<br />a static API or JAR file to include your business logic.
		</UploadMediaFile>,
	];

	const mongoAuthName = [
		<DBName
			key="dbName"
			dbName="Authentication DB Name"
			tooltip="The name of database where user is created"
			fieldName="db_settings.auth_db"
		/>,
	];

	const dataBases = [
		{ id: 'mysql', label: 'MySQL' },
		{ id: 'postgres', label: 'PostgreSQL' },
		{ id: 'oracle', label: 'Oracle' },
		{ id: 'mongodb', label: 'MongoDB' },
	];

	const proovDbScheme = [
		<FormGroup key="dbType" label="Database Type" mandatory>
			<Field
				name="db_settings.db_type"
				validateOn={['blur', 'change']}
				component={({ input }) => (
					<Select
						required
						className={style.selectType}
						options={dataBases}
						{...input}
						value={input.value}
						getValue="id"
						getLabel="label"
					/>
				)}
			/>
			<Error sticky name="db_settings.db_type" />
		</FormGroup>,
		<DBName key="dbName" fieldName="db_settings.db_name" />,
		<IPAndPortField
			key="ipPort"
			ipName="db_settings.ip_address"
			portName="db_settings.port"
		/>,
		<UsernamePasswordField key="userPassword" name="db_settings" />,
	];

	if (dbType === 'mongodb') {
		proovDbScheme.splice(2, 0, mongoAuthName);
	}

	const isFile = !(
		fileResource === undefined || Object.keys(fileResource).length === 0
	);

	const selectHarFile =
		isFile && fileResource.label.split('.').pop() !== 'jar' ? (
			<HarFileSelector key="HarFileSelector" fileType="har" />
		) : null;

	const httpArchive = [
		'Visit ',
		<Link key="link" to="/repository/har" onClick={() => hideModal()}>
			<span className={style.link}>My Http Archive</span>
		</Link>,
		' to further customize this environment by uploading your own .har files.',
	];

	const hint = [
		!isFile && (
			<p key="hint" className={style.hint}>
				{httpArchive}
			</p>
		),
	];

	scheme =
		apiType === 'soap'
			? [...scheme, proovSpecificationSchemeSoap, hint, selectHarFile]
			: source === 'file'
			? [...scheme, proovSpecificationSchemeRest, hint, selectHarFile]
			: [...scheme, proovDbScheme];

	return <div>{scheme}</div>;
};

ApiProovOwnedFields.propTypes = {
	source: PropTypes.string,
	authType: PropTypes.string,
	apiType: PropTypes.string,
	hideModal: PropTypes.func,
	fileResource: PropTypes.object,
	onFileUpload: PropTypes.func.isRequired,
	mediaPending: PropTypes.bool.isRequired,
};

export default ApiProovOwnedFields;
