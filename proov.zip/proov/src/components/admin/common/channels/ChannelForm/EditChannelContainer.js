import * as PILOT_TYPES from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
// eslint-disable-next-line import/no-named-default
import { default as lab } from './LabChannel/editChannel/EditChannelFormContainer';
// eslint-disable-next-line import/no-named-default
import { default as safezone } from './PopChannel/editChannel/EditChannelFormContainer';

const EditChannelContainer = props => {
	const EditChannelFactory = ({ pilotType }) => {
		const channelType = {
			[PILOT_TYPES.LAB]: lab,
			[PILOT_TYPES.AWS_SC]: lab,
			[PILOT_TYPES.SAFEZONE]: safezone
		};

		const Component = channelType[pilotType];

		return React.createElement(Component, { ...props });
	};

	return EditChannelFactory(props);
};

EditChannelContainer.propTypes = {
	pilotType: PropTypes.string.isRequired
};

export default EditChannelContainer;
