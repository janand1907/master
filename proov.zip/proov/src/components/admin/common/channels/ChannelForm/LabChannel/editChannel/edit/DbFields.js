import React from 'react';
import PropTypes from 'prop-types';
import DropZone from 'components/ui/DropZone/DropZone';
import Shelf from 'components/ui/Rack/Shelf';
import { FileIcon } from 'components/ui/Icons';
import { FormGroup, Field, Error } from 'components/common/Forms';
import { readFileAsText } from 'utils';
import * as i18n from 'i18n/en/channelForm.json';
import DBName from 'components/admin/common/commonFields/DBName';
import RestrictTablesField from 'components/admin/common/commonFields/RestrictTablesField';
import IPAndPortField from 'components/admin/common/commonFields/IPAndPortField';
import UsernamePasswordField from 'components/admin/common/commonFields/UsernamePasswordField';
import CredentialsSwitch from 'components/admin/common/commonFields/credentials/CredentialsSwitch';
import CredentialsFields from 'components/admin/common/commonFields/credentials/CredentialsFields';
import style from '../../../style.scss';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';

const DBFields = ({
	isProovOwned,
	restrictTables,
	channel,
	dbType,
	disabled,
	isAssingningCredentials,
}) => {
	const bigQueryScheme = [
		<FormGroup key="projectId" label="Project ID" mandatory>
			<Field
				disabled={disabled}
				name="db_name"
				component="input"
				type="text"
				maxLength={128}
				className="form-control"
			/>
			<Error sticky name="db_name" />
		</FormGroup>,
		<FormGroup key="credentialsFile" label="Upload credentials file" mandatory>
			<Field
				name="credentials_file"
				validateOn="change"
				component={({ input }) => {
					return typeof input.value === 'object' ? (
						<Shelf
							value={input.value.name}
							renderValue={(v) => (
								<span>
									<FileIcon className={style.shelfIcon} />
									{v}
								</span>
							)}
							allowRemove
							allowEdit={false}
							onRemove={() => {
								input.onChange();
							}}
						/>
					) : (
						<DropZone
							types={['json']}
							onDropEnd={({ files }) =>
								readFileAsText(files[0], (e) => {
									input.onChange({
										name: files[0].name,
										contents: e.target.result,
									});
								})
							}
							maxFilesCount={1}
							maxFileSize={1}
							className={style.dropZone}
						>
							<FileIcon className={style.dropZoneIcon} />
							{i18n.upload.dropCredentials}
						</DropZone>
					);
				}}
			/>
			<Error sticky name="credentials_file" />
		</FormGroup>,
		<RestrictTablesField
			key="restrictTables"
			label="Restrict datasets"
			showRack={restrictTables}
		/>,
	];

	const otherDbTypeScheme = [
		<DBName key="dbName" fieldName="db_name" />,
		<IPAndPortField
			key="ipPort"
			disabled={disabled}
			ipName="ip_address"
			portName="port"
		/>,
		<UsernamePasswordField key="usernamePassword" disabled={disabled} />,
		<RestrictTablesField
			key="restrictTables"
			disabled={disabled}
			showRack={restrictTables}
		/>,
	];

	const envData = [
		<dl key="dlData" className={style.dlData}>

		{channel.cloud_type && <React.Fragment>	<dt>Cloud-based</dt>
			<dd>{CLOUD_TYPE_TO_ICON[channel.cloud_type] && CLOUD_TYPE_TO_ICON[channel.cloud_type].label}</dd>
			</React.Fragment>}
			<dt>Host</dt>
			<dd>{channel.ip_address}</dd>
			<dt>Port Number</dt>
			<dd>{channel.port}</dd>
			<dt>Username</dt>
			<dd>{channel.username}</dd>
			<dt>Password</dt>
			<dd>{channel.password}</dd>
		</dl>,
	];

	let scheme = [];

	if (isProovOwned) {
		scheme = [
			<Field key="dbType" name="db_type" component="input" type="hidden" />,
			...envData,
		];
	} else {
		scheme = [
			<Field
				key="dbTypeHidden"
				name="db_type"
				component="input"
				type="hidden"
			/>,
			...(dbType
				? dbType === 'bigquery'
					? bigQueryScheme
					: otherDbTypeScheme
				: []),
			<CredentialsSwitch
				key="is_assingning_credentials"
				fieldName="is_assingning_credentials"
			/>,
			isAssingningCredentials ? (
				<CredentialsFields key="credentials" fieldName="credentials" />
			) : (
				[]
			),
		];
	}

	return <div>{scheme}</div>;
};

DBFields.propTypes = {
	dbType: PropTypes.string,
	restrictTables: PropTypes.bool,
	isProovOwned: PropTypes.bool,
	isAssingningCredentials: PropTypes.bool,
	disabled: PropTypes.bool,
	channel: PropTypes.object.isRequired,
};

export default DBFields;
