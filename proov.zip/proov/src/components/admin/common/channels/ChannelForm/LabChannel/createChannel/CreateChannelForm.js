import React from 'react';
import PropTypes from 'prop-types';
import ConnectionTypeSelect from '../../common/ConnectionTypeSelect';
import ServerForm from './create/ServerForm/ServerForm';
import DbForm from './create/DbForm/DbForm';
import ApiForm from './create/ApiForm/ApiForm';
import SftpForm from './create/SftpForm/SftpForm';
import StorageForm from './create/StorageForm/StorageForm';
import BlockchainForm from './create/BlockchainForm/BlockchainForm';
import DockerForm from './create/DockerForm/DockerForm';
import SaaSForm from './create/SaaSForm/SaaSForm';
import WebForm from './create/WebForm/WebForm';

const CreateChannelForm = props => {
	const channelFormFactory = props => {
		const { selectedForm, componentTypes } = props;
		const forms = {
			server: ServerForm,
			db: DbForm,
			api: ApiForm,
			sftp: SftpForm,
			storage: StorageForm,
			blockchain: BlockchainForm,
			docker: DockerForm,
			saas: SaaSForm,
			web: WebForm
		};

		const Component = forms[selectedForm];

		return React.createElement(Component, { isRequestToEnterprise: componentTypes ? true : false, ...props });
	};

	const { onConnectionTypeChange, selectedForm, componentTypes } = props;
	return (
		<React.Fragment>
			<ConnectionTypeSelect
				key="connection"
				changeEndpointType={onConnectionTypeChange}
				value={selectedForm}
				componentTypesOptions={componentTypes}
			/>

			{channelFormFactory(props)}
		</React.Fragment>
	);
};

CreateChannelForm.propTypes = {
	onConnectionTypeChange: PropTypes.func.isRequired,
	selectedForm: PropTypes.string.isRequired
};

export default CreateChannelForm;
