/* eslint-disable camelcase */
import { SAFEZONE } from 'constants/pilotTypes';
import { pick } from 'lodash';
import isLength from 'validator/lib/isLength';
import isIP from 'validator/lib/isIP';
import isInt from 'validator/lib/isInt';
import isURL from 'validator/lib/isURL';
import * as i18n from 'i18n/en/channelFormValidation.json';

const isExist = value => !!value;
const str = value => (value || '').toString().trim();
const validator = (validate, message) => value =>
	!validate(value) ? message : undefined;

const projectIdPattern = /^[A-Za-z0-9\!\-\"\']{4,30}$/;

// Validators for environment component
const componentValidators = {
	// Common validators
	name: validator(
		val => isLength(str(val), { min: 1, max: 35 }),
		'Please specify a name for this endpoint (1-35 characters)'
	),
	type: validator(val => isExist(val), 'Please select the endpoint type'),
	source: validator(val => isExist(val), 'Please select the source type'),
	os: validator(val => isExist(val), 'Please select a Server Type'),
	aws_instance: validator(val => isExist(val), 'Please select an instance type'),
	db_name: (val, { db_type }) => {
		if (db_type === 'bigquery') {
			const strVal = str(val);
			if (!isLength(strVal, { min: 4, max: 30 })) {
				return '4-30 characters';
			}
			if (!strVal.match(projectIdPattern)) {
				return 'Project ID has invalid characters';
			}
		} else {
			if (!isLength(str(val), { min: 2, max: 64 })) {
				return '2-64 characters';
			}
			if (!str(val).match(/^[a-z0-9_]+$/i)) {
				return 'Permitted characters [0-9,a-z,A-Z,_]';
			}
		}
	},
	db_type: validator(val => isExist(val), 'Please select a database type'),
	credentials_file: validator(
		val => val && typeof val === 'object',
		'Please upload credentials file'
	),
	ip_address: validator(val => {
		const valStr = str(val);
		return (
			(isIP(valStr) || isURL(valStr, { allow_underscores: true })) &&
			isLength(str(valStr), { min: 4, max: 2083 })
		);
	}, 'Please enter a valid IP'),
	port: validator(val => isInt(str(val)) && val <= 65535, 'Port is invalid'),
	username: validator(
		val => isLength(str(val), { min: 2, max: 110 }),
		'2-110 characters'
	),
	password: value => {
		if (value && typeof value === 'object') return;
		if (!isLength(str(value), { min: 2, max: 200 })) {
			return 'Please specify a valid password (2-200 characters)';
		}
	},
	password_pem: value => {
		if (value && typeof value === 'object') return;
		if (!isLength(str(value), { min: 2, max: 200 })) {
			return 'Please specify a valid PEM file';
		}
	},
	bm: obj => {
		let err = {};
		if (obj && obj.enabled && !obj.file_id) {
			err['bm.file_id'] = 'Please select pcap file';
		}
		return err;
	},
	api_type: validator(val => isExist(val), 'Please select an API type'),
	api_spec_file_url: value => {
		if (value && typeof value === 'object') return;
		if (!isLength(str(value), { min: 2, max: 200 })) {
			return 'Please specify a valid JSON file';
		}
	},
	api_url: validator(
		val =>
			isLength(str(val), { min: 4, max: 2083 }) &&
			isURL(val, { allow_underscores: true }),
		'4-2083 characters'
	),
	auth: obj => {
		let err = {};
		if (obj && obj.type === 'oauth2.0') {
			if (!isExist(obj) || !isExist(obj.client_id)) {
				err['auth.client_id'] = 'Please select a client id';
			}
			if (
				!isExist(obj) ||
				(!isExist(obj.client_secret) && obj.grant_type === 'client_credentials')
			) {
				err['auth.client_secret'] = 'Please select a client_secret';
			}
			// if (!isExist(obj) || !(isLength(str(obj.auth_url), { min: 4, max: 2083 }) && isURL(obj.auth_url, { allow_underscores: true }))) err['auth.auth_url'] = '4-2083 characters';
			if (
				!isExist(obj) ||
				!(
					isLength(str(obj.token_url), { min: 4, max: 2083 }) &&
					isURL(obj.token_url, { allow_underscores: true })
				)
			) {
				err['auth.token_url'] = '4-2083 characters';
			}
			if (!isExist(obj) || !isLength(str(obj.password), { min: 2, max: 200 })) {
				err['auth.password'] = '2-200 characters';
			}
			if (!isExist(obj) || !isLength(str(obj.username), { min: 2, max: 110 })) {
				err['auth.username'] = '2-110 characters';
			}
		} else if (obj && obj.type === 'basic') {
			if (!isExist(obj) || !isLength(str(obj.password), { min: 2, max: 200 })) {
				err['auth.password'] = '2-200 characters';
			}
			if (!isExist(obj) || !isLength(str(obj.username), { min: 2, max: 110 })) {
				err['auth.username'] = '2-110 characters';
			}
		}
		return err;
	},
	db_settings: obj => {
		let err = {};
		if (!isExist(obj) || !isLength(str(obj.password), { min: 2, max: 200 })) {
			err['db_settings.password'] = '2-200 characters';
		}
		if (!isExist(obj) || !isLength(str(obj.username), { min: 2, max: 110 })) {
			err['db_settings.username'] = '2-110 characters';
		}
		const valStr = obj && obj.ip_address ? str(obj.ip_address) : '';
		if (
			!isExist(valStr) ||
			(!isIP(valStr) && !isURL(valStr, { allow_underscores: true }))
		) {
			err['db_settings.ip_address'] = 'Please enter a valid IP';
		}
		if (!isExist(obj) || !isInt(str(obj.port)) || obj.port > 65535) {
			err['db_settings.port'] = 'Port is invalid';
		}
		if (!isExist(obj) || !isExist(obj.db_type)) {
			err['db_settings.db_type'] = 'Please select a database type';
		}
		if (!isExist(obj) || !isLength(str(obj.db_name), { min: 2, max: 128 })) {
			err['db_settings.db_name'] = '2-128 characters';
		}
		return err;
	},

	safe_zone: obj => {
		let err = {};
		const valStr = obj && obj.ip_address ? str(obj.ip_address) : '';
		if (
			!isExist(valStr) ||
			(!isIP(valStr) && !isURL(valStr, { allow_underscores: true }))
		) {
			err['safe_zone.ip_address'] = 'Please enter a valid IP';
		}
		if (!isExist(obj) || !isInt(str(obj.port)) || obj.port > 65535) {
			err['safe_zone.port'] = 'Port is invalid';
		}
		return err;
	},
	user_owned: obj => {
		let err = {};
		const valStr = obj && obj.ip_address ? str(obj.ip_address) : '';
		if (
			!isExist(valStr) ||
			(!isIP(valStr) && !isURL(valStr, { allow_underscores: true }))
		) {
			err['user_owned.ip_address'] = 'Please enter a valid IP';
		}
		if (!isExist(obj) || !isInt(str(obj.port)) || obj.port > 65535) {
			err['user_owned.port'] = 'Port is invalid';
		}
		return err;
	},

	file_resource: validator(
		val => val && val.url && typeof val.url === 'string',
		'Please upload specification file'
	),

	ip_address_for_API: validator(val => {
		if (!val) return false;
		const valStr = val.toString().trim();
		return (
			(isIP(valStr) || isURL(valStr, { allow_underscores: true })) &&
			isLength(str(valStr), { min: 4, max: 2083 })
		);
	}, 'Please enter a valid IP'),
	credentials: validator(val => val && val.length !== 0, i18n.credentials),
	cloud_type: validator((val) => isExist(val) , i18n.cloud_type)
};

const popOrUserOwnedValidation = comp => {
	const isUserOwnedValid = Object.values(comp.user_owned).some(v => !!v);
	const isPopValid = Object.values(comp.safe_zone).some(v => !!v);

	if ((!isUserOwnedValid && !isPopValid) || (isUserOwnedValid && isPopValid)) {
		return ['user_owned', SAFEZONE];
	} else if (isUserOwnedValid && !isPopValid) {
		return ['user_owned'];
	} else {
		return [SAFEZONE];
	}
};

const activeAllowedForPopOrUserOwned = comp => {
	if (comp.active === 'user_owned') {
		return ['user_owned'];
	} else if (comp.active === SAFEZONE) {
		return [SAFEZONE];

		// if (comp.active) {
		// 	return [comp.active];
	} else {
		return [];
	}
};

function getSchemeForComponent(comp) {
	const common = ['type', 'name'];
	switch (comp.type) {
		case 'server':
			return [
				...common,
				'os',
				'ip_address',
				'port',
				'username',
				'password',
				'password_pem',
				'auth',
				'is_assingning_credentials',
				'cloud_type',
				...(comp.is_assingning_credentials ? ['credentials'] : [])
			];
		case 'db':
			return [
				...common,
				'cloud_type',
				'db_type',
				...activeAllowedForPopOrUserOwned(comp),
				...popOrUserOwnedValidation(comp),
				...(comp.db_type
					? [
						'db_name',
						'username',
						'password',
						'is_assingning_credentials',
						...(comp.is_assingning_credentials ? ['credentials'] : [])
					  ]
					: [])
			];
		case 'api':
			return [
				...common,
				'db_settings',
				'ip_address_for_API',
				'ip_address',
				'api_type',
				'auth',
				'username',
				'password',
				'source',
				'db_type',
				'cloud_type',
				...(comp.api_type === 'rest'
					? ['api_spec_file_url']
					: ['api_url', 'file_resource'])
			];
		default:
			return [];
	}
}

function runValidators(data, validators) {
	let err,
		errors = {};
	Object.keys(validators).forEach(field => {
		err = validators[field](data[field], data);
		if (typeof err === 'string') {
			errors[field] = err;
		} else if (typeof err === 'object') {
			errors = { ...errors, ...err };
		}
	});
	return errors;
}

export default function validate(values) {
	return runValidators(values, {
		...pick(componentValidators, getSchemeForComponent(values))
	});
}
