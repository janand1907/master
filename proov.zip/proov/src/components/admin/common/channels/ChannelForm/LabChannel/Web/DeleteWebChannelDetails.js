import React from 'react';
import PropTypes from 'prop-types';
import { Spinner } from 'components/ui/Spinner';
import { deletePilotChannel } from 'ducks/admin/pilot/channel/actions';
import { hideModal } from 'ducks/modal/actions';
import { connect } from 'react-redux';
import * as i18n from 'i18n/en/channelForm.json';
import style from './DeleteWebChannelDetails.scss';

const DeleteWebChannelDetails = ({ channel, pending, pilotId, hideModal, deletePilotChannel }) => {
   const handleConfirm = () => {
        deletePilotChannel(
            pilotId,
            channel.id,
            channel.name,
            channel.type,
        );
    }

    return (
        <div className={style.root}>
            <h4 >{i18n.deleteWebDetails.areYouSure}</h4>
            <div>
                <p>{i18n.deleteWebDetails.deleteMessage}</p>
            </div>
            <div>
                <button type="button" className={style.btnCancel} onClick={() => hideModal()} >
                    {i18n.deleteWebDetails.cancel}
                </button>
                <button
                    type="button"
                    className={style.btnConfirm}
                    onClick={() => handleConfirm()}
                >
                    {i18n.deleteWebDetails.confirm} {pending && <Spinner />}
                </button>
            </div>
        </div>
    );
};

DeleteWebChannelDetails.propTypes = {
    channel: PropTypes.object.isRequired,
    pending: PropTypes.bool.isRequired,
    error: PropTypes.string,
    onDelete: PropTypes.func.isRequired,
    onCancel: PropTypes.func.isRequired
};
export default connect(null, { hideModal, deletePilotChannel })(
    DeleteWebChannelDetails
);