import React from 'react';
import PropTypes from 'prop-types';
import EnvStatus from 'components/admin/common/channels/ChannelStatus/ChannelStatus';
import IconWrapper from 'components/admin/common/channels/icons/IconWrapper';
import { CLOUD_TYPE_TO_ICON,SUPPORTED_CLOUD_CHANNEL_TYPE  } from 'constants/channel/cloudType';
import style from '../../style.scss';

const EditChannelFormHeader = ({ data }) => {
	const Icon = CLOUD_TYPE_TO_ICON[data.cloud_type] && CLOUD_TYPE_TO_ICON[data.cloud_type].icon;

	return (
		<div className={style.editHeader}>
			<div className={style.iconContainer}>
				<IconWrapper {...data} />
			</div>
			<div className={style.dataContainer}>
				<p className={style.name}>{data.name}</p>
				{data.status && <EnvStatus status={data.status} />}
				{data.bm && data.bm.enabled && <div><EnvStatus bmStatus={data.bm.status} /></div>}
			</div>
			{SUPPORTED_CLOUD_CHANNEL_TYPE.includes(data.type) && Icon && <Icon className={style.cloudTypeIcon}/>}

		</div>
	);
};

EditChannelFormHeader.propTypes = {
	data: PropTypes.object
};

export default EditChannelFormHeader;
