import React from 'react';
import PropTypes from 'prop-types';
import { Field } from 'components/common/Forms';
import { Lookup } from 'components/common/Lookups';
import style from '../../../style.scss';
import { CLOUD_TYPE_TO_ICON } from 'constants/channel/cloudType';

const APIFieldsProov = ({ source, apiType, channel }) => {
	let scheme = [
		<Field key="apiType" name="api_type" component="input" type="hidden" />,
		<Field key="apiSource" name="source" component="input" type="hidden" />
	];

	let authFields = {};
	if (channel && channel.auth && channel.auth.type && channel.auth.type === 'basic') {
		authFields = {
			'Username': channel.auth.username,
			'Password': channel.auth.password
		};
	} else if (channel && channel.auth && channel.auth.type && channel.auth.type === 'oauth2.0') {
		authFields = {
			'Client ID': channel.auth.client_id,
			'Client Secret': channel.auth.client_secret,
			'Token URL': channel.auth.token_url,
			'Grant Type': channel.auth.grant_type
		};
		if (channel && channel.auth && channel.auth.grant_type && channel.auth.grant_type === 'password') {
			// extend for oAuth2.0 password grant
			authFields = {
				...authFields,
				'Username': channel.auth.username,
				'Password': channel.auth.password
			};
		}
	}

	const proovSpecification = [
		channel && channel.api_url &&
		<dl key="dlData" className={style.dlData}>
			<dt>Base URL</dt>
			<dd>{channel.api_url}</dd>
		</dl>,
		<dl key="cloud_type" className={style.dlData}>
			<dt>Cloud-based</dt>
			<dd>{CLOUD_TYPE_TO_ICON[channel.cloud_type].label}</dd>
		</dl>,
		channel && channel.auth && channel.auth.type !== 'none' &&
		<dl key="dlData2" className={style.dlData}>
			<dt>Authentication</dt>
			<dt className={style.authType}>{channel.auth.type}</dt>
		</dl>,
		channel && channel.auth && channel.auth.type !== 'none' && Object.keys(authFields).length > 0 &&
		<div key="dlDataCredentials" className={style.credentials}>
			{Object.keys(authFields).map((item, index) => {
				return (
					<dl key={index} className={style.dlData}>
						<dt>{item}</dt>
						<dd>{authFields[item]}</dd>
					</dl>);
			})}
		</div>
	];

	const proovDbScheme = [
		channel && channel.db_settings &&
		<div>
			<p>Database connection details</p>
			<dl key="dlData" className={style.dlData}>
				<dt>DB type</dt>
				<dd>{channel.db_settings.db_type && <Lookup lookupType="db_type" lookupKey={channel.db_settings.db_type} lookupValue={v => v.label} />}</dd>

				<dt>Name</dt>
				<dd>{channel.db_settings.db_name}</dd>

				<dt>Host</dt>
				<dd>{channel.db_settings.ip_address}</dd>

				<dt>Port</dt>
				<dd>{channel.db_settings.port}</dd>

				<dt>Username</dt>
				<dd>{channel.db_settings.username}</dd>

				<dt>Password</dt>
				<dd>{channel.db_settings.password}</dd>
			</dl>
		</div>
	];

	scheme = apiType === 'soap' ? [...scheme, proovSpecification]
		: source === 'file' ? [...scheme, proovSpecification] : [...scheme, proovDbScheme];

	return (
		<div>
			{scheme}
		</div>
	);
};

APIFieldsProov.propTypes = {
	source: PropTypes.string,
	apiType: PropTypes.string,
	channel: PropTypes.object,
};

export default APIFieldsProov;
