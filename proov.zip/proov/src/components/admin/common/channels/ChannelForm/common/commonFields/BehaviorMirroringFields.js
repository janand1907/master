import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { pcapFiles } from 'ducks/repository/behaviorMirroring/selectors';
import BehaviorMirroringSwitch from './BehaviorMirroringSwitch';
import PcapFilesSelect from './PcapFilesSelect';

function BehaviorMirroringFields({
	pcapFilesList,
	pending,
	isEnabled,
	isDedicatedEnabled,
}) {
	const filterdPcapFiles = pcapFilesList.filter(
		(file) => file.status === 'ready'
	);
	return (
		<div>
			<BehaviorMirroringSwitch
				disabled={!filterdPcapFiles.length || isDedicatedEnabled}
				isDedicatedEnabled={isDedicatedEnabled}
			/>
			{isEnabled && (
				<div>
					<PcapFilesSelect
						key="uploedPcap"
						pcapFiles={filterdPcapFiles}
						pending={pending}
					/>
				</div>
			)}
		</div>
	);
}

BehaviorMirroringFields.propTypes = {
	pcapFilesList: PropTypes.array,
	isEnabled: PropTypes.bool,
	isDedicatedEnabled: PropTypes.bool,
	pending: PropTypes.bool,
};

function mapStateToProps(state) {
	const pcapFilesList = pcapFiles(state).data || [];
	const pending = pcapFiles(state).pending;
	return { pcapFilesList, pending };
}

export default connect(mapStateToProps)(BehaviorMirroringFields);
