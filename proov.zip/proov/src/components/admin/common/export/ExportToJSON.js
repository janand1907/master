import { LAB } from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
import { exportLabEnvironment, exportAWSEnvironment } from './transform';

const ExportToJSON = ({ environment, pilotType, className, text }) => {
	const handleExport = function (environment) {
		if (!environment) return;
		const transformedEnvironment =
			pilotType === LAB
				? exportLabEnvironment(environment)
				: exportAWSEnvironment(environment);
		let dataStr =
			'data:text/json;charset=utf8,' +
			encodeURIComponent(JSON.stringify(transformedEnvironment));
		let downloadAnchorNode = document.createElement('a');
		downloadAnchorNode.setAttribute('href', dataStr);
		downloadAnchorNode.setAttribute('download', 'environments.json');
		document.body.appendChild(downloadAnchorNode);
		downloadAnchorNode.click();
		document.body.removeChild(downloadAnchorNode);
	};

	return (
		<a className={className} onClick={() => handleExport(environment)}>
			{text? text :"Export to JSON"}
		</a>
	);
};

export default ExportToJSON;

ExportToJSON.propTypes = {
	environment: PropTypes.array.isRequired,
	className: PropTypes.string,
	pilotType: PropTypes.string,
};
