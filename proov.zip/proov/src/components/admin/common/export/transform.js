import { groupBy, cloneDeep, filter, pick, map, merge } from 'lodash';

const standardChannels = {
	server: [
		'name',
		'type',
		'os',
		'os_dist',
		'ip_address',
		'aws_instance',
		'port',
		'username',
		'servers',
		'credentials',
	],
	db: [
		'name',
		'type',
		'db_type',
		'db_name',
		'auth_db',
		'db_version',
		'ip_address',
		'port',
		'username',
		'credentials',
	],
	vpn: ['name', 'type', 'host', 'port', 'username'],
	sftp: ['name', 'type', 'ip_address', 'port', 'username'],
	api: [
		'name',
		'type',
		'api_type',
		'file_resource',
		'auth',
		'servers',
		'har_file_name',
	],
	storage: [
		'name',
		'type',
		'aws',
		'ip_address',
		'port',
		'is_user_owned',
		'is_read_only',
		'username',
	],
	blockchain: ['name', 'type', 'ip_address', 'port', 'account'],
	docker: [
		'name',
		'type',
		'os',
		'ip_address',
		'port',
		'username',
		'credentials',
	],
};

const awsChannels = {
	aws_dynamo_db: ['name', 'type', 'arn', 'ip_address', 'primary_partition_key'],
	aws_ec2: [
		'name',
		'type',
		'arn',
		'db_type',
		'instance_type',
		'port',
		'username',
		'public_ip',
	],
	aws_lambda: ['name', 'type', 'arn', 'credentials'],
	aws_rds: [
		'name',
		'type',
		'arn',
		'url',
		'vpc_id',
		'username',
		'port',
		'engine',
		'subnet_id',
		'instance_type',
		'security_groups',
		'db_name',
	],
	aws_s3: ['name', 'type', 'is_public', 'arn'],
	aws_sns: ['name', 'type', 'arn'],
	aws_sqs: ['name', 'type', 'arn'],
	aws_emr: [
		'name',
		'type',
		'arn',
		'applications',
		'subnet_id',
		'emr_version',
		'cluster_id',
	],
};

export function exportLabEnvironment(env) {
	// Filter out deleted environmetns
	const cloneEnvironment = filter(
		cloneDeep(env),
		(i) => i.status !== 'deleted'
	);

	// Purge unnecessary fields
	let purgeFields = map(cloneEnvironment, (channel) => {
		// Purge fields from servers property: Relevant to API & Dedicated Server Channels
		if (Array.isArray(channel.servers)) {
			channel.servers = map(channel.servers, (m) =>
				pick(m, standardChannels.server)
			);
		}

		if (channel.credentials && channel.credentials.length !== 0) {
			channel.credentials = map(channel.credentials, (c) =>
				pick(c, 'username')
			);
		}

		if (channel.auth) {
			delete channel.auth.password;
		}

		return pick(channel, standardChannels[channel.type]);
	});

	// Aggregate by type
	return groupBy(purgeFields, (channel) => channel.type);
}

export function exportAWSEnvironment(env) {
	const allChannels = merge(awsChannels, standardChannels);
	return Object.values(env).map((channel) =>
		pick(channel, allChannels[channel.type])
	);
}
