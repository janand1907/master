import React from 'react';
import PropTypes from 'prop-types';
import cn from 'utils/classNames';
import { InfoIcon, AwardIcon } from 'components/ui/Icons';

import * as i18n from 'i18n/en/charts.json';
import css from './style.scss';
import IconWithTooltip from 'components/ui/Icons/IconWithTooltip';

class MetricDescription extends React.Component {
	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
		this.handleBlur = this.handleBlur.bind(this);
		this.state = {
			description: props.metric.description || '',
			successCriteria: props.metric.success_criteria || '',
		};
	}

	UNSAFE_componentWillReceiveProps(nextProps) {
		const { description, success_criteria, isValidate } = nextProps.metric;
		this.setState({
			description: description || '',
			successCriteria: success_criteria || ''
		});
	}
	handleChange() {
		this.setState({
			description: this.description.value,
			successCriteria: this.successCriteria.value,
		});
	}

	handleBlur() {
		const { description, success_criteria } = this.props.metric;
		if (description !== this.description.value || success_criteria !== this.successCriteria.value) {

			this.props.onDescriptionChange(this.props.metric, this.description.value, this.successCriteria.value);
		}
	}

	errorLabel() {
		const { description, success_criteria } = this.props.metric;
		const desc = !description;
		const criteria = !success_criteria;
		const descLength = description && description.length == 1;
		const criteriaLength = success_criteria && success_criteria.length == 1;

		return (desc || criteria) ? (<span className="error">{`Please provide ${desc ? i18n.tooltip.description : ""}
			${desc && criteria ? "and" : ""} ${criteria ? i18n.tooltip.successCriteria : ""} `}</span>)
			: (descLength || criteriaLength) ?
				(<span className="error">{`Value of ${descLength ? i18n.tooltip.description : ""}
			${descLength && criteriaLength ? "and" : ""} ${criteriaLength ? i18n.tooltip.successCriteria : ""} must be at least 2 characters`}</span>) : ""

	}
	render() {
		const { isValidate } = this.props.metric;
		const isNotValidateDescription = !isValidate.description;
		const isNotValidateCriteria = !isValidate.criteria;

		return (
			<div className={cn(css.root, this.props.className, { [css.error]: isNotValidateDescription || isNotValidateCriteria })}>
				{isNotValidateCriteria || isNotValidateDescription ? this.errorLabel():''}
				<div className={css.inputWrapper}>

					<IconWithTooltip icon={<InfoIcon className={css.infoIcon} />} textToDisplay={i18n.tooltip.description} />
					<input
						ref={ref => (this.description = ref)}
						className={cn(css.descInput, 'form-control', {
							[css.error]: isNotValidateDescription
						})}
						maxLength={100}
						onChange={this.handleChange}
						onBlur={this.handleBlur}
						placeholder={i18n.placeholder.description}
						type="text"
						value={this.state.description}
					/>
				</div>
				<div className={css.inputWrapper}>
					<IconWithTooltip icon={<AwardIcon className={css.infoIcon} />} textToDisplay={i18n.tooltip.successCriteria} />
					<input
						ref={ref => (this.successCriteria = ref)}
						className={cn(css.descInput, 'form-control', { [css.error]: isNotValidateCriteria })}
						maxLength={100}
						onChange={this.handleChange}
						onBlur={this.handleBlur}
						placeholder={i18n.placeholder.successCriteria}
						type="text"
						value={this.state.successCriteria}
					/>
				</div>
			</div>
		);
	}
}

MetricDescription.propTypes = {
	metric: PropTypes.object,
	onDescriptionChange: PropTypes.func,
	className: PropTypes.string
};

export default MetricDescription;
