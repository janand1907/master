import React from 'react';
import PropTypes from 'prop-types';
import { InfoIcon, AwardIcon } from 'components/ui/Icons';
import style from './style.scss';

const iconStyle = {
	width: '20px',
	height: '20px',
	fill: '#097bbf'
};

const MetricDescriptionForDashboard = ({ metric }) => {
	return (
		<div>
			<div className={style.metricDescriptionWrapperDashboard}>
				<InfoIcon id="dash_desc_icon_info" style={iconStyle} />
				<span>{metric && metric.description}</span>
			</div>
			<div className={style.metricDescriptionWrapperDashboard}>
				<AwardIcon id="dash_desc_icon_award" style={iconStyle} />
				<span>{metric && metric.success_criteria}</span>
			</div>
		</div>
	);
};

MetricDescriptionForDashboard.propTypes = {
	metric: PropTypes.object
};

export default MetricDescriptionForDashboard;
