import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';



const IconWithTooltip = props => {
	const { icon,textToDisplay} = props;


	return (
		<TooltipTarget
			tooltip={
				<Tooltip placement="left" >
					{textToDisplay}
				</Tooltip>
			}
		>
			{icon}
		</TooltipTarget>
	);
};

IconWithTooltip.propTypes = {
	textToDisplay: PropTypes.string
};

export default IconWithTooltip;
