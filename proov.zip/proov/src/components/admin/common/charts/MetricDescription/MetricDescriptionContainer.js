import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import Permission from 'components/Permission';
import { setMetricDescription } from 'ducks/admin/analytics/metrics/actions';
import { getSelectedMetric } from 'ducks/admin/analytics/metrics/selectors';
import MetricDescription from './MetricDescription';

class MetricDescriptionContainer extends React.PureComponent {
	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(metric, description, successCriteria) {
		this.props.setMetricDescription(metric, description, successCriteria);
	}

	render() {
		return (
			<Permission
				alias="MetricDescription"
				component={<MetricDescription {...this.props} onDescriptionChange={this.handleChange} />}
			/>
		);
	}
}

MetricDescriptionContainer.propTypes = {
	metric: PropTypes.object,
	setMetricDescription: PropTypes.func
};

function mapStateToProps(state) {
	return {
		metric: getSelectedMetric(state)
	};
}

export default connect(mapStateToProps, { setMetricDescription })(MetricDescriptionContainer);
