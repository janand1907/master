export MovingAverage from './MovingAverage';
