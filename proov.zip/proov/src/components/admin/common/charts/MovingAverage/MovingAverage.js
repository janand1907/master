import React from 'react';
import PropTypes from 'prop-types';
import Select from 'components/ui/Select/Select';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import cn from 'utils/classNames';
import * as i18n from 'i18n/en/charts.json';
import css from './style.scss';


const MovingAverage = props => {
	return (
		<div className={cn(css.root, props.className)}>
			<div className={css.selectWrapper}>
				<TooltipTarget
					tooltip={
						<Tooltip placement="top">
							{props.optionsTooltip ? props.optionsTooltip : globalize.parseString(i18n.tooltip.movingAverage)}
						</Tooltip>
					}
				>
					<Select
						className={css.select}
						options={props.options}
						getValue="id"
						getLabel="label"
						value={props.value}
						onChange={props.onChange}
						placeholder="None"
					/>
				</TooltipTarget>
			</div>
		</div>
	);
};

MovingAverage.propTypes = {
	className: PropTypes.string,
	value: PropTypes.number,
	onChange: PropTypes.func.isRequired
};

export default MovingAverage;
