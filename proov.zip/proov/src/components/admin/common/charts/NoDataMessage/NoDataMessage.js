import React from 'react';
import PropTypes from 'prop-types';
import cn from 'utils/classNames';
import * as i18n from 'i18n/en/charts.json';
import css from './style.scss';
import { ExportIcon } from 'components/ui/Icons';

class NoDataMessage extends React.PureComponent {
	componentDidMount() {
		this.props.onReady();
	}

	render() {
		const { type, message, className, wrapperClassName } = this.props;
		if (!type) {
			return (
				<div className={cn(css.root, wrapperClassName)}>
					<p className={cn(css.message, className)}>{message.toString()}</p>
				</div>
			);
		}
		return (
			<div className={cn(css.root, wrapperClassName)}>
				{type === 'nodata' && (
					<p className={cn(css.message, className)}>{i18n.messages.nodata}</p>
				)}
				{type === 'novendors' && (
					<p className={cn(css.message, className)}>
						{i18n.messages.novendors}
					</p>
				)}
				{type === 'archive' && (
					<div className={css.messageWrapper}>
						<p className={cn(css.message, className)}>{i18n.messages.archive}</p>
						<p className={cn(css.message, className)}><ExportIcon fill="gray" className={css.exportIcon} /></p>
					</div>
				)}
			</div>
		);
	}
}

NoDataMessage.propTypes = {
	className: PropTypes.string,
	wrapperClassName: PropTypes.string,
	type: PropTypes.oneOf(['nodata', 'novendors', 'archive']),
	onReady: PropTypes.func,
	message: PropTypes.string,
};

NoDataMessage.defaultProps = {
	onReady: () => {},
};

export default NoDataMessage;
