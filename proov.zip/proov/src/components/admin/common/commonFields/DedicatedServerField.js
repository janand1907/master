import React from 'react';
import PropTypes from 'prop-types';
import cx from 'utils/classNames';
import Switch from 'components/ui/Switch/Switch';
import { FormGroup, Field } from 'components/common/Forms';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import style from './style.scss';

const DedicatedServerField = ({ isBmEnabled }) => {
	return (
		<FormGroup className={style.prvServerSwitchWrapper} label={<span className={style.biggerLabel}>For each ISV have a dedicated server</span>}>
			<Field
				name="is_dedicated"
				component={({ input }) => (
					<TooltipTarget
						className={style.tooltipSwitch}
						tooltip={
							<Tooltip
								placement="left"
								className={cx(style.tooltipFadein, (isBmEnabled ? style.tooltipBlock : style.tooltipNone))}>
								<span>Behavior Mirroring cannot be enabled <br /> if you are using separate servers.</span>
							</Tooltip>
						}>
						<Switch
							className={style.switch}
							name={input.name}
							disabled={isBmEnabled}
							onToggle={input.onChange}
							toggled={input.value}
						/>
					</TooltipTarget>
				)
				}
			/>
		</FormGroup>
	);
};

DedicatedServerField.propTypes = {
	isBmEnabled: PropTypes.bool
};

export default DedicatedServerField;
