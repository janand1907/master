import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import style from './style.scss';

const IPAndPortField = ({ fullWidth, disabled, ipName, portName, mandatory, ...props }) => {
	return (
		<div className={fullWidth ? style.fullWidthWrapper : style.halfWidthWrapper}>

			{ipName &&
			<FormGroup label="Host" inline={!fullWidth} mandatory={mandatory}>
				<Field disabled={disabled} name={ipName} component="input" type="text" maxLength={2083} className={fullWidth ? style.fullWidth : style.halfWidth} />
				<Error sticky name={ipName} />
			</FormGroup>
			}

			{portName &&
			<FormGroup label="Port" inline={!fullWidth} mandatory={mandatory}>
				<Field disabled={disabled} name={portName} component="input" type="text" maxLength={5} className={fullWidth ? style.fullWidth : style.halfWidth} />
				<Error sticky name={portName} />
			</FormGroup>
			}
		</div>
	);
};

IPAndPortField.propTypes = {
	ipName: PropTypes.string,
	portName: PropTypes.string,
	disabled: PropTypes.bool,
	fullWidth: PropTypes.bool,
	mandatory: PropTypes.bool,
};

IPAndPortField.defaultProps = {
	disabled: false,
	fullWidth: false,
	mandatory: true,
	ipName: '',
	portName: ''
};

export default IPAndPortField;
