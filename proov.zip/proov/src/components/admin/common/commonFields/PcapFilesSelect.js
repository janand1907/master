import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import { Spinner } from 'components/ui/Spinner';
import Select from 'components/ui/Select/Select';
import style from './style.scss';

const PcapFilesSelect = ({ pcapFiles, pending }) => {

	if (pending) { return <div className={style.spinnerContainer}><Spinner /></div> }
	return (
		<FormGroup label="Choose from existing PCAP files" mandatory>
			<Field
				name="bm.file_id"
				validateOn={['blur', 'change']}
				component={({ input }) => (
					<Select
						required
						className={style.selectType}
						options={pcapFiles}
						{...input}
						value={input.value}
						getValue="id"
						getLabel="file_name"
					/>
				)}
			/>
			<Error sticky name="bm.file_id" />
		</FormGroup>
	);
};

PcapFilesSelect.propTypes = {
	pcapFiles: PropTypes.array,
	pending: PropTypes.bool,
};

export default PcapFilesSelect;

