import React from 'react';
import { FormGroup, Field, Error } from 'components/common/Forms';
import style from './style.scss';
import Select from 'components/ui/Select/Select';

const ApiKey = (isViewMode) => {
    const OPTIONS = [{ id: 'headers', label: 'Headers' }, { id:'params', label: "Query Params" }]

    return (
        <div>
            <FormGroup key="key" label="Key" mandatory>
                <Field name="auth.key" component="input" type="text" className="form-control" placeholder="" disabled={isViewMode}/>
                <Error sticky name="auth.key" />
            </FormGroup>
            <FormGroup key="value" label="Value" mandatory>
                <Field name="auth.value" component="input" type="text" className="form-control" placeholder="" disabled={isViewMode}/>
                <Error sticky name="auth.value" />
            </FormGroup>
            <FormGroup label="Add to" mandatory>
                <Field
                    name="auth.add_to"
                    validateOn={['blur', 'change']}
                    disabled={isViewMode}
                    component={({ input }) => (
                        <Select
                         	menuClassName={style.menuSelect}
                        	optionClassName={style.optionSelect}
                            options={OPTIONS}
                            {...input}
                            value={input.value}
                            getValue="id"
                            getLabel="label"
                        />
                    )}
                />
                 <Error sticky name="auth.add_to" />

                <Error sticky name="os_dist" />
            </FormGroup>
        </div>
    );
};


export default ApiKey;