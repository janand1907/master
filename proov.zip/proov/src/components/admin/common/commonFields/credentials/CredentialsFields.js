import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import Rack from 'components/ui/Rack/Rack';
import CredentialsEditor from './CredentialsEditor';
import CredentialsShelf from './CredentialsShelf';

function CredentialsFields({ fieldName, authType }) {
	function renderAddShelf({ handleAdd, items, customProps }) {
		return (
			<CredentialsEditor
				authType={customProps}
				mode="create"
				onAdd={handleAdd}
				existingValue={items}
			/>
		);
	}

	// @tomer - this function doesn't rendered?
	function renderEditShelf({
		value,
		handleSave,
		handleCancel,
		items,
		index,
		customProps,
	}) {
		return (
			<CredentialsEditor
				mode="edit"
				authType={customProps}
				onSave={handleSave}
				onCancel={handleCancel}
				initialValue={value}
				existingValue={items}
				existingIndex={index}
			/>
		);
	}

	function renderShelf(value) {
		return <CredentialsShelf credential={value} />;
	}

	return (
		<FormGroup label="Add Credentials (Up to 10 credentials)" mandatory>
			<Field
				validateOn="change"
				name={fieldName}
				defaultValue={[]}
				component={({ input }) => {
					return (
						<Rack
							shelfProps={{
								renderValue: renderShelf,
								renderEdit: renderEditShelf,
								allowEdit: false,
								allowRemove: true,
							}}
							customProps={authType}
							renderEdit={renderAddShelf}
							items={input.value}
							onChange={(value) => {
								input.onChange(value);
							}}
						/>
					);
				}}
			/>
			<Error sticky name="credentials" />
		</FormGroup>
	);
}

CredentialsFields.propTypes = {
	credentials: PropTypes.array,
	authType: PropTypes.string,
	fieldName: PropTypes.string,
};

export default CredentialsFields;
