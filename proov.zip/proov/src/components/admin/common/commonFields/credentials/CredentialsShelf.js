import React from 'react';
import PropTypes from 'prop-types';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { Field, Password, FormGroup } from 'components/common/Forms';
import { InfoIcon, FileIcon } from 'components/ui/Icons';
import style from '.././style.scss';
import cx from 'utils/classNames';

const CredentialsShelf = ({ credential }) => {
	return (
		<div key={credential.username} className={style.shelfContainer}>
			<div className={style.halfWidthWrapper}>
				<FormGroup
					inline
					className={style.credentialField}
					mandatory
				>
					<Field
						disabled={true}
						component="input"
						type="text"
						maxLength="2083"
						value={credential.username}
						title={credential.username}
						className={cx("form-control",style.cursorAuto)}

					/>
				
				</FormGroup>
				<FormGroup
					inline
					className={style.credentialField}
					mandatory
				>
					<Field
						type="password"
						maxLength="2083"
						className="form-control"
						component={({ input, meta }) => {
							input.value = credential.password;
							input.disabled = true;
							return (
								<div className="form-control-wrapper">
									<Password
										input={input}
										placeholder='password'

									/>
								</div>
							);
						}}

					/>
				</FormGroup>
			</div>

			{credential.password_file_name && (
				<div className={style.shelfText}><span>
					<FileIcon className={style.shelfIcon} />
					{credential.password_file_name}
				</span></div>
			)}

			{credential.is_assgined && (
				<TooltipTarget
					tooltip={
						<Tooltip placement="left" className={style.tooltipFadein}>
							<span className={style.tooltip}>
								Assignee: <br />
								{credential.assignee}
							</span>
						</Tooltip>
					}
					className={style.shelfTooltip}
				>
					<InfoIcon className={style.iconTooltip} />
				</TooltipTarget>
			)}
		</div>
	);
};

CredentialsShelf.propTypes = {
	credential: PropTypes.object
};

export default CredentialsShelf;
