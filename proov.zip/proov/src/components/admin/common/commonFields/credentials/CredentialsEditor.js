import React from 'react';
import PropTypes from 'prop-types';
import isLength from 'validator/lib/isLength';
import { FormGroup, Field, Password, Error } from 'components/common/Forms';
import * as i18n from 'i18n/en/channelForm.json';
import DropZone from 'components/ui/DropZone/DropZone';
import { CloseIcon, PlusIcon } from 'components/ui/Icons';
import { FileIcon } from 'components/ui/Icons';
import { readFileAsText } from 'utils';
import Shelf from 'components/ui/Rack/Shelf';
import style from '.././style.scss';
import cx from 'utils/classNames';

function CredentialsEditor({
	onAdd,
	onSave,
	onCancel,
	initialValue,
	mode,
	authType,
	existingValue,
	existingIndex,
}) {
	const [credentials, setCredentials] = React.useState({});

	React.useEffect(() => {
		const userName = initialValue ? initialValue.username : '';
		const passWord = initialValue ? initialValue.password : '';

		setCredentials({
			usernameValue: userName,
			invalidUsername: false,
			illegalUsername: false,
			duplicateUsername: false,
			passwordValue: passWord,
			invalidPassword: false,
			pemFile: null,
		});
	}, [initialValue, setCredentials]);

	function handleValidate(event) {
		const { usernameValue, passwordValue } = credentials;
		const fieldName = event.target.name;

		if (fieldName === 'credential_username') {
			const ENG_NUM_SPECIAL_CHAR = /^[a-zA-Z0-9$@$!%*?&#^\-_.+]+$/;
			const isLegalChar = usernameValue && ENG_NUM_SPECIAL_CHAR.test(usernameValue);
			const isValid = usernameValue && isLength(usernameValue, { min: 2, max: 110 });

			isLegalChar && isValid && duplicateUsernameCheck();
			setCredentials({
				...credentials,
				invalidUsername: !isValid,
				illegalUsername: !isLegalChar,
			});
		} else if (passwordValue) {
			const isValid = isLength(passwordValue, { min: 2, max: 200 });
			setCredentials({ ...credentials, invalidPassword: !isValid });
		}
	}

	function duplicateUsernameCheck() {
		if (existingValue.length !== 0) {
			const duplicateUsername =
				existingValue.filter(
					(c, index) =>
						index !== existingIndex && c.username === credentials.usernameValue
				).length !== 0;
			setCredentials({ ...credentials, duplicateUsername: duplicateUsername });
		}
	}

	function handleAddClick() {
		if (existingValue.length <= 9) {
			const { usernameValue, passwordValue, pemFile } = credentials;
			if (authType === 'basic') {
				onAdd({
					username: usernameValue.trim(),
					password: passwordValue.trim(),
				});
				setCredentials({ ...credentials, usernameValue: '', passwordValue: '' });
			} else {
				onAdd({ username: usernameValue.trim(), ...pemFile });
				setCredentials({ ...credentials, usernameValue: '', pemFile: null });
			}
		}
	}

	function handleUpdateClick() {
		const { usernameValue, passwordValue } = credentials;
		onSave({
			username: usernameValue.trim(),
			password: passwordValue.trim(),
		});
	}

	function handleCancelClick() {
		onCancel();
		setCredentials({ ...credentials, usernameValue: '', passwordValue: '' });
	}

	function handleInputChange(event) {
		event.persist();
		const fieldData = event;
		const fieldName =
			event.target.name === 'credential_username'
				? 'usernameValue'
				: 'passwordValue';

		setCredentials({ ...credentials, [fieldName]: event.target.value }, () =>
			handleValidate(fieldData)
		);
	}

	function handlePemChange(name, content) {
		setCredentials({
			...credentials,
			pemFile: { password_file_name: name, password_file: content },
		});
	}

	const {
		usernameValue,
		invalidUsername,
		duplicateUsername,
		passwordValue,
		invalidPassword,
		illegalUsername,
		pemFile,
	} = credentials;
	const disabled = existingValue.length > 9 || !(usernameValue && (passwordValue || pemFile)) ||
		invalidUsername ||
		invalidPassword ||
		duplicateUsername ||
		illegalUsername;
	return (

		<div className={style.editor}>
			<div className={style.halfWidthWrapper}>
				<FormGroup
					inline
					className={style.credentialField}
					mandatory
				>
					<Field
						name="credential_username"
						className="form-control"
						data-invalid={
							invalidUsername || duplicateUsername || illegalUsername
						}
						type="text"
						maxLength="200"
						value={usernameValue}
						placeholder="username"
						component="input"
						validateOn="change"
						onChange={handleInputChange}
						onBlur={handleValidate}
					/>
					<Error sticky name="credential_username" />

				</FormGroup>

				{authType === 'basic' ? (
					<FormGroup
						inline
						className={style.credentialField}
						mandatory
					>
						<Field
							name="credential_password"
							className="form-control"
							data-invalid={invalidPassword}
							value={passwordValue}
							placeholder="password"
							validateOn="change"
							onChange={handleInputChange}
							onBlur={handleValidate}
							component={({ input, meta }) => {
								input.value = passwordValue;
								return (
									<Password
										input={input}
										placeholder='password'
										className='form-control'
									/>
								);
							}}
						/>
					
						<Error sticky name="credential_password" />
					</FormGroup>
				) : (
					<FormGroup
						inline
						className={style.credentialField}
						key="credentials_file"
						label="PEM Credential"
						mandatory
					>
						<Field
							name="credentials_file"
							validateOn="change"
							component={({ input }) => {
								return typeof input.value === 'object' && pemFile ? (
									<Shelf
										value={input.value.name}
										renderValue={(v) => (
											<span>
												<FileIcon className={style.shelfIcon} />
												{v}
											</span>
										)}
										allowRemove
										allowEdit={false}
										className={style.miniShelf}
										onRemove={() => {
											input.onChange();
										}}
									/>
								) : (
									<DropZone
										types={['pem']}
										onDropEnd={({ files }) => {
											readFileAsText(files[0], (e) => {
												input.onChange({
													name: files[0].name,
													contents: e.target.result,
												});
												handlePemChange(files[0].name, e.target.result);
											});
										}}
										maxFilesCount={1}
										maxFileSize={1}
										className={style.pemDropZone}
									>
										<FileIcon className={style.miniDropZoneIcon} />
										Upload
									</DropZone>
								);
							}}
						/>
					</FormGroup>
				)}
			</div>

			<div className={style.editActions}>
				{mode === 'edit' && (
					<button
						type="button"
						onClick={handleCancelClick}
						className={style.actionBtn}
					>
						Cancel
					</button>
				)}
				<PlusIcon
					onClick={!disabled && handleAddClick}
					className={cx(style.actionBtn, disabled && style.disabled)}
				>
					<title>Add Credentials</title>
				</PlusIcon>
			</div>
		</div>
	);
}

CredentialsEditor.propTypes = {
	onAdd: PropTypes.func,
	onSave: PropTypes.func,
	onCancel: PropTypes.func,
	initialValue: PropTypes.object,
	existingValue: PropTypes.array,
	mode: PropTypes.string,
	authType: PropTypes.string,
	existingIndex: PropTypes.number,
};

CredentialsEditor.defaultProps = {
	authType: 'basic',
};

export default CredentialsEditor;
