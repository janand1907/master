import React from 'react';
import PropTypes from 'prop-types';
import Switch from 'components/ui/Switch/Switch';
import { FormGroup, Field } from 'components/common/Forms';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import * as i18n from 'i18n/en/channelForm.json';
import style from '.././style.scss';

const CredentialsSwitch = ({ disabled }) => {
	return (
		<FormGroup
			className={style.credentialsSwitchWrapper}
			label={
				<span className={style.biggerLabel}>{i18n.credentialsSwitch}
					<TooltipTarget
						tooltip={
							<Tooltip placement="left" className={style.tooltipFadein}>
								<span>
									{globalize.parseString(i18n.tooltips.credentials)}
								</span>
							</Tooltip>
						}>
						<InfoIcon className={style.iconTooltip} />
					</TooltipTarget>
				</span>
			}>
			<Field
				name="is_assingning_credentials"
				component={({ input }) => (
					<Switch
						className={style.switch}
						name={input.name}
						onToggle={input.onChange}
						toggled={input.value}
						disabled={disabled}
					/>
				)}
			/>
		</FormGroup>
	);
};

CredentialsSwitch.propTypes = {
	disabled: PropTypes.bool
};

export default CredentialsSwitch;
