


import React from 'react';
import { FormGroup, Field, Error } from 'components/common/Forms';
import Select from 'components/ui/Select/Select';
import style from './style.scss';
import { CLOUD_TYPE_TO_ICON, CLOUD_TYPE } from 'constants/channel/cloudType';


const CloudTypeField = ({ onChange,disabled }) => {

    return <FormGroup label="Select Cloud Service Provider" mandatory>
        <Field
            name="cloud_type"
            validateOn={['blur', 'change']}
            onChange={onChange}
            component={({ input }) => (
                <Select
                    disabled={disabled}
                    options={CLOUD_TYPE}
                    {...input}
                    value={input.value}
                    getLabel={(option) => {
                        const Icon = CLOUD_TYPE_TO_ICON[option].icon;
                        return <React.Fragment><Icon className={style.cloudIcon} />{CLOUD_TYPE_TO_ICON[option].label}</React.Fragment>
                    }}
                />
            )}
        />

        <Error sticky name="cloud_type" />
    </FormGroup>
}

export default CloudTypeField;