import React from 'react';
import PropTypes from 'prop-types';
import DropZone from 'components/ui/DropZone/DropZone';
import Shelf from 'components/ui/Rack/Shelf';
import { FileIcon } from 'components/ui/Icons';
import { FormGroup, Field, Error } from 'components/common/Forms';
import readFileAsText from 'utils/readFileAsText';
import style from './style.scss';

const PasswordField = ({ fieldName, allowFile, ...props }) => {
	return (
		<FormGroup label="Password" mandatory {...props}>
			{!allowFile && <Field name={fieldName} component="input" type="password" autoComplete="off" maxLength={200} className="form-control" />}
			{allowFile && (
				<Field name={fieldName} validateOn="change" component={({ input }) => (
					<div>
						{typeof input.value === 'object'
							? <Shelf allowRemove
								allowEdit={false}
								value={input.value.name}
								renderValue={v => (<span><FileIcon className={style.shelfIcon} />{v}</span>)}
								onRemove={() => { input.onChange() }} />
							: [
								<input key={`${fieldName}_input`} {...input} autoComplete="off" type="password" maxLength={200} className="form-control" />,
								<label key="or" className={style.orLabel}>or</label>,
								<DropZone key={`${fieldName}_dropzone`}
									types={['pem', 'ppk']}
									maxFilesCount={1}
									maxFileSize={1}
									onDropEnd={({ files }) => readFileAsText(files[0], e => { input.onChange({ name: files[0].name, contents: e.target.result }) })}
									className={style.dropZone}>
									<FileIcon className={style.dropZoneIcon} />
							Upload PPK/PEM file
								</DropZone>
							]
						}
					</div>
				)} />
			)}
			<Error sticky name={fieldName} />
		</FormGroup>
	);
};

PasswordField.propTypes = {
	fieldName: PropTypes.string.isRequired,
	allowFile: PropTypes.bool.isRequired
};

PasswordField.defaultProps = {
	allowFile: true
};

export default PasswordField;
