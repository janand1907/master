import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error,Password } from 'components/common/Forms';
import style from './style.scss';

const UsernamePasswordField = ({ disabled, name }) => {
	return (
		<div className={style.halfWidthWrapper}>
			<FormGroup label="Username" mandatory>
				<Field
					disabled={disabled}
					name={name ? `${name}.username` : 'username'}
					component="input"
					type="text"
					autoComplete="off"
					maxLength={110}
					className={style.halfWidth}
				/>
				<Error sticky name={name ? `${name}.username` : 'username'} />
			</FormGroup>
			<FormGroup label="Password" mandatory className={style.spaceFormGroup}>
			<Password
				fieldProps={{disabled:disabled, name:name ? `${name}.password` : 'password',
				component: "input", className: style.halfWidth, placeholder: "" }}
				isForm={true}
			/>
				<Error
					className={style.passwordField}
					sticky
					name={name ? `${name}.password` : 'password'}
				/>
			</FormGroup>
		</div>
	);
};

UsernamePasswordField.propTypes = {
	name: PropTypes.string,
	disabled: PropTypes.bool.isRequired,
};

UsernamePasswordField.defaultProps = {
	disabled: false,
};

export default UsernamePasswordField;
