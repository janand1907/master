import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import * as i18n from 'i18n/en/channelForm.json';
import style from './style.scss';

const DBName = ({ dbName, tooltip, fieldName, disabled = false,hidden=false }) => {
	return (
		<FormGroup hidden={hidden} mandatory>
			<div className={style.label}>
				<div>
					{dbName ? dbName : 'Database Name'}{' '}
					<span className="mandatory">*</span>
				</div>
				<TooltipTarget
					className={style.tooltipWrapper}
					tooltip={
						<Tooltip placement="right">
							{tooltip
								? tooltip
								: globalize.parseString(i18n.tooltips.dbConstraints)}
						</Tooltip>
					}
				>
					<InfoIcon className={style.iconTooltip} />
				</TooltipTarget>
			</div>

			<Field
				name={fieldName}
				component="input"
				placeholder="Enter a name for the database"
				type="text"
				maxLength={64}
				className="form-control"
				disabled={disabled}
			/>

			<Error sticky name={fieldName} />
		</FormGroup>
	);
};

DBName.propTypes = {
	disabled: PropTypes.bool,
	fieldName: PropTypes.string,
};

export default DBName;
