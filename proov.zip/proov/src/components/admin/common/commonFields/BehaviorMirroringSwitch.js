import React from 'react';
import PropTypes from 'prop-types';
import cx from 'utils/classNames';
import Switch from 'components/ui/Switch/Switch';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import { FormGroup, Field } from 'components/common/Forms';
import * as i18n from 'i18n/en/channelForm.json';
import style from './style.scss';

const BehaviorMirroringSwitch = ({ disabled, isDedicatedEnabled }) => {

	let tooltipToDisplay = null;
	let showTooltip = disabled && isDedicatedEnabled || disabled ? true : null;
	if (disabled && isDedicatedEnabled) {
		tooltipToDisplay = <span>{globalize.parseString(i18n.tooltips.notDedicatedServer)}</span>;
	} else if (disabled) {
		tooltipToDisplay = <span>{globalize.parseString(i18n.tooltips.noPcapFiles)}</span>;
	}

	return (
		<FormGroup className={style.prvBmSwitchWrapper}>
			<div className={style.biggerLabel}>Enable Behavior Mirroring</div>
			<TooltipTarget
				tooltip={
					<Tooltip placement="right" className={style.tooltipFadein}><span>{globalize.parseString(i18n.tooltips.bmInfo)}</span></Tooltip>
				}>
				<InfoIcon className={style.iconTooltip} />
			</TooltipTarget>

			<Field
				name="bm.enabled"
				component={({ input }) => (
					<TooltipTarget
						className={style.tooltipSwitch}
						tooltip={
							<Tooltip
								placement="left"
								className={cx(style.tooltipFadein, (showTooltip ? style.tooltipBlock : style.tooltipNone))}>
								{tooltipToDisplay}
							</Tooltip>
						}>
						<Switch
							className={style.bmSwitch}
							name={input.name}
							onToggle={input.onChange}
							disabled={disabled}
							toggled={input.value}
						/>
					</TooltipTarget>

				)}
			/>
		</FormGroup>
	);
};


BehaviorMirroringSwitch.propTypes = {
	disabled: PropTypes.bool,
	isDedicatedEnabled: PropTypes.bool
};

export default BehaviorMirroringSwitch;
