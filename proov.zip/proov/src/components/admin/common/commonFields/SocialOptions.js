import { TwitterIcon, GoogleIcon, MicrosoftIcon, FacebookIcon, GithubIcon, AppleIcon, LinkedInIcon, MailIcon } from 'components/ui/Icons';

export const SOCIAL_OPTIONS = [
    { id: 'google', label: 'Google', icon: GoogleIcon },
    { id: 'facebook', label: 'Facebook', icon: FacebookIcon },
    { id: 'linkedin', label: 'LinkedIn', icon: LinkedInIcon },
    { id: 'twitter', label: 'Twitter', icon: TwitterIcon },
    { id: 'github', label: 'GitHub', icon: GithubIcon },
    { id: 'apple', label: 'Apple', icon: AppleIcon },
    { id: 'microsoft', label: 'Microsoft', icon: MicrosoftIcon },
    { id: 'email', label: 'Email', icon: MailIcon }
];