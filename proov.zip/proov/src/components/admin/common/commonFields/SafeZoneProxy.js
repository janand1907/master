import React from 'react';
import PropTypes from 'prop-types';
import Switch from 'components/ui/Switch/Switch';
import { FormGroup, Field } from 'components/common/Forms';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import * as i18n from 'i18n/en/channelForm.json';
import style from './style.scss';

const SafeZoneProxy = ({ proxy }) => {
	return (
		<FormGroup
			className={style.proxySwitch}
			label={
				<span className={style.biggerLabel}>
					{i18n.proxySwitch}
					<TooltipTarget
						tooltip={
							<Tooltip placement="right" className={style.tooltipFadein}>
								<span>{globalize.parseString(i18n.tooltips.proxy)}</span>
							</Tooltip>
						}
					>
						<InfoIcon className={style.iconTooltip} />
					</TooltipTarget>
				</span>
			}
		>
			<Field
				name="is_direct_access"
				component={({ input }) => (
					<Switch
						name={input.name}
						onToggle={input.onChange}
						toggled={input.value}
						disabled={!proxy}
					/>
				)}
			/>
		</FormGroup>
	);
};

SafeZoneProxy.propTypes = {
	proxy: PropTypes.string
};

export default SafeZoneProxy;
