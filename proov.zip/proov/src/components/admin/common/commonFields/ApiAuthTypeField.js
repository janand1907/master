import React from 'react';
import PropTypes from 'prop-types';
import cx from 'utils/classNames';
import { RadioGroup, Radio } from 'components/ui/RadioGroup';
import { FormGroup, Field, Error } from 'components/common/Forms';
import UsernamePasswordField from '../commonFields/UsernamePasswordField';
import OAuthFields from '../commonFields/OAuthFields';
import ApiKey from '../commonFields/ApiKey';
import style from './style.scss';

const ApiAuthTypeField = ({ authType, grantType, hideOAuth, typeChannel, apiType }) => {
	const renderChildern = (authType,grantType) => {

		switch (authType) {
			case "basic":
			return <UsernamePasswordField key="authFields" name="auth" />
			case "oauth2.0":
			return	<OAuthFields grantType={grantType} />
			case "api_key":
				return	<ApiKey />
			default:
				return null;
		}
	}
	return (
		<div>
			<FormGroup label="Authentication Type" mandatory>
				<Field
					name="auth.type"
					validateOn="change"
					defaultValue={authType || "basic"}
					component={({ input }) => (
						<RadioGroup className={style.radioGroup} name={input.name} selectedValue={input.value} onChange={input.onChange}>
							<label className={cx(style.authRadio, 'form-check-inline')}>
								<Radio value="basic" className="form-control" />
								Basic
							</label>
							{!hideOAuth && <label className={cx(style.authRadio, 'form-check-inline')}>
								<Radio value="oauth2.0" className="form-control" />
								OAuth 2.0
							</label>}
							{typeChannel == "Saas" && apiType === 'rest' &&
								< label className={cx(style.authRadio, 'form-check-inline')}>
									<Radio value="api_key" className="form-control" />
									API Key
								</label>}
							<label className={cx(style.authRadio, 'form-check-inline')}>
								<Radio value="none" className="form-control" />
								None
							</label>
						</RadioGroup>
					)}
				/>
				<Error sticky name="auth.type" />
			</FormGroup>

			{renderChildern(authType,grantType)}
		</div >
	);
};

ApiAuthTypeField.propTypes = {
	authType: PropTypes.string,
	grantType: PropTypes.string,
	hideOAuth: PropTypes.bool,
};

export default ApiAuthTypeField;
