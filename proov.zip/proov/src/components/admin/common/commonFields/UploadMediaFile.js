import React from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Field, Error } from 'components/common/Forms';
import { Spinner } from 'components/ui/Spinner';
import DropZone from 'components/ui/DropZone/DropZone';
import Shelf from 'components/ui/Rack/Shelf';
import { FileIcon } from 'components/ui/Icons';
import style from './style.scss';

const UploadMediaFile = ({
	mandatory,
	fileName,
	label,
	allowedFiles,
	allowView,
	onUpload,
	pending,
	disabledRemove,
	...props
}) => {
	return (
		<FormGroup key={fileName} label={label} mandatory={mandatory}>
			<Field
				name={fileName}
				validateOn={['blur', 'change']}
				defaultValue={null}
				component={({ input }) => {
					return input.value && input.value.url && input.value.label ? (
						<Shelf
							allowView={allowView}
							value={input.value}
							renderValue={v => (
								<span>
									<FileIcon className={style.shelfIcon} />
									{v.label}
								</span>
							)}
							allowRemove={disabledRemove ? false : true}
							allowEdit={false}
							onRemove={() => {
								input.onChange();
							}}
						/>
					) : (
						<DropZone
							types={allowedFiles}
							onDropEnd={({ success, files }) => {
								onUpload(files[0], fileName);
							}}
							maxFilesCount={1}
							maxFileSize={200}
							className={style.dropZone}
							wrapperClassName={props.childrenClassName}
						>
							{pending && (
								<div className={style.spinnerDropZoneWrapper}>
									<Spinner />
								</div>
							)}
							<FileIcon className={style.dropZoneIcon} />
							{props.children}
						</DropZone>
					);
				}}
			/>
			<Error sticky name={fileName} />
		</FormGroup>
	);
};

UploadMediaFile.propTypes = {
	fileName: PropTypes.string.isRequired,
	label: PropTypes.string,
	mandatory: PropTypes.bool,
	children: PropTypes.node,
	allowedFiles: PropTypes.array.isRequired,
	onUpload: PropTypes.func.isRequired,
	pending: PropTypes.bool,
	childrenClassName: PropTypes.string
};

export default UploadMediaFile;
