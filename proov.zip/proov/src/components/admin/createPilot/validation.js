/* eslint-disable camelcase */
import { some } from 'lodash';
import striptags from 'striptags';
import isLength from 'validator/lib/isLength';
import isEmail from 'validator/lib/isEmail';
import moment from 'moment';
import * as i18n from 'i18n/en/createPilotValidation.json';

const isExist = value => !!value;
const isNotEmptyArray = value => !value || value.length !== 0;
const str = value => (value || '').toString().trim();
const validator = (validate, message) => value =>
	!validate(value) ? message : undefined;

const strWithoutTags = value =>
	striptags(value)
		.replace(/(&lt;)|(&gt;)/g, '')
		.trim();

const formValidators = {
	// Overview
	name: validator(val => isLength(str(val), { min: 2, max: 50 }), i18n.name),
	category: validator(val => isExist(val), i18n.category),
	description: validator(
		val => isLength(strWithoutTags(val), { min: 10, max: 10000 }),
		i18n.description
	),
	stages: val => {
		const STAGES = ['joining', 'preparation', 'execution', 'evaluation'];
		if (!val) {
			return i18n.stages.noDuration;
		}
		if (
			val &&
			(!val.execution ||
				(val.execution &&
					(!val.execution.start_date || !val.execution.end_date)))
		) {
			return i18n.stages.noRange;
		}

		for (let i = 0; i < STAGES.length; i++) {
			if (
				(val[STAGES[i]].start_date && !val[STAGES[i]].end_date) ||
				(val[STAGES[i]].end_date && !val[STAGES[i]].start_date)
			) {
				const curStage = STAGES[i];
				return globalize.parseString(i18n.stages.incorrectDuration, {
					curStage
				});
			}
		}

		const activeStages = STAGES.filter(
			s => val[s] && val[s].start_date && val[s].end_date
		);
		for (let i = 0; i < activeStages.length - 1; i++) {
			const curStage = activeStages[i];
			const nextDay = moment
				.utc(val[curStage].end_date)
				.add(1, 's')
				.toISOString();
			const startDate = moment
				.utc(val[activeStages[i + 1]].start_date)
				.toISOString();
			if (nextDay !== startDate) {
				return globalize.parseString(i18n.stages.incorrectDuration, {
					curStage
				});
			}
		}
	},
	approval_policy: validator(val => isExist(val), i18n.approval_policy),
	region_policy: validator(val => isNotEmptyArray(val), i18n.region_policy),
	tags: val => {
		if (!Array.isArray(val)) return undefined;
		if (val.length > 5) {
			return i18n.tags.lengthLong;
		}
		if (some(val, tag => tag.length < 2)) {
			return i18n.tags.lengtShort;
		}
	},
	tech_contact_email: val => {
		if (str(val).length == 0) return undefined;
		if (!isEmail(val)) {
			return i18n.tech_contact_email;
		}
	},
	tech_contact_phone: val => {
		if (!val) return;
		const [code, number] = val;
		const codeString = str(code),
			numberString = str(number);
		if (!codeString && !numberString) return; // could be empty
		if (!codeString) {
			return i18n.tech_contact_phone.empty;
		}
		if (numberString.length < 4) {
			return i18n.tech_contact_phone.length;
		}
	},
	// Requirements
	goals: validator(
		val =>
			!str(val) || isLength(str(strWithoutTags(val)), { min: 2, max: 10000 }),
		i18n.goals
	),
	eval_criteria: val => {
		if (Array.isArray(val)) {
			if (val.length < 4) {
				return i18n.eval_criteria.short;
			}
			if (val.length > 25) {
				return i18n.eval_criteria.long;
			}
		}
	},
	target_vendors: validator(
		val => !str(val) || isLength(str(strWithoutTags(val)), { max: 1000 }),
		i18n.target_vendors
	),
	scenarios: validator(
		val => !str(val) || isLength(str(val), { max: 10000 }),
		i18n.scenarios
	),

	// Instructions
	instructions: validator(
		val => isLength(str(strWithoutTags(val)), { max: 10000 }),
		i18n.instructions
	),
	portfolio_id: value => {
		const regexp = new RegExp('(port-)[a-zA-Z0-9]{13}');
		return !value || regexp.test(value)
			? undefined
			: i18n.portfolio_id_incorrect;
	}
};

function runValidators(data, validators) {
	let err,
		errors = {};
	Object.keys(validators).forEach(field => {
		err = validators[field](data[field], data);
		if (typeof err === 'string') {
			errors[field] = err;
		} else if (typeof err === 'object') {
			errors = { ...errors, ...err };
		}
	});
	return errors;
}

export default function validate(values) {
	return runValidators(values, { ...formValidators });
}
