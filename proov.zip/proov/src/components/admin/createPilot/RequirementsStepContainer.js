import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getUploadInProcess } from 'ducks/admin/createPilot/selectors';
import { uploadAttachment } from 'ducks/admin/createPilot/actions';
import RequirementsStep from './RequirementsStep';

const RequirementsStepContainer = props => {

	return (
		<RequirementsStep
			onAttachmentSelect={props.actions.onAttachmentSelect}
		/>
	);
};

RequirementsStepContainer.propTypes = {
	actions: PropTypes.object.isRequired
}

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			onAttachmentSelect: uploadAttachment
		}
	};
}

function mapStateToProps(state) {
	return {
		isUploadInProcess: getUploadInProcess(state)
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(RequirementsStepContainer);


