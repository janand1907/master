import EXTENSIONS from 'constants/fileExtensions';
import React from 'react';
import PropTypes from 'prop-types';
import { Duration } from 'components/common/Duration';
import HtmlEditor from 'components/common/HtmlEditor/HtmlEditor';
import { Field, FormGroup, Error } from 'components/common/Forms';
import { LookupSelect } from 'components/common/Lookups';
import { Switch } from 'components/ui/Switch';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import { DropZone } from 'components/ui/DropZone';
import { Rack } from 'components/ui/Rack';
import { FileIcon } from 'components/ui/Icons';
import Spinner from 'components/ui/Spinner/Spinner';
import { InfoTooltip } from 'components/common/InfoTooltip';
import * as i18n from 'i18n/en/createPilot.json';
import PillsAutoComplete from './PillsAutoComplete';
import style from './style.scss';

const OverviewStep = props => {
	return (
		<div>
			{/* PoC Name */}
			<FormGroup label="PoC Name" mandatory>
				<Field
					name="name"
					component="input"
					type="text"
					className="form-control"
					placeholder="Enter a name for the PoC"
					maxLength="50"
					required
				/>
				<Error sticky name="name" />
			</FormGroup>

			{/* Category */}
			<FormGroup label="Category" mandatory>
				<Field
					name="category"
					validateOn={['blur', 'change']}
					sortBy="option"
					component={({ input }) => (<LookupSelect {...input} required lazy={false} lookupType="category" placeholder="Select a category" defaultOption="Select one..." className={style.controlCategory} />)}
				/>
				<Error sticky name="category" />
			</FormGroup>

			{/* Duration (start/end dates) */}
			<FormGroup label="Duration" inline mandatory>
				<p className={style.stagesDescription}>{i18n.overviewStep.durationDescription}</p>
				<Field
					name="stages"
					component={({ input: { value, onChange: handleDurationChange } }) => (
						<Duration
							onDurationChange={handleDurationChange}
							value={value}
						/>
					)}
					required
				/>
				<Error sticky name="stages" />
			</FormGroup>

			{/* Approval policy */}
			<FormGroup label={(
				<span>Approval Policy <span className="mandatory">*</span>
					<InfoTooltip>{i18n.overviewStep.tooltip.approvalPolicy}</InfoTooltip>
				</span>
			)}>
				<Field
					name="approval_policy"
					validateOn="change"
					component={({ input: { name, value, onChange: handleChange } }) => (
						<RadioGroup name={name} selectedValue={value} onChange={handleChange}>
							<PushButton value="manual" className={style.controlPush}> Requires Approval</PushButton>
							<PushButton value="open" className={style.controlPush}> Open to all</PushButton>
						</RadioGroup>
					)}
				/>
				<Error sticky name="approval_policy" />
			</FormGroup>

			{/* Is public? */}
			<FormGroup
				labelClassName={style.inlineLabel}
				label={(
					<span>
						Public <InfoTooltip placement="top">{i18n.overviewStep.tooltip.isPublic}</InfoTooltip>
					</span>
				)}>
				<Field
					name="is_public"
					component={({ input: { name, value, onChange: handleToggle } }) => (
						<Switch
							name={name}
							onToggle={handleToggle}
							toggled={value}
							className={style.controlSwitch}
						/>
					)}
				/>
			</FormGroup>

			{/* Description */}
			<FormGroup label="Description" className={style.description} mandatory>
				<Field
					name="description"
					component={({ input }) => (
						<HtmlEditor
							onChange={input.onChange}
							initialValue={input.value}
						/>
					)}
					className={style.textarea}
					placeholder={i18n.overviewStep.placeholder.description}
					maxLength="10000"
				/>
				<Error sticky name="description" />
			</FormGroup>

			{/* Tags */}
			<FormGroup label="Tags">
				<Field
					name="tags"
					defaultValue={[]}
					validateOn={['blur', 'change']}
					component={({ input }) => (
						<PillsAutoComplete
							allowDuplicates={false}
							maxItemsCount={5}
							ignoreCase
							autoCompleteProps={{
								inputProps: {
									...input,
									placeholder: i18n.overviewStep.placeholder.tags,
									maxLength: 50
								}
							}}
							onAutoCompleteChange={props.onTagsAutoCompleteChange}
						/>
					)}
				/>
				<Error sticky name="tags" />
			</FormGroup>

			{/* Attachments */}
			<FormGroup label={(
				<div>
					<div>{i18n.overviewStep.attachmentsHeader}</div>
					<div className="muted">
						{i18n.overviewStep.attachmentsBody}
					</div>
				</div>
			)}>
				<Field
					name="attachments_public"
					defaultValue={[]}
					component={({ input: { value, onChange: handleChange } }) => (
						<Rack
							items={value}
							allowAdd={value.length < 5}
							onChange={handleChange}
							renderEdit={({ handleAdd }) => (
								<DropZone
									maxFileSize={40}
									types={EXTENSIONS}
									accept={EXTENSIONS}
									onDropEnd={({ files }) => {
										props.onAttachmentSelect(files[0], r => handleAdd(r));
									}}
									disabled={props.isUploadInProcess}>
									{!props.isUploadInProcess ? 'Drag and drop a file or click to browse' : <Spinner /> }
								</DropZone>
							)
							}
							shelfProps={{
								allowRemove: true,
								allowEdit: false,
								renderValue: v => (
									<span className={style.attachmentShelfText}>
										<FileIcon className={style.shelfIcon} />
										{v.title}
									</span>
								),
							}}
						/>
					)}
				/>
				<Error sticky name="attachments_public" />
			</FormGroup>
		</div>
	);
};

OverviewStep.propTypes = {
	isUploadInProcess: PropTypes.bool,
	onTagsAutoCompleteChange: PropTypes.func,
	onAttachmentSelect: PropTypes.func
};

export default OverviewStep;
