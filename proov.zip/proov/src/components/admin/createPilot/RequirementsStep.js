import React from 'react';
import PropTypes from 'prop-types';
import HtmlEditor from 'components/common/HtmlEditor/HtmlEditor';
import { LookupSelect } from 'components/common/Lookups';
import { FormGroup, Field, Error } from 'components/common/Forms';
import { Rack } from 'components/ui/Rack';
import { FileIcon } from 'components/ui/Icons';
import Spinner from 'components/ui/Spinner/Spinner';
import DropZone from 'components/ui/DropZone/DropZone';
import EXTENSIONS from 'constants/fileExtensions';
import * as i18n from 'i18n/en/createPilot.json';
import style from './style.scss';

const RequirementsStep = props => {
	return (
		<div>
			<FormGroup label="Goals">
				<Field
					name="goals"
					component={({ input }) => (
						<HtmlEditor
							onChange={input.onChange}
							initialValue={input.value}
						/>
					)}
					className={style.textarea}
					maxLength="10000"
					placeholder={i18n.requirementsStep.placeholder.goals}
				/>
				<Error sticky name="goals" />
			</FormGroup>

			<FormGroup label="Budget">
				<Field
					name="budget"
					validateOn={['blur', 'change']}
					sortBy="option"
					component={({ input }) => (<LookupSelect {...input} lazy={false} lookupType="budget" defaultOption="Select..." className={style.controlBudget} />)}
				/>
			</FormGroup>

			<FormGroup label="Target Vendors">
				<Field
					name="target_vendors"
					component={({ input }) => (
						<HtmlEditor
							onChange={input.onChange}
							initialValue={input.value}
						/>
					)}
					className={style.textarea}
					maxLength="1000"
					placeholder={i18n.requirementsStep.placeholder.target_vendors}
				/>
				<Error sticky name="target_vendors" />
			</FormGroup>

			<FormGroup label="Scenarios">
				<Field
					name="scenarios"
					component={({ input }) => (
						<HtmlEditor
							onChange={input.onChange}
							initialValue={input.value}
						/>
					)}
					className={style.textarea}
					maxLength="10000"
					placeholder={i18n.requirementsStep.placeholder.scenarios}
				/>
				<Error sticky name="scenarios" />
			</FormGroup>

			<FormGroup label="Instructions">
				<Field
					name="instructions"
					component={({ input }) => (
						<HtmlEditor
							onChange={input.onChange}
							initialValue={input.value}
						/>
					)}
					maxLength="10000"
					className={style.textareaLg}
					placeholder={i18n.overviewStep.placeholder.instructions}
				/>
			</FormGroup>

			<FormGroup label={(
				<div>
					<div>{i18n.overviewStep.attachmentsHeader}</div>
				</div>)}>
				<Field
					name="attachments_private"
					defaultValue={[]}
					component={({ input: { value, onChange: handleChange }, meta }) => (
						<Rack
							items={value}
							allowAdd={value.length < 5}
							onChange={handleChange}
							renderEdit={({ handleAdd }) => (
								<DropZone
									maxFileSize={40}
									types={EXTENSIONS}
									accept={EXTENSIONS}
									onDropEnd={({ files }) => {
										props.onAttachmentSelect(files[0], r => handleAdd(r));
									}}
									disabled={props.isUploadInProcess}>
									{!props.isUploadInProcess ? 'Drag and drop a file or click to browse' : <Spinner />}
								</DropZone>
							)
							}
							shelfProps={{
								allowRemove: true,
								allowEdit: false,
								renderValue: v => (
									<span className={style.attachmentShelfText}>
										<FileIcon className={style.shelfIcon} />
										{v.title}
									</span>
								),
							}}
						/>
					)}
				/>
			</FormGroup>

		</div>
	);
};

RequirementsStep.propTypes = {
	onAttachmentSelect: PropTypes.func.isRequired
};

export default RequirementsStep;
