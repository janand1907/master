import { USER_STATUS, USER_SERVER_STATUS } from 'constants/user/userStatus';
import { USER_SERVER_ROLE } from 'constants/user/userRole';
import React from 'react';
import PropTypes from 'prop-types';
import { GridView } from 'components/ui/GridView';
import Permission from 'components/Permission';
import MiniMenu from 'components/ui/Menu/MiniMenu';
import { NewSpinner } from 'components/ui/NewSpinner';
import cx from 'utils/classNames';
import style from './PoCTeam.scss';

const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
];
class PoCTeamStep extends React.PureComponent {
    constructor(props) {
        super(props);
        this.getTableConfig = this.getTableConfig.bind(this);
    }

    getTableConfig() {
        return [
            {

                value: ({ id }) => <input
                    className={cx("form-control", style.mfaInput)}
                    type="checkbox"
                    id={id}
                    checked={this.props.selectedUserValues.findIndex(e => e.id === id) !== -1 ? true : false}
                    disabled={this.props.disabled}
                    onChange={(e) => { this.props.handleUser(id) }}
                />
            },
            {
                title: 'User Details',
                value: ({ id, first_name, last_name, email, department, last_login, role, created_at }) => ({
                    id,
                    first_name,
                    last_name,
                    email,
                    department,
                    last_login,// new Date(last_login),
                    role,
                    created_at
                }), // eslint-disable-line camelcase
                format: v => (
                    <div>
                        <div className={style.name}>
                            {v.first_name +
                                ' ' +
                                v.last_name +
                                (v.id === this.props.me.id ? ' (You)' : '')}
                        </div>
                        <div className={style.email}>{v.email}</div>
                        <div className={style.topSpace}>
                            <div className={style.email}>Last Login:</div>
                            <div className={style.email}>{v.last_login === null ? 'Never' : v.last_login}</div>
                            {/* <div className={style.role}>{v.last_login.getDate() + ' ' + months[v.last_login.getMonth()] + ' ' + v.last_login.getFullYear()}</div> */}
                        </div>
                    </div>
                )
            },
            {
                value: ({ role, department }) => (
                    <div>
                        <div>
                        <div className={style.email}>Department:</div>
                            <div className={style.email}>{department === null ? '-' : department}</div>
                        </div>
                        <div className={style.topSpace}>
                        <div className={style.email}>Role:</div>
                        <div className={style.email}>{role.replace(/_/g, ' ')}</div>
                        </div>
                    </div>
                )
            },
            // {
            //     title: 'Department',
            //     value: ({ department }) => <div>{department}</div>
            // },
            // {
            //     title: 'Created At',
            //     value: ({ created_at }) => {
            //         let date = new Date(created_at);
            //         const months = [
            //             'Jan',
            //             'Feb',
            //             'Mar',
            //             'Apr',
            //             'May',
            //             'Jun',
            //             'Jul',
            //             'Aug',
            //             'Sep',
            //             'Oct',
            //             'Nov',
            //             'Dec'
            //         ];
            //         let createdAt =
            //             date.getDate() +
            //             ' ' +
            //             months[date.getMonth()] +
            //             ' ' +
            //             date.getFullYear();

            //         return <div className={style.role}>{createdAt}</div>;
            //     }
            // },
            // {
            //     title: 'Status',
            //     value: ({ status }) => ({ status }),
            //     format: v => (
            //         <div className={style.status}>
            //             {v.status === USER_SERVER_STATUS.PENDING
            //                 ? USER_STATUS.PENDING
            //                 : v.status}
            //         </div>
            //     )
            // },
            // {
            //     title: 'MFA',
            //     value: ({ enable_mfa }) => <input
            //         className={cx("form-control", style.mfaInput)}
            //         type="checkbox"
            //         id={enable_mfa}
            //         checked={enable_mfa}
            //         disabled={true}
            //     />
            // },
            // {
            //     title: 'Edit',
            //     value: ({ id, status, role }) => ({ id, status, role }),
            //     format: v => {
            //         let menuOptions = [];

            //         if (
            //             this.props.me.role === USER_SERVER_ROLE.ADMIN ||
            //             this.props.me.role === USER_SERVER_ROLE.OWNER
            //         ) {
            //             menuOptions = [
            //                 {
            //                     name: 'delete',
            //                     text: 'Delete',
            //                     icon: 'TrashIcon',
            //                     function: this.props.onDelete
            //                 },
            //                 {
            //                     name: 'edit',
            //                     text: 'Edit',
            //                     icon: 'EditIcon',
            //                     function: this.props.onEdit
            //                 }
            //             ];
            //         }

            //         if (
            //             (this.props.me.role === USER_SERVER_ROLE.ADMIN &&
            //                 v.role === USER_SERVER_ROLE.OWNER) ||
            //             (this.props.me.id === v.id && v.role === USER_SERVER_ROLE.USER) ||
            //             (this.props.me.id === v.id && v.role === USER_SERVER_ROLE.OWNER)
            //         ) {
            //             menuOptions = [
            //                 {
            //                     name: 'edit',
            //                     text: 'Edit',
            //                     icon: 'EditIcon',
            //                     function: this.props.onEdit
            //                 }
            //             ];
            //         }

            //         return (this.props.me.id === v.id &&
            //             v.role === USER_SERVER_ROLE.USER) ||
            //             this.props.me.role === USER_SERVER_ROLE.ADMIN ||
            //             this.props.me.role === USER_SERVER_ROLE.OWNER ? (
            //             <Permission
            //                 alias="TeamManagement#editUser"
            //                 component={
            //                     this.props.pending == v.id ? (
            //                         <NewSpinner wrapperClassName={style.userPending} size="s" />
            //                     ) : (
            //                         <MiniMenu handlers={menuOptions} item={v.id} />
            //                     )
            //                 }
            //             />
            //         ) : null;
            //     }
            // }
        ];
    }

    render() {
        const { onAdd, users, subscription } = this.props;
        return (
            <div className={style.container}>
                <GridView
                    className={cx(style.usersGrid,style.customGrid)}
                    config={this.getTableConfig()}
                    data={users}
                />
            </div>
        );
    }
}

PoCTeamStep.propTypes = {
    /**
     * List of all users
     */
    users: PropTypes.array.isRequired,
    onAdd: PropTypes.func.isRequired,
    subscription: PropTypes.object,
    onEdit: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    pending: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
    /**
     * User Id
     */
    me: PropTypes.object.isRequired
};

export default PoCTeamStep;
