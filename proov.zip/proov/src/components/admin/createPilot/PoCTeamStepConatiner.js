import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import {
	getTeamPending,
	_getTeamUsers,
	getSubscription
} from 'ducks/myAccount/selectors';
import { getMeUser } from 'ducks/me/selectors';
import { getTeamUsers, removeUser } from 'ducks/myAccount/actions';
import { showModal } from 'ducks/modal/actions';
import { Spinner } from 'components/ui/Spinner';
import { createToast } from 'ducks/toaster/actions';
import PoCTeamStep from './PoCTeamStep';

class PoCTeamStepConatiner extends React.PureComponent {
	constructor() {
		super();
	}

	UNSAFE_componentWillMount() {
		this.props.getTeamUsers();
	}

	render() {
		const { users, me, subscription, teamPending, userPending } = this.props;
		if (teamPending) {
			return <Spinner />;
		}

		return (
			<PoCTeamStep
				users={users}
				me={me}
				pending={userPending}
				disabled={true}
				handleUser={this.props.handleuser}
				selectedUserValues={this.props.selectedUserValues}
			/>
		);
	}
}

function mapStateToProps(state) {
	return {
		users: _getTeamUsers(state) || [],
		teamPending: getTeamPending(state).get,
		userPending: getTeamPending(state).update || getTeamPending(state).delete,
		me: getMeUser(state),
	};
}

PoCTeamStepConatiner.propTypes = {
	getTeamUsers: PropTypes.func.isRequired,
	showModal: PropTypes.func.isRequired,
	me: PropTypes.object.isRequired,
	users: PropTypes.array.isRequired,
	createToast: PropTypes.func,
	teamPending: PropTypes.bool.isRequired,
	userPending: PropTypes.oneOfType([PropTypes.bool, PropTypes.string])
};

export default connect(mapStateToProps, {
	getTeamUsers,
	createToast,
	showModal
})(PoCTeamStepConatiner);
