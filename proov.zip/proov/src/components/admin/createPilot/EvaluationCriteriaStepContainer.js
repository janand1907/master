import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { debounce } from 'lodash';
import { getEvalCriteriaSuggestions } from 'ducks/shared/actions';
import EvaluationCriteriaStep from './EvaluationCriteriaStep';

const EvaluationCriteriaStepContainer = props => {

	return (
		<EvaluationCriteriaStep
			onCriterionsAutoCompleteChange={props.actions.handleCriterionsAutoComplete}
		/>
	);
};

EvaluationCriteriaStepContainer.propTypes = {
	actions: PropTypes.object.isRequired
};

function handleAsync(dispatch, actionCreator, value, done) {
	return dispatch(actionCreator(value, done));
}

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			handleCriterionsAutoComplete: debounce(
				(value, done) => handleAsync(dispatch, getEvalCriteriaSuggestions, value, done),
				400
			)
		}
	};
}

export default connect(undefined, mapDispatchToProps)(EvaluationCriteriaStepContainer);


