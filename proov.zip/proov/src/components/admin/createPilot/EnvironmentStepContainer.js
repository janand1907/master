import { LAB } from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { modelSelector } from 'ducks/forms/selectors';
import { getSubscription } from 'ducks/myAccount/selectors';
import { getCreatePilot } from 'ducks/admin/createPilot/selectors';
import { getAWSAccountId } from 'ducks/gateway/register/selectors';
import * as actions from 'ducks/admin/createPilot/actions';
import { getPcapFiles } from 'ducks/repository/behaviorMirroring/actions';
import { getHarFiles } from 'ducks/repository/httpArchive/actions';
import { showModal, hideModal } from 'ducks/modal/actions';
import { fetchAWSAccountId } from 'ducks/gateway/register/actions';
import { getMeCompany } from 'ducks/me/selectors';
import EnvironmentStep from './EnvironmentStep';

class EnvironmentStepContainer extends React.PureComponent {
	constructor(props, context) {
		super(props, context);
		this.handleComponentSave = this.handleComponentSave.bind(this);
		this.handleComponentEdit = this.handleComponentEdit.bind(this);
		this.handleComponentNew = this.handleComponentNew.bind(this);
		this.handleComponentRemove = this.handleComponentRemove.bind(this);
		this.handleComponentUpdate = this.handleComponentUpdate.bind(this);
	}

	componentDidMount() {
		const { errors, companyId } = this.props;
		if (errors && Object.keys(errors).length > 0) {
			this.editChannelIndex = Object.keys(errors)[0]; // Change it
			const params = {
				pilotType: LAB,
				onSave: this.handleComponentUpdate,
				channelIndex: this.editChannelIndex,
				isWizard: true,
				isWizardEdit: true,
				errors: errors[Object.keys(errors)[0]]
			};
			this.props.actions.showModal('CreateChannel', params);
		}
		this.props.actions.fetchAWSAccountId(companyId, 'createPilot');
		this.props.actions.getPcapFiles();
		this.props.actions.getHarFiles();
	}

	handleComponentSave(env) {
		const { form } = this.context;
		if (env.hasOwnProperty('is_proov_owned')) {
			env = { ...env, is_user_owned: !env.is_proov_owned };
		}
		form.arrayPush('environment', env);
		this.props.actions.hideModal();
	}

	handleComponentUpdate(env, done, resetErrors = false) {
		const { form } = this.context;
		const { errors } = this.props;
		if (env.hasOwnProperty('is_proov_owned')) {
			env = { ...env, is_user_owned: !env.is_proov_owned };
		}
		form.change(`environment[${this.editChannelIndex}]`, env);
		if (resetErrors && errors && Object.keys(errors).length) {
			let newErrors = { ...errors };
			delete newErrors[this.editChannelIndex];
			this.props.actions.setChannelErrorsComponents(newErrors);
		}
		this.props.actions.hideModal();
	}

	handleComponentEdit(env, envIndex) {
		this.editChannelIndex = envIndex; // Change it
		const { errors } = this.props;
		const params = {
			pilotType: LAB,
			onSave: this.handleComponentUpdate,
			channelIndex: envIndex,
			isWizard: true,
			isWizardEdit: true,
			errors: errors[Object.keys(errors)[envIndex]]
		};

		this.props.actions.showModal('CreateChannel', params);
	}

	handleComponentNew(envIndex) {
		const params = {
			onSave: this.handleComponentSave,
			isWizard: true,
			pilotType: LAB
		};

		this.props.actions.showModal('CreateChannel', params);
	}

	handleComponentRemove(envIndex) {
		this.props.actions.removeComponent(envIndex);
		this.context.form.arrayRemove('environment', envIndex);
	}

	render() {
		return (
			<EnvironmentStep
				form={this.context.form.name}
				channels={this.props.channels}
				onComponentSave={this.handleComponentSave}
				onComponentEdit={this.handleComponentEdit}
				onComponentNew={this.handleComponentNew}
				onComponentRemove={this.handleComponentRemove}
				awsAccountId={this.props.awsAccountId}
				next={this.props.next}
				errors={this.props.errors}
				pilotType={this.props.pilotType}
				access={this.props.subscription.config}
			/>
		);
	}
}

EnvironmentStepContainer.propTypes = {
	actions: PropTypes.object.isRequired,
	channels: PropTypes.array,
	subscription: PropTypes.object,
	pilotType: PropTypes.string,
	errors: PropTypes.object,
	companyId: PropTypes.string,
	awsAccountId: PropTypes.string,
	removeError: PropTypes.func,
	fetchAWSAccountId: PropTypes.func,
	isCurrComponentNew: PropTypes.bool,
	next: PropTypes.func.isRequired
};

EnvironmentStepContainer.contextTypes = {
	form: PropTypes.object.isRequired
};

function mapStateToProps(state) {
	const channels = modelSelector(state, 'createPilot', 'environment') || [];
	const pilotType = modelSelector(state, 'createPilot', 'pilot_type') || '';

	const { channelErrors, componentIndex, componentCount } = getCreatePilot(state);
	return {
		channels,
		errors: channelErrors,
		isCurrComponentNew: componentIndex >= componentCount,
		componentIndex,
		pilotType,
		companyId: getMeCompany(state).id,
		awsAccountId: getAWSAccountId(state),
		subscription: getSubscription(state)
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators(
			{ ...actions, showModal, hideModal, getPcapFiles, getHarFiles, fetchAWSAccountId },
			dispatch
		)
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(EnvironmentStepContainer);
