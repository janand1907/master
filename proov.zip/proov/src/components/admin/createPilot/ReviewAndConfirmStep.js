import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import PillList from 'components/ui/Pill/PillList';
import { FileIcon } from 'components/ui/Icons';
import { Lookup } from 'components/common/Lookups';
import ChannelList from 'components/admin/createPilot/env/ChannelList';
import { Field } from 'components/common/Forms';
import { environmentTransform } from 'utils/transformEnvironment';
import { ChevronSmallIcon, EditIcon } from 'components/ui/Icons';
import Switch from 'components/ui/Switch/Switch';
import style from './style.scss';
import cx from 'utils/classNames';
import PoCTeamStep from './PoCTeamStep';

const ReviewAndConfirm = ({ data, onGoToStep, errors, channels, onComponentEdit, onComponentNew, onComponentRemove, users, me, teamPending, handleUser, selectedUserValues }) => {
	const [dataCollapsed, setDataCollapsed] = React.useState({
		overview: { title: "Overview", isCollapsed: false },
		requirements: { title: "Requirements", isCollapsed: false },
		eval_criteria: { title: "Evaluation criteria", isCollapsed: false },
		poc_team: { title: "PoC Team", isCollapsed: false },
		environment: { title: "Environment", isCollapsed: false },

	});

	const notProvided = <span className="muted">Not provided</span>;

	let environmentChannel = environmentTransform(data.environment);
	function toggle(tab) {
		setDataCollapsed({ ...dataCollapsed, [tab]: { ...dataCollapsed[tab], isCollapsed: !dataCollapsed[tab].isCollapsed } }
		);
	}

	const stages = Object.keys(data.stages).map(key => {
		if (data.stages[key].start_date || data.stages[key].end_date) {
			return (
				<p key={key}>
					<span>{key.charAt(0).toUpperCase() + key.substr(1).toLowerCase()}:</span>{' '}
					{moment.utc(data.stages[key].start_date).format('MMMM D, YYYY')} UTC{' '}
					{String.fromCharCode(8594)}{' '}
					{moment.utc(data.stages[key].end_date).format('MMMM D, YYYY')} UTC
				</p>
			);
		}
	});

	return (
		<div>
			{/* Overview section */}
			<section>
				<div onClick={() => toggle("overview")}>
					<div className={style.pocDetailsCard}>

						<div className={style.wrapperArrow}>
							<ChevronSmallIcon
								className={cx(style.chevronIcon, {
									[style.chevronIconDown]: dataCollapsed.overview.isCollapsed,
								}
								)
								}
							/>
							<h4 className={style.sectionHeader}>{dataCollapsed.overview.title}</h4>


						</div>
						<button className={style.btnEditSection} onClick={() => onGoToStep(0)}>
							Edit
						</button>
					</div>
					{dataCollapsed.overview.isCollapsed && <dl className={style.reviewList}>
						<dt>PoC name</dt>
						<dd>{data.name}</dd>

						<dt>Public</dt>
						<dd>{data.is_public ? 'Yes' : 'No'}</dd>

						<dt>Category</dt>
						<dd>
							<Lookup lookupType="category" lookupKey={data.category} />
						</dd>

						<dt>Duration</dt>
						<dd>{stages}</dd>

						<dt>Approval policy</dt>
						<dd>
							{data.approval_policy === 'manual' ? 'Requires Approval' : 'Open to all'}
						</dd>

						<dt>Description</dt>
						<dd>
							{data.description ? (
								<div
									className="pre"
									dangerouslySetInnerHTML={{ __html: data.description }}
								/>
							) : (
								<p className="pre">{notProvided}</p>
							)}
						</dd>

						<dt>Tags</dt>
						<dd>
							{data.tags && data.tags.length ? <PillList items={data.tags} /> : notProvided}
						</dd>

						<dt>Attachment</dt>
						<dd>
							{data.attachments_public && data.attachments_public.length ? (
								<PillList
									items={data.attachments_public}
									getContent={att => (
										<span>
											<FileIcon className={style.shelfIcon} />
											{att.title}
										</span>
									)}
									className={style.pillListVertical}
									pillClassName={style.pillVertical}
								/>
							) : (
								notProvided
							)}
						</dd>
					</dl>}
				</div>
			</section>

			{/* Requirements section */}
			<section>
				<div onClick={() => toggle("requirements")}>
					<div className={style.pocDetailsCard}>
						<div className={style.wrapperArrow}>
							<ChevronSmallIcon
								className={cx(style.chevronIcon, {
									[style.chevronIconDown]: dataCollapsed.requirements.isCollapsed,
								}
								)
								}
							/>
							<h4 className={style.sectionHeader}>{dataCollapsed.requirements.title}</h4>

						</div>
						<button className={style.btnEditSection} onClick={() => onGoToStep(1)}>
							Edit
						</button>
					</div>
					{dataCollapsed.requirements.isCollapsed && <React.Fragment> <dl className={style.reviewList}>
						<dt>Goals</dt>
						<dd>
							{data.goals ? (
								<div className="pre" dangerouslySetInnerHTML={{ __html: data.goals }} />
							) : (
								<p className="pre">{notProvided}</p>
							)}
						</dd>

						<dt>Budget</dt>
						<dd>
							{data.budget ? (
								<Lookup lookupType="budget" lookupKey={data.budget} />
							) : (
								notProvided
							)}
						</dd>

						<dt>Target vendors</dt>
						<dd>
							{data.target_vendors ? (
								<div
									className="pre"
									dangerouslySetInnerHTML={{ __html: data.target_vendors }}
								/>
							) : (
								<p className="pre">{notProvided}</p>
							)}
						</dd>

						<dt>Scenarios</dt>
						<dd>
							{data.scenarios ? (
								<div className="pre" dangerouslySetInnerHTML={{ __html: data.scenarios }} />
							) : (
								<p className="pre">{notProvided}</p>
							)}
						</dd>
					</dl>
						<dl className={style.reviewList}>
							<dt>Define instruction</dt>
							<dd>
								{data.instructions ? (
									<div
										className="pre"
										dangerouslySetInnerHTML={{ __html: data.instructions }}
									/>
								) : (
									<p className="pre">{notProvided}</p>
								)}
							</dd>

							<dt>Attachment</dt>
							<dd>
								{data.attachments_private && data.attachments_private.length ? (
									<PillList
										items={data.attachments_private}
										getContent={att => (
											<span>
												<FileIcon className={style.shelfIcon} />
												{att.title}
											</span>
										)}
										className={style.pillListVertical}
										pillClassName={style.pillVertical}
									/>
								) : (
									notProvided
								)}
							</dd>
						</dl>
					</React.Fragment>}</div>
			</section>

			{/* Evaluation Criteria section */}
			<section>
				<div onClick={() => toggle("eval_criteria")}>
					<div className={style.pocDetailsCard}>
						<div className={style.wrapperArrow}>
							<ChevronSmallIcon
								className={cx(style.chevronIcon, {
									[style.chevronIconDown]: dataCollapsed.eval_criteria.isCollapsed,
								}
								)
								}
							/>
							<h4 className={style.sectionHeader}>{dataCollapsed.eval_criteria.title}</h4>
						</div>
						<button className={style.btnEditSection} onClick={() => onGoToStep(2)}>
							Edit
						</button>
					</div>


					{dataCollapsed.eval_criteria.isCollapsed && <dl >	<dt>{data.eval_criteria.length} Evaluation Criteria</dt>

						<dd className={style.evaluationCriterias}>
							{data.eval_criteria.map(item =>
								<div className={style.criteriaWrapperReview}>
									<p className={style.criteriaContent}>{item}</p>
								</div>
							)}
						</dd>
					</dl>}
				</div>

			</section>

			{/* PoC Team section */}
			<section>
				<div onClick={() => toggle("poc_team")}>
					<div className={style.pocDetailsCard}>
						<div className={style.wrapperArrow}>
							<ChevronSmallIcon
								className={cx(style.chevronIcon, {
									[style.chevronIconDown]: dataCollapsed.poc_team.isCollapsed,
								}
								)
								}
							/>
							<h4 className={style.sectionHeader}>{dataCollapsed.poc_team.title}</h4>
						</div>
						<button className={style.btnEditSection} onClick={() => onGoToStep(3)}>
							Edit
						</button>
					</div>
				</div>
				{dataCollapsed.poc_team.isCollapsed &&
					<PoCTeamStep users={users} me={me} pending={false} disabled={false} selectedUserValues={selectedUserValues} handleUser={handleUser} />}
				{/* </div> */}

			</section>
			{/* Environment section */}
			<section>
				<div onClick={() => toggle("environment")}>
					<div className={style.pocDetailsCard}>
						<div className={style.wrapperArrow}>
							<ChevronSmallIcon
								className={cx(style.chevronIcon, {
									[style.chevronIconDown]: dataCollapsed.environment.isCollapsed,
								}
								)
								}
							/>
							<h4 className={style.sectionHeader}>{dataCollapsed.environment.title}</h4>

						</div>
						<button className={style.btnEditSection} onClick={() => onGoToStep(3)}>
							Edit
						</button>
					</div>
					{dataCollapsed.environment.isCollapsed && <React.Fragment>
						{!data.environment || !data.environment.length ? (
							notProvided) : (
							<ChannelList
								channels={channels}
								errors={errors}
								newEnvironmentClick={onComponentNew}
								editEnvironmentClick={onComponentEdit}
								deleteEnvironmentClick={onComponentRemove}
								isReview={true}
							/>

						)}

						<div className={style.envRedirectSwitch}>
							<label>Take me to set up environment</label>
							<Field
								name="redirect_to_envs"
								component={({ input }) => (
									<Switch name={input.name} onToggle={input.onChange} toggled={input.value} />
								)}
							/>
						</div>
					</React.Fragment>}
				</div>
			</section>
		</div>
	);
};

ReviewAndConfirm.propTypes = {
	data: PropTypes.object,
	onGoToStep: PropTypes.func.isRequired
};

ReviewAndConfirm.defaultProps = {
	data: {}
};

export default ReviewAndConfirm;
