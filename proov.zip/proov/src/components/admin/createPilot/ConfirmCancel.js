import React from 'react';
import PropTypes from 'prop-types';
import * as i18n from 'i18n/en/createPilot.json';
import style from './ConfirmCancel.scss';

const ConfirmCancel = props => {
	return (
		<div className={style.root}>
			<h4>{i18n.confirmCancel.header}</h4>
			<p>{i18n.confirmCancel.info}</p>
			<button type="button" className={style.btnCancel} onClick={props.onCancel}>{i18n.confirmCancel.cancel}</button>
			<button type="button" className={style.btnConfirm} onClick={props.onConfirm}>{i18n.confirmCancel.confirm}</button>
		</div>
	);
};

ConfirmCancel.propTypes = {
	onConfirm: PropTypes.func,
	onCancel: PropTypes.func,
};

export default ConfirmCancel;
