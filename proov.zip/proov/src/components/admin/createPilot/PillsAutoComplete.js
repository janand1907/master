import React from 'react';
import PropTypes from 'prop-types';
import PillList from 'components/ui/Pill/PillList';
import AutoComplete from 'components/ui/AutoComplete/AutoComplete';

const PillsAutoComplete = ({ autoCompleteProps, pillListProps, onAutoCompleteChange, allowDuplicates, ignoreCase, maxItemsCount }) => {
	const { inputProps: input, ...rest } = autoCompleteProps;
	const isDisabled = maxItemsCount && Array.isArray(input.value) && input.value.length >= maxItemsCount;
	return (
		<div>
			<AutoComplete
				resetOnSelect
				allowCustom
				minValueLength={2}
				{...rest}
				onChange={onAutoCompleteChange}
				onSelect={(value) => {
					if (allowDuplicates || (ignoreCase ? input.value.map(s => s.toLowerCase()).indexOf(value.toLowerCase()) : input.value.indexOf(value)) < 0) {
						input.onChange([...input.value, value]);
					}
				}}
				style={{ width: '100%', marginBottom: '10px' }}
				inputProps={{ className: 'form-control', ...input, disabled: isDisabled, placeholder: isDisabled ? `Only ${maxItemsCount} items are allowed` : input.placeholder }} />
			<PillList
				allowRemove
				{...pillListProps}
				items={input.value}
				onPillRemove={(item) => {
					const index = input.value.indexOf(item);
					input.onChange([ ...input.value.slice(0, index), ...input.value.slice(index + 1)]); }} />
		</div>
	);
};

PillsAutoComplete.propTypes = {
	allowDuplicates: PropTypes.bool.isRequired,
	maxItemsCount: PropTypes.number,		// max items count
	ignoreCase: PropTypes.bool,				// whether case should be ignored when checking for duplicates
	onAutoCompleteChange: PropTypes.func.isRequired,
	pillListProps: PropTypes.object,
	autoCompleteProps: PropTypes.shape({
		inputProps: PropTypes.object.isRequired
	}).isRequired
};

PillsAutoComplete.defaultProps = {
	allowDuplicates: false,
	ignoreCase: false
};

export default PillsAutoComplete;
