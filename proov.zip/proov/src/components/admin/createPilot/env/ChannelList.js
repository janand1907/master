/* eslint react/no-array-index-key: "off" */
import React from 'react';
import PropTypes from 'prop-types';
import { includes } from 'lodash';
import ChannelCard from './ChannelCard';
import style from './style.scss';

const ChannelList = ({
	isReview,
	channels,
	errors,
	newEnvironmentClick,
	editEnvironmentClick,
	deleteEnvironmentClick,
	isReviewRequests,
	isReadOnly,
	text,
	checkIsValidate
}) => {
	return (
		<div className={style.environmentList}>
			{channels &&
				channels.map((item, index) => {
					let err = false;
					if (
						errors &&
						Object.keys(errors).length &&
						includes(Object.keys(errors), index.toString())
					) {
						err = true;
					}
					return (
						<div key={index}>
							<ChannelCard
								data={item}
								index={index}
								editCard={editEnvironmentClick}
								deleteCard={deleteEnvironmentClick}
								className={err ? style.errorCard : null}
								isReviewRequests={isReviewRequests}
								isReadOnly={isReadOnly}
								isInValid={checkIsValidate && checkIsValidate(item)}
							/>
						</div>
					);
				})}
			{!isReviewRequests && !isReview && <button type="button" className={style.buttonNew} onClick={newEnvironmentClick} disabled={isReadOnly}>
				{text ? text : 'Set up environment'}
			</button>}
		</div>
	);
};

export default ChannelList;

ChannelList.propTypes = {
	channels: PropTypes.array,
	newEnvironmentClick: PropTypes.func.isRequired,
	editEnvironmentClick: PropTypes.func.isRequired,
	deleteEnvironmentClick: PropTypes.func.isRequired,
	errors: PropTypes.object,
	isReviewRequests: PropTypes.bool
};
