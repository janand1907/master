import React from 'react';
import PropTypes from 'prop-types';
import { CLOUD_TYPE_TO_ICON, SUPPORTED_CLOUD_CHANNEL_TYPE } from 'constants/channel/cloudType';
import { changeUserOwnedToProov } from 'utils/transformEnvironment';
import cx from 'utils/classNames';
import EditIcon from 'components/ui/Icons/EditIcon';
import TrashIcon from 'components/ui/Icons/TrashIcon';
import IconWrapper from 'components/admin/common/channels/icons/IconWrapper';
import { TooltipTarget, Tooltip } from 'components/ui/Tooltip';
import { InfoIcon } from 'components/ui/Icons';
import style from './style.scss';

class EnvironmentCard extends React.PureComponent {
	constructor() {
		super();
		this.editChannel = this.editChannel.bind(this);
		this.deleteChannel = this.deleteChannel.bind(this);
	}

	editChannel(environment, index) {
		this.props.editCard(environment, index);
	}

	deleteChannel() {
		this.props.deleteCard(this.props.index);
	}

	render() {
		const { data, index, isReviewRequests, isReadOnly, isInValid, getNameToDisplay } = this.props;
		const supportChannel = SUPPORTED_CLOUD_CHANNEL_TYPE.includes(data.type)
		const Icon = supportChannel ? data.cloud_type ? CLOUD_TYPE_TO_ICON[data.cloud_type].icon : null : CLOUD_TYPE_TO_ICON.DEFAULT.icon;

		let dataTransformed = changeUserOwnedToProov(data);

		return (<div className={cx(style.outline, this.props.className)} >
			<div className={style.header}>
				<div className={style.headerBadge}>
					<IconWrapper {...dataTransformed} />
				</div>
				<div className={style.headerInfo}>
					<h3>{dataTransformed.name}</h3>
					{Icon && <Icon className={cx(style.cloudTypeIcon, style[supportChannel ? data.cloud_type : 'DEFAULT'])} />}

				</div>
				{!isReadOnly && <div className={style.headerIcons}>
					{isReviewRequests && isInValid && <TooltipTarget
						className={style.target}
						tooltip={<Tooltip placement="left">Add required info</Tooltip>}
					>
						<InfoIcon className={style.iconInfo} />
					</TooltipTarget>}
					<EditIcon className={cx(style.editIcon, isReviewRequests && !isInValid && style.isReviewRequestValid )} onClick={() => this.editChannel(dataTransformed, index)} />
					<TrashIcon className={style.trashIcon} onClick={() => this.deleteChannel(index)} />
				</div>}
			</div>
		</div>);
	}
}

export default EnvironmentCard;

EnvironmentCard.propTypes = {
	data: PropTypes.object,
	index: PropTypes.number,
	editCard: PropTypes.func,
	deleteCard: PropTypes.func,
	className: PropTypes.string
};
