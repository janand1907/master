import { LAB, AWS_SC } from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { some, min } from 'lodash';
import { getCreatePilot } from 'ducks/admin/createPilot/selectors';
import { transformErrorData } from 'utils';
import * as actions from 'ducks/admin/createPilot/actions';
import { setErrors } from 'ducks/forms/actions';
import { showModal, hideModal } from 'ducks/modal/actions';
import { createToast } from 'ducks/toaster/actions';
import { getSubscription } from 'ducks/myAccount/selectors';
import CreatePilotWizard from './CreatePilotWizard';
import { getMeUser } from 'ducks/me/selectors';

// TODO: The container should probably not be aware of the fields and the step they're at (@or)
// Find a way in which the container could interact with the wizard to jump to a specific field.
const allFields = [
	[
		'is_public',
		'name',
		'category',
		'dates',
		'approval_policy',
		'description',
		'tags',
		'attachments_public'
	],
	['goals', 'eval_criteria', 'budget', 'target_vendors', 'scenarios'],
	['instructions', 'attachments_private'],
	['access_rights', 'pilot_type', 'environment']
];
const ENV_STEP_INDEX = 2;
const TOTAL_STEP_COUNT = 6;

class CreatePilotWizardContainer extends React.PureComponent {
	constructor(props) {
		super(props);
		this.state = {
			user: []
		}
		this.handleFormSubmit = this.handleFormSubmit.bind(this);
		this.handleStepNext = this.handleStepNext.bind(this);
		this.handleStepPrevious = this.handleStepPrevious.bind(this);
		this.handleStepActive = this.handleStepActive.bind(this);
		this.handleCancel = this.handleCancel.bind(this);
		this.handleFinish = this.handleFinish.bind(this);
		this.handleGoToStep = this.handleGoToStep.bind(this);
		this.reject = this.reject.bind(this);
		this.handleUserList = this.handleUserList.bind(this);
	}

	UNSAFE_componentWillMount() {
		this.props.actions.goToStep(0);
	}

	componentWillUnmount() {
		this.props.actions.reset(); // reset ui state
		this._form.reset(); // reset form state
	}

	/**
	 * API: Retrieves the form model.
	 * @returns {object} The form model.
	 */
	getFormValues() {
		return this._form.getValues();
	}

	reject(err) {
		// TODO: Better writing?
		const fieldErrors = transformErrorData(err.errorData);
		const minStepErr = min(
			Object.keys(fieldErrors).map(f => this._getFieldStep(f))
		);
		const invalidStep = minStepErr >= 0 ? minStepErr : 4; // min index
		let invalidComp = this._getInvalidComponentIndexes(fieldErrors);
		if (invalidComp && typeof invalidComp === 'object') {
			let errorChannel = {};
			invalidComp = invalidComp.map(e => {
				errorChannel[e] = this._getInvalidComponentError(fieldErrors, e);
			});
			this.props.actions.setChannelErrorsComponents(errorChannel);
		}
		this.props.actions.goToStep(invalidStep);
		this._scrollToTop();
	}

	handleFormSubmit(values) {
		if (this.props.step === TOTAL_STEP_COUNT - 1) {
			// save in server
			let Data = { accounts: this.state.user }
			let data = this.props.data;
			let pilot = this.props.data;
			//pilot.accounts = this.state.user;
			let newData = { ...pilot, ...Data }
			this.props.actions.create(
				//this.props.data,
				newData,
				id => this.props.onCompleted(id, values.redirect_to_envs),
				this.reject
			);
		} else {
			// move to next step (aggregate data)
			if (this.props.step === 3) {
				this.props.actions.next({ "accounts": this.state.user }, this.props.step);
			} else {
				this.props.actions.next(values, this.props.step);
			}

			this._scrollToTop();
		}
	}

	handleStepNext({ current, next }) {
		debugger
		if (current === ENV_STEP_INDEX) {
			// if the last environment component is not yet saved,
			// we should remove it before submitting the form (so validation will not fail).
			if (this.props.isCurrComponentNew) {
				// this._form.arrayPop('environment');		// TODO: Container should not be aware of the field name! (@or)
			}
		}

		const valid = this._form.submit();
		document.activeElement.blur();
		if (!valid) {
			this._scrollToTop();
		}
		return !valid; // return `true` to cancel
	}

	handleStepPrevious({ current, next }) {
		if (current === ENV_STEP_INDEX) {
			// same as handleEnvironmentNext(), only for prev
			if (this.props.isCurrComponentNew) {
				// this._form.arrayPop('environment');		// TODO: Container should not be aware of the field name! (@or)
			}
		}

		this.props.actions.back(this.props.step);
		document.activeElement.blur();
		this._scrollToTop();
	}

	handleStepActive({ index }) {
		// when "environment" step becomes active, add a new component draft and set to edit mode
		if (index === ENV_STEP_INDEX) {
			if (this.props.isCurrComponentNew && this._form) {
				// this._form.arrayPush('environment', { type: 'server', is_user_owned: false });	// eslint-disable-line camelcase
			}
		}
	}

	handleCancel() {
		// `CreatePilotPage` will handle confirmation
		this.props.actions.cancel(this.props.step);
		this.props.history.push('/admin');
	}

	handleFinish() {
		// Simply submit the form. `handleFormSubmit` will handle the rest.
		this._form.submit();
	}

	handleGoToStep(index) {
		this.props.actions.goToStep(index);
		this._scrollToTop();
	}

	_scrollToTop() {
		// TODO: BAD!!! should actually scrollToView the first invalid input
		window.scrollTo(0, 0);
	}

	// gets the index of the step with the given field
	// TODO: Container should not be aware of that (@or)
	_getFieldStep(field) {
		if (typeof field !== 'string') return -1;
		for (let i = 0; i < allFields.length; i++) {
			if (
				some(
					allFields[i],
					v => v.indexOf(field) === 0 || field.indexOf(v) === 0
				)
			) {
				return i;
			}
		}
		return -1;
	}

	// TODO: Container should not be aware of that. What happens if field name changes? (@or)
	_getFirstInvalidComponentIndex(errors) {
		const regex = new RegExp(`environment\\[(\\d+)?\\]`);
		const index = min(
			Object.keys(errors).map(f => parseInt((regex.exec(f) || [])[1]))
		); // min index
		return index;
	}

	// TODO Rewrite @slava
	_getInvalidComponentIndexes(errors) {
		const regex = new RegExp(`environment\\[(\\d+)?\\]`);
		const indexes = Object.keys(errors).map(f =>
			parseInt((regex.exec(f) || [-1, -1])[1])
		);
		return indexes[0] === -1 ? undefined : indexes;
	}

	_getInvalidComponentError(errors, index) {
		if (!errors) return {};
		const prefix = 'environment[' + index + '].';
		return Object.keys(errors).reduce((acc, key) => {
			if (key.indexOf(prefix) === 0) {
				acc[key.substr(prefix.length)] = errors[key];
			}
			return acc;
		}, {});
	}
	handleUserList(data) {
		debugger
		let index = this.state.user.findIndex(e => e.id === data);
		if (index === -1) {
			let newUser = { "id": data, "is_access": true };
			this.setState({ user: [...this.state.user, newUser] });
		} else {
			let p = [...this.state.user];
			p.splice(index, 1);
			this.setState({ user: p });
		}

	}
	render() {
		const initialValues = {
			is_public: true,
			pilot_type:
				this.props.subscription && this.props.subscription.service_catalog.limit
					? AWS_SC
					: LAB,
			redirect_to_envs: true,
			portfolio_id: null,
			eval_criteria: [],
			environment: []
		};

		if (this.props.me) {
			let id = this.props.me.id;
			let index = this.state.user.findIndex(r => r.id === id);
			if (index === -1) {
				this.setState({ user: [...this.state.user, { "id": id, "is_access": true }] })
			}
		}
		return (
			this.props.subscription && (
				<CreatePilotWizard
					formRef={node => {
						if (node) {
							this._form = node.getWrappedInstance();
						}
					}}
					onFormSubmit={this.handleFormSubmit}
					onStepNext={this.handleStepNext}
					onStepPrevious={this.handleStepPrevious}
					onStepActive={this.handleStepActive}
					onCancel={this.handleCancel}
					onFinish={this.handleFinish}
					onGoToStep={this.handleGoToStep}
					step={this.props.step}
					initialValues={initialValues}
					removeError={this.handleRemoveError}
					data={this.props.data}
					pending={this.props.pending}
					selectedUserList={this.handleUserList}
					user={this.state.user}
					selectedUserValues={this.state.user}
				/>
			)
		);
	}
}

CreatePilotWizardContainer.propTypes = {
	/**
	 * @ignore react-router
	 */
	history: PropTypes.shape({
		push: PropTypes.func.isRequired
	}).isRequired,

	/**
	 * Callback for when pilot creation is completed successfully
	 */
	onCompleted: PropTypes.func.isRequired,
	subscription: PropTypes.object,
	// redux
	actions: PropTypes.object.isRequired,
	step: PropTypes.number,
	data: PropTypes.object,
	pending: PropTypes.bool,
	isCurrComponentNew: PropTypes.bool
};

function mapStateToProps(state) {
	const {
		step,
		data,
		pending,
		componentIndex,
		componentCount
	} = getCreatePilot(state);
	return {
		step,
		data,
		pending,
		subscription: getSubscription(state).config,
		isCurrComponentNew: componentIndex >= componentCount,
		me: getMeUser(state),
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators(
			{ ...actions, showModal, hideModal, setErrors, createToast },
			dispatch
		),
		dispatch
	};
}

export default withRouter(
	connect(mapStateToProps, mapDispatchToProps, null, { withRef: true })(
		CreatePilotWizardContainer
	)
);
