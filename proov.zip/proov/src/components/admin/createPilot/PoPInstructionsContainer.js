import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
	getAdminPilotSafeModeVpnConfig,
	getAdminPilotPending
} from 'ducks/admin/pilot/selectors';
import { getProovAccess } from 'ducks/admin/pilot/actions';
import { NewSpinner } from 'components/ui/NewSpinner';
import PoPInstructionsForm from 'components/admin/pilotView/client/details/PoPInstructionsForm';
import * as i18n from 'i18n/en/pilotView.json';
import Permission from 'components/Permission';
import style from './PoPInstructionsContainer.scss';

const bundles = {
	windows: `https://s3-us-west-2.amazonaws.com/safezone-bundles/${
		__PROD__ ? 'production' : 'stage'
	}/proov-windows-bundle.zip`,
	linux: `https://s3-us-west-2.amazonaws.com/safezone-bundles/${
		__PROD__ ? 'production' : 'stage'
	}/proov-linux-bundle.tar.gz`,
	api: `https://s3-us-west-2.amazonaws.com/safezone-bundles/${
		__PROD__ ? 'production' : 'stage'
	}/proov-api-bundle.tar.gz`,
	proxy: `https://s3-us-west-2.amazonaws.com/safezone-bundles/${
		__PROD__ ? 'production' : 'stage'
	}/proov-proxy-bundle.tar.gz`
};

class PoPInstructionsContainer extends React.Component {
	componentDidMount() {
		this.props.actions.getProovAccess();
	}

	render() {
		const { isWizard, safeModeVpnConfig, history, pending } = this.props;

		return (
			<React.Fragment>
				<div className={style.container}>
					<h2 className={style.howItWorks}>how it works</h2>
					<div className={style.step}>
						<span>one</span>
						<h3>configuration</h3>
						<div className={style.instructions}>
							<p>{globalize.parseString(i18n.client.safeZone.instructions)}</p>
							<div className={style.terms}>
								{pending ? (
									<NewSpinner />
								) : (
									safeModeVpnConfig && (
										<div className={style.access}>
											{safeModeVpnConfig.map((item, index) => {
												return (
													<div className={style.credentialsRow} key={index}>
														<React.Fragment>
															<div className={style.accessField} title={item.cidr}>
																{item.cidr ? item.cidr : ''}
															</div>
														</React.Fragment>
													</div>
												);
											})}
										</div>
									)
								)}
							</div>
						</div>
					</div>

					<div className={style.step}>
						<span>two</span>
						<h3>installation</h3>
						<div className={style.instructions}>
							<a href={bundles.linux} download>
								{globalize.parseString(i18n.client.safeZone.bundle, { type: 'Linux' })}
							</a>
							<br />
							<a href={bundles.windows} download>
								{globalize.parseString(i18n.client.safeZone.bundle, { type: 'Windows' })}
							</a>
							<br />
							<a href={bundles.api} download>
								{globalize.parseString(i18n.client.safeZone.bundle, { type: 'API' })}
							</a>
							<br />
							<a href={bundles.proxy} download>
								{globalize.parseString(i18n.client.safeZone.safeZoneBundle)}
							</a>
						</div>
					</div>

					<div className={style.step}>
						<span>three</span>
						<h3>setup channels</h3>
						<div className={style.instructions}>
							<p className={style.guide}>
								{globalize.parseString(i18n.client.safeZone.guide.steps)}
							</p>
							<br />
							<p>
								<ul className={style.guidelines}>
									<li>{globalize.parseString(i18n.client.safeZone.guide.server)}</li>
									<li>{globalize.parseString(i18n.client.safeZone.guide.api)}</li>
									<li>{globalize.parseString(i18n.client.safeZone.guide.db)}</li>
								</ul>
							</p>
						</div>
					</div>

					{isWizard ? (
						<div className={style.step}>
							<span>four</span>
							<h3>review</h3>
							<div className={style.instructions}>
								{globalize.parseString(i18n.client.safeZone.review)}
							</div>
						</div>
					) : (
						<div className={style.step}>
							<h3>safezone advanced mode</h3>
							<p>
								Optional
								<br />
								{globalize.parseString(i18n.client.safeZone.proxy)}
							</p>
							<div className={style.instructions}>
								<Permission
									alias="PoPInstructionsForm"
									component={<PoPInstructionsForm history={history} />}
								/>
							</div>
						</div>
					)}
				</div>
			</React.Fragment>
		);
	}
}

function mapStateToProps(state) {
	const safeModeVpnConfig = getAdminPilotSafeModeVpnConfig(state);
	const pending = getAdminPilotPending(state).instructions;

	return {
		safeModeVpnConfig,
		pending
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: bindActionCreators({ getProovAccess }, dispatch)
	};
}

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(PoPInstructionsContainer);

PoPInstructionsContainer.propTypes = {
	actions: PropTypes.object,
	history: PropTypes.object,
	isWizard: PropTypes.bool,
	safeModeVpnConfig: PropTypes.array,
	pending: PropTypes.bool
};

PoPInstructionsContainer.defaultProps = {
	isWizard: false
};
