import React from 'react';
import PropTypes from 'prop-types';
import cn from 'utils/classNames';
import { FormGroup, Field, Error } from 'components/common/Forms';
import * as i18n from 'i18n/en/createPilot.json';
import EvaluationCriteriaField from './EvaluationCriteriaField';
import style from './style.scss';

const EvaluationCriteriaStep = props => {
	return (
		<div>
			<FormGroup label={<span>{i18n.requirementsStep.eval_criteriaHeader}<span className="mandatory">*</span> <div className="info">{i18n.requirementsStep.eval_criteriaBody}</div></span>}>
				<Field
					name="eval_criteria"
					defaultValue={[]}
					validateOn={['blur', 'change']}
					component={({ input }) => (
						<EvaluationCriteriaField 
							maxItemsCount={25}
							autoCompleteProps={{ inputProps: { ...input, className: 'form-control', maxLength: 500 } }}
						/>)}
				/>
				<Error sticky name="eval_criteria" />
			</FormGroup>
		</div>
	);
};

EvaluationCriteriaStep.propTypes = {
	onCriterionsAutoCompleteChange: PropTypes.func.isRequired
};

export default EvaluationCriteriaStep;
