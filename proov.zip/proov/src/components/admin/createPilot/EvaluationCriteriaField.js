import React from 'react';
import PropTypes from 'prop-types';
import { DeleteIcon } from 'components/ui/Icons';
import AutoComplete from 'components/ui/AutoComplete/AutoComplete';
import style from './style.scss';

const EvaluationCriteriaField = ({ autoCompleteProps, maxItemsCount }) => {
    const { inputProps: input, ...rest } = autoCompleteProps;
    const isDisabled = maxItemsCount && Array.isArray(input.value) && input.value.length >= maxItemsCount;
    return (
        <div>
            <div className={style.addCriteriaWrapper}>
                <AutoComplete
                    resetOnSelect
                    allowCustom
                    addPlusButton
                    minValueLength={10}
                    {...rest}
                    isTextarea={true}
                    onSelect={(value) => input.onChange([...input.value, value])}
                    style={{ width: '100%', display: 'flex', 'margin-bottom': '10px' }}
                    inputProps={{ className: 'form-control', ...input, disabled: isDisabled, placeholder: isDisabled ? `Only ${maxItemsCount} items are allowed` : input.placeholder }}
                />

            </div>
            {input.value.map(item => 
                <div className={style.criteriaWrapper}>
                    <p className={style.criteriaContent}  dangerouslySetInnerHTML={{ __html: item.replaceAll('\n', '<br />') }}></p> 
                    <DeleteIcon className={style.deleteCriteria} onClick={() => input.onChange(input.value.filter(i=> i !== item))}/>
                </div>
            )}
        </div>
    );
};

EvaluationCriteriaField.propTypes = {
    maxItemsCount: PropTypes.number,		// max items count
    autoCompleteProps: PropTypes.shape({
        inputProps: PropTypes.object.isRequired
    }).isRequired
};

export default EvaluationCriteriaField;
