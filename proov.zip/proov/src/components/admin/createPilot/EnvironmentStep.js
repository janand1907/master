import { SAFEZONE, LAB, RED_CLOUD } from 'constants/pilotTypes';
import React from 'react';
import PropTypes from 'prop-types';
import ChannelList from 'components/admin/createPilot/env/ChannelList';
import { FormGroup, Field, Error } from 'components/common/Forms';
import { RadioGroup, PushButton } from 'components/ui/RadioGroup';
import infoImage from 'assets/images/create_pilot.png';
import * as i18n from 'i18n/en/createPilot.json';
import cx from 'utils/classNames';
import PoPInstructionsContainer from './PoPInstructionsContainer';
import style from './style.scss';

class EnvironmentStep extends React.PureComponent {
	constructor(props) {
		super(props);
		this.state = { pilotType: props.pilotType || LAB };
		this.handleEnvironmentType = this.handleEnvironmentType.bind(this);
	}

	handleEnvironmentType(e, onChange) {
		const value = e.currentTarget.value;
		this.setState({ pilotType: value }, () => {
			onChange(value);
		});
	}

	render() {
		const {
			channels,
			errors,
			onComponentNew,
			onComponentEdit,
			onComponentRemove,
			access,
			awsAccountId
		} = this.props;

		return (
			<div>
				{/* Pilot Type */}
				{/* The 'lab' value is initialised with the from intial value, in the future all radio button options should be active */}
				{!access.service_catalog.limit ? (
					<React.Fragment>
						<h2 className={style.header}>CHOOSE POC ENVIRONMENT TYPE:</h2>
						<Field
							name="pilot_type"
							destroyFields={value => (value !== LAB ? ['environment'] : [])}
							component={({ input: { name, value, onChange } }) => (
								<RadioGroup
									name={name}
									selectedValue={value}
									onChange={value =>
										this.handleEnvironmentType(value, onChange)
									}
									className={style.container}
								>
									<PushButton value={LAB} className={style.pilotType}>
										<span className={style.proov}>proo</span> Cloud Lab
									</PushButton>
									<PushButton
										value={SAFEZONE}
										className={cx(style.pilotType, {
											[style.disabled]: !access.safe_zone.limit
										})}
										disabled={!access.safe_zone.limit}
									>
										<span className={style.proov}>proo</span> SafeZone
									</PushButton>
									<PushButton
										value={RED_CLOUD}
										className={cx(style.pilotType, {
											[style.disabled]: !access.red_cloud.limit
										})}
										disabled={!access.red_cloud.limit}
									>
										<span className={style.proov}>proo</span> Red Cloud
									</PushButton>
								</RadioGroup>
							)}
						/>
					</React.Fragment>
				) : (
					<React.Fragment>
						<Field name="pilot_type" component="input" type="hidden" />
						<h2 className={style.header}>
							SHARE YOUR SERVICE CATALOG PORTFOLIO:
						</h2>
						<ol>
							<li>
								Open the
								<a
									target="_blank"
									rel="noopener noreferrer"
									href="https://console.aws.amazon.com/servicecatalog/"
								>
									{' '}
									AWS Service Catalog console
								</a>
								, and go to <b>Portfolios</b> page.
							</li>
							<li>
								Select the portfolio that you want to share, and choose{' '}
								<b>Share Portfolio</b>.
							</li>
							<li>
								In the <b>Enter AWS account ID window</b>, type the following
								account ID: <b>{awsAccountId}</b>, and choose <b>Share</b>.
							</li>
						</ol>
						<p>
							If sharing succeeds, a message on the <b>Portfolios</b> page
							confirms that the portfolio is linked with the target account.
						</p>
						<FormGroup>
							<Field
								type="text"
								name="portfolio_id"
								validateOn={['blur', 'change']}
								className="form-control"
								component="input"
								maxLength="18"
								placeholder="port-xxxxxxxxxxxxx"
								tabIndex="11"
							/>
							<Error sticky name="portfolio_id" />
						</FormGroup>
					</React.Fragment>
				)}

				{this.state.pilotType !== SAFEZONE ? (
					<React.Fragment>
						<h2 className={style.header}>SET-UP POC ENVIRONMENTS:</h2>
						<div>
							<img src={infoImage} className={style.envStepDescriptionImg} />
							<p className={style.envStepDescription}>
								{i18n.environmentStep.envStepDescription}
							</p>

							<ChannelList
								channels={channels}
								errors={errors}
								newEnvironmentClick={onComponentNew}
								editEnvironmentClick={onComponentEdit}
								deleteEnvironmentClick={onComponentRemove}
							/>
						</div>
					</React.Fragment>
				) : (
					<PoPInstructionsContainer isWizard={true} />
				)}
			</div>
		);
	}
}

EnvironmentStep.propTypes = {
	form: PropTypes.string.isRequired,
	channels: PropTypes.array,
	awsAccountId: PropTypes.string,
	access: PropTypes.object,
	next: PropTypes.func.isRequired,
	onComponentSave: PropTypes.func.isRequired,
	onComponentEdit: PropTypes.func.isRequired,
	onComponentRemove: PropTypes.func.isRequired,
	onComponentNew: PropTypes.func.isRequired,
	errors: PropTypes.object,
	pilotType: PropTypes.string
};

export default EnvironmentStep;
