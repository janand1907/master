import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { debounce } from 'lodash';
import { getTagSuggestions } from 'ducks/shared/actions';
import { uploadAttachment } from 'ducks/admin/createPilot/actions';
import { getUploadInProcess } from 'ducks/admin/createPilot/selectors';
import OverviewStep from './OverviewStep';

const OverviewStepContainer = props => {
	return (
		<OverviewStep
			onTagsAutoCompleteChange={props.actions.handleTagsAutoComplete}
			onAttachmentSelect={props.actions.handleAttachmentSelect}
			isUploadInProcess={props.isUploadInProcess}
		/>
	);
};

OverviewStepContainer.propTypes = {
	actions: PropTypes.object.isRequired,
	isUploadInProcess: PropTypes.bool
};

function handleAsync(dispatch, actionCreator, value, done) {
	return dispatch(actionCreator(value, done));
}

function mapStateToProps(state) {
	return {
		isUploadInProcess: getUploadInProcess(state)
	};
}

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			handleTagsAutoComplete: debounce((value, done) => handleAsync(dispatch, getTagSuggestions, value, done), 400),
			handleAttachmentSelect: (...args) => dispatch(uploadAttachment(...args))
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(OverviewStepContainer);
