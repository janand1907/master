import React from 'react';
import PropTypes from 'prop-types';
import { Form, Error } from 'components/common/Forms';
import { Steps, Step } from 'components/ui/MultiStep';
import { Alert } from 'components/ui/Alert';
import { ErrorIcon } from 'components/ui/Icons';
import validate from './validation';
import OverviewStepContainer from './OverviewStepContainer';
import RequirementsStepContainer from './RequirementsStepContainer';
import EnvironmentStepContainer from './EnvironmentStepContainer';
import EvaluationCriteriaStepContainer from './EvaluationCriteriaStepContainer';
import ReviewAndConfirmStepContainer from './ReviewAndConfirmStepContainer';
import style from './style.scss';
import PoCTeamStepConatiner from './PoCTeamStepConatiner';

const CreatePilotWizard = props => {

	const formProps = {
		form: 'createPilot',
		ref: props.formRef,
		noValidate: true,
		destroyOnUnmount: true,
		onSubmit: props.onFormSubmit,
		initialValues: props.initialValues,
		className: style.form,
		preserve: true,
		validators: validate
	};

	const stepProps = {
		onNext: props.onStepNext,
		onPrevious: props.onStepPrevious,
		onActive: props.onStepActive
	};

	const globalError = (
		<Error
			name=""
			component={({ error }) => (
				<Alert type="error">
					<ErrorIcon className={style.errorIcon} />
					<span>{error}</span>
				</Alert>)}
		/>);

	return (
		<div className={style.root}>
			<h2 className={style.mainHeading}>Create a new PoC</h2>
			<Form {...formProps} className={style.wrapper}>
				<Steps
					showCancel
					prevLabel="Back"
					finishLabel="Publish"
					className={style.steps}
					footerClassName={style.stepsFooter}
					step={props.step}
					pending={props.pending}
					onCancel={props.onCancel}>
					<Step label="Overview" {...stepProps}>
						{globalError}
						<OverviewStepContainer />
					</Step>
					<Step label="Requirements" {...stepProps}>
						{globalError}
						<RequirementsStepContainer />
					</Step>
					<Step label="Evaluation Criteria" {...stepProps}>
						{globalError}
						<EvaluationCriteriaStepContainer />
					</Step>
					<Step label="PoC Team" className={style.spinnerCenter} {...stepProps}>
						{globalError}
						<PoCTeamStepConatiner handleuser={props.selectedUserList} selectedUserValues={props.selectedUserValues} />
					</Step>
					<Step label="Environment" {...stepProps}>
						{globalError}
						<EnvironmentStepContainer next={props.onGoToStep} />
					</Step>
					<Step label="Review & Confirm" {...stepProps} onNext={props.onFinish}>
						{globalError}
						<ReviewAndConfirmStepContainer data={props.data} selectedUserValues={props.selectedUserValues} onGoToStep={props.onGoToStep} handleuser={props.selectedUserList} />
					</Step>
				</Steps>
			</Form>
		</div>
	);

};

CreatePilotWizard.propTypes = {
	formRef: PropTypes.func,										// a `ref` props for the <Form> component
	onFormSubmit: PropTypes.func,								// user submits the form
	onStepNext: PropTypes.func,									// user moves to the next step
	onStepPrevious: PropTypes.func,							// user goes back to the previous step
	onStepActive: PropTypes.func,								// a wizard step becomes active
	onCancel: PropTypes.func,										// user cancels the wizard
	onFinish: PropTypes.func,										// user finishes the wizard
	onGoToStep: PropTypes.func,									// user clicks to go directly to a step (in the confirmation screen)
	step: PropTypes.number,					// index of the current step
	data: PropTypes.object,											// data of the entire form
	initialValues: PropTypes.object,						// initial values of the form
	pending: PropTypes.bool											// whether currently pending
};

CreatePilotWizard.defaultProps = {
	step: 0
};

export default CreatePilotWizard;
