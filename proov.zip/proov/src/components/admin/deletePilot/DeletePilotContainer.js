import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';
import { Steps, Step } from 'components/ui/MultiStep';
import {
	verifyCode,
	verificationCode,
	confirm,
	cancel,
	goToStep
} from 'ducks/flows/deletePilot/actions';
import {
	getDeletePilotFlow,
	getDeletePilotFlowPending
} from 'ducks/flows/deletePilot/selectors';
import { hideModal } from 'ducks/modal/actions';
import DeletePilotTerms from './DeletePilotTerms';
import DeletePilotVerification from './DeletePilotVerification'; // code component
import DeletePilotReview from './DeletePilotReview';
import style from './styles.scss';

const STEPS = {
	TERMS: 0,
	VERIFICATION: 1,
	REVIEW: 2
};

class DeletePilotContainer extends React.Component {
	constructor(props) {
		super(props);
		this.handleVerify = this.handleVerify.bind(this);
		this.handleVerificationCode = this.handleVerificationCode.bind(this);
		this.handleTerms = this.handleTerms.bind(this);
		this.handleNext = this.handleNext.bind(this);
		this.handlePrevious = this.handlePrevious.bind(this);
		this.handleCancel = this.handleCancel.bind(this);

		this.state = {
			isAgree: false
		};
	}

	handleTerms(e) {
		this.setState({ isAgree: e.currentTarget.checked });
	}

	handleVerify(code) {
		this.props.actions.verifyCode(this.props.pilot.id, code);
	}

	handleVerificationCode() {
		this.props.actions.verificationCode(this.props.pilot.id);
	}

	handleNext() {
		switch (this.props.currentStep) {
			case STEPS.TERMS:
				if (this.state.isAgree) {
					this.props.actions.goToStep(this.props.currentStep + 1);
					this.handleVerificationCode();
				}
				return;
			case STEPS.REVIEW:
				this.handleConfirm();
				return;
		}
	}

	handlePrevious() {
		this.props.actions.goToStep(this.props.currentStep - 1);
	}

	handleConfirm() {
		const { pilot, code } = this.props;
		this.props.actions.confirm(pilot.id, pilot.name, code);
		this.props.actions.hideModal();
		this.props.history.push('/admin');
	}

	handleCancel() {
		this.props.actions.cancel();
		this.props.actions.hideModal();
	}

	render() {
		const { pilot, pendingVerify, pendingConfirm, status, currentStep,message } = this.props;

		return (
			<div className={style.joinPilot}>
				<h3>Delete PoC</h3>
				<Steps
					className={style.stepsComponent}
					contentClassName={style.stepsContent}
					footerClassName={style.stepsFooter}
					finishLabel="Confirm"
					finishClassName={style.finishBtn}
					onCancel={this.handleCancel}
					step={currentStep}
					allowNext={this.state.isAgree}
					hideNextInStep={1}
					pending={pendingConfirm}
					showCancel
					showNext={currentStep !== 1}
				>
					<Step label="Terms" onNext={this.handleNext} onPrevious={this.handlePrevious}>
						<DeletePilotTerms
							handleTerms={this.handleTerms}
							isAgree={this.state.isAgree}
						/>
					</Step>
					<Step
						label="Verification"
						onNext={this.handleNext}
						onPrevious={this.handlePrevious}
					>
						<DeletePilotVerification
							status={status}
							message={message}
							handleVerificationCode={this.handleVerificationCode}
							handleVerify={this.handleVerify}
							pendingVerify={pendingVerify}
						/>
					</Step>
					<Step label="Review" onNext={this.handleNext} onPrevious={this.handlePrevious}>
						<DeletePilotReview pilotName={pilot.name} />
					</Step>
				</Steps>
			</div>
		);
	}
}

DeletePilotContainer.propTypes = {
	pilot: PropTypes.object.isRequired,
	history: PropTypes.shape({
		push: PropTypes.func.isRequired
	}).isRequired,
	actions: PropTypes.object,
	currentStep: PropTypes.number,
	status: PropTypes.string,
	pendingConfirm: PropTypes.bool,
	pendingVerify: PropTypes.bool,
	code: PropTypes.string,
	isVerified: PropTypes.bool,
	dispatch: PropTypes.func
};

function mapStateToProps(state) {
	const { status, code, isVerified, currentStep,message } = getDeletePilotFlow(state);
	const { verify, confirm } = getDeletePilotFlowPending(state);

	return {
		status,
		code,
		isVerified,
		pendingConfirm: confirm,
		pendingVerify: verify,
		currentStep,
		message
	};
}

function mapDispatchToProps(dispatch) {
	return {
		dispatch: dispatch,
		actions: bindActionCreators(
			{ verifyCode, verificationCode, confirm, cancel, goToStep, hideModal },
			dispatch
		)
	};
}

export default withRouter(
	connect(
		mapStateToProps,
		mapDispatchToProps
	)(DeletePilotContainer)
);
