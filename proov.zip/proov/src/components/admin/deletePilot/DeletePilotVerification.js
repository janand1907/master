import React from 'react';
import PropTypes from 'prop-types';
import * as i18n from 'i18n/en/deletePilot.json';
import NewSpinner from 'components/ui/NewSpinner/NewSpinner';
import ErrorIcon from 'components/ui/Icons/ErrorIcon';
import style from './styles.scss';

const CODE = new Array(6).fill(0);

class DeletePilotVerification extends React.Component {
	constructor(props) {
		super(props);
		this.handleClick = this.handleClick.bind(this);
		this.handleBlur = this.handleBlur.bind(this);
		this.handleFocus = this.handleBlur.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.handleKeyPress = this.handleKeyPress.bind(this);
		this.onClear = this.onClear.bind(this);

		this.state = {
			code: '',
			input: React.createRef(),
			focused: false
		};
	}

	handleClick() {
		this.state.input.current.focus();
	}

	handleFocus() {
		this.setState({ focused: true });
	}

	handleBlur() {
		this.setState({
			focused: false
		});
	}

	handleChange(e) {
		const input = e.target.value;
		if (input.length === CODE.length) {
			this.setState({ code: input }, this.props.handleVerify(input));
		} else {
			const code = this.state.code + input.slice(0, CODE.length);
			if (code.length === CODE.length) {
				this.setState({ code }, this.props.handleVerify(code));
			} else {
				this.setState({ code });
			}
		}
	}

	handleKeyPress(e) {
		if (e.key === 'Backspace') {
			this.setState(state => {
				return {
					code: state.code.slice(0, state.code.length - 1)
				};
			});
		}
	}

	onClear() {
		this.setState({code: ''})
	}

	render() {
		const digits = this.state.code ? this.state.code.split('') : '';
		const hideInput = !(digits.length < CODE.length);
		const selectedIndex = digits.length < CODE.length ? digits.length : CODE.length - 1;
		return (
			<div className={style.step}>
				<div className={style.header}>
					<h6>Verification</h6>
				</div>
				{this.props.pendingVerify ? (
					<NewSpinner size="m" />
				) : (
					<div className={style.verification}>
						<div className={style.codeText}>
							{globalize.parseString(i18n.verification.info)}
						</div>
						<div className={style.code}>
							{CODE.map((v, index) => {
								const selected = digits.length === index;
								const filled = digits.length === CODE.length && index === CODE.length - 1;
								return (
									<div key={index} className={style.digit}>
										{digits[index]}
										{(selected || filled) && this.state.focused && (
											<div className={style.shadows} />
										)}
									</div>
								);
							})}
							<input
								onClick={this.handleClick}
								value=""
								ref={this.state.input}
								onChange={this.handleChange}
								onKeyDown={this.handleKeyPress}
								onFocus={this.handleFocus}
								onBlur={this.handleBlur}
								className={style.input}
								maxLength="6"
								style={{
									width: '32px',
									top: '0px',
									bottom: '0px',
									left: `${selectedIndex * 32}px`,
									opacity: hideInput ? 0 : 1
								}}
							/>
						</div>
						{this.state.code.length != 0 && <ErrorIcon className={style.clearIcon} onClick={this.onClear} />}
						<div className={style.validationError}>
							{this.props.status !== 'ok' &&
								this.state.code.length === CODE.length &&
								globalize.parseString(i18n.verification.failed)}
						</div>
						<div className={style.resendWrapper}>
						<div className={style.msgRecived}>{this.props.message}</div>
							{globalize.parseString(i18n.verification.resend)}
							<br />
							<button
								className={style.resendBtn}
								onClick={this.props.handleVerificationCode}
							>
								Resend
							</button>
						
						</div>
					</div>
				)}
			</div>
		);
	}
}

DeletePilotVerification.propTypes = {
	status: PropTypes.string,
	message: PropTypes.string,
	pendingVerify: PropTypes.bool,
	handleVerify: PropTypes.func,
	handleVerificationCode: PropTypes.func,
	error: PropTypes.string
};

export default DeletePilotVerification;
