import React, { Component } from 'react';
import PropTypes from 'prop-types';
import * as i18n from 'i18n/en/deletePilot.json';
import style from './styles.scss';

class DeletePilotTerms extends Component {
	constructor(props) {
		super(props);

		// this.state = {
		// 	isReading: true
		// };
	}

	// handleScroll(e) {
	// 	const { scrollHeight, scrollTop, clientHeight } = e.target;
	// 	const isReading = scrollHeight - scrollTop > clientHeight;
	// 	this.setState({ isReading });
	// }

	render() {
		return (
			<React.Fragment>
				<div className={style.header}>
					<h6>Terms &amp; Conditions</h6>
				</div>
				{/* <div className={style.terms} onScroll={e => this.handleScroll(e)}> */}
				<div className={style.terms}>{globalize.parseString(i18n.terms.text)}</div>
				<div className={style.agreementWrapper}>
					<div>
						<input
							type="checkbox"
							className={style.checkbox}
							defaultChecked={this.props.isAgree}
							onChange={this.props.handleTerms}
							// disabled={this.state.isReading}
						/>
					</div>
					<div className={style.agreement}>
						{globalize.parseString(i18n.terms.agreement)}
					</div>
				</div>
			</React.Fragment>
		);
	}
}

DeletePilotTerms.propTypes = {
	isAgree: PropTypes.bool.isRequired,
	handleTerms: PropTypes.func
};

export default DeletePilotTerms;
