import React, { Component } from 'react';
import PropTypes from 'prop-types';
import * as i18n from 'i18n/en/deletePilot.json';
import { SuccessIcon } from 'components/ui/Icons';
import style from './styles.scss';

class DeletePilotReview extends Component {
	render() {
		const { pilotName } = this.props;
		return (
			<div className={style.step}>
				<div className={style.header}>
					<h6>Review</h6>
				</div>
				<div className={style.review}>
					<SuccessIcon className={style.successIcon} />
					<p className={style.message}>
						{globalize.parseString(i18n.review, { pilotName })}
					</p>
				</div>
			</div>
		);
	}
}

DeletePilotReview.propTypes = {
	pilotName: PropTypes.string
};

export default DeletePilotReview;
