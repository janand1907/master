import API from '@mocks/channels/APIs';
import server from '@mocks/channels/servers';
import database from '@mocks/channels/databases';
import storage from '@mocks/channels/storage';
import sftp from '@mocks/channels/sftp';
// import VPN from '@mocks/channels/VPN';


export default () => {
	return [
		...Object.values(API),
		...Object.values(server),
		...Object.values(database),
		...Object.values(storage),
		...Object.values(sftp)
		// ...Object.values(VPN)
	];
};
