import createFormReducer from 'utils/createFormReducer';
import getForm from 'utils/getForm';

describe('getForm util', () => {

	it('should find a form when mounted at root', () => {
		const reducer = createFormReducer('a');
		const state = reducer(undefined, { type: '' });
		const result = getForm(state, 'a', true);
		expect(result).toEqual(state);
	});

	it('should find a form when nested', () => {
		// Mounted at level 1
		let reducer = createFormReducer('b');
		let formState = reducer(undefined, { type: '' });
		let state = { form: formState };
		let result = getForm(state, 'b', true);
		expect(result).toEqual(formState);

		// Mounted deep
		reducer = createFormReducer('c');
		formState = reducer(undefined, { type: '' });
		state = { this: { is: { quite: { deep: formState } } } };
		result = getForm(state, 'c', true);
		expect(result).toEqual(formState);
	});

	it('should return null when not found', () => {
		const result = getForm({}, 'd', true);
		expect(result).toBeNull();
	});

	it('should not be fooled by a state with a similar structure', () => {
		const formState = {
			initial: {},
			model: {},
			fields: {},
			form: {},
			[Symbol('$form')]: 'e',
		};
		const state = { form: formState };
		const result = getForm(state, 'e', true);
		expect(result).toBeNull();
	});

});
