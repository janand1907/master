import { currencyFormatter } from 'utils';


describe('Utils/currencyFormatter', () => {
	it('Should round down when number is in billions', () => {
		expect(currencyFormatter(120008908978)).toMatch('$120B');
	});
	it('Should round up when number is in billions', () => {
		expect(currencyFormatter(120698908978)).toMatch('$120.7B');
	});
	it('Should round down when number is in millions', () => {
		expect(currencyFormatter(120008908)).toMatch('$120M');
	});
	it('Should round up when number is in millions', () => {
		expect(currencyFormatter(120678908)).toMatch('$120.7M');
	});
	it('Should round down when number is in K\'s', () => {
		expect(currencyFormatter(120008)).toMatch('$120K');
	});
	it('Should round up when number is in K\'s', () => {
		expect(currencyFormatter(120668)).toMatch('$120.7K');
	});
	it('Should show number as is', () => {
		expect(currencyFormatter(120)).toMatch('$120');
	});
});
