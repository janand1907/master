import { cloneDeep } from 'lodash';
import {
	calcProcessesSum, getMinMaxAvg, getInitialGraphsIds, isChartHasData, isSelectedGraphs, getNewSelectedIds
} from 'utils/charts/chartUtils';

const dataOneProcess = [
	{
		company_id: 1,
		per_process: false,
		values: [{
			'name': null,
			'id': null,
			'min': 1,
			'max': 1,
			'avg': 1,
			'samples': [{ 'x': '2019-02-04T08:00:00Z', 'y': 1 }, { 'x': '2019-02-04T08:00:20Z', 'y': 2 }]
		}]
	}
];

const dataSeveralProcess = [
	{
		company_id: 1,
		per_process: true,
		values: [{
			'name': '1',
			'id': '1',
			'min': 1,
			'max': 1,
			'avg': 1,
			'samples': [{ 'x': '2019-02-04T08:00:00Z', 'y': 1 }, { 'x': '2019-02-04T08:00:20Z', 'y': 1 }]
		},
		{
			'name': '2',
			'id': '2',
			'min': 2,
			'max': 2,
			'avg': 2,
			'samples': [{ 'x': '2019-02-04T08:00:00Z', 'y': 2 }, { 'x': '2019-02-04T08:00:20Z', 'y': 2 }]
		}]
	}
];

const dataSeveralProcessNoData = [
	{
		company_id: 1,
		per_process: true,
		values: [
			{ 'name': '1', 'id': '1', 'min': null, 'max': null, 'avg': null, 'samples': [] },
			{ 'name': '2', 'id': '2', 'min': null, 'max': null, 'avg': null, 'samples': [] }
		]
	}
];

const dataSeveralProcessResultTotalAll = {
	'name': 'Total',
	'min': 3,
	'max': 3,
	'avg': 3,
	'samples': [{ 'x': '2019-02-04T08:00:00Z', 'y': 3 }, { 'x': '2019-02-04T08:00:20Z', 'y': 3 }]
};

const dataSeveralProcessResultTotalOne = {
	'name': 'Total',
	'min': 2,
	'max': 2,
	'avg': 2,
	'samples': [{ 'x': '2019-02-04T08:00:00Z', 'y': 2 }, { 'x': '2019-02-04T08:00:20Z', 'y': 2 }]
};


const selectedGraphsNull = null;

const selectedGraphs = { '1': true, '1_2': true };

const selectedGraphsAll = { '1': true, '1_1': true, '1_2': true };

const selectedGraphsAllFalse = { '1': false, '1_1': false, '1_2': false };

describe('chart utils func calcProcessesSum', () => {

	it('calc sum for one process', () => {
		const result = calcProcessesSum(dataOneProcess, selectedGraphsNull);
		expect(result).toEqual(dataOneProcess);
	});

	it('calc sum for several process', () => {
		const result = calcProcessesSum(dataSeveralProcess, selectedGraphsNull);
		let newDataSeveraProcess = cloneDeep(dataSeveralProcess);
		newDataSeveraProcess[0].values = [dataSeveralProcessResultTotalAll, ...newDataSeveraProcess[0].values];
		expect(result).toEqual(newDataSeveraProcess);
	});

	it('calc sum for several process. One checked', () => {
		const result = calcProcessesSum(dataSeveralProcess, selectedGraphs);
		let newDataSeveraProcess = cloneDeep(dataSeveralProcess);
		newDataSeveraProcess[0].values = [dataSeveralProcessResultTotalOne, ...newDataSeveraProcess[0].values];
		expect(result).toEqual(newDataSeveraProcess);
	});

});

describe('chart utils func getMinMaxAvg', () => {

	it('calc getMinMaxAvg', () => {
		const result = getMinMaxAvg(dataSeveralProcess[0].values[1].samples);
		expect(result).toEqual({ min: 2, max: 2, avg: 2 });
	});

});


describe('chart utils func getInitialGraphsIds', () => {

	it('calc getInitialGraphsIds', () => {
		const result = getInitialGraphsIds(dataSeveralProcess);
		expect(result).toEqual(selectedGraphsAll);
	});

});


describe('chart utils func isChartHasData', () => {

	it('gets isChartHasData', () => {
		const result = isChartHasData(dataSeveralProcess);
		expect(result).toEqual(false);

		const result2 = isChartHasData(dataSeveralProcessNoData);
		expect(result2).toEqual(true);
	});

});

describe('chart utils func isSelectedGraphs', () => {

	it('gets isSelectedGraphs', () => {
		const result = isSelectedGraphs(selectedGraphs);
		expect(result).toEqual(false);

		const result2 = isSelectedGraphs(selectedGraphsAll);
		expect(result2).toEqual(false);

		const result3 = isSelectedGraphs(selectedGraphsNull);
		expect(result3).toEqual(false);

		const result4 = isSelectedGraphs(selectedGraphsAllFalse);
		expect(result4).toEqual(true);
	});

});

describe('chart utils func getNewSelectedIds', () => {

	it('gets getNewSelectedIds', () => {
		const result = getNewSelectedIds({ '1': true }, { '1': true, '1_1': true }, { '1': false });
		expect(result).toEqual({ '1': false, '1_1': false });

		const result2 = getNewSelectedIds({ '1': true }, { '1': true, '1_1': true }, { '1': false });
		expect(result2).toEqual({ '1': false, '1_1': false });

		const result3 = getNewSelectedIds({ '1': true, '1_1': true }, { '1': true }, { '1': true });
		expect(result3).toEqual({ '1': true });
	});

});

