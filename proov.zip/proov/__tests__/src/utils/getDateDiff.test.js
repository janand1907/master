import getDateDiff from 'utils/getDateDiff';


describe('Utils/getDateDiff', () => {
	const startTime = '2017-04-03T12:00:30.793Z';
	const endTime = '2017-04-04T00:40:40.908Z';
	const timeLeft = getDateDiff(startTime, endTime);
	it('Should return the correct diffrence in hours', () => {
		expect(timeLeft.hours).toBe(12);
	});
	it('Should return the correct diffrence in days', () => {
		expect(timeLeft.days).toBe(0);
	});
	it('Should return the correct diffrence in weeks', () => {
		expect(timeLeft.weeks).toBe(0);
	});
});
