import createAction from 'utils/createAction';

describe('createAction util', () => {

	it('creates an FSA', () => {
		// Without metadata
		expect(createAction('foo', 'bar'))
			.toEqual({ type: 'foo', payload: 'bar' });

		// With metadata
		expect(createAction('foo', 'bar', { foo: 'bar' }))
			.toEqual({ type: 'foo', payload: 'bar', meta: { foo: 'bar' } });
	});

	it('creates an FSA for error', () => {
		const err = new Error('Error!');
		expect(createAction('foo', err))
			.toEqual({ type: 'foo', payload: err, error: true });
	});

});
