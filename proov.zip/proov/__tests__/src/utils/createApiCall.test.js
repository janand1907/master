import createApiCall from 'utils/createApiCall';

describe('createApiCall util', () => {

	it('creates an object with a standard structure', () => {
		const options = {
			endpoint: '/foo/bar',
			method: 'GET',
			types: ['REQUEST', 'SUCCESS', 'FAILURE']
		};
		const action = createApiCall(options, { foo: 'bar' });
		expect(action).toMatchObject({
			type: '@@api/MAKE_CALL',
			meta: { api: options, foo: 'bar' }
		});
	});

	it('sets `credentials` option properly', () => {
		expect(createApiCall().meta.api.credentials).toEqual('same-origin'); // Default
		expect(createApiCall({ credentials: 'include' }).meta.api.credentials).toEqual('include');
	});

	it('sets `Content-Type` header properly', () => {
		const selector = (a) => a.meta.api.headers['Content-Type'];

		// When body is String
		expect(selector(createApiCall({ body: '' }))).toEqual('application/json');

		// When body is Object
		expect(selector(createApiCall({ body: {} }))).toEqual('application/json');

		// When body is FormData
		expect(selector(createApiCall({ body: new FormData() }))).toBeUndefined();
	});

	it('assigns custom headers properly', () => {
		const action = createApiCall({ headers: { 'x-foo': 'bar' } });
		expect(action.meta.api.headers['x-foo']).toEqual('bar');
	});

	it('stringifies body if necessary', () => {
		// Should stringify if Object
		let action = createApiCall({
			headers: { 'Content-Type': 'application/json' },
			body: { foo: 'bar' }
		});
		expect(action.meta.api.body).toEqual(JSON.stringify({ foo: 'bar' }));

		// Should not stringify if String
		action = createApiCall({
			headers: { 'Content-Type': 'application/json' },
			body: 'foo'
		});
		expect(action.meta.api.body).toEqual('foo');

		// Should not stringify if not application/json
		action = createApiCall({ body: new FormData() });
		expect(action.meta.api.body).toBeInstanceOf(FormData);
	});

});
