import multi from 'middleware/multiMiddleware';

describe('multi middleware', () => {

	const fakeDispatch = jest.fn();
	const fakeNext = jest.fn(action => action.type);

	afterEach(() => {
		fakeDispatch.mockClear();
		fakeNext.mockClear();
	});

	it('ignores actions that are not arrays', () => {
		const action = { type: 'FOO' };
		const result = multi({ dispatch: fakeDispatch })(fakeNext)(action);

		// middleware returns the result of next(action)
		expect(result).toEqual(action.type);

		// next() was called exactly once
		expect(fakeNext).toHaveBeenCalledTimes(1);

		// next() was called with the original action
		expect(fakeNext).toHaveBeenCalledWith(action);

		// dispatch() was not called
		expect(fakeDispatch).not.toHaveBeenCalled();
	});

	it('dispatches multiple actions in a row', () => {
		const actions = [ { type: 'FOO' }, { type: 'BAR' }];
		const result = multi({ dispatch: fakeDispatch })(fakeNext)(actions);

		// middleware returns an array of dispatch() results
		expect(result).toHaveLength(2);

		// dispatch() was called exactly twice
		expect(fakeDispatch).toHaveBeenCalledTimes(2);

		// dispatch() was called with each and every action
		const [first, second] = fakeDispatch.mock.calls;
		expect(first[0]).toEqual(actions[0]);
		expect(second[0]).toEqual(actions[1]);

		// next() was not called
		expect(fakeNext).not.toHaveBeenCalled();
	});

});
