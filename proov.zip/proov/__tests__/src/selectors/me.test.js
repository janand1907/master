import * as meSelectors from 'ducks/me/selectors';
import { client } from '@mocks/auth';

const state = {
	me: {
		authenticated: true,
		company: {
			pending: false,
			data: client
		},
		user: {
			pending: false,
			data: client
		}
	}
};

describe('me selectors', () => {
	it('getUser', () => {
		expect(meSelectors.getMeUser(state)).toEqual(client);
	});

	it('isUserPending', () => {
		expect(meSelectors.isUserPending(state)).toEqual(false);
	});

	it('getUserCompany', () => {
		expect(meSelectors.getMeCompany(state)).toEqual(client);
	});

	it('isCompanyPending', () => {
		expect(meSelectors.isCompanyPending(state)).toEqual(false);
	});

	it('isUserAuthenticated', () => {
		expect(meSelectors.isUserAuthenticated(state)).toEqual(true);
	});
});
