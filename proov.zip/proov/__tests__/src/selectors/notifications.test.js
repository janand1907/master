import { vendorNotifications as notifications } from '@mocks/notification';
import * as selectors from 'ducks/notifications/selectors';

const state = {
	notifications: {
		notifications: notifications,
		skip: 0,
		limit: 6,
		pending: {
			firstLoad: false,
			loadMore: false,
			markAsRead: false
		},
		isMoreToLoad: false,
		error: null
	}
};

describe('notifications selectors', () => {
	it('getNotifications', () => {
	  	expect(selectors.getNotifications(state)).toEqual(state.notifications);
	});

	it('getNotificationsData', () => {
	  	expect(selectors.getNotificationsData(state)).toEqual(state.notifications.notifications);
	});

	it('getLimit', () => {
	  	expect(selectors.getLimit(state)).toEqual(state.notifications.limit);
	});

	it('getSkip', () => {
	  	expect(selectors.getSkip(state)).toEqual(state.notifications.skip);
	});

	it('isMoreToLoad', () => {
		  expect(selectors.isMoreToLoad(state)).toEqual(state.notifications.isMoreToLoad);
	});

	it('getPending', () => {
		expect(selectors.getPending(state)).toEqual(state.notifications.pending);
	});
});
