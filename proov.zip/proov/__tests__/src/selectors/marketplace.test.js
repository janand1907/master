import pilot from '@mocks/pilot';
import company from '@mocks/company';
import * as mpSelectors from 'ducks/marketplace/selectors';

const state = {
	marketplace: {
		pilot: pilot,
		pending: { pilot: false, company: false }
	}
};

xdescribe('marketplace selectors', () => {
	it('getMpCompany', () => {
		expect(mpSelectors.getMpCompany(state)).toEqual(company);
	});

	it('getMpPilot', () => {
		expect(mpSelectors.getMpPilot(state)).toEqual(pilot);
	});

	it('getMpPending', () => {
		expect(mpSelectors.getMpPending(state)).toEqual({ pilot: false, company: false });
	});
});
