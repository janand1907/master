import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';
import DropZone from 'components/ui/DropZone/DropZone.js';

describe('DropZone componen', () => {

	const filesGood = [{ name:'avatar.jpg', size:234787, type:'image/jpeg' }];

	const maxFileSize = 1;
	const filesBigSize = [{ name:'avatar.jpg', size:1024 * 1024 * 2, type:'image/jpeg' }];
	const filesWrongExtention = [{ name:'avatar.pdf', size:1024 * 1024 * 1, type:'image/jpeg' }];
	const filesSeveral = [{ name:'avatar.jpg', size:1024 * 1024 * 1, type:'image/jpeg' }, { name:'avatar2.jpg', size:1024 * 1024 * 1, type:'image/jpeg' }];

	it('DropZone::render,drop', () => {
		const dropZone = mount(<DropZone onDropEnd={(res) => { expect(res.success).toBeTruthy(); expect(res.files).toEqual(filesGood) }} types={['jpg', 'png']} />);
		expect(dropZone.state('isDragActive')).toBeFalsy();
		expect(dropZone.state('isDropAllowed')).toBeTruthy();
		dropZone.find('div').at(1).simulate('drop', { dataTransfer: { files: filesGood } });
		expect(dropZone.state('isDragActive')).toBeFalsy();
		expect(dropZone.state('isDropAllowed')).toBeTruthy();
	});

	it('DropZone::FILE_MAX_ERROR', () => {
		const dropZone = mount(<DropZone maxFileSize={maxFileSize} onDropEnd={(res) => true} types={['jpg', 'png']} />);
		dropZone.find('div').at(1).simulate('drop', { dataTransfer: { files: filesBigSize } });
		expect(dropZone.state('isDragActive')).toBeFalsy();
		expect(dropZone.state('isDropAllowed')).toBeTruthy();
		expect(dropZone.state('error')).toEqual('The file exceeding the max file size of 1Mb');
	});

	it('DropZone::FILE_EXTENTION_ERROR ', () => {
		const dropZone = mount(<DropZone onDropEnd={(res) => true} types={['jpg', 'png']} />);
		dropZone.find('div').at(1).simulate('drop', { dataTransfer: { files: filesWrongExtention } });
		expect(dropZone.state('isDragActive')).toBeFalsy();
		expect(dropZone.state('isDropAllowed')).toBeTruthy();
		expect(dropZone.state('error')).toEqual('Hm... The uploaded file extension is invalid');
	});

	it('DropZone::FILE_MAX_ERROR ', () => {
		const dropZone = mount(<DropZone onDropEnd={(res) => true} types={['jpg', 'png']} />);
		dropZone.find('div').at(1).simulate('drop', { dataTransfer: { files: filesSeveral } });
		expect(dropZone.state('isDragActive')).toBeFalsy();
		expect(dropZone.state('isDropAllowed')).toBeTruthy();
		expect(dropZone.state('error')).toEqual('You can`t upload more than 1 files.');
	});

	it('DropZone::dragover ', () => {
		const dropZone = mount(<DropZone maxFileSize={maxFileSize} onDropEnd={(res) => true} types={['jpg', 'png']} />);
		dropZone.find('div').at(1).simulate('dragover', { dataTransfer: { files: filesGood } });
		expect(dropZone.state('isDragActive')).toBeTruthy();
		expect(dropZone.state('isDropAllowed')).toBeTruthy();
	});

	it('DropZone::snapshot', () => {
		let dropZone = renderer.create(
			<DropZone maxFileSize={maxFileSize} onDropEnd={(res) => true} types={['jpg', 'png']} />
		);
		expect(dropZone.toJSON()).toMatchSnapshot();
	});

});
