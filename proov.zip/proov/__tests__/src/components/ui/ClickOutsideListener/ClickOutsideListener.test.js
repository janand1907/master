import React from 'react';
import renderer from 'react-test-renderer';
import ClickOutsideListener from 'components/ui/ClickOutsideListener/ClickOutsideListener';

xdescribe('<ClickOutsideListener />', () => {
	const spy = jest.fn();
	it('renders correctly with wrapping div', () => {
		const component = renderer.create(
			<ClickOutsideListener preventWrap onClickOutside={spy}>
				<div>test</div>
			</ClickOutsideListener>
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('renders c orrectly without wrapping div', () => {
		const component = renderer.create(
			<ClickOutsideListener onClickOutside={spy}>
				<div>child1</div>
				<div>child2</div>
			</ClickOutsideListener>
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

});
