import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';
import Switch from 'components/ui/Switch/Switch.js';

describe('Switch', () => {

	const cSwitch = mount(<Switch />);

	it('Switch::render', () => {
		expect(cSwitch.find('span').text()).toBe('Off');
		expect(cSwitch.state('toggled')).toBeFalsy();
	});

	it('Switch::change value', () => {
		cSwitch.find('input').simulate('change', { target: { checked: true } });
		expect(cSwitch.find('span').text()).toBe('On');
		expect(cSwitch.state('toggled')).toBeTruthy();

		cSwitch.find('input').simulate('change', { target: { checked: false } });
		expect(cSwitch.find('span').text()).toBe('Off');
		expect(cSwitch.state('toggled')).toBeFalsy();
	});

	it('Switch::Snapshot', () => {
		const crSwitch = renderer.create(
			<Switch />
    );

		let tree = crSwitch.toJSON();
		expect(tree).toMatchSnapshot();
	});
});
