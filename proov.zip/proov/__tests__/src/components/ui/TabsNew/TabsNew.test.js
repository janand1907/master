import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';
import TabsNew from 'components/ui/TabsNew/TabsNew.js';
import Tab from 'components/ui/TabsNew/Tab.js';

describe('TabsNew', () => {

	const tabsConf = [
		{ label: 'label1' },
		{ label: 'label2' },
		{ label: 'label3', disabled: true }
	];

	const cTabsNew = mount(
		<TabsNew tabs={tabsConf}>
			<Tab>1</Tab>
			<Tab>2</Tab>
			<Tab>3</Tab>
		</TabsNew>
	);

	it('TabsNew::render', () => {
		expect(cTabsNew.text()).toBe('label1label2label31');
		expect(cTabsNew.find('li').at(0).text()).toBe('label1');
		expect(cTabsNew.find('li').at(1).text()).toBe('label2');
		expect(cTabsNew.find('li').at(2).text()).toBe('label3');
		expect(cTabsNew.find('div').at(1).text()).toBe('1');
		expect(cTabsNew.state('selectedTab')).toBe(0);
	});

	it('TabsNew::change tabs', () => {
		cTabsNew.find('li').at(1).simulate('click');
		expect(cTabsNew.find('div').at(1).text()).toBe('2');
		expect(cTabsNew.state('selectedTab')).toBe(1);
		cTabsNew.find('li').at(0).simulate('click');
		expect(cTabsNew.find('div').at(1).text()).toBe('1');
		expect(cTabsNew.state('selectedTab')).toBe(0);
	});

	it('TabsNew::check disabled tab', () => {
		cTabsNew.find('li').at(2).simulate('click');
		expect(cTabsNew.find('div').at(1).text()).toBe('1');
		expect(cTabsNew.state('selectedTab')).toBe(0);

	});

	it('TabsNew::Snapshot', () => {
		const crTabsNew = renderer.create(
			<TabsNew tabs={tabsConf}>
				<Tab>1</Tab>
				<Tab>2</Tab>
				<Tab>3</Tab>
			</TabsNew>
    );

		let tree = crTabsNew.toJSON();
		expect(tree).toMatchSnapshot();
	});
});
