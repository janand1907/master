import React from 'react';
import { mount } from 'enzyme';
import Accordion from 'components/ui/Accordion/Accordion.js';

const setup = (active, lock = false) => {
	const props = {
		header: <p>header</p>,
		details: <span>details</span>,
		isActive: active,
		lock: lock,
		onToggle: () => {}
	};

	return mount(<Accordion {...props} />);
};

const setupDefault = () => {
	const props = {
		header: <p>header</p>,
		details: <span>details</span>,
		onToggle: () => {}
	};

	return mount(<Accordion {...props} />);
};

const setupNoElement = () => {
	const props = {
		onToggle: () => {}
	};

	return mount(<Accordion {...props} />);
};

describe('Accordion testing', () => {
	it('Check the header', () => {
		const wrapper = setup(true);
		expect(wrapper.find('div').at(1).text()).toEqual('header');
	});

	it('Should be active', () => {
		const wrapper = setup(true);
		expect(wrapper.state().active).toBeTruthy();
	});

	it('Should be closed when clicking the header', () => {
		const wrapper = setup(true);
		expect(wrapper.state().active).toBeTruthy();
		wrapper.find('div').at(1).simulate('click');
		expect(wrapper.state().active).toBeFalsy();
	});

	it('Should be opened when clicking the header', () => {
		const wrapper = setup(false);
		expect(wrapper.state().active).toBeFalsy();
		wrapper.find('div').at(1).simulate('click');
		expect(wrapper.state().active).toBeTruthy();
	});

	it('Should be remain opened', () => {
		const wrapper = setup(true, true);
		expect(wrapper.state().active).toBeTruthy();
		wrapper.find('div').at(1).simulate('click');
		expect(wrapper.state().active).toBeTruthy();
	});

	it('Should be remain closed', () => {
		const wrapper = setup(false, true);
		expect(wrapper.state().active).toBeFalsy();
		wrapper.find('div').at(1).simulate('click');
		expect(wrapper.state().active).toBeFalsy();
	});

	it('Should invoke cwr and change state', () => {
		const wrapper = setup(false);
		expect(wrapper.state().active).toBeFalsy();
		wrapper.setProps({ isActive: true });
		expect(wrapper.state().active).toBeTruthy();
	});

	it('Should init default props', () => {
		const wrapper = setupDefault();
		expect(wrapper.props().isActive).toBeFalsy();
		expect(wrapper.props().lock).toBeFalsy();
		expect(wrapper.props().className).toEqual('');
		expect(wrapper.props().headerActiveClassName).toEqual('');
	});
});
