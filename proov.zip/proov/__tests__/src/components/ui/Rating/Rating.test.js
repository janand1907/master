import React from 'react';
import renderer from 'react-test-renderer';
import Rating from 'components/ui/Rating/Rating';

describe('<Rating />', () => {
	it('renders correctly with rate of 0', () => {
		const component = renderer.create(
			<Rating className="foo" rate={0} />
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('renders correctly with rate of float number that close to the upper rounded number', () => {
		const component = renderer.create(
			<Rating className="foo" rate={2.8} />
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('renders correctly with rate of float number that close to the lower rounded number', () => {
		const component = renderer.create(
			<Rating className="foo" rate={4.2} />
		);
		expect(component.toJSON()).toMatchSnapshot();
	});
});
