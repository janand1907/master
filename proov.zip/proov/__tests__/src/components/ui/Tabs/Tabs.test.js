import React from 'react';
import renderer from 'react-test-renderer';
import { mount, shallow } from 'enzyme';
import Tabs from 'components/ui/Tabs/Tabs.js';


describe('Tabs', () => {
  const onchange = () => { };
  const someClassName = 'someclassname';
  const tabList = [
    'Tab 1',
    'Tab 2',
    'Tab 3'
  ];

  const chNode = '<p>Child</p>';

  const props = { children: chNode, tabList: tabList, className: someClassName, activeTab: 'Tab 1' };
  const cTabsNew = shallow(
    <Tabs {...props} />
  );

  it("the 'componentWillReceiveProps' should change the state of 'activeTab'", () => {
    cTabsNew.setProps({ activeTab: 'Tab 1' });
    expect(cTabsNew.state('activeTab')).toBe('Tab 1');
  });

  it('Tabs::activeTab', () => {
    expect(cTabsNew.state('activeTab')).toBe('Tab 1');
  });


  it('Tabs::onClick', () => {
    cTabsNew.find('li').at(2).simulate('click');
    expect(cTabsNew.state('activeTab')).toBe('Tab 3');

    cTabsNew.find('li').at(1).simulate('click');
    expect(cTabsNew.state('activeTab')).toBe('Tab 2');
  });

  it('Tabs::Snapshot', () => {
    const crTabs = renderer.create(
      <Tabs {...props} />
    );
    let tree = crTabs.toJSON();
    expect(tree).toMatchSnapshot();
  });

});

