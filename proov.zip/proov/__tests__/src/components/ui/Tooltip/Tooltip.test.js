import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';
import Tooltip from 'components/ui/Tooltip/Tooltip.js';

describe('Tooltip', () => {

	it('Tooltip::render', () => {
		let cTooltip = mount(<Tooltip />);
		expect(cTooltip.state('style')).toEqual({ 'right': -15, 'top': '50%', 'transform': 'translate(100%, -50%)' });

		cTooltip = mount(<Tooltip placement="left" />);
		expect(cTooltip.state('style')).toEqual({ 'left': -15, 'top': '50%', 'transform': 'translate(-100%, -50%)' });

		cTooltip = mount(<Tooltip placement="top" />);
		expect(cTooltip.state('style')).toEqual({ 'left': '50%', 'top': -15, 'transform': 'translate(-50%, -100%)' });

		cTooltip = mount(<Tooltip placement="bottom" />);
		expect(cTooltip.state('style')).toEqual({ 'bottom': -15, 'left': '50%', 'transform': 'translate(-50%, 100%)' });

		cTooltip = mount(<Tooltip placement="top" spacing={10} />);
		expect(cTooltip.state('style')).toEqual({ 'left': '50%', 'top': -10, 'transform': 'translate(-50%, -100%)' });

		cTooltip = mount(<Tooltip placement="left" spacing={10} />);
		expect(cTooltip.state('style')).toEqual({ 'left': -10, 'top': '50%', 'transform': 'translate(-100%, -50%)' });

		cTooltip = mount(<Tooltip placement="right" spacing={10} />);
		expect(cTooltip.state('style')).toEqual({ 'right': -10, 'top': '50%', 'transform': 'translate(100%, -50%)' });

		cTooltip = mount(<Tooltip placement="bottom" spacing={10} />);
		expect(cTooltip.state('style')).toEqual({ 'bottom': -10, 'left': '50%', 'transform': 'translate(-50%, 100%)' });

		cTooltip = mount(<Tooltip spacing={0} anchor={{ x: 200, y: 200 }}>Tooltip text</Tooltip>);
		expect(cTooltip.text()).toBe('Tooltip text');
		expect(cTooltip.state('style')).toEqual({ 'left': 200, 'top': 200, 'transform': 'translateY(-50%)' });

	});

	it('Tooltip::Snapshot', () => {
		const crTooltip = renderer.create(
			<Tooltip />
    );

		let tree = crTooltip.toJSON();
		expect(tree).toMatchSnapshot();
	});
});
