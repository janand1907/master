import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';
import GridView from 'components/ui/GridView/GridView.js';

describe('GridView', () => {
	const configTable = [
		{ title: 'Col1', value: ({ val1 }) => val1 },
		{ title: 'Col2', value:  ({ val2 }) => val2, sort: true },
		{ title: 'Col3', value:  ({ val3 }) => val3, sort: true },
	];
	const dataTable = [{ val1:1, val2: 2, val3: 3 }, { val1:4, val2: 5, val3: 6 }, { val1:7, val2: 8, val3: 9 }];
	const dataTable2 = [{ val1:10, val2: 11, val3: 12 }, { val1:13, val2: 14, val3: 15 }, { val1:16, val2: 17, val3: 18 }];
	const cGridView = mount(<GridView config={configTable} data={dataTable} sortConfig={{ sortColumn: 1, sortOrder: 1 }} />);

	/*
		Col1 Col2 ↓ Col3
	    1    2     3
		  4    5     6
		  7    8     9
	*/

	it('GridView::render', () => {
		expect(cGridView.text()).toBe('Col1 Col2 ↓Col3 123456789');

		cGridView.find('td').forEach(function (node, key) {
			expect(node.text()).toBe((key + 1).toString());
		});

		expect(cGridView.find('thead').find('th').length).toBe(3);
		expect(cGridView.find('tbody').find('tr').length).toBe(3);
		expect(cGridView.find('tbody').find('tr').at(0).find('td').length).toBe(3);
		expect(cGridView.find('tbody').find('tr').at(1).find('td').length).toBe(3);
		expect(cGridView.find('tbody').find('tr').at(2).find('td').length).toBe(3);
	});

	it('GridView::sorting', () => {
		//Sort by second column asc
		cGridView.find('thead').find('th').at(1).simulate('click');
		expect(cGridView.find('tbody').at(0).find('td').at(0).text()).toBe('7');
		expect(cGridView.find('tbody').at(0).find('td').at(1).text()).toBe('8');
		expect(cGridView.find('tbody').at(0).find('td').at(2).text()).toBe('9');
		expect(cGridView.find('tbody').at(0).find('td').at(3).text()).toBe('4');
		expect(cGridView.find('tbody').at(0).find('td').at(4).text()).toBe('5');
		expect(cGridView.find('tbody').at(0).find('td').at(5).text()).toBe('6');
		expect(cGridView.find('tbody').at(0).find('td').at(6).text()).toBe('1');
		expect(cGridView.find('tbody').at(0).find('td').at(7).text()).toBe('2');
		expect(cGridView.find('tbody').at(0).find('td').at(8).text()).toBe('3');
		expect(cGridView.state('sortColumn')).toBe(1);
		expect(cGridView.state('sortOrder')).toBe(-1);

		//Sort by second column desc
		cGridView.find('thead').find('th').at(1).simulate('click');
		cGridView.find('td').forEach(function (node, key) {
			expect(node.text()).toBe((key + 1).toString());
		});
		expect(cGridView.state('sortColumn')).toBe(1);
		expect(cGridView.state('sortOrder')).toBe(1);

		//First column is not sortable. Click return the same result
		cGridView.find('thead').find('th').at(0).simulate('click');
		cGridView.find('td').forEach(function (node, key) {
			expect(node.text()).toBe((key + 1).toString());
		});
		expect(cGridView.state('sortColumn')).toBe(1);
		expect(cGridView.state('sortOrder')).toBe(1);
	});


	it('GridView::cwr and change state', () => {
		cGridView.setProps({ data: dataTable2 });
		expect(cGridView.state('data')).toBe(dataTable2);
	});

	it('GridView::Snapshot', () => {
		let crGridView = renderer.create(
			<GridView config={configTable} data={dataTable} sortConfig={{ sortColumn: 1, sortOrder: 1 }} />
    );
		expect(crGridView.toJSON()).toMatchSnapshot();

		crGridView = renderer.create(
			<GridView config={configTable} data={dataTable} />
		);
		expect(crGridView.toJSON()).toMatchSnapshot();

		crGridView = renderer.create(
			<GridView config={configTable} data={[]} />
		);
		expect(crGridView.toJSON()).toMatchSnapshot();

		crGridView = renderer.create(
			<GridView config={[]} data={[]} />
		);
		expect(crGridView.toJSON()).toMatchSnapshot();
	});

});
