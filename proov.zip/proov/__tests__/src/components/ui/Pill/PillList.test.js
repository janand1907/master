import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';
import PillList from 'components/ui/Pill/PillList';

describe('<PillList />', () => {

	const items = [
		{ id: 'first', title: 'First' },
		{ id: 'second', title: 'Second' },
		{ id: 'third', title: 'Third' }
	];

	it('render correctly', () => {
		const props = {
			items,
			allowRemove: true,
			getKey: (item) => item.id,
			getContent: (item) => item.title,
			className: 'foo',
			pillClassName: 'bar'
		};

		// When removable
		let component = renderer.create(<PillList {...props} />);
		expect(component.toJSON()).toMatchSnapshot();

		// When not removable
		component = renderer.create(<PillList {...props} allowRemove={false} />);
		expect(component.toJSON()).toMatchSnapshot();

		// When items are plain (minimum config)
		component = renderer.create(
			<PillList items={['first', 'second', 'third']} />
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('raises event when pill is removed', () => {
		const handleRemove = jest.fn();
		const component = mount(
			<PillList
				items={items}
				getContent={item => item.title}
				allowRemove
				onPillRemove={handleRemove} />
		);

		// Simulate remove 1st
		component.find('button').at(0).simulate('click');
		expect(handleRemove).toHaveBeenLastCalledWith(items[0]);

		// Simulate remove 2nd
		component.find('button').at(1).simulate('click');
		expect(handleRemove).toHaveBeenLastCalledWith(items[1]);
	});

});
