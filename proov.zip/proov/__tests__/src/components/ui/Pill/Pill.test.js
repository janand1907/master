import React from 'react';
import renderer from 'react-test-renderer';
import { shallow } from 'enzyme';
import Pill from 'components/ui/Pill/Pill';

describe('<Pill />', () => {

	it('renders correctly when removable', () => {
		const component = renderer.create(
			<Pill className="foo" allowRemove>bar</Pill>
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('renders correctly when not removable', () => {
		const component = renderer.create(
			<Pill className="foo">bar</Pill>
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('raises event when remove button is clicked', () => {
		const spy = jest.fn();
		const component = shallow(
			<Pill allowRemove onRemove={spy}>bar</Pill>
		);
		component.find('button').simulate('click');
		expect(spy).toHaveBeenCalledTimes(1);
	});

});
