import React from 'react';
import renderer from 'react-test-renderer';
import MultiSelect from 'components/ui/MultiSelect/MultiSelect';

const optionsObj = {
	'34584359': { name: 'John', gender: 'Male' },
	'34584334': { name: 'Dave', gender: 'Male' },
	'34584323': { name: 'Mike', gender: 'Male' },
	'34584354': { name: 'Sara', gender: 'Femle' }
};

const optionsArr = [
	{ name: 'John', gender: 'Male', id: '34584354' },
	{ name: 'Dave', gender: 'Male', id: '34584359' },
	{ name: 'Mike', gender: 'Male', id: '34584334' },
	{ name: 'Sara', gender: 'Femle', id: '34584323' }
];

const selectedIds = ['34584354', '34584334'];

describe('<MultiSelect />', () => {

	it('renders correctly with Object', () => {
		const component = renderer.create(
			<MultiSelect
				className="foo"
				options={optionsObj}
				selected={selectedIds}
				getContent={item => optionsObj[item].name} />
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('renders correctly with Array', () => {
		const component = renderer.create(
			<MultiSelect
				className="foo"
				options={optionsArr}
				selected={selectedIds}
				getValue={item => item.id}
				getContent={item => item.name} />
		);
		expect(component.toJSON()).toMatchSnapshot();
	});
});
