import React from 'react';
import renderer from 'react-test-renderer';
import { MemoryRouter as Router } from 'react-router-dom';
import { DetailsIcon, VendorsIcon, ChartIcon, AWSIcon, Menu } from 'components/ui';
import ChannelsMenuContainer from 'components/admin/pilotView/client/analytics/ChannelsMenu/ChannelsMenuContainer';

const	items = [
	{ name: 'details', url: `/admin/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669/details`, text: 'PoC Details', icon: <DetailsIcon className="detailsIcon" />, expandible: null },
	{ name: 'vendors', url: `/admin/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669/vendors`, text: 'Startups/ISVs', icon: <VendorsIcon className="vendorsIcon" />, expandible: null },
	{ name: 'analytics', url: `/admin/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669/analytics`, text: 'Analytics & Simulation', icon: <ChartIcon className="chartIcon" />, expandible: <ChannelsMenuContainer /> },
	{ name: 'export', url: `/admin/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669/export`, text: 'Deploy to AWS Service Catalog', icon: <AWSIcon className="awsIcon" />, expandible: null },
];

describe('<Menu />', () => {

	it('renders correctly with items', () => {
		const component = renderer.create(
			<Router>
				<Menu
					className="foo"
					activeItemClassName="foo_active"
					items={items}
				/>
			</Router>
		);
		expect(component.toJSON()).toMatchSnapshot();
	});
});
