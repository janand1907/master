import React from 'react';
import renderer from 'react-test-renderer';
import Badge from 'components/ui/Badge/Badge';

describe('<Badge />', () => {

	it('renders correctly with children and item', () => {
		const component = renderer.create(
			<Badge className="foo" item={10}><div>test</div></Badge>
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('renders correctly when item equals to 0', () => {
		const component = renderer.create(
			<Badge className="foo" item={0}><div>test</div></Badge>
		);
		expect(component.toJSON()).toMatchSnapshot();
	});

});
