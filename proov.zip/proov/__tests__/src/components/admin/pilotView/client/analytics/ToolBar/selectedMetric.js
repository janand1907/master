const selectedMetric = 	{
	'id': '190',
	'name': 'x190',
	'label': 'Proc Stat Threads Windows',
	'category': 'PROC STAT',
	'unit': '%',
	'range':
    [
    	0.0,
    	65536.0
    ],
	'expression': null
};


export default selectedMetric;
