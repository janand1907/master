// Q: What are User SOAP auth options?
// A: None and basic
//
export default [
	{
		id: 'd967aa7492063499f22e401e2e8f7b80ca2abe1f',
		name: 'User SOAP Auth Basic',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		status: 'ready',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null
	},
	{
		id: 'd967aa7492063499f22e401e2e8f7b80ca2abe1g',
		name: 'User SOAP | Auth None | URL',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'none'
		},
		status: 'ready',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null
	},
	{
		id: 'd967aa7492063499f22e401e2e8f7b80ca2abe1h',
		name: 'User SOAP | Auth None | Spec',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'none'
		},
		status: 'ready',
		api_type: 'soap',
		api_url: null,
		file_resource: 'http://kapob.nu/mi'
	},
	{
		id: 'd967aa7492063499f22e401e2e8f7b80ca2dssad',
		name: 'SOAP API Pending',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		status: 'pending',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null
	},
	{
		id: 'd967aa7492063499f22e401e2e8f7b80ca2dssae',
		name: 'Proov SOAP API',
		is_user_owned: false,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		status: 'ready',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null
	},
	{
		id: 'bc4927270059ed2e49e0e8b0451f4689e3848df1',
		name: 'RESTful API | oAuth2.0 | URL',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'oauth2.0',
			client_id: 'asdfjasdljfasdkjf',
			client_secret: '1912308409123890',
			grant_type: 'client_credentials',
			token_url: 'https://YOUR_AUTH0_DOMAIN/oauth2/token'
		},
		status: 'ready',
		api_type: 'rest',
		api_url: 'http://ti.si/wasle',
		file_resource: null
	},
	{
		id: 'bc4927270059ed2e49e0e8b0451f4689e3848df5',
		name: 'RESTful API | oAuth2.0 | Spec',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'oauth2.0',
			client_id: 'asdfjasdljfasdkjf',
			client_secret: '1912308409123890',
			grant_type: 'password',
			token_url: 'https://YOUR_AUTH0_DOMAIN/oauth2/token',
			username: 'hello',
			password: 'goodbye123'
		},
		status: 'ready',
		api_type: 'rest',
		api_url: null,
		file_resource: {
			label: 'prooV_swagger.json',
			url: 'http://jsonviewer.stack.hu/'
		}
	},
	{
		id: 'bc4927270059ed2e49e0e8b0451f4689e3848df8',
		name: 'RESTful API no. 1',
		is_user_owned: true,
		type: 'api',
		auth: { type: 'none' },
		status: 'pending',
		api_type: 'rest',
		api_url: null,
		file_resource: {
			label: 'prooV_swagger.json',
			url: 'http://jsonviewer.stack.hu/'
		}
	},
	{
		id: 'bc4927270059ed2e49e0e8b0451f4689e3848df9',
		name: 'RESTful API no. 1',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		status: 'ready',
		api_type: 'rest',
		api_url: 'http://www.api.com',
		file_resource: null
	}
];
