import React from 'react';
import { shallow } from 'enzyme';
import SimulationTab from 'components/admin/pilotView/client/analytics/SimulationTab/SimulationTab';

describe('<SimulationTab />', () => {
	const wrapper = shallow(<SimulationTab />);

	it('renders correctly', () => {
		expect(wrapper).toMatchSnapshot();
	});
});
