import React from 'react';
import { shallow } from 'enzyme';
import ToolBar from 'components/admin/pilotView/client/analytics/ToolBar/ToolBar';
import selectedMetric from './selectedMetric';

describe('<ToolBar />', () => {
	const wrapper = shallow(<ToolBar dataType="simulator" selectedMetric={selectedMetric} />);

	it('renders correctly', () => {
		expect(wrapper).toMatchSnapshot();
	});
});
