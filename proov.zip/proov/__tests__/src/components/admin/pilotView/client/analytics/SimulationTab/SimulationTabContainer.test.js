import React from 'react';
import { Provider } from 'react-redux';
import configureMockStore from 'redux-mock-store';
import { shallow } from 'enzyme';
import SimulationTabContainer from 'components/admin/pilotView/client/analytics/SimulationTab/SimulationTabContainer';
import state from './../state';

describe('containers', () => {

	describe('<SimulationTabContainer>', () => {
		let store, wrapper;

		beforeAll(() => {
			store = configureMockStore()(state);

			wrapper = shallow(
				<Provider store={store}>
					<SimulationTabContainer />
				</Provider>
			);
		});

		it('.mapStateToProps()', () => {
			const props = wrapper.props();
			expect(props).toMatchSnapshot();
		});
	});

});
