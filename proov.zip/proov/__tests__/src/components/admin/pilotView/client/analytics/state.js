import { pilot1 } from '@mocks/pilot';
import { metrics } from '@mocks/analytics';

const chartData = [
	{
		'company_id': '1',
		'min': 10,
		'max': 15,
		'avg': 12,
		'samples': [
			{
				'x': 1478174432542,
				'y': 14
			},
			{
				'x': 1479296816709,
				'y': 10
			},
			{
				'x': 1480419200876,
				'y': 10
			},
			{
				'x': 1481541585043,
				'y': 11
			}
		]
	},
	{
		'company_id': '2',
		'min': 47,
		'max': 63,
		'avg': 50,
		'samples': [
			{
				'x': 1478174431710,
				'y': 54
			},
			{
				'x': 1479296815894,
				'y': 58
			},
			{
				'x': 1480419200078,
				'y': 54
			},
			{
				'x': 1481541584262,
				'y': null
			}
		]
	},
	{
		'company_id': '3',
		'min': 31,
		'max': 39,
		'avg': 31,
		'samples': [
			{
				'x': 1478174431511,
				'y': 33
			},
			{
				'x': 1479296815699,
				'y': 31
			},
			{
				'x': 1480419199887,
				'y': 36
			},
			{
				'x': 1481541584075,
				'y': 36
			}
		]
	},
	{
		'company_id': '4',
		'min': 84,
		'max': 84,
		'avg': 77,
		'samples': [
			{
				'x': 1478174432290,
				'y': 84
			},
			{
				'x': 1479296816462,
				'y': 84
			},
			{
				'x': 1480419200634,
				'y': 84
			},
			{
				'x': 1481541584806,
				'y': 84
			}
		]
	},
	{
		'company_id': '5',
		'min': 10,
		'max': 11,
		'avg': 10,
		'samples': [
			{
				'x': 1478174432054,
				'y': 10
			},
			{
				'x': 1479296816231,
				'y': 11
			},
			{
				'x': 1480419200408,
				'y': 10
			},
			{
				'x': 1481541584585,
				'y': 11
			}
		]
	}
];


const state = {
	admin: {
		pilot: {
			data: pilot1,
			pending: false,
			pendingUpdate: false,
			pendingMedia: false,
			pendingAccept: false,
			pendingDeny: false,
			fieldsPending: false,
			pendingCheckout: false
		},
		analytics: {
			general: {
				channelId: undefined,
				allMetrics: { data: metrics, pending: false, error: null },
				selectedMetric: undefined,
				deleteMetric: { pending: false, error: null },
				tab: 'analytics',
				selectedVendors: pilot1.vendors.map(v => v.id),
			},
			charts: {
				context: { data: chartData, pending: false, error: null, from: pilot1.start_time, to: pilot1.end_time },
				focus: { data: chartData, pending: false, error: null, from: pilot1.start_time, to: pilot1.end_time },
				live: { data: chartData, pending: false, error: null, from: pilot1.start_time, to: pilot1.end_time }
			},
			simulator: {
				selectedParam1: metrics[0],
				selectedParam2: metrics[1],
				vendorId: '1',
				pending: true,
				data: {
					x1: [
						{
							...metrics[0],
							children: [
								metrics[1], metrics[2], metrics[3]
							]
						},
						{
							...metrics[4],
							children: [
								metrics[5], metrics[6], metrics[7]
							]
						},
					],
					y: '100',
					cpp_id: '5a863ef7e1b2c200c1bdfc9b9a186271baaa276d'
				},
				error: '',
				x1Value: 0,
				x2Value: 0,
				prediction: {
					pending: false,
					data: null
				}
			}
		}
	}
};

export default state;
