import React from 'react';
import { shallow } from 'enzyme';
import TestResult from 'components/admin/pilotView/client/analytics/CustomMetric/TestResult/TestResult';

describe('<TestResult />', () => {
	const spy = jest.fn();
	const component = shallow(
		<TestResult
			isTestReady={true}
			placeholder="RESULT"
			pending={false}
			result="test"
			onTest={spy}
		/>
	);
	it('renders correctly', () => {
		expect(component).toMatchSnapshot();
	});

	it('raises event when test button is clicked', () => {
		component.find('button').simulate('click');
		expect(spy).toHaveBeenCalledTimes(1);
	});
});
