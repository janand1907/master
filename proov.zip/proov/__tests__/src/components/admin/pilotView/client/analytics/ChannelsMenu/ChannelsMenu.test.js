import React from 'react';
import { mount } from 'enzyme';
import ChannelsMenu from 'components/admin/pilotView/client/analytics/ChannelsMenu/ChannelsMenu';
import ItemsList from 'components/ui/ItemsExplorer/ItemsList';

xdescribe('<ChannelsMenu />', () => {
	let wrapper, spy;
	const channels = [{ id: null, name: 'Business KPI\'s' }];
	beforeAll(() => {
		spy = jest.fn();
		wrapper = mount(<ChannelsMenu channels={channels} onSetChannel={spy} channelId={channels[0].id} />);
	});

	it('renders correctly', () => {
		expect(wrapper).toMatchSnapshot();
	});

	it('raises onSetChannel when selecting channel', () => {
		let channel = wrapper.find(ItemsList)
			.first()
			.childAt(0);
		channel.simulate('click');
		expect(spy).toHaveBeenCalledTimes(1);
	});
});
