import React from 'react';
import { shallow } from 'enzyme';
import Details from 'components/admin/common/channels/channelCard/details/Storage';
import mocks from '@mocks/channels/storage';

describe('Storage Channel Card', () => {

	it('With Password', () => {
		const props = mocks.sftp_1;
		const tree = shallow(<Details {...props} />);
		expect(tree).toMatchSnapshot();
	});

	it('With Credential', () => {
		const props = mocks.sftp_2;
		const tree = shallow(<Details {...props} />);
		expect(tree).toMatchSnapshot();
	});
});
