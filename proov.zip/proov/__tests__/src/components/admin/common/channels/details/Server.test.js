import React from 'react';
import { shallow } from 'enzyme';
import mocks from '@mocks/channels/servers';
import Details from 'components/admin/common/channels/channelCard/details/Server';

describe('Servers Channel Details', () => {

	// Q: What's proov's SSH credentials
	// A: Only PEM
	describe('Proov\'s Servers', () => {

		it('RDC | READY | password', () => {
			const props = mocks.proov_1;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('RDC | PENDING | password', () => {
			const props = mocks.proovu_2;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('SSH | READY | password', () => {
			const props = mocks.proov_3;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('SSH | PENDING | password', () => {
			const props = mocks.proov_4;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('Five labels', () => {
			const props = mocks.proov_4;
			const wrapper = shallow(<Details {...props} />);
	     expect(wrapper.find('dd')).toHaveLength(5);
		});
	});

	// Q: What's User SSH credentials
	// A: Password or PEM
	describe('Users\'s Servers', () => {
		it('SSH | READY | password', () => {
			const props = mocks.user_1;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('SSH | READY | PEM', () => {
			const props = mocks.user_2;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('SSH | PEANDING | PEM', () => {
			const props = mocks.user_3;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});
	});
});
