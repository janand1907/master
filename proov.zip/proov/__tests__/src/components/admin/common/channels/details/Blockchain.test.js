import React from 'react';
import { shallow } from 'enzyme';
import Details from 'components/admin/common/channels/channelCard/details/Blockchain';
import mocks from '@mocks/channels/blockchain';

describe('Blockchain Channel Card', () => {

	it('With Password', () => {
		const props = mocks.blockchain_channel;
		const tree = shallow(<Details {...props} />);
		expect(tree).toMatchSnapshot();
	});
});
