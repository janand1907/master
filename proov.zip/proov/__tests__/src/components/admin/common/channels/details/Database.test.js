import React from 'react';
import { shallow } from 'enzyme';
import Details from 'components/admin/common/channels/channelCard/details/Database';
import mocks from '@mocks/channels/databases';

describe('Database Channel Details', () => {

	describe('Proov Database', () => {
		it('Postgres', () => {
			const props = mocks.db_1;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('mySQL', () => {
			const props = mocks.db_2;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('Pending', () => {
			const props = mocks.db_3;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});
	});

	describe('User Database', () => {

		it('Redshift DB', () => {
			const props = mocks.db_4;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('Bigquery DB', () => {
			const props = mocks.db_5;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});

		it('Pending', () => {
			const props = mocks.db_6;
			const tree = shallow(<Details {...props} />);
			expect(tree).toMatchSnapshot();
		});
	});
});
