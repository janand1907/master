import React from 'react';
import { shallow} from 'enzyme';
import renderer from 'react-test-renderer';
import ApiAuthTypeField from 'components/admin/common/channels/ChannelForm/commonFields/ApiAuthTypeField'

xdescribe('<ApiAuthTypeField>', () => {
    let state, store, wrapper, component;

    const props = {
        name: "",
        authType: "",
        grantType: ""
    };

   beforeAll(() => {
        wrapper = shallow(<ApiAuthTypeField  {...props} />);

    });

    it("renders without crashing", () => {
        expect(wrapper.length).toEqual(1);
    });

    it("snapshot", () => {
        expect(wrapper).toMatchSnapshot();
    });

 });
