import getEnvsMocks from '@utils/getEnvironmentMock';
import React from 'react';
import { shallow } from 'enzyme';
import ChannelCard from 'components/admin/createPilot/env/ChannelCard';


xdescribe('<ChannelCard/>', () => {

	const eventHandlers = {
		editCard: () => {},
		deleteCard: () => {}
	};

	it('snapshot: all environment types', () => {
		getEnvsMocks().forEach((item, index) => {
			const props = {
				index,
				data: item,
				...eventHandlers
			};
			const tree = shallow(<ChannelCard {...props} />);
			expect(tree).toMatchSnapshot();
		});

	});
});
