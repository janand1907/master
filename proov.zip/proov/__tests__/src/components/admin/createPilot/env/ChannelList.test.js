import getEnvsMocks from '@utils/getEnvironmentMock';
import React from 'react';
import { shallow } from 'enzyme';
import ChannelList from 'components/admin/createPilot/env/ChannelList';


describe('<ChannelList>', () => {
	const eventHandlers = {
		newEnvironmentClick: () => {},
		editEnvironmentClick: () => {},
		deleteEnvironmentClick: () => {}
	};


	describe('Array of channels', () => {

		const props = {
			channels: getEnvsMocks(),
			errors: null,
			...eventHandlers
		};

		it('snapshot', () => {
			const tree = shallow(<ChannelList {...props} />);
			expect(tree).toMatchSnapshot();
		});

	});

	describe('Array of channels:error', () => {

		const props = {
			channels: getEnvsMocks(),
			errors: {
				'0': { 'name': 'Invalid email address' },
				'1': { 'email': 'Component name is required' }
			},
			...eventHandlers
		};

		it('snapshot', () => {
			const tree = shallow(<ChannelList {...props} />);
			expect(tree).toMatchSnapshot();
		});

	});

});
