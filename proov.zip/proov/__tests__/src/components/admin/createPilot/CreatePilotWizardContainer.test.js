import React from 'react';
import { Provider } from 'react-redux';
import configureMockStore from 'redux-mock-store';
import { mount } from 'enzyme';
import rootReducer from './../../../../../src/ducks';
import CreatePilotWizard from './../../../../../src/components/admin/createPilot/CreatePilotWizard';
import CreatePilotWizardContainer from './../../../../../src/components/admin/createPilot/CreatePilotWizardContainer';

describe('containers', () => {

	xdescribe('<CreatePilotWizardContainer>', () => {

		let state = rootReducer(undefined, { type: ['@@form'], meta: { form: {} } });
		const store = configureMockStore()(() => state);
		const wrapper = mount(
			<Provider store={store}>
				<CreatePilotWizardContainer />
			</Provider>
		);
		const wrapped = wrapper.find(CreatePilotWizard).first();

		it('.mapStateToProps', () => {
			// w/o tasks
			expect(wrapped.props()).toMatchSnapshot();

			// w/ tasks
			// const initialAction = {
			// 	type: types.GET_SUCCESS,
			// 	payload: [
			// 		{
			// 			id: 'foo',
			// 			status: TaskStatus.SUCCESS,
			// 			type: 'db',
			// 			progress: 1,
			// 			title: 'foo title',
			// 			assetId: null
			// 		},
			// 	]
			// };
			// state = rootReducer(undefined, initialAction);
			// wrapper.update();
			// expect(wrapped.props()).toMatchSnapshot();
		});

		xit('.mapDispatchToProps', () => {
			const { onFormSubmit } = wrapped.props();

			expect(onFormSubmit).toBeInstanceOf(Function);
			onDismiss('foo');

			expect(store.getActions()).toEqual([
				dismissTask('foo')
			]);
		});

	});

});
