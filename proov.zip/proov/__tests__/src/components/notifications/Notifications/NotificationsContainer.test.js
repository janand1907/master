import React from 'react';
import { shallow } from 'enzyme';
import { NotificationsContainer } from './../../../../../src/components/notifications/Notifications/NotificationsContainer';

describe('containers', () => {

	describe('<NotificationsContainer>', () => {

		let wrapper;
		// our mock getNotifications function to replace the one provided by mapDispatchToProps
		const getNotifications = jest.fn();
		const dismissNotifications = jest.fn();
		const markAsRead = jest.fn();

		let props = {
			actions: { getNotifications, dismissNotifications, markAsRead },
			pending: { firstLoad: null, loadMore: null },
			notifications: [],
			isMoreToLoad: false,
			limit: 30,
			onSelect: jest.fn(),
		};

		beforeEach(() => {
			getNotifications.mockReset();
			wrapper = shallow(<NotificationsContainer {...props} />);
		});


		it('CWM invoked', () => {
			expect(getNotifications.mock.calls.length).toBe(1);
			expect(getNotifications.mock.calls[0]).toEqual(
				[30, 0, true]
			);
		});

		it('CWUM invoked', () => {

			wrapper.unmount();
			expect(dismissNotifications).toHaveBeenCalled();
		});

		it('Render', () => {
			wrapper = shallow(<NotificationsContainer {...props} />);
			expect(wrapper.find('Notifications').length).toBe(1);
		});

		it('handleLoadMore func', () => {
			// first run func does nothing because isMoreToLoad is false
			const value = wrapper.instance().handleLoadMore();
			expect(value).toBe(undefined);
			// already been called on CWM ones
			expect(getNotifications).toHaveBeenCalledTimes(1);


			wrapper = shallow(<NotificationsContainer {...props} isMoreToLoad={true} limit={1} />);
			wrapper.instance().handleLoadMore();
			expect(getNotifications.mock.calls[1]).toEqual(
				[1, 0, true]
			);

		});

		it('handleSelect func', () => {
			const syntheticEvent = { persist: () => { }, stopPropagation: () => { }, currentTarget: { id: 'Foo' } };
			wrapper.instance().handleSelect(syntheticEvent);

			expect(props.onSelect).toHaveBeenCalled();
			expect(markAsRead).toHaveBeenCalled();
			expect(markAsRead.mock.calls[0]).toEqual(
				['Foo']
			);
		});
	});
});
