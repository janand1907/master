import React from 'react';
import { shallow } from 'enzyme';
import Notifications from './../../../../../src/components/notifications/Notifications/Notifications';

describe('containers', () => {

	describe('<Notifications>', () => {

		let wrapper;

		let props = {
			notifications: ['foo'],
			pendingLoadMore: false,
			pendingFirstLoad: false,
			isMoreToLoad: false,
			onLoadMore: jest.fn(),
			onSelect: jest.fn(),
		};

		it('Render without problems', () => {
			wrapper = shallow(<Notifications {...props} />);

			expect(wrapper.find('h6').at(0)
				.text()).toEqual('Notifications');

		});

		it('Render no Notifications Message', () => {
			wrapper = shallow(<Notifications {...props} notifications={[]} />);

			expect(wrapper.find('p').at(0)
				.text()).toEqual('You don\'t have any notifications');
		});

	});
});
