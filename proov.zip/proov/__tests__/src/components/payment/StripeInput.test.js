import React from 'react';
import { shallow } from 'enzyme';
import StripeInput from './../../../../src/components/payment/StripeInput';

describe('<StripeInput />', () => {
	let spyCdm, spyOnLoaded, wrapper;
	beforeAll(() => {
		spyOnLoaded = jest.fn();
		spyCdm = spyOn(StripeInput.prototype, 'componentDidMount');
		wrapper = shallow(<StripeInput onLoaded={spyOnLoaded} onChange={() => {}} onReadyChange={() => {}} />);
	});

	it('should render correctly', () => {
		expect(wrapper).toMatchSnapshot();
	});

	it('should call componentDidMount', () => {
		wrapper.instance().componentDidMount();
		expect(spyCdm).toHaveBeenCalled();
	});
});

