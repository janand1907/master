import React from 'react';
import { shallow } from 'enzyme';
import AllowSuggestion from '../../../../../src/components/myAccount/section/GeneralInformation/AllowSuggestion';

xdescribe('AllowSuggestion component', () => {
	it('in', () => {
		expect(shallow(<AllowSuggestion />));
	});
});
