import React from 'react';
import { Provider } from 'react-redux';
import configureMockStore from 'redux-mock-store';
import { shallow, mount } from 'enzyme';
import AddUserForm from '../../../../../../src/components/myAccount/section/TeamManagement/AddUserForm';

jest.mock('../../../../../../src/components/common/Forms/Error.js', () => 'Error');
jest.mock('../../../../../../src/components/common/Forms/Field.js', () => 'Field');
jest.mock('../../../../../../src/components/common/Forms/Form.js', () => 'Form');

describe('components', () => {

	let state, store, wrapper, component;

	describe('<AddUserForm>', () => {

		const onCancel = jest.fn();

		state = {};
		store = configureMockStore()(state);

		const props = {
			onCancel,
			pending: false,
			formProps: {}
		};
		wrapper = mount(
			<Provider store={store}>
				<AddUserForm {...props} />
			</Provider>
		);


		it('snapshot', () => {
			let component = shallow(<AddUserForm {...props} />);
			expect(component).toMatchSnapshot();
		});

		it('Cancel button click', () => {
			wrapper.find('button').at(0)
				.simulate('click');
			expect(onCancel).toHaveBeenCalled();
		});

	});

});
