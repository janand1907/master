import React from 'react';
import { shallow, mount } from 'enzyme';
import TeamManagement from '../../../../../../src/components/myAccount/section/TeamManagement/TeamManagement';

describe('components', () => {

	describe('<TeamManagement>', () => {

		const onAdd = jest.fn();
		const onEdit = jest.fn();

		const props = {
			onAdd,
			onEdit,
			myId: 1,
			users: []
		};

		it('snapshot', () => {
			let component = shallow(<TeamManagement {...props} />);
			expect(component).toMatchSnapshot();
		});

		it('Add button click', () => {
			let component = mount(<TeamManagement {...props} />);
			component.find('button').find('button')
				.first()
				.simulate('click');
			expect(onAdd).toHaveBeenCalled();
		});

	});

});
