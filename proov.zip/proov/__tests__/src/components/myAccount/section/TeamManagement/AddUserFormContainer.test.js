import React from 'react';
import { Provider } from 'react-redux';
import configureMockStore from 'redux-mock-store';
import { mount } from 'enzyme';
import AddUserFormContainer from '../../../../../../src/components/myAccount/section/TeamManagement/AddUserFormContainer';
import AddUserForm from '../../../../../../src/components/myAccount/section/TeamManagement/AddUserForm';

jest.mock('../../../../../../src/components/common/Forms/Error.js', () => 'Error');

describe('containers', () => {

	describe('<AddUserFormContainer>', () => {
		let state, store, wrapper, component;

		beforeEach(() => {
			state = {
				myAccount: {
					team: {
						users: [],
						pending: {
							addPending: false
						}
					}
				},
				me: {
					company: {
						data: {
							name: 'Company name'
						}
					}
				}
			};
			store = configureMockStore()(state);
			wrapper = mount(
				<Provider store={store}>
					<AddUserFormContainer />
				</Provider>
			);
			component = wrapper.find(AddUserForm).first();
		});

		it('.mapStateToProps()', () => {
			const props = component.props();
			expect(props).toMatchSnapshot();
			expect(props.onCancel).toBeInstanceOf(Function);
		});

	});

});
