import React from 'react';
import { Provider } from 'react-redux';
import configureMockStore from 'redux-mock-store';
import { mount } from 'enzyme';
import EditUserFormContainer from '../../../../../../src/components/myAccount/section/TeamManagement/EditUserFormContainer';
import EditUserForm from '../../../../../../src/components/myAccount/section/TeamManagement/EditUserForm';

jest.mock('../../../../../../src/components/common/Forms/modelSelector.js', () => 'model');
jest.mock('../../../../../../src/components/common/Forms/Error.js', () => 'Error');

describe('containers', () => {

	describe('<EditUserFormContainer>', () => {
		let state, store, wrapper, component;

		beforeEach(() => {
			state = {
				myAccount: {
					team: {
						users: [],
						pending: {
							getPending: false,
							deletePending: false,
							updatePending: false,
						}
					}
				},
				forms: {
					'userEditForm': {}
				}
			};
			store = configureMockStore()(state);
			wrapper = mount(
				<Provider store={store}>
					<EditUserFormContainer />
				</Provider>
			);
			component = wrapper.find(EditUserForm).first();
		});

		xit('.mapStateToProps()', () => {
			const props = component.props();
			expect(props).toMatchSnapshot();
			expect(props.onCancel).toBeInstanceOf(Function);
		});

	});

});
