import React from 'react';
import { Provider } from 'react-redux';
import configureMockStore from 'redux-mock-store';
import { shallow, mount } from 'enzyme';
import EditUserForm from '../../../../../../src/components/myAccount/section/TeamManagement/EditUserForm';

jest.mock('../../../../../../src/components/common/Forms/Error.js', () => 'Error');
jest.mock('../../../../../../src/components/common/Forms/Field.js', () => 'Field');
jest.mock('../../../../../../src/components/common/Forms/Form.js', () => 'Form');

describe('components', () => {

	let state, store, wrapper, component;

	describe('<EditUserForm>', () => {

		const onCancel = jest.fn();
		const onRemove = jest.fn();

		state = {};
		store = configureMockStore()(state);

		const props = {
			user: {},
			deletePending: false,
			pending: false,
			formProps: {},
			onCancel,
			onRemove,
			modelStatus: 'active'
		};
		wrapper = mount(
			<Provider store={store}>
				<EditUserForm {...props} />
			</Provider>
		);


		it('snapshot', () => {
			let component = shallow(<EditUserForm {...props} />);
			expect(component).toMatchSnapshot();
		});

		it('Cancel button click', () => {
			wrapper.find('button').at(1)
				.simulate('click');
			expect(onCancel).toHaveBeenCalled();
		});

	});

});
