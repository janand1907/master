import React from 'react';
import renderer from 'react-test-renderer';
import { MemoryRouter as Router } from 'react-router-dom';
import MyAccountMenu from '../../../../../src/components/myAccount/menu/MyAccountNav';


describe('My Account Menu', () => {
	it('Prop Type: client', () => {
		const props = { type: 'client', authType: 'proov' };
		const tree = renderer.create(
			<Router><MyAccountMenu {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});

	it('Prop Type: vendor', () => {
		const props = { type: 'vendor', authType: 'proov' };
		const tree = renderer.create(
			<Router><MyAccountMenu {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});

	it('Prop authType: proov', () => {
		const props = { type: 'vendor', authType: 'proov' };
		const tree = renderer.create(
			<Router><MyAccountMenu {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});

	it('Prop authType: linkedin', () => {
		const props = { type: 'vendor', authType: 'linkedin' };
		const tree = renderer.create(
			<Router><MyAccountMenu {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});

	it('Prop onSelect: function', () => {
		const props = { type: 'vendor', authType: 'linkedin' };
		const tree = renderer.create(
			<Router><MyAccountMenu {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});
});
