import { isAllRegionChecked, isAllRegionUnchecked, mapCountriesByRegion, isRegionPartiallychecked } from 'components/common/CountrySelect/utils.js';
import { country } from '@mocks/common.js';

describe('CountrySelect utils', () => {
	let region = mapCountriesByRegion(
		{
			'Guatemala': country.Guatemala,
			'Panama': country.Panama,
			'Nicaragua': country.Nicaragua
		}
	)['Latin America'];
	const regionIds = region.map(country => { return country.id });
	const partiallyChecked = regionIds.filter(country => (country !== 'Panama'));

	it('isAllRegionChecked - should return true (fully checked)', () => {
		expect(isAllRegionChecked(region, regionIds)).toBeTruthy();
	});

	it('isAllRegionChecked - should return false (partially checked)', () => {
		expect(isAllRegionChecked(region, partiallyChecked)).toBeFalsy();
	});

	it('isAllRegionUnchecked - should return true (fully unchecked)', () => {
		expect(isAllRegionUnchecked(region, [])).toBeTruthy();
	});

	it('isAllRegionUnchecked - should return false (partially unchecked)', () => {
		expect(isAllRegionUnchecked(region, partiallyChecked)).toBeFalsy();
	});

	it('isRegionPartiallychecked - should return true (partially checked)', () => {
		expect(isRegionPartiallychecked(region, partiallyChecked)).toBeTruthy();
	});

	it('isRegionPartiallychecked - should return false (fully checked)', () => {
		expect(isRegionPartiallychecked(region, regionIds)).toBeFalsy();
	});

	xit('isRegionPartiallychecked - should return false (fully unchecked)', () => {
		expect(isRegionPartiallychecked(region, [])).toBeFalsy();
	});
});
