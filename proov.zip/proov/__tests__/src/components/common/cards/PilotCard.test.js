import React from 'react';
import renderer from 'react-test-renderer';
import { MemoryRouter as Router } from 'react-router-dom';
import PilotCard from 'components/common/cards/PilotCard/PilotCard';
import { pilots } from '@mocks/pilot';

const pilot = pilots[0];
xdescribe('Pilot Card', () => {

	it('Props:: data, isOwn: false', () => {
		const props = { data: pilot, isOwn: false };
		const tree = renderer.create(
			<Router><PilotCard {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});


	it('Props:: data, isOwn: true', () => {
		const props = { data: pilot, isOwn: true };
		const tree = renderer.create(
			<Router><PilotCard {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});
});
