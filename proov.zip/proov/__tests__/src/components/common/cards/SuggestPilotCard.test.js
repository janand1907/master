import React from 'react';
import renderer from 'react-test-renderer';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import SuggestPilotCard from 'components/common/cards/SuggestPilotCard/SuggestPilotCard';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);
const store = mockStore({ });

xdescribe('Suggest Pilot Card', () => {
	it('SuggestPilotCard', () => {
		const tree = renderer.create(
			<Provider store={store}>
				<SuggestPilotCard onSuggest={new Function()} />
			</Provider>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});
});
