import React from 'react';
import renderer from 'react-test-renderer';
import { MemoryRouter as Router } from 'react-router-dom';
import CompanyCard from 'components/common/cards/CompanyCard/CompanyCard';
import { vendor, client } from '@mocks/company';

describe('Vendor Company Card', () => {

	it('Props:: isViewable: false, isSuggestable: false', () => {
		const func = new Function();
		const isViewable = function () { return false };
		const isSuggestable = function () { return false };

		const props = { data: vendor, isViewable, isSuggestable, onSuggest: func };
		const tree = renderer.create(
			<Router><CompanyCard {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});

	it('Props:: isViewable: true, isSuggestable: true', () => {
		const func = new Function();
		const isViewable = function () { return false };
		const isSuggestable = function () { return false };

		const props = { data: vendor, isViewable, isSuggestable, onSuggest: func };
		const tree = renderer.create(
			<Router><CompanyCard {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});
});

xdescribe('Client Company Card', () => {

	it('Props:: isViewable: false, isSuggestable: false', () => {
		const func = new Function();
		const isViewable = function () { return false };
		const isSuggestable = function () { return false };

		const props = { data: client, isViewable, isSuggestable, onSuggest: func };
		const tree = renderer.create(
			<Router><CompanyCard {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});

	it('Props:: isViewable: true, isSuggestable: true', () => {
		const func = new Function();
		const isViewable = function () { return true };
		const isSuggestable = function () { return true };

		const props = { data: client, isViewable, isSuggestable, onSuggest: func };
		const tree = renderer.create(
			<Router><CompanyCard {...props} /></Router>
		).toJSON();
		expect(tree).toMatchSnapshot();
	});

});
