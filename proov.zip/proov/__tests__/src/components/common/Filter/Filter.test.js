import React from 'react';
import renderer from 'react-test-renderer';
import { Filter } from 'components/common/Filter';

const options = {
	status: {
		title: 'Status',
		items: {
			'in_progress': { selected: false, label: 'In progress' },
			'success': { selected: false, label: 'Ready' },
			'new': { selected: false, label: 'Draft' }
		}
	},
	tables: {
		title: '# of tables ',
		items: {
			'1-10': { selected: false, label: '1-10' },
			'11-20': { selected: false, label: '11-20' },
		}
	}
};

describe('Filter component', () => {

	it('Filter::Snapshot visible', () => {
		const filter = renderer.create(
			<Filter
				options={options}
				showFilter={true}
			/>
		);

		let tree = filter.toJSON();
		expect(tree).toMatchSnapshot();
	});


	it('Filter::Snapshot hidden', () => {
		const filter = renderer.create(
			<Filter
				options={options}
				showFilter={false}
			/>
		);

		let tree = filter.toJSON();
		expect(tree).toMatchSnapshot();
	});

});
