import renderer from 'react-test-renderer';
import React from 'react';
import { Footer } from 'components/common/Footer';

describe('<Footer />', () => {
	global.__PROD__ = false;

	it('renders correctly for Enterprise', () => {
		const tree = renderer.create(
			<Footer companyType="client" />
		).toJSON();
		expect(tree).toMatchSnapshot();
	});

	it('renders correctly for Startup', () => {
		const tree = renderer.create(
			<Footer companyType="vendor" />
		).toJSON();
		expect(tree).toMatchSnapshot();
	});
});
