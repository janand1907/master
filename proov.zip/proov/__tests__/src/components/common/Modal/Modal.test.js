import React from 'react';
import renderer from 'react-test-renderer';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import { Modal } from 'components/common/Modal';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

describe('<Modal />', () => {

	it('Modal::Snapshot', () => {
		let store = mockStore({ modal: { 	modalType: '', isOpen: false, canClose: false, data: null } });
	  let tree = renderer.create(<Provider store={store}><Modal /></Provider>);
	  expect(tree).toMatchSnapshot();

		store = mockStore({ modal: { 	modalType: '', isOpen: true, canClose: true, data: null } });
	  tree = renderer.create(<Provider store={store}><Modal /></Provider>);
	  expect(tree).toMatchSnapshot();
	});

});
