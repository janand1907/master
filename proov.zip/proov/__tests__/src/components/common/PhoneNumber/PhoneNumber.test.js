import React from 'react';
import renderer from 'react-test-renderer';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { shallow } from 'enzyme';
import { Provider } from 'react-redux';
import PhoneNumber from 'components/common/PhoneNumber/PhoneNumber.js';


const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

const country = {
	'Afghanistan': {
		'code': 'AF',
		'dial_code': '93',
		'label': 'Afghanistan',
		'region': 'Asia'
	},
	'Albania': {
		'code': 'AL',
		'dial_code': '355',
		'label': 'Albania',
		'region': 'East Europe'
	} };
const store = mockStore({ lookups: { country } });

describe('PhoneNumber componen', () => {
	it('PhoneNumber::render, input validation', () => {

		const phoneNumber = shallow(
			<PhoneNumber store={store} value={['AF','8610355']} /> //eslint-disable-line
	  );
		expect(phoneNumber.state('code')).toBe('AF');
		expect(phoneNumber.state('number')).toBe('8610355');

		expect(phoneNumber.find('input').props().value).toEqual('8610355');
		expect(phoneNumber.state('code')).toBe('AF');
		expect(phoneNumber.state('number')).toBe('8610355');

		phoneNumber.find('input').simulate('change', { target: { value: 'asfdadsf' } });
		expect(phoneNumber.find('input').props().value).toEqual('');
		expect(phoneNumber.state('code')).toBe('AF');
		expect(phoneNumber.state('number')).toBe('');

		phoneNumber.find('input').simulate('change', { target: { value: ' ' } });
		expect(phoneNumber.find('input').props().value).toEqual('');
		expect(phoneNumber.state('code')).toBe('AF');
		expect(phoneNumber.state('number')).toBe('');

		phoneNumber.find('input').simulate('change', { target: { value: '1234567890' } });
		expect(phoneNumber.find('input').props().value).toEqual('1234567890');
		expect(phoneNumber.state('code')).toBe('AF');
		expect(phoneNumber.state('number')).toBe('1234567890');

	});

	it('PhoneNumber::Snapshot', () => {
		const phoneNumber = renderer.create(
			<Provider store={store}><PhoneNumber value={['AF', '8610355']} /></Provider>
    );

		let tree = phoneNumber.toJSON();
		expect(tree).toMatchSnapshot();
	});

});
