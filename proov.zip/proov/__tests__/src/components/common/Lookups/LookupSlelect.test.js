import React from 'react';
// import renderer from 'react-test-renderer';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { mount } from 'enzyme';
import LookupSelect from 'components/common/Lookups/LookupSelect.js';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

describe('LookupSelect componen', () => {

	const store = mockStore({ lookups: { country: {
		data: {
			'Afghanistan': 'Afghanistan',
			'Albania': 'Albania'
		} } } });
	const lookupSelect = mount(<LookupSelect lookupType="country" store={store} lazy={false} />);

	it('LookupSelect::render,toggle', () => {
		expect(lookupSelect.text()).toBe('Select...');
		lookupSelect.find('span').at(0).simulate('click');
		expect(lookupSelect.text()).toBe('Select...Select...AfghanistanAlbania');
		expect(lookupSelect.find('li').at(0).text()).toBe('Select...');
		expect(lookupSelect.find('li').at(1).text()).toBe('Afghanistan');
		expect(lookupSelect.find('li').at(2).text()).toBe('Albania');
		lookupSelect.find('span').at(0).simulate('click');
		expect(lookupSelect.text()).toBe('Select...');
	});

});
