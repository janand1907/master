
import { pilot1 as pilot } from '@mocks/pilot';
import { vendor as company } from '@mocks/company';
import * as actionTypes from 'ducks/marketplace/types';
import reducer from 'ducks/marketplace/reducers';

const initialState = {
	pilot: null,
	company: null,
	pending: { pilot: false, company: false }
};

describe('marketplaceReducer', () => {
	it('initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it('PILOT_FETCH_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_FETCH_REQUEST,
		}))
			.toEqual({
				...initialState, pending: { ...initialState.pending, pilot: true }
			});
	});

	it('PILOT_FETCH_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, pilot: true } }, {
			type: actionTypes.PILOT_FETCH_SUCCESS,
			payload: pilot,
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, pilot: false }, pilot: pilot });
	});

	it('PILOT_FETCH_FAILURE', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, pilot: true } }, {
			type: actionTypes.PILOT_FETCH_FAILURE
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, pilot: false } });
	});

	it('PILOT_FIELDS_FETCH_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_FIELDS_FETCH_REQUEST,
		}))
			.toEqual({
				...initialState
			});
	});

	it('PILOT_FIELDS_FETCH_SUCCESS', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_FIELDS_FETCH_SUCCESS,
			payload: pilot,
		}))
			.toEqual({ ...initialState, pilot: { ...initialState.pilot, joinable: pilot.joinable } });
	});

	it('PILOT_FIELDS_FETCH_FAILURE', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_FIELDS_FETCH_FAILURE
		}))
			.toEqual({ ...initialState });
	});

	it('COMPANY_FETCH_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.COMPANY_FETCH_REQUEST,
		}))
			.toEqual({
				...initialState, pending: { ...initialState.pending, company: true }
			});
	});

	it('COMPANY_FETCH_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, company: true } }, {
			type: actionTypes.COMPANY_FETCH_SUCCESS,
			payload: company,
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, company: false }, company: company });
	});

	it('COMPANY_FETCH_FAILURE', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, company: true } }, {
			type: actionTypes.COMPANY_FETCH_FAILURE
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, company: false } });
	});
});
