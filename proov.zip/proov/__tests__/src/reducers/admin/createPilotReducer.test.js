import { pilots } from '@mocks/pilot';
import * as actionTypes from 'ducks/admin/createPilot/types';
import reducer from 'ducks/admin/createPilot/reducers';

const initialState = {
	data: {},			// pilot data, aggregates data for review & confirm
	pending: false,
	step: null,
	componentCount: 0,	// number of components added successfully
	componentIndex: 0,	// index for currently edited components
	channelErrors: {}, // Server errors
	isUploadInProcess: false,
};

const error = { message: 'some error message' };

describe('createPilotReducer', () => {
	it('initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it('RESET', () => {
		expect(reducer({ ...initialState, pendingPost: true }, {
			type: actionTypes.RESET
		}))
			.toEqual({ ...initialState });
	});

	it('CREATE_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.CREATE_REQUEST
		}))
			.toEqual({
				...initialState, pending: true
			});
	});

	it('CREATE_SUCCESS', () => {
		const data = pilots[0];
		expect(reducer({ ...initialState, pending: true }, {
			type: actionTypes.CREATE_SUCCESS,
			payload: data
		}))
			.toEqual({ ...initialState, pending: false, data });
	});

	it('CREATE_FAILURE', () => {
		expect(reducer({ ...initialState, pending: true }, {
			type: actionTypes.CREATE_FAILURE
		}))
			.toEqual({ ...initialState, pending: false });
	});

	it('NEXT', () => {
		const payload = { name: 'new name' };
		initialState.data = pilots[0];
		expect(reducer({ ...initialState, step: 0 }, {
			type: actionTypes.NEXT,
			payload
		}))
			.toEqual({
				...initialState, step: 1, data: { ...initialState.data, ...payload }
			});
	});

	it('BACK - step is 0', () => {
		initialState.step = 0;
		expect(reducer({ ...initialState }, {
			type: actionTypes.BACK
		}))
			.toEqual({
				...initialState
			});
	});

	it('BACK - step is bigger than 0', () => {
		initialState.step = 1;
		expect(reducer({ ...initialState }, {
			type: actionTypes.BACK
		}))
			.toEqual({
				...initialState, step: 0
			});
	});

	it('GOTO_STEP', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.GOTO_STEP,
			payload: 3
		}))
			.toEqual({
				...initialState, step: 3
			});
	});

	it('REMOVE_ENV_COMPONENT - index > componentIndex', () => {
		initialState.componentCount = 1;
		initialState.componentIndex = 2;
		const index = 3;
		expect(reducer({ ...initialState }, {
			type: actionTypes.REMOVE_ENV_COMPONENT,
			payload: index
		}))
			.toEqual({
				...initialState, componentCount: 0, componentIndex: 2
			});
	});

	it('REMOVE_ENV_COMPONENT - index <= componentIndex', () => {
		initialState.componentCount = 1;
		initialState.componentIndex = 2;
		const index = 2;
		expect(reducer({ ...initialState }, {
			type: actionTypes.REMOVE_ENV_COMPONENT,
			payload: index
		}))
			.toEqual({
				...initialState, componentCount: 0, componentIndex: 1
			});
	});

	it('SET_CHANNEL_ERRORS', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.SET_CHANNEL_ERRORS,
			payload: error
		}))
			.toEqual({
				...initialState, channelErrors: error
			});
	});

	it('EDIT_ENV_COMPONENT', () => {
		const index = 1;
		expect(reducer({ ...initialState }, {
			type: actionTypes.EDIT_ENV_COMPONENT,
			payload: index
		}))
			.toEqual({
				...initialState, componentIndex: index
			});
	});

	it('SAVE_ENV_COMPONENT - componentIndex >= componentCount', () => {
		initialState.componentCount = 2;
		initialState.componentIndex = 4;
		expect(reducer({ ...initialState }, {
			type: actionTypes.SAVE_ENV_COMPONENT
		}))
			.toEqual({
				...initialState, componentCount: 3, componentIndex: 3
			});
	});

	it('SAVE_ENV_COMPONENT - componentIndex < componentCount', () => {
		initialState.componentCount = 2;
		initialState.componentIndex = 1;
		expect(reducer({ ...initialState }, {
			type: actionTypes.SAVE_ENV_COMPONENT
		}))
			.toEqual({
				...initialState, componentCount: 2, componentIndex: 2
			});
	});
});
