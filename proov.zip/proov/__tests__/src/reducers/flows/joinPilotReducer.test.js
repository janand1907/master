import pilotJoinRequest from '@mocks/pilotJoinRequest';
import reducer from 'ducks/flows/joinPilot/reducers';
import * as actionTypes from 'ducks/flows/joinPilot/types';

const initialState = {
	selfEvaluation: null,
	pending: {
		get: false,
		submit: false
	},
	error: null,
	currentStep: null
};

const { selfEvaluation } = pilotJoinRequest;
const message = 'some message';
const errorMessage = 'some error message';
const step = 1;

describe('joinPilotReducer', () => {
	it('initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it('PILOT_JOIN_FETCH_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_JOIN_FETCH_REQUEST
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, get: true }, error: null });
	});

	it('PILOT_JOIN_FETCH_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, get: true }, error: null }, {
			type: actionTypes.PILOT_JOIN_FETCH_SUCCESS,
			payload: selfEvaluation
		}))
			.toEqual({
				...initialState, pending: { ...initialState.pending, get: false }, selfEvaluation, error: null
			});
	});

	it('PILOT_JOIN_FETCH_FAILURE', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, get: true }, error: null }, {
			type: actionTypes.PILOT_JOIN_FETCH_FAILURE,
			payload: errorMessage
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, get: false }, error: errorMessage });
	});

	it('PILOT_JOIN_POST_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_JOIN_POST_REQUEST
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, submit: true } });
	});

	it('PILOT_JOIN_POST_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, submit: true } }, {
			type: actionTypes.PILOT_JOIN_POST_SUCCESS,
			payload: { message }
		}))
			.toEqual({
				...initialState, pending: { ...initialState.pending, submit: false }
			});
	});

	it('PILOT_JOIN_POST_FAILURE', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, submit: true } }, {
			type: actionTypes.PILOT_JOIN_POST_FAILURE,
			payload: { message }
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, submit: false } });
	});

	it('PILOT_JOIN_GO_TO_STEP', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_JOIN_GO_TO_STEP,
			payload: { step }
		}))
			.toEqual({ ...initialState, currentStep: step });
	});

	it('PILOT_JOIN_CANCEL', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_JOIN_CANCEL
		}))
			.toEqual({ ...initialState, currentStep: null });
	});
});
