import reducer from 'ducks/flows/invitePilot/reducers';
import {
	PILOT_INVITE_AUTOCOMPLETE_REQUEST, PILOT_INVITE_AUTOCOMPLETE_SUCCESS, PILOT_INVITE_AUTOCOMPLETE_FAILURE,
	PILOT_INVITE_POST_REQUEST, PILOT_INVITE_POST_SUCCESS, PILOT_INVITE_POST_FAILURE, SET_PILOT_ID
} from 'ducks/flows/invitePilot/types';

describe('invitePilotReducer', () => {
	const initialState = {
		pending: {
			invite: false,
			autoComplete: false
		},
		autoComplete: [],
		pilotId: undefined
	};

	it('invitePilotReducer::initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it('invitePilotReducer::${PILOT_INVITE_AUTOCOMPLETE_REQUEST}', () => {
		expect(reducer(initialState, {
			type: PILOT_INVITE_AUTOCOMPLETE_REQUEST,
			payload: '',
			meta: { auth: true }
		}))
			.toEqual({ 'autoComplete': [], 'pending': { autoComplete: true, invite: false }, 'pilotId': undefined });
	});

	it('invitePilotReducer::${PILOT_INVITE_AUTOCOMPLETE_SUCCESS}', () => {
		expect(reducer(initialState, {
			type: PILOT_INVITE_AUTOCOMPLETE_SUCCESS,
			payload: ['test'],
			meta: { auth: true }
		}))
			.toEqual({ 'autoComplete': ['test'], 'pending': { autoComplete: false, invite: false }, 'pilotId': undefined });
	});

	it('invitePilotReducer::${PILOT_INVITE_AUTOCOMPLETE_FAILURE}', () => {
		expect(reducer(initialState, {
			type: PILOT_INVITE_AUTOCOMPLETE_FAILURE,
			payload: '',
			meta: { auth: true }
		}))
			.toEqual({ 'autoComplete': [], 'pending': { autoComplete: false, invite: false }, 'pilotId': undefined });
	});

	it('invitePilotReducer::${PILOT_INVITE_POST_REQUEST}', () => {
		expect(reducer(initialState, {
			type: PILOT_INVITE_POST_REQUEST,
			payload: '',
			meta: { auth: true }
		}))
			.toEqual({ 'autoComplete': [], 'pending': { autoComplete: false, invite: true }, 'pilotId': undefined });
	});

	it('invitePilotReducer::${PILOT_INVITE_POST_SUCCESS}', () => {
		expect(reducer(initialState, {
			type: PILOT_INVITE_POST_SUCCESS,
			payload: '',
			meta: { auth: true }
		}))
			.toEqual({ 'autoComplete': [], 'pending': { autoComplete: false, invite: false }, 'pilotId': undefined });
	});

	it('invitePilotReducer::${PILOT_INVITE_POST_FAILURE}', () => {
		expect(reducer(initialState, {
			type: PILOT_INVITE_POST_FAILURE,
			payload: '',
			meta: { auth: true }
		}))
			.toEqual({ 'autoComplete': [], 'pending': { autoComplete: false, invite: false }, 'pilotId': undefined });
	});

	it('invitePilotReducer::${SET_PILOT_ID}', () => {
		expect(reducer(initialState, {
			type: SET_PILOT_ID,
			payload: '1',
			meta: { auth: true }
		}))
			.toEqual({ 'autoComplete': [], 'pending': { autoComplete: false, invite: false }, 'pilotId': '1' });
	});
});
