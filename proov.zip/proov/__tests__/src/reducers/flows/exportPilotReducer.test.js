import pilotExport from '@mocks/pilotExport';
import * as actionTypes from 'ducks/flows/exportPilot/types';
import reducer from 'ducks/flows/exportPilot/reducers';

const initialState = {
	pending: {
		get: false,
		post: false
	},
	error: null
};

const errorMessage = 'some error message';

describe('exportPilotReducer', () => {
	it('initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it('PILOT_EXPORT_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_EXPORT_REQUEST
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, post: true }, error: null });
	});

	it('PILOT_EXPORT_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, post: true }, error: null }, {
			type: actionTypes.PILOT_EXPORT_SUCCESS
		}))
			.toEqual({
				...initialState, pending: { ...initialState.pending, post: false }, error: null
			});
	});

	it('PILOT_EXPORT_FAILURE', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, post: false }, error: null }, {
			type: actionTypes.PILOT_EXPORT_FAILURE,
			payload: errorMessage
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, post: false }, error: errorMessage });
	});

	it('PILOT_EXPORT_GET_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.PILOT_EXPORT_GET_REQUEST
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, get: true } });
	});

	it('PILOT_EXPORT_GET_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, get: false } }, {
			type: actionTypes.PILOT_EXPORT_GET_SUCCESS,
			payload: pilotExport
		}))
			.toEqual({
				...initialState, service_catalog: { ...pilotExport }, pending: { ...initialState.pending, get: false }
			});
	});

	it('PILOT_EXPORT_GET_FAILURE', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, get: true } }, {
			type: actionTypes.PILOT_EXPORT_GET_FAILURE
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, get: false } });
	});
});
