import * as actions from 'ducks/forms';
import * as actionTypes from 'ducks/forms/types';

describe('actions', () => {

	it('should create an action register', () => {
		const form = 'createPilot';
		const field = 'name';
		const expectedAction = {
			meta: {
				fieldType: 'Field',
				form,
				preserve: false,
			},
			payload: field,
			type: actionTypes.FORM_REGISTER_FIELD
		};
		expect(actions.register(form, field)).toEqual(expectedAction);
	});

	it('should create an action unregister', () => {
		const form = 'createPilot';
		const field = 'name';
		const expectedAction = {
			meta: {
				form,
				preserve: false,
			},
			payload: field,
			type: actionTypes.FORM_UNREGISTER_FIELD
		};
		expect(actions.unregister(form, field)).toEqual(expectedAction);
	});

	it('should create an action setInitialValues', () => {
		const form = 'createPilot';
		const values = { name: 'name' };
		const expectedAction = {
			meta: {
				form
			},
			payload: values,
			type: actionTypes.FORM_SET_INITIAL_VALUE
		};
		expect(actions.setInitialValues(form, values)).toEqual(expectedAction);
	});

	it('should create an action reset', () => {
		const form = 'createPilot';
		const field = 'name';
		const expectedAction = {
			meta: {
				field: field,
				form
			},
			type: actionTypes.FORM_RESET
		};
		expect(actions.reset(form, field)).toEqual(expectedAction);
	});

	it('should create an action resetAll', () => {
		const form = 'createPilot';
		const expectedAction = {
			meta: {
				form
			},
			type: actionTypes.FORM_RESET_ALL
		};
		expect(actions.resetAll(form)).toEqual(expectedAction);
	});

	it('should create an action change', () => {
		const form = 'createPilot';
		const field = 'name';
		const value = 'Pilot name';
		const expectedAction = {
			meta: {
				field: field,
				form
			},
			payload: value,
			type: actionTypes.FORM_CHANGE
		};
		expect(actions.change(form, field, value)).toEqual(expectedAction);
	});

	it('should create an action focus', () => {
		const form = 'createPilot';
		const field = 'name';
		const expectedAction = {
			meta: {
				field: field,
				form
			},
			type: actionTypes.FORM_FOCUS
		};
		expect(actions.focus(form, field)).toEqual(expectedAction);
	});

	it('should create an action beginAsyncValidation', () => {
		const form = 'createPilot';
		const field = 'name';
		const expectedAction = {
			meta: {
				field: field,
				form
			},
			type: actionTypes.FORM_BEGIN_ASYNC_VALIDATION
		};
		expect(actions.beginAsyncValidation(form, field)).toEqual(expectedAction);
	});

	it('should create an action finishAsyncValidation', () => {
		const form = 'createPilot';
		const field = 'name';
		const error = { error: 'error' };
		const expectedAction = {
			meta: {
				field: field,
				form
			},
			payload: error,
			type: actionTypes.FORM_FINISH_ASYNC_VALIDATION
		};
		expect(actions.finishAsyncValidation(form, field, error)).toEqual(expectedAction);
	});

	it('should create an action setErrors', () => {
		const form = 'createPilot';
		const field = 'name';
		const error = { error: 'error' };
		const expectedAction = {
			meta: {
				field: field,
				form,
				submit: false
			},
			payload: error,
			type: actionTypes.FORM_SET_ERRORS
		};
		expect(actions.setErrors(form, field, error)).toEqual(expectedAction);
	});

	it('should create an action clearErrors', () => {
		const form = 'createPilot';
		const field = 'name';
		const expectedAction = {
			meta: {
				field: field,
				form,
				clearPending: false
			},
			type: actionTypes.FORM_CLEAR_ERRORS
		};
		expect(actions.clearErrors(form, field)).toEqual(expectedAction);
	});

	it('should create an action arrayPush', () => {
		const form = 'createPilot';
		const field = 'name';
		const value = 'Pilot name';
		const expectedAction = {
			meta: {
				field: field,
				form
			},
			payload: value,
			type: actionTypes.FORM_ARRAY_PUSH
		};
		expect(actions.arrayPush(form, field, value)).toEqual(expectedAction);
	});

	it('should create an action arrayPop', () => {
		const form = 'createPilot';
		const field = 'name';
		const expectedAction = {
			meta: {
				field: field,
				form
			},
			type: actionTypes.FORM_ARRAY_POP
		};
		expect(actions.arrayPop(form, field)).toEqual(expectedAction);
	});

	it('should create an action arrayInsert', () => {
		const form = 'createPilot';
		const field = 'name';
		const value = 'Pilot name';
		const index = 1;
		const expectedAction = {
			meta: {
				field: field,
				form,
				index
			},
			payload: value,
			type: actionTypes.FORM_ARRAY_INSERT
		};
		expect(actions.arrayInsert(form, field, index, value)).toEqual(expectedAction);
	});

	it('should create an action arrayRemove', () => {
		const form = 'createPilot';
		const field = 'name';
		const value = 'Pilot name';
		const index = 1;
		const expectedAction = {
			meta: {
				field: field,
				form
			},
			payload: index,
			type: actionTypes.FORM_ARRAY_REMOVE
		};
		expect(actions.arrayRemove(form, field, index)).toEqual(expectedAction);
	});

});
