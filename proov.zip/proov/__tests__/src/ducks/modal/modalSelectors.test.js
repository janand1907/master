import * as selectors from 'ducks/modal/selectors';

const state = {
	modal: {
		modalType: '',
		isOpen: false,
		canClose: true,
		data: null
	}
};

describe('modal selectors', () => {
	it('getModal', () => {
	  	expect(selectors.getModal(state)).toEqual(state.modal);
	});
});
