import { validatePassword, getTagSuggestions, getEvalCriteriaSuggestions } from 'ducks/shared/actions';
import * as types from 'ducks/shared/types';

describe('sharedActions', () => {

	const callback = jest.fn();

	it('sharedAction::validatePassword', () => {
		const password = 'textpassword';

		const action = validatePassword(password, callback);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.VALIDATE_PWD_REQUEST,
				password,
				callback
			})
		);

	});

	it('sharedAction::getTagSuggestions', () => {
		const keyword = 'system';

		const action = getTagSuggestions(keyword, callback);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.TAGS_FETCH_REQUEST,
				keyword,
				callback
			})
		);

	});

	it('sharedAction::getEvalCriteriaSuggestions', () => {
		const keyword = 'system';

		const action = getEvalCriteriaSuggestions(keyword, callback);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.EVAL_CRITERIA_FETCH_REQUEST,
				keyword,
				callback
			})
		);

	});

});
