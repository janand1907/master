import { getExportPilotFlow, getExportPilotFlowPending, getFlows } from 'ducks/flows/exportPilot/selectors';
import { getInvitePilotFlow, getInvitePilotFlowPending } from 'ducks/flows/invitePilot/selectors';
import { getJoinPilotFlow, getJoinPilotFlowPending } from 'ducks/flows/joinPilot/selectors';
import { getSuggestPilotFlow, getSuggestPilotFlowPending } from 'ducks/flows/suggestPilot/selectors';

const state = {
	flows: {
		exportPilot: {
			pendingGet: false,
			pendingPost: false,
			error: null
		},
		invitePilot: {
			pending: false,
			pendingAutocomplete: false,
			autocomplete: [],
			pilotId: undefined
		},
		joinPilot: {
			self_evaluation: null,
			pendingGet: false,
			pendingSubmit: false,
			error: null,
			currentStep: null
		},
		suggestPilot: {
			pending: false,
			pendingAutocomplete: false,
			autocomplete: [],
			currentStep: null
		}
	}
};

describe('flows selectors', () => {
	it('getFlows', () => {
		expect(getFlows(state)).toEqual(state.flows);
	});

	it('getExportPilotFlow', () => {
		expect(getExportPilotFlow(state)).toEqual(state.flows.exportPilot);
		expect(getExportPilotFlowPending(state)).toEqual(state.flows.exportPilot.pending);
	});

	it('getInvitePilotFlow', () => {
		expect(getInvitePilotFlow(state)).toEqual(state.flows.invitePilot);
		expect(getInvitePilotFlowPending(state)).toEqual(state.flows.invitePilot.pending);

	});

	it('getJoinPilotFlow', () => {
		expect(getJoinPilotFlow(state)).toEqual(state.flows.joinPilot);
		expect(getJoinPilotFlowPending(state)).toEqual(state.flows.joinPilot.pending);

	});

	it('getSuggestPilotFlow', () => {
		expect(getSuggestPilotFlow(state)).toEqual(state.flows.suggestPilot);
		expect(getSuggestPilotFlowPending(state)).toEqual(state.flows.suggestPilot.pending);

	});
});
