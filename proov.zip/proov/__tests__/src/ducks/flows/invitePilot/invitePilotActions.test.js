import { autocomplete, setPilotId, submit, inviteVendorClick } from 'ducks/flows/invitePilot/actions';
import * as types from 'ducks/flows/invitePilot/types';

describe('actions', () => {

	it('should create an action autocomplete', () => {
		const keyword = 'keyword';
		const pilotId = '1';
		const expectedAction =  {
			intent: 'pilot_invite',
			keyword: 'keyword',
			params: { pilotId: '1' },
			type: types.PILOT_INVITE_AUTOCOMPLETE_REQUEST
		};
		expect(autocomplete(keyword, pilotId)).toEqual(expectedAction);
	});

	it('should create an action submit', () => {
		const pilotId = '1';
		const data = {};

		const expectedAction =  {
			data: {},
			metas: [null, { 'mixpanel': { 'event': 'Invite to a PoC', 'props': { 'pilotId': '1' } } }, null],
			pilotId: '1',
		    type: types.PILOT_INVITE_POST_REQUEST
		};
		expect(submit(pilotId, data)).toEqual(expectedAction);
	});

	it('should create an action inviteVendorClick', () => {
		const source = 'source';
		const expectedAction = {
			meta: {
				mixpanel: { event: 'Invite Vendors Click - source' }
			},
			type: types.INVITE_VENDORS_CLICK
		};
		expect(inviteVendorClick(source)).toEqual(expectedAction);
	});

	it('should create an action setPilotId', () => {
		const pilotId = '1234';
		const expectedAction = {
			payload: pilotId,
			type: types.SET_PILOT_ID
		};
		expect(setPilotId(pilotId)).toEqual(expectedAction);
	});
});
