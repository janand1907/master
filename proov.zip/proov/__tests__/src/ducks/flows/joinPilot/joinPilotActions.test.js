import * as actions from 'ducks/flows/joinPilot/actions';
import * as types from 'ducks/flows/joinPilot/types';

describe('actions', () => {

	it('should create an action get', () => {
		const id = '1';

		const action = actions.get(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.PILOT_JOIN_FETCH_REQUEST,
				id
			})
		);
	});

	it('should create an action submit', () => {
		const id = '1';
		const data = {};

		const action = actions.submit(id, data);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.PILOT_JOIN_POST_REQUEST,
				id,
				data
			})
		);

	});

	it('should create an action accept', () => {
		const id = '1';

		const action = actions.accept(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.PILOT_JOIN_ACCEPT_REQUEST,
				id
			})
		);
	});

	it('should create an action reset', () => {
		const action = actions.reset();

		expect(action).toEqual(
			expect.objectContaining({
				type: types.PILOT_JOIN_RESET,
			})
		);
	});

	it('should create an action deny', () => {
		const requestId = '1';
		const message = 'message';

		const action = actions.deny({ requestId, message });

		expect(action).toEqual(
			expect.objectContaining({
				type: types.PILOT_JOIN_DENY_REQUEST,
				requestId,
				message
			})
		);
	});

	it('should create an action checkout', () => {
		const pilotId = '1';
		const stripeToken = 'stripe_token';
		const resolve = 'resolve';

		const action = actions.checkout(pilotId, stripeToken, resolve);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.PILOT_JOIN_CHECKOUT_REQUEST,
				pilotId,
				stripeToken,
				resolve
			})
		);
	});

	it('should create an action cancel', () => {
		const pilotId = '1';
		const step = 1;

		const expectedAction = {
			meta: {
				mixpanel: expect.any(Object)
			},
			type: types.PILOT_JOIN_CANCEL
		};
		expect(actions.cancel(pilotId, step)).toEqual(expectedAction);
	});

	it('should create an action goToStep', () => {
		const pilotId = '1';
		const step = 1;

		const expectedAction = {
			meta: {
				mixpanel: expect.any(Object)
			},
			type: types.PILOT_JOIN_GO_TO_STEP,
			payload: { step }
		};
		expect(actions.goToStep(step, pilotId)).toEqual(expectedAction);
	});

});
