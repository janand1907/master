import * as gwSelectors from 'ducks/gateway';

const state = {
	gateway: {
		login: { logging: false, isLinkedIn: true, pinging: false },
		forgot: { pending: false, message: '', status: null },
		register: { pending: false, status: null, message: null },
		joinTeam: { pending: true, user: null },
	}
};

describe('gateway selectors', () => {
	it('getGateway', () => {
		expect(gwSelectors.getGateway(state)).toEqual(state.gateway);
	});
});
