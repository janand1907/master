import * as actionTypes from '../../../../../src/ducks/gateway/joinTeam/types';
import { joinTeam, validateUser } from '../../../../../src/ducks/gateway/joinTeam/actions';

describe('actions', () => {
	/* eslint-disable camelcase */
	it('should create an action joinTeam', () => {
		const history = 'fooo';
		const data = {
			phone: ['050123456789', '052123456789'],
		};

		const expectedAction = {
			type: actionTypes.JOIN_TEAM_REQUEST,
			body: { phone: { country_code: data.phone[0], phone_number: data.phone[1] } },
			history
		};

		expect(joinTeam(data, history)).toEqual(expectedAction);

	});
	/* eslint-enable */

	it('should create an action validateUser', () => {

		const token = '123abc';
		const expectedAction = {
			type: actionTypes.VALIDATE_TEAM_REQUEST,
			body: token
		};
		expect(validateUser(token)).toEqual(expectedAction);
	});

});
