import user from '@mocks/user';
import * as actionTypes from 'ducks/gateway/joinTeam/types';
import reducer from 'ducks/gateway/joinTeam/reducers';

const initialState = {
	pending: false,
	user: null
};

const message = 'some message';
const errorMessage = 'some error message';

describe('joinTeamReducer', () => {
	it('initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it('VALIDATE_TEAM_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.VALIDATE_TEAM_REQUEST
		}))
			.toEqual({ ...initialState, pending: true });
	});

	it('VALIDATE_TEAM_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: true }, {
			type: actionTypes.VALIDATE_TEAM_SUCCESS,
			payload: user
		}))
			.toEqual({
				...initialState, pending: false, user
			});
	});

	it('VALIDATE_TEAM_FAILURE', () => {
		expect(reducer({ ...initialState, pending: true }, {
			type: actionTypes.VALIDATE_TEAM_FAILURE,
			payload: { message: errorMessage }
		}))
			.toEqual({ ...initialState, pending: false });
	});

	it('JOIN_TEAM_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.JOIN_TEAM_REQUEST
		}))
			.toEqual({ ...initialState, pending: true });
	});

	it('JOIN_TEAM_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: true }, {
			type: actionTypes.JOIN_TEAM_SUCCESS,
			payload: { message }
		}))
			.toEqual({
				...initialState, pending: false
			});
	});

	it('JOIN_TEAM_FAILURE', () => {
		expect(reducer({ ...initialState, pending: true }, {
			type: actionTypes.JOIN_TEAM_FAILURE,
			payload: { message }
		}))
			.toEqual({ ...initialState, pending: false });
	});
});
