import * as gwSelectors from 'ducks/gateway/joinTeam/selectors';

const state = {
	gateway: {
		login: { logging: false, isLinkedIn: true, pinging: false },
		forgot: { pending: false, message: '', status: null },
		register: { pending: false, status: null, message: null },
		joinTeam: { pending: true, user: null },
	}
};

describe('gateway joinTeam selectors', () => {

	it('getGatewayJoinTeam', () => {
		expect(gwSelectors.getGatewayJoinTeam(state)).toEqual(state.gateway.joinTeam);
	});
});
