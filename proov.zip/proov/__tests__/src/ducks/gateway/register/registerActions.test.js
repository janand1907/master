import * as types from 'ducks/gateway/register/types';
import { register, reset, setSuccess, completeRegistration } from 'ducks/gateway/register/actions';

describe('actions', () => {

	it('should create an action register', () => {

		const data = { email: 'test@test.com' };

		const action = register(data);

		const expectedAction = {
			type: types.REGISTER_REQUEST,
			data,
			metas: [null, { mixpanel: { event: 'Sign Up', props: { email: data.email } } }, null]

		};

		expect(action).toEqual(expectedAction);

	});

	it('should create an action reset', () => {
		const expectedAction = {
			type: types.REGISTER_RESET
		};
		expect(reset()).toEqual(expectedAction);
	});

	it('should create an action setSuccess', () => {
		const expectedAction = {
			type: types.SET_SUCCESS
		};
		expect(setSuccess()).toEqual(expectedAction);
	});

	it('should create an action completeRegistration', () => {
		/* eslint-disable camelcase */

		const data = {
			email_address: 'test@test.com',
			password: '12345',
			token: 'abc1234'
		};

		const action = completeRegistration(data);

		const expectedAction = {
			type: types.COMPLETE_REGISTRATION_REQUEST,
			payload: data
		};
		expect(action).toEqual(expectedAction);

		/* eslint-enable camelcase */

	});

});
