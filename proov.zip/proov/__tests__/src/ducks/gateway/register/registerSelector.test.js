import * as gwSelectors from 'ducks/gateway/register/selectors';

const state = {
	gateway: {
		login: { logging: false, isLinkedIn: true, pinging: false },
		forgot: { pending: false, message: '', status: null },
		register: { pending: false, status: null, message: null },
		joinTeam: { pending: true, user: null },
	}
};

describe('gateway register selectors', () => {

	it('getGatewayRegister', () => {
		expect(gwSelectors.getGatewayRegister(state)).toEqual(state.gateway.register);
	});
});
