import reducer from 'ducks/welcome/reducers';

describe('welcomeReducer', () => {
	it('returns initial state', () => {
		expect(reducer(undefined, {})).toEqual({
			promotion: null,
			pending: {
				promotion: false,
				recommendedPilots: false,
				recommendedCompanies: false,
			},
			recommendedPilots: null,
			recommendedCompanies: null
		});
	});

	/* [PROMOTION_FETCH_SUCCESS]: (state, promotion) => {
		return { ...state, pendingPromotion: false, promotion: promotion };
	}, */
	it('handles PROMOTION_FETCH_SUCCESS action', () => {
		expect(reducer([], {
			type: 'PROMOTION_FETCH_SUCCESS',
			payload: {
				id: 'default_promotion_client',
				title: 'Great News',
				text: 'New opportunities are waiting for you in the marketplace',
				cta: [
					{
						Browse: '/marketplace/search/vendor'
					}
				],
				image: '/api/media/get/ufyyx0cjv5vhd3cu58ki'
			},
			meta: {
				auth: true
			}
		})).toEqual(
			{
				promotion: {
					'id': 'default_promotion_client',
					'title': 'Great News',
					'text': 'New opportunities are waiting for you in the marketplace',
					'cta': [
						{
							'Browse': '/marketplace/search/vendor'
						}
					],
					'image': '/api/media/get/ufyyx0cjv5vhd3cu58ki'
				},
				pending: {
					promotion: false
				}
			}
		);
	});

	/*
		[PROMOTION_FETCH_REQUEST]: (state, promotion) => {
		return { ...state, pendingPromotion: true, promotion: null };
	},*/
	it('handles PROMOTION_FETCH_REQUEST action', () => {
		expect(reducer([], {
			type: 'PROMOTION_FETCH_REQUEST',
			payload: null,
			meta: {
				auth: true
			}
		})).toEqual(
			{
				promotion: null,
				pending: {
					promotion: true
				}
			}
		);

	});

	/* 	[PROMOTION_FETCH_FAILURE]: (state, promotion) => {
			return { ...state, pendingPromotion: false, promotion: null };
		}, */
	it('handles PROMOTION_FETCH_FAILURE action', () => {
		expect(reducer([], {
			type: 'PROMOTION_FETCH_FAILURE',
			payload: null,
			meta: {
				auth: true
			}
		})).toEqual(
			{
				promotion: null,
				pending: {
					promotion: false
				}
			}
		);
	});

	/* [RECOM_PILOTS_FETCH_REQUEST]: (state, pilots) => {
		return { ...state, pendingRecommendedPilots: true, recommendedPilots: null };
	}, */
	it('handles RECOM_PILOTS_FETCH_REQUEST action', () => {
		expect(reducer([], {
			type: 'RECOM_PILOTS_FETCH_REQUEST',
			payload: null
		})).toEqual(
			{
				recommendedPilots: null,
				pending: {
					recommendedPilots: true
				}
			}
		);
	});

	/* [RECOM_PILOTS_FETCH_SUCCESS]: (state, pilots) => {
		return { ...state, pendingRecommendedPilots: false, recommendedPilots: pilots };
	}, */
	it('handles RECOM_PILOTS_FETCH_SUCCESS action', () => {
		expect(reducer([], {
			type: 'RECOM_PILOTS_FETCH_SUCCESS',
			payload: {
				id: 'testId'
			}
		})).toEqual(
			{
				pending: {
					recommendedPilots: false
				},
				recommendedPilots: {
					id: 'testId'
				}
			}
		);
	});


	/* [RECOM_PILOTS_FETCH_FAILURE]: (state, pilots) => {
		return { ...state, pendingRecommendedPilots: false, recommendedPilots: null };
	} */
	it('handles RECOM_PILOTS_FETCH_FAILURE action', () => {
		expect(reducer([], {
			type: 'RECOM_PILOTS_FETCH_FAILURE',
			payload: null
		})).toEqual(
			{
				pending: {
					recommendedPilots: false
				},
				recommendedPilots: null
			}
		);
	});

	/* [RECOM_COMPANIES_FETCH_REQUEST]: (state, companies) => {
		return { ...state, pendingRecommendedCompanies: true, recommendedCompanies: null };
	} */
	it('handles RECOM_COMPANIES_FETCH_REQUEST action', () => {
		expect(reducer([], {
			type: 'RECOM_COMPANIES_FETCH_REQUEST',
			payload: null
		})).toEqual(
			{
				pending: {
					recommendedCompanies: true
				},
				recommendedCompanies: null
			}
		);
	});

	/* [RECOM_COMPANIES_FETCH_SUCCESS]: (state, companies) => {
		return { ...state, pendingRecommendedCompanies: false, recommendedCompanies: companies };
	} */
	it('handles RECOM_COMPANIES_FETCH_SUCCESS action', () => {
		expect(reducer([], {
			type: 'RECOM_COMPANIES_FETCH_SUCCESS',
			payload: {
				id: 'testId'
			}
		})).toEqual(
			{
				pending: {
					recommendedCompanies: false
				},
				recommendedCompanies: {
					id: 'testId'
				}
			}
		);
	});

	/* [RECOM_COMPANIES_FETCH_FAILURE]: (state, companies) => {
		return { ...state, pendingRecommendedCompanies: false, recommendedCompanies: null };
	} */
	it('handles RECOM_COMPANIES_FETCH_FAILURE action', () => {
		expect(reducer([], {
			type: 'RECOM_COMPANIES_FETCH_FAILURE',
			payload: null
		})).toEqual(
			{
				pending: {
					recommendedCompanies: false
				},
				recommendedCompanies: null
			}
		);
	});

});
