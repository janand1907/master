/* global API_ROOT */

import { getRecomPromotion, getRecomPilots, getRecomCompanies } from 'ducks/welcome/actions';
import * as types from 'ducks/welcome/types';


describe('Welcome actions', () => {

	it('getPromotion', () => {
		const id = '1';
		const action = getRecomPromotion(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.PROMOTION_FETCH_REQUEST,
				id
			})
		);
	});

	it('getRecomPilots', () => {
		const action = getRecomPilots();

		expect(action).toEqual(
			expect.objectContaining({
				type: types.RECOM_PILOTS_FETCH_REQUEST
			})
		);
	});

	it('getRecomCompanies', () => {
		const action = getRecomCompanies();

		expect(action).toEqual(
			expect.objectContaining({
				type: types.RECOM_COMPANIES_FETCH_REQUEST
			})
		);
	});

});
