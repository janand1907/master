import * as selectors from 'ducks/welcome/selectors';
import { pilots } from '../../../../server/json/pilot';
import { companies } from '../../../../server/json/company';
import { promotions } from '../../../../server/json/promotion';

const state = {
	welcome: {
		promotion: promotions[0],
		pending: {
			promotion: false,
			recommendedPilots: false,
			recommendedCompanies: false,
		},
		recommendedPilots: pilots,
		recommendedCompanies: companies
	}
};

describe('welcome selectors', () => {
	it('getWelcome', () => {
	  	expect(selectors.getWelcome(state)).toEqual(state.welcome);
	});

	it('getPromotion', () => {
		expect(selectors.getPromotion(state)).toEqual(state.welcome.promotion);
	});

	it('getRecommendedPilots', () => {
		expect(selectors.getRecommendedPilots(state)).toEqual(state.welcome.recommendedPilots);
	});

	it('getRecommendedCompanies', () => {
		expect(selectors.getRecommendedCompanies(state)).toEqual(state.welcome.recommendedCompanies);
	});

	it('getPending', () => {
		expect(selectors.getPending(state)).toEqual(state.welcome.pending);
	});
});
