
import {
	getCompany,
	getPilot,
	refreshJoinable
} from 'ducks/marketplace/actions';
import * as actionTypes from 'ducks/marketplace/types';

describe('actions', () => {

	it('getCompany', () => {
		const id = '1';
		const history = 'history';
		const expectedAction = {
			id: '1',
			metas: [null, { mixpanel: { event: 'MP - Open Company', props: { companyId: '1' } } }, null],
			type: actionTypes.COMPANY_FETCH_REQUEST
		};
		expect(getCompany(id, history)).toEqual(expectedAction);

	});

	it('getPilot', () => {
		const id = '1';
		const history = 'history';
		const expectedAction = {
			id: '1',
			metas: [null, { mixpanel: { event: 'MP - Open PoC', props: { pilotId: '1' } } }, null],
			type: actionTypes.PILOT_FETCH_REQUEST
		};
		expect(getPilot(id, history)).toEqual(expectedAction);
	});

	it('refreshJoinable', () => {
		const id = '1';
		const action = refreshJoinable(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: actionTypes.PILOT_FIELDS_FETCH_REQUEST,
				id
			})
		);
	});


});
