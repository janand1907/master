import { getAnalytics } from 'ducks/admin/analytics';

const state = {
	admin: {
		analytics: {
		},
	}
};

describe('analytics selectors - index', () => {

	it('getAnalytics', () => {
		expect(getAnalytics(state)).toEqual(state.admin.analytics);
	});
});
