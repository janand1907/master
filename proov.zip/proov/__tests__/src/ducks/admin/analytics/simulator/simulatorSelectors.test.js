import * as selectors from 'ducks/admin/analytics/simulator/selectors';

const state = {
	admin: {
		analytics: {
			simulator: {
				selectedParam1: null,
				selectedParam2: null,
				vendorId: '',
				pending: true,
				data: null,
				error: '',
				x1Value: 0,
				x2Value: 0,
				prediction: {
					pending: false,
					data: null
				}
			},
		}
	}
};

describe('analytics selectors - simulator', () => {

	it('getSimulatorSelector', () => {
		expect(selectors.getSimulatorSelector(state)).toEqual(state.admin.analytics.simulator);
	});
});
