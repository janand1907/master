import * as types from 'ducks/admin/analytics/simulator/types';
import * as actions from 'ducks/admin/analytics/simulator/actions';

describe('simulator actions', () => {
	const cppId = '2c9f91cc581b679301582b31b3da00ef';
	const outputKpiId = 'd967aa7492063499f22e401e2e8f7b80ca2abe1f';
	const kpiId1 = '2c9f9be05d93caaa015d93d0eecd0000';
	const kpiValue1 = 'kpiValue1';
	const kpiId2 = '2c9f9be05d93caaa015d93d0eecd0001';
	const kpiValue2 = 'kpiValue2';
	const param = 'param';
	const vendorId = 'beb285138f1249d2a71fb8424fd508a7';
	const pilotId = '2c9f91cc581b679301582b31b3da00ef';
	const channelId = 'd967aa7492063499f22e401e2e8f7b80ca2abe1f';
	const metricId = '2c9f9be05d93caaa015d93d0eecd0000';
	const companyId = 'beb285138f1249d2a71fb8424fd508a7';

	it('getPrediction', () => {
		const expectedAction = {
			type: types.PREDICTION_REQUEST,
			payload: { cppId, outputKpiId, kpiId1, kpiValue1, kpiId2, kpiValue2 }
		};
		expect(actions.getPrediction(cppId, outputKpiId, kpiId1, kpiValue1, kpiId2, kpiValue2)).toEqual(expectedAction);
	});

	it('resetSimulator', () => {
		const expectedAction = { type: types.RESET_SIMULATOR };
		expect(actions.resetSimulator()).toEqual(expectedAction);
	});

	it('setMetricValue', () => {
		const x1 = kpiValue1, x2 = kpiValue2;
		const expectedAction = { type: types.SET_METRIC_VALUE, payload: { x1, x2 } };
		expect(actions.setMetricValue({ x1, x2 })).toEqual(expectedAction);
	});

	it('setSimulatorVendor', () => {
		const expectedAction = {
			type: types.SET_SIMULATOR_VENDOR,
			payload: vendorId
		};
		expect(actions.setSimulatorVendor(vendorId)).toEqual(expectedAction);
	});

	it('setSimulatorParam1', () => {
		const expectedAction = { type: types.SET_SIMULATOR_PARAM1, payload: param };
		expect(actions.setSimulatorParam1(param)).toEqual(expectedAction);
	});

	it('setSimulatorParam2', () => {
		const expectedAction = { type: types.SET_SIMULATOR_PARAM2, payload: param };
		expect(actions.setSimulatorParam2(param)).toEqual(expectedAction);
	});

	it('getSimulator', () => {
		const expectedAction = { type: types.SIMULATOR_REQUEST, payload: { pilotId, channelId, metricId, companyId } };
		expect(actions.getSimulator(pilotId, channelId, metricId, companyId)).toEqual(expectedAction);
	});
});
