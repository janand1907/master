import * as types from 'ducks/admin/analytics/charts/types';
import * as actions from 'ducks/admin/analytics/charts/actions';

describe('charts actions', () => {

	it('setDateRange', () => {
		const fromDate = '2018-05-19T00:00:00.000Z';
		const toDate = '2018-05-30T23:59:59.000Z';
		const expectedAction = { type: types.SET_DATE_RANGE, payload: { fromDate, toDate } };
		expect(actions.setDateRange(fromDate, toDate)).toEqual(expectedAction);
	});

	it('getArchivePeriodicFirstCall', () => {
		const expectedAction = { type: types.PERIODIC_FETCH_FIRST_CALL_REQUEST };
		expect(actions.getArchivePeriodicFirstCall()).toEqual(expectedAction);
	});

	it('startLiveData', () => {
		const pilotId = '2c9f91cc581b679301582b31b3da00ef';
		const channelId = 'd967aa7492063499f22e401e2e8f7b80ca2abe1f';
		const metricId = '2c9f9be05d93caaa015d93d0eecd0000';
		const expectedAction = { type: types.START_LIVE_DATA, payload: { pilotId, channelId, metricId } };
		expect(actions.startLiveData(pilotId, channelId, metricId)).toEqual(expectedAction);
	});

	it('stopLiveData', () => {
		const expectedAction = { type: types.STOP_LIVE_DATA };
		expect(actions.stopLiveData()).toEqual(expectedAction);
	});
});
