import { metrics } from '@mocks/analytics';
import * as selectors from 'ducks/admin/analytics/charts/selectors';

const state = {
	admin: {
		analytics: {
			general: {
				channelId: '2343298r538245',
				allMetrics: { data: metrics, pending: false, error: null },
				selectedMetric: metrics[0],
				deleteMetric: { pending: false, error: null },
				tab: 'analytics',
				selectedVendors: []
			},

			charts: {
				focus: { data: [], pending: false, error: null, from: '2016-05-03T00:00:00Z', to: '2018-05-09T23:59:59Z' },		// focus chart
				context: { data: [], pending: false, error: null, from: '2016-05-03T00:00:00Z', to: '2018-05-09T23:59:59Z' },	// context chart
				live: { data: [], pending: false, error: null, from: '2016-05-03T00:00:00Z', to: '2018-05-09T23:59:59Z' },
				resolution: null,
				enableShowAll: false,
				pending: false,
				data: [],
				error: null,
				isFetchingLiveDataActive: false
			},
		}
	}
};


describe('analytics selectors - charts', () => {

	it('getAnalytics', () => {
		expect(selectors.getAnalytics(state)).toEqual(state.admin.analytics);
	});

	it('getCharts', () => {
		expect(selectors.getCharts(state)).toEqual(state.admin.analytics.charts);
	});

	it('getResolution', () => {
		expect(selectors.getResolution(state)).toEqual(state.admin.analytics.charts.resolution);
	});

	it('getPending', () => {
		expect(selectors.getPending(state)).toEqual(state.admin.analytics.charts.pending);
	});

	it('getEnableShowAll', () => {
		expect(selectors.getEnableShowAll(state)).toEqual(state.admin.analytics.charts.enableShowAll);
	});

	it('getSelectedDates', () => {
		expect(selectors.getSelectedDates(state)).toEqual(state.admin.analytics.charts.selectedDates);
	});

	it('getData', () => {
		expect(selectors.getData(state)).toEqual(state.admin.analytics.charts.data);
	});

	it('getError', () => {
		expect(selectors.getError(state)).toEqual(state.admin.analytics.charts.error);
	});

	it('isFetchingLiveDataActive', () => {
		expect(selectors.isFetchingLiveDataActive(state)).toEqual(state.admin.analytics.charts.isFetchingLiveDataActive);
	});

});
