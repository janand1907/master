import * as types from 'ducks/admin/analytics/createMetric/types';
import * as actions from 'ducks/admin/analytics/createMetric/actions';

describe('createMetric actions', () => {
	const pilotId = '2c9f91cc581b679301582b31b3da00ef';
	const channelId = 'd967aa7492063499f22e401e2e8f7b80ca2abe1f';
	const label = 'test';
	const expression = 'x442/x400';
	const expressionType = 'formula';
	const params = ['442', '400'];
	const locator = {
		type: 'api.rest',
		url: 'https://jsonplaceholder.typicode.com/todos/1',
		path: 'userId'
	};
	const auth = { type: 'none' };
	const history = {};
	const array = [];

	it('setSelectedChannelIdForCreateWizard', () => {
		const expectedAction = { type: types.SET_SELECTED_CHANNEL_FOR_CREATE_KPI, payload: channelId };
		expect(actions.setSelectedChannelIdForCreateWizard(channelId)).toEqual(expectedAction);
	});

	it('validateMetric', () => {
		const expectedAction = {
			type: types.METRIC_VALIDATE_REQUEST,
			payload: { pilotId, label, expression, expressionType, channelId, params }
		};
		expect(actions.validateMetric(pilotId, label, expression, expressionType, channelId, params)).toEqual(expectedAction);
	});

	it('resetMetricValidate', () => {
		const expectedAction = { type: types.METRIC_VALIDATE_RESET };
		expect(actions.resetMetricValidate()).toEqual(expectedAction);
	});

	it('validateParameter', () => {
		const expectedAction = {
			type: types.PARAMETER_VALIDATE_REQUEST, payload: { pilotId, label, locator, auth }
		};
		expect(actions.validateParameter(pilotId, label, locator, auth)).toEqual(expectedAction);
	});

	it('resetParameterValidate', () => {
		const expectedAction = { type: types.PARAMETER_VALIDATE_RESET };
		expect(actions.resetParameterValidate()).toEqual(expectedAction);
	});

	it('getParameters', () => {
		const expectedAction = { type: types.PARAMETERS_FETCH_REQUEST, payload: pilotId };
		expect(actions.getParameters(pilotId)).toEqual(expectedAction);
	});

	it('createParameter', () => {
		const expectedAction = {
			type: types.PARAMETER_CREATE_REQUEST, payload: { pilotId, label, locator, auth, history }
		};
		expect(actions.createParameter(pilotId, label, locator, auth, history)).toEqual(expectedAction);
	});

	it('updateUsedParameters', () => {
		const expectedAction = {
			type: types.PARAMETER_UPDATE_USED, payload: array
		};
		expect(actions.updateUsedParameters(array)).toEqual(expectedAction);
	});

	it('resetUsedParameters', () => {
		const expectedAction = { type: types.PARAMETER_RESET_USED };
		expect(actions.resetUsedParameters()).toEqual(expectedAction);
	});

	it('createMetric', () => {
		const expectedAction = {
			type: types.METRIC_CREATE_REQUEST,
			payload: { pilotId, label, expression, expressionType, channelId, params, history }
		};
		expect(actions.createMetric(pilotId, label, expression, expressionType, channelId, params, history)).toEqual(expectedAction);
	});
});
