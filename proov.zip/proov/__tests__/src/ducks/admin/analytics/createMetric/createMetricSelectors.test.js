import * as selectors from 'ducks/admin/analytics/createMetric/selectors';

const state = {
	admin: {
		analytics: {
			//Create new custom kpi
			createMetric: {
				pending: false,
				isCompleted: false,
				error: null,
				parameters:
				{
					data: [],
					used: [],
					selectedChannelId: 'Custom',
					selectedEndPoint: null,
					allowedChannelId: null,
					pending: {
						get: false,
						create: false
					},
					error: null
				},
				createParamValidation: { pending: false, result: null, error: null },
				createMetricValidation: { pending: false, result: null, error: null }
			}
		}
	}
};


describe('analytics selectors - Create Metric', () => {

	it('getCreateMetric', () => {
		expect(selectors.getCreateMetric(state)).toEqual(state.admin.analytics.createMetric);
	});

	it('getParameters', () => {
		expect(selectors.getParameters(state)).toEqual(state.admin.analytics.createMetric.parameters);
	});

	it('getParametersPending', () => {
		expect(selectors.getParametersPending(state)).toEqual(state.admin.analytics.createMetric.parameters.pending);
	});

	it('getAllowedParamsByChannel', () => {
		expect(selectors.getAllowedParamsByChannel(state)).toEqual(state.admin.analytics.createMetric.parameters.data);
	});

	it('getCreateMetricValidation', () => {
		expect(selectors.getCreateMetricValidation(state)).toEqual(state.admin.analytics.createMetric.createMetricValidation);
	});

	it('getCreateMetricValidation', () => {
		expect(selectors.getCreateParamValidation(state)).toEqual(state.admin.analytics.createMetric.createParamValidation);
	});

});
