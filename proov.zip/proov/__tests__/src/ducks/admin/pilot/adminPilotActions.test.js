import * as myPilotsActionTypes from 'ducks/admin/myPilots/types';
import * as pilotActionTypes from 'ducks/admin/pilot/types';
import * as actions from 'ducks/admin/pilot/actions';
import { getMyPilots } from 'ducks/admin/myPilots/actions';

describe('adminActions', () => {

	it(`getMyPilots`, () => {
		const action = getMyPilots();

		expect(action).toEqual(
			expect.objectContaining({
				type: myPilotsActionTypes.MY_PILOTS_FETCH_REQUEST,
			})
		);
	});

	it(`getMyPilot`, () => {
		const id = '1';
		const section = 'section';
		const action = actions.getMyPilot(id, section);

		expect(action).toEqual(
			expect.objectContaining({
				type: pilotActionTypes.MY_PILOT_FETCH_REQUEST,
				id,
				section
			})
		);
	});

	it(`getMyPilotForPilotPage`, () => {
		const id = '1';
		const companyType = 'companyType';
		const action = actions.getMyPilotForPilotPage(id, companyType);

		expect(action).toEqual(
			expect.objectContaining({
				type: pilotActionTypes.MY_PILOT_FETCH_FIELDS_REQUEST,
				id,
				section: companyType
			})
		);
	});

	it(`getMyPilotForEnvironment`, () => {
		const id = '1';
		const action = actions.getMyPilotForEnvironment(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: pilotActionTypes.MY_PILOT_FETCH_FIELDS_REQUEST,
				id,
				section: 'Environment'
			})
		);
	});

	it(`getMyPilotForInstructions`, () => {
		const id = '1';
		const action = actions.getMyPilotForInstructions(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: pilotActionTypes.MY_PILOT_FETCH_FIELDS_REQUEST,
				id,
				section: 'Instructions'
			})
		);
	});

	it(`getMyPilotForOverview`, () => {
		const id = '1';
		const action = actions.getMyPilotForOverview(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: pilotActionTypes.MY_PILOT_FETCH_FIELDS_REQUEST,
				id,
				section: 'Overview'
			})
		);
	});

	it(`getMyPilotForRequirements`, () => {
		const id = '1';
		const action = actions.getMyPilotForRequirements(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: pilotActionTypes.MY_PILOT_FETCH_FIELDS_REQUEST,
				id,
				section: 'Requirements'
			})
		);
	});

	it(`getMyPilotForVendors`, () => {
		const id = '1';
		const action = actions.getMyPilotForVendors(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: pilotActionTypes.MY_PILOT_FETCH_FIELDS_REQUEST,
				id,
				section: 'ForVendors'
			})
		);
	});

	it(`getPilotJoinRequests`, () => {
		const id = '1';
		const action = actions.getPilotJoinRequests(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: pilotActionTypes.MY_PILOT_FETCH_FIELDS_REQUEST,
				id,
				section: 'JoinRequests'
			})
		);
	});

});
