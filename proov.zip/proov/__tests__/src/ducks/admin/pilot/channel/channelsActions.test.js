import * as actions from 'ducks/admin/pilot/channel/actions';
import * as types from 'ducks/admin/pilot/channel/types';

describe('actions', () => {

	it('should create an action deployDatasetToDB', () => {

		const pilotId = '1';
		const envId = '2';
		const datasetId = '3';

		const action = actions.deployDatasetToDB(pilotId, envId, datasetId);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.DEPLOY_DATASET_REQUEST,
				pilotId,
				envId,
				datasetId
			})
		);

	});

	it('should create an action addPilotChannel', () => {
		const pilotId = 1;
		const channel = '{}';

		const action = actions.addPilotChannel(pilotId, channel);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.CHANNEL_POST_REQUEST,
				pilotId,
				channel
			})
		);
	});

	it('should create an action deletePilotChannel', () => {
		const pilotId = 1;
		const channelId = 2;

		const action = actions.deletePilotChannel(pilotId, channelId);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.DELETE_CHANNEL_REQUEST,
				pilotId,
				channelId
			})
		);
	});


	it('should create an action updatePilotChannel', () => {
		const pilotId = 1;
		const channel = {};
		const channelId = 2;

		const action = actions.updatePilotChannel(pilotId, channel, channelId);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.CHANNEL_PATCH_REQUEST,
				pilotId,
				channel,
				channelId
			})
		);
	});

	it('should create an action uploadMediaFile', () => {
		const file = '';

		const action = actions.uploadMediaFile(file);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.UPLOAD_CHANNEL_FILE_REQUEST,
				file
			})
		);
	});

});

