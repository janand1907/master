/* global API_ROOT */
import { getNotifications, markAsRead, resetNotifications, dismissNotifications } from 'ducks/notifications/actions';
import * as types from 'ducks/notifications/types';

describe('notifications actions', () => {

	it('getNotifications', () => {
		const limit = '50';
		const skip = '20';
		const isFirstLoad = true;
		const action = getNotifications(limit, skip, isFirstLoad);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.NOTIFICATIONS_FETCH_REQUEST,
				limit,
				skip,
				meta: { isFirstLoad }
			})
		);
	});

	it('markAsRead', () => {
		const id = '1';
		const action = markAsRead(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.NOTIFICATION_MARK_REQUEST,
				id,
				meta: { notificationId: id }
			})
		);
	});

	it('resetNotifications', () => {
		const action = resetNotifications();

		expect(action).toEqual(
			expect.objectContaining({
				type: types.NOTIFICATIONS_RESET
			})
		);
	});

	it('dismissNotifications', () => {
		const action = dismissNotifications();

		expect(action).toEqual(
			expect.arrayContaining([
				{ type: types.NOTIFICATIONS_UPDATE_LIMIT, payload: 6 },
				{ type: types.NOTIFICATIONS_UPDATE_SKIP, payload: 0 },
				{ type: types.NOTIFICATIONS_RESET }
			])
		);
	});
});
