import uuidv1 from 'uuid/v1';
// import recordSaga from '@utils/testUtils';
import * as saga from 'ducks/myAccount/saga';
import * as actions from 'ducks/myAccount/actions';
import * as types from 'ducks/myAccount/types';
// import * as systemActionTypes from 'ducks/system/types';
import * as companyApi from 'endpoints/company';
import * as userApi from 'endpoints/user';
import * as mediaApi from 'endpoints/media';
import * as meApi from 'endpoints/me';
import { call, select } from 'redux-saga/effects';
import * as modalActionTypes from 'ducks/modal/types';

describe('myAccount sagas', () => {
	describe('UPDATE_COMPANY_DETAILS_REQUEST', () => {
		const id = uuidv1();

		const companyDetails = {
			funding: {
				investors: ''
			},
			linkedin: ''
		};

		const section = 'achievements'; // one of the section choices

		const transformedCompanyDetails = {
			funding: {
				investors: null
			},
			linkedin: null
		};
		it('UPDATE_COMPANY_DETAILS_SUCCESS', () => {
			const generator = saga.updateCompanyDetails(
				actions.updateCompanyDetails(id, companyDetails, null, section)
			);

			expect(generator.next().value).toEqual(
				call(companyApi.updateCompany, id, transformedCompanyDetails)
			);

			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.UPDATE_COMPANY_DETAILS_SUCCESS,
				payload: {},
				meta: { section }
			});

			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.GET_COMPANY_ACHIEVEMENTS,
				id
			});
		});

		it('UPDATE_COMPANY_DETAILS_FAILURE', () => {
			const generator = saga.updateCompanyDetails(
				actions.updateCompanyDetails(id, companyDetails, null, section)
			);
			expect(generator.next().value).toEqual(
				call(companyApi.updateCompany, id, transformedCompanyDetails)
			);
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.UPDATE_COMPANY_DETAILS_FAILURE,
				payload: 'error',
				meta: { section }
			});
		});
	});

	describe('MY_AVATAR_UPLOAD_REQUEST', () => {
		const companyId = uuidv1();
		const file = new File([], 'Screenshot_6.jpg');
		const position = { x: 45, y: 0, w: 65, h: 65 };
		const payload = { companyId, file, position, type: 'MY_AVATAR_UPLOAD_REQUEST' };

		it('MY_AVATAR_UPLOAD_SUCCESS', () => {
			const generator = saga.saveAvatar(actions.saveAvatar(companyId, file, position));
			expect(generator.next().value).toEqual(call(companyApi.saveAvatar, payload));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.MY_AVATAR_UPLOAD_SUCCESS,
				payload: {}
			});
			expect(generator.next().value.PUT.action).toMatchObject({
				type: modalActionTypes.MODAL_HIDE
			});
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.GET_COMPANY_VERSION_REQUEST,
				id: companyId
			});
		});

		it('MY_AVATAR_UPLOAD_FAILURE', () => {
			const generator = saga.saveAvatar(actions.saveAvatar(companyId, file, position));
			expect(generator.next().value).toEqual(call(companyApi.saveAvatar, payload));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.MY_AVATAR_UPLOAD_FAILURE,
				payload: 'error'
			});
		});
	});

	describe('GET_COMPANY_VERSION_REQUEST', () => {
		const companyId = uuidv1();

		it('GET_COMPANY_VERSION_SUCCESS', () => {
			const generator = saga.getCompanyVersion(actions.getVersion(companyId));
			expect(generator.next().value).toEqual(
				call(companyApi.getCompany, companyId, 'version')
			);
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.GET_COMPANY_VERSION_SUCCESS,
				payload: {}
			});
		});

		it('GET_COMPANY_VERSION_FAILURE', () => {
			const generator = saga.getCompanyVersion(actions.getVersion(companyId));
			expect(generator.next().value).toEqual(
				call(companyApi.getCompany, companyId, 'version')
			);
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.GET_COMPANY_VERSION_FAILURE,
				payload: 'error'
			});
		});
	});

	describe('GET_USER_DETAILS_REQUEST', () => {
		const id = uuidv1();

		it('GET_USER_DETAILS_SUCCESS', () => {
			const generator = saga.getUser(actions.getPersonalInfo(id));
			expect(generator.next().value).toEqual(call(userApi.getUser, id));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.GET_USER_DETAILS_SUCCESS,
				payload: {}
			});
		});

		it('GET_USER_DETAILS_FAILURE', () => {
			const generator = saga.getUser(actions.getPersonalInfo(id));
			expect(generator.next().value).toEqual(call(userApi.getUser, id));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.GET_USER_DETAILS_FAILURE,
				payload: 'error'
			});
		});
	});

	describe('UPDATE_USER_DETAILS_REQUEST', () => {
		const id = uuidv1();
		const personalInfo = {};
		it('UPDATE_USER_DETAILS_SUCCESS', () => {
			const generator = saga.updatePersonalInfo(
				actions.updatePersonalInfo(id, personalInfo)
			);
			expect(generator.next().value).toEqual(call(userApi.updateUser, id, personalInfo));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.UPDATE_USER_DETAILS_SUCCESS,
				payload: {}
			});
			expect(generator.next().value).toEqual(
				call(saga.getUser, { id })
			);
		});

		it('UPDATE_USER_DETAILS_FAILURE', () => {
			const generator = saga.updatePersonalInfo(
				actions.updatePersonalInfo(id, personalInfo)
			);
			expect(generator.next().value).toEqual(call(userApi.updateUser, id, personalInfo));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.UPDATE_USER_DETAILS_FAILURE,
				payload: 'error'
			});
			expect(generator.next().value.PUT.action).toMatchObject({
				meta: {
					form: 'personalInfo',
					submit: true
				},
				payload: {
					'': undefined
				},
				type: '@@form/SET_ERRORS'
			});
		});
	});

	describe('UPDATE_PASSWORD_REQUEST', () => {
		const id = uuidv1();
		const oldPassword = 'oldPassword';
		const newPassword = 'newPassword';

		it('UPDATE_PASSWORD_SUCCESS', () => {
			const generator = saga.updatePassword(
				actions.updatePassword(id, oldPassword, newPassword)
			);
			expect(generator.next().value).toEqual(
				call(userApi.changePassword, id, oldPassword, newPassword)
			);
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.UPDATE_PASSWORD_SUCCESS,
				payload: {}
			});
		});

		it('UPDATE_PASSWORD_FAILURE', () => {
			const generator = saga.updatePassword(
				actions.updatePassword(id, oldPassword, newPassword)
			);
			expect(generator.next().value).toEqual(
				call(userApi.changePassword, id, oldPassword, newPassword)
			);
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.UPDATE_PASSWORD_FAILURE,
				payload: 'error'
			});
			expect(generator.next().value.PUT.action).toMatchObject({
				meta: {
					form: 'password',
					submit: true
				},
				payload: {
					'': undefined
				},
				type: '@@form/SET_ERRORS'
			});
		});
	});

	describe('GET_TEAM_USERS_REQUEST', () => {
		it('GET_TEAM_USERS_SUCCESS', () => {
			const generator = saga.getTeamUsers(actions.getTeamUsers());
			expect(generator.next().value).toEqual(call(userApi.getUsers));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.GET_TEAM_USERS_SUCCESS,
				payload: {}
			});
		});

		it('GET_TEAM_USERS_FAILURE', () => {
			const generator = saga.getTeamUsers(actions.getTeamUsers());
			expect(generator.next().value).toEqual(call(userApi.getUsers));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.GET_TEAM_USERS_FAILURE,
				payload: 'error'
			});
		});
	});

	describe('CREATE_TEAM_USER_REQUEST', () => {
		const userDetails = {
			email: 'test@proov.io',
			first_name: 'firstname',
			last_name: 'lastname',
			role: 'user'
		};

		it('CREATE_TEAM_USER_SUCCESS', async () => {
			const generator = saga.inviteNewUser(actions.inviteNewUser(userDetails));
			expect(generator.next().value).toEqual(call(userApi.createUser, userDetails));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.CREATE_TEAM_USER_SUCCESS,
				payload: {}
			});
			expect(generator.next().value).toEqual(call(saga.getTeamUsers));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: modalActionTypes.MODAL_HIDE
			});
			expect(generator.next().value).toEqual(select());
		});

		it('CREATE_TEAM_USER_FAILURE', async () => {
			const generator = saga.inviteNewUser(actions.inviteNewUser(userDetails));
			expect(generator.next().value).toEqual(call(userApi.createUser, userDetails));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.CREATE_TEAM_USER_FAILURE,
				payload: 'error'
			});
			expect(generator.next().value.PUT.action).toMatchObject({
				meta: {
					form: 'userAddForm',
					submit: true
				},
				payload: {
					'': undefined
				},
				type: '@@form/SET_ERRORS'
			});
		});
	});

	describe('UPDATE_TEAM_USER_REQUEST', () => {
		const id = uuidv1();
		const userDetails = {
			email: 'test@proov.io',
			first_name: 'firstname',
			last_name: 'lastname',
			role: 'user'
		};
		it('UPDATE_TEAM_USER_SUCCESS', () => {
			const generator = saga.updateTeamUser(actions.updateTeamUser(id, userDetails));
			expect(generator.next().value).toEqual(call(userApi.updateUser, id, userDetails));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.UPDATE_TEAM_USER_SUCCESS,
				payload: {}
			});
			expect(generator.next().value).toEqual(call(saga.getTeamUsers));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: modalActionTypes.MODAL_HIDE
			});
		});

		it('UPDATE_TEAM_USER_FAILURE', () => {
			const generator = saga.updateTeamUser(actions.updateTeamUser(id, userDetails));
			expect(generator.next().value).toEqual(call(userApi.updateUser, id, userDetails));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.UPDATE_TEAM_USER_FAILURE,
				payload: 'error'
			});
			expect(generator.next().value.PUT.action).toMatchObject({
				meta: {
					form: 'userAccount',
					submit: true
				},
				payload: {
					'': undefined
				},
				type: '@@form/SET_ERRORS'
			});
		});
	});

	describe('DELETE_TEAM_USER_REQUEST', () => {
		const id = uuidv1();

		it('DELETE_TEAM_USER_SUCCESS', () => {
			const generator = saga.removeTeamUser(actions.removeUser(id));
			expect(generator.next().value).toEqual(call(userApi.deleteUser, id));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.DELETE_TEAM_USER_SUCCESS,
				payload: {}
			});
			expect(generator.next().value).toEqual(call(saga.getTeamUsers));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: modalActionTypes.MODAL_HIDE
			});
		});

		it('DELETE_TEAM_USER_FAILURE', () => {
			const generator = saga.removeTeamUser(actions.removeUser(id));
			expect(generator.next().value).toEqual(call(userApi.deleteUser, id));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.DELETE_TEAM_USER_FAILURE,
				payload: 'error'
			});
			expect(generator.next().value.PUT.action).toMatchObject({
				meta: {
					form: 'userAccount',
					submit: true
				},
				payload: {
					'': undefined
				},
				type: '@@form/SET_ERRORS'
			});
		});
	});

	describe('INVITE_TEAM_USER_REQUEST', () => {
		const id = uuidv1();

		it('INVITE_TEAM_USER_SUCCESS', () => {
			const generator = saga.inviteTeamUser(actions.inviteTeamUser(id));
			expect(generator.next().value).toEqual(call(userApi.sendInvite, id));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.INVITE_TEAM_USER_SUCCESS,
				payload: {}
			});
			expect(generator.next().value).toEqual(call(saga.getTeamUsers));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: modalActionTypes.MODAL_HIDE
			});
		});

		it('INVITE_TEAM_USER_FAILURE', () => {
			const generator = saga.inviteTeamUser(actions.inviteTeamUser(id));
			expect(generator.next().value).toEqual(call(userApi.sendInvite, id));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.INVITE_TEAM_USER_FAILURE,
				payload: 'error'
			});
			expect(generator.next().value.PUT.action).toMatchObject({
				meta: {
					form: 'userEditForm',
					submit: true
				},
				payload: {
					'': undefined
				},
				type: '@@form/SET_ERRORS'
			});
		});
	});

	describe('UPLOAD_RESOURCE_REQUEST', () => {
		const title = 'title';
		const url = 'https://proov.io';

		it('UPLOAD_RESOURCE_SUCCESS', () => {
			const generator = saga.uploadMediaUrl(actions.uploadMediaUrl({ title, url }));
			expect(generator.next().value).toEqual(
				call(mediaApi.createUrlMedia, { title, url })
			);
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.UPLOAD_RESOURCE_SUCCESS,
				payload: {}
			});
		});

		it('UPLOAD_RESOURCE_FAILURE', () => {
			const generator = saga.uploadMediaUrl(actions.uploadMediaUrl({ title, url }));
			expect(generator.next().value).toEqual(
				call(mediaApi.createUrlMedia, { title, url })
			);
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.UPLOAD_RESOURCE_FAILURE,
				payload: 'error'
			});
		});
	});

	describe('UPLOAD_FILE_RESOURCE_REQUEST', () => {
		const file = 'title';
		const intent = undefined; // action doesn't get an intent

		it('UPLOAD_FILE_RESOURCE_SUCCESS', () => {
			const generator = saga.uploadMediaFile(actions.uploadMediaFile(file));
			expect(generator.next().value).toEqual(
				call(mediaApi.createFileMedia, file, intent)
			);
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.UPLOAD_FILE_RESOURCE_SUCCESS,
				payload: {}
			});
		});

		it('UPLOAD_FILE_RESOURCE_FAILURE', () => {
			const generator = saga.uploadMediaFile(actions.uploadMediaFile(file));
			expect(generator.next().value).toEqual(
				call(mediaApi.createFileMedia, file, intent)
			);
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.UPLOAD_FILE_RESOURCE_FAILURE,
				payload: 'error'
			});
		});
	});

	describe('UPDATE_RESOURCE_REQUEST', () => {
		const id = uuidv1();
		const file = { title: 'file', version: '1' };

		it('UPDATE_RESOURCE_SUCCESS', () => {
			const generator = saga.updateMediaFile(actions.updateMediaFile(id, file));
			expect(generator.next().value).toEqual(call(mediaApi.updateMedia, id, file));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.UPDATE_RESOURCE_SUCCESS,
				payload: {}
			});
		});

		it('UPDATE_RESOURCE_FAILURE', () => {
			const generator = saga.updateMediaFile(actions.updateMediaFile(id, file));
			expect(generator.next().value).toEqual(call(mediaApi.updateMedia, id, file));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.UPDATE_RESOURCE_FAILURE,
				payload: 'error'
			});
		});
	});

	describe('GET_SUBSCRIPTION_REQUEST', () => {
		it('GET_SUBSCRIPTION_SUCCESS', () => {
			const generator = saga.getSubscription(actions.getSubscription());
			expect(generator.next().value).toEqual(call(meApi.getSubscription));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.GET_SUBSCRIPTION_SUCCESS,
				payload: {}
			});
		});

		it('GET_SUBSCRIPTION_FAILURE', () => {
			const generator = saga.getSubscription(actions.getSubscription());
			expect(generator.next().value).toEqual(call(meApi.getSubscription));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.GET_SUBSCRIPTION_FAILURE,
				payload: 'error'
			});
		});
	});

	describe('GET_USAGE_PER_PILOT_REQUEST', () => {
		const id = uuidv1();

		it('GET_USAGE_PER_PILOT_SUCCESS', () => {
			const generator = saga.getUsagePerPilot(actions.getUsagePerPilot(id));
			expect(generator.next().value).toEqual(call(meApi.getUsagePerPilot, id));
			expect(generator.next().value.PUT.action).toMatchObject({
				type: types.GET_USAGE_PER_PILOT_SUCCESS,
				payload: {}
			});
		});

		it('GET_USAGE_PER_PILOT_FAILURE', () => {
			const generator = saga.getUsagePerPilot(actions.getUsagePerPilot(id));
			expect(generator.next().value).toEqual(call(meApi.getUsagePerPilot, id));
			expect(generator.throw('error').value.PUT.action).toMatchObject({
				type: types.GET_USAGE_PER_PILOT_FAILURE,
				payload: 'error'
			});
		});
	});
});
