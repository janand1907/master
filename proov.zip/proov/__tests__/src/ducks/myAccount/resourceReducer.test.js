import * as types from 'ducks/myAccount/types';
import createAction from 'utils/createAction';
import { resources as reducer } from 'ducks/myAccount/reducers';

describe('recource reducers', () => {
	const initialState = {
		pending: false,
		error: '',
		timestamp: ''
	};

	it('Return the initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	/*[actionType.GET_COMPANY_DETAILS_REQUEST]: (state) => {
		return { ...state, pending: true, error: '' };
	},*/
	it(`Return State ${types.GET_COMPANY_DETAILS_REQUEST}`, () => {
		expect(reducer(initialState, createAction(types.GET_COMPANY_DETAILS_REQUEST, null)))
			.toEqual({ ...initialState, pending: true, error: '' });
	});

	/* [actionType.GET_COMPANY_DETAILS_SUCCESS]: (state) => {
		return { ...state, pending: false, error: '' };
	}, */
	it(`Return State ${types.GET_COMPANY_DETAILS_SUCCESS}`, () => {
		expect(reducer(initialState, createAction(types.GET_COMPANY_DETAILS_SUCCESS, null, { section: 'resources' })))
			.toEqual({ ...initialState, pending: false, error: '' });
	});

	/* [actionType.GET_COMPANY_DETAILS_FAILURE]: (state, payload) => {
		return { ...state, pending: false, error: payload.message };
	}, */
	it(`Return State ${types.GET_COMPANY_DETAILS_FAILURE}`, () => {
		expect(reducer(initialState,
			createAction(types.GET_COMPANY_DETAILS_FAILURE,	{ message: 'something went wrong' }, { section: 'resources' })))
			.toEqual({ ...initialState, pending: false, error: 'something went wrong' });
	});

	/* [actionType.UPDATE_COMPANY_DETAILS_REQUEST]: (state) => {
		return { ...state, pending: true, error: '' };
	}, */
	it(`Return State ${types.UPDATE_COMPANY_DETAILS_REQUEST}`, () => {
		expect(reducer(initialState, createAction(types.UPDATE_COMPANY_DETAILS_REQUEST, null)))
			.toEqual({ ...initialState, pending: true, error: '' });
	});

	/* [actionType.UPDATE_COMPANY_DETAILS_SUCCESS]: (state) => {
		return { ...state, pending: false, error: '' };
	}, */
	it(`Return State ${types.UPDATE_COMPANY_DETAILS_SUCCESS}`, () => {
		expect(reducer(initialState, createAction(types.UPDATE_COMPANY_DETAILS_SUCCESS, null, { section: 'resources' })))
			.toEqual({ ...initialState, pending: false, error: '' });
	});

	/* [actionType.UPDATE_COMPANY_DETAILS_FAILURE]: (state, payload) => {
		return { ...state, pending: false, error: payload.message };
	}, */
	it(`Return State ${types.UPDATE_COMPANY_DETAILS_FAILURE}`, () => {
		expect(reducer(initialState, createAction(types.UPDATE_COMPANY_DETAILS_FAILURE, { message: 'some good news!' }, { section: 'resources' })))
			.toEqual({ ...initialState, pending: false, error: 'some good news!' });
	});

	/* [actionType.SET_COMPANY_TIMESTAMP]: (state, payload) => {
		return { ...state, timestamp: payload };
	} */
	it(`Return State ${types.SET_COMPANY_TIMESTAMP}`, () => {
		expect(reducer(initialState,
			createAction(
				types.SET_COMPANY_TIMESTAMP,
				'some timestamp'
			)))
			.toEqual({ ...initialState, pending: false, timestamp: 'some timestamp' });
	});

});
