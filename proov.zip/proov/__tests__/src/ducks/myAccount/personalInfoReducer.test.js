import * as types from 'ducks/myAccount/types';
import createAction from 'utils/createAction';
import { personalInfo as reducer } from 'ducks/myAccount/reducers';

describe('my account personalInfo reducers', () => {
	const initialState = {
		pending: false,
		error: '',
		timestamp: ''
	};

	it('Return the initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it(`Return State ${types.GET_USER_DETAILS_REQUEST}`, () => {
		expect(reducer(initialState, createAction(types.GET_USER_DETAILS_REQUEST, null)))
		.toEqual({ ...initialState, pending: true, error: '' });
	});

	it(`Return State ${types.GET_USER_DETAILS_SUCCESS}`, () => {
		expect(reducer(initialState, createAction(types.GET_USER_DETAILS_SUCCESS, null)))
		.toEqual({ ...initialState, pending: false, error: '' });
	});

	it(`Return State ${types.GET_USER_DETAILS_FAILURE}`, () => {
		expect(reducer(initialState,
			createAction(types.GET_USER_DETAILS_FAILURE,	{ message: 'something went wrong' })))
			.toEqual({ ...initialState, pending: false, error: 'something went wrong' });
	});

	it(`Return State ${types.UPDATE_USER_DETAILS_REQUEST}`, () => {
		expect(reducer(initialState, createAction(types.UPDATE_USER_DETAILS_REQUEST, null)))
			.toEqual({ ...initialState, pending: true, error: '' });
	});

	it(`Return State ${types.UPDATE_USER_DETAILS_SUCCESS}`, () => {
		expect(reducer(initialState, createAction(types.UPDATE_USER_DETAILS_SUCCESS, null)))
			.toEqual({ ...initialState, pending: false, error: '' });
	});

	it(`Return State ${types.UPDATE_USER_DETAILS_FAILURE}`, () => {
			expect(reducer(initialState,
			createAction(types.UPDATE_USER_DETAILS_FAILURE,	{ message: 'something went wrong' })))
			.toEqual({ ...initialState, pending: false, error: 'something went wrong' });
	});

	it(`Return State ${types.SET_USER_TIMESTAMP}`, () => {
		expect(reducer(initialState,
			createAction(
				types.SET_USER_TIMESTAMP,
				'017-02-28T07:38:54.020Z'
			)))
			.toEqual({ ...initialState, pending: false, timestamp: '017-02-28T07:38:54.020Z' });
	});
});
