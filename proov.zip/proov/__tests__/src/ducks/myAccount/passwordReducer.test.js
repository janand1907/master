import { password as reducer } from 'ducks/myAccount/reducers';
import * as types from 'ducks/myAccount/types';

describe('my account password reducers', () => {
	const initialState = {
		pending: false,
		error: '',
		isSuccess: false
	};

	it('Return the initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it(`Return State ${types.UPDATE_PASSWORD_REQUEST}`, () => {
		expect(reducer(initialState, { type: types.UPDATE_PASSWORD_REQUEST })).toMatchSnapshot();
	});

	it(`Return State ${types.UPDATE_PASSWORD_SUCCESS}`, () => {
		expect(reducer(initialState, { type: types.UPDATE_PASSWORD_SUCCESS })).toMatchSnapshot();
	});

	it(`Return State ${types.UPDATE_PASSWORD_FAILURE}`, () => {
		expect(reducer(initialState, { type: types.UPDATE_PASSWORD_FAILURE, payload: { message: 'something went wrong' } })).toMatchSnapshot();
	});
});
