import * as types from 'ducks/myAccount/types';
import * as actions from 'ducks/myAccount/actions';
import createAction from 'utils/createAction';

describe('My Account actions', () => {
	const companyId = '2c9f93d957fb3223015815d155d40054';

	// saveAvatar
	it('Return Save Avatar action', () => {
		const file = new File([''], 'test');
		const position = { x: 10, y: 10, w: 10, h: 10 };

		const action = actions.saveAvatar(companyId, file, position);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.MY_AVATAR_UPLOAD_REQUEST,
				companyId,
				file,
				position
			})
		);
	});

	//uploadMediaUrl
	it('Return Upload Media Url Action', () => {
		const payload = {
			title: 'my vedio',
			url: 'youtub.com'
		};
		const resolve = jest.fn();
		const reject = jest.fn();

		const action = actions.uploadMediaUrl({ ...payload }, resolve, reject);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.UPLOAD_RESOURCE_REQUEST,
				title: payload.title,
				url: payload.url,
				resolve,
				reject
			})
		);

	});

	//uploadMediaFile
	it('Return Upload Media File Action', () => {
		const file = new File([''], 'test');
		const resolve = jest.fn();
		const reject = jest.fn();

		const action = actions.uploadMediaFile(file, resolve, reject);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.UPLOAD_FILE_RESOURCE_REQUEST,
				resolve,
				reject,
				file,
			})
		);
	});

	//updateMediaFile
	it('Return Update Media File Action', () => {

		const id = '1234';
		const patch = {
			title: 'title',
			url: 'bbc.co.uk'
		};
		const resolve = jest.fn();
		const reject = jest.fn();

		const action = actions.updateMediaFile(id, patch, resolve, reject);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.UPDATE_RESOURCE_REQUEST,
				id,
				patch,
				resolve,
				reject
			})
		);
	});

	// getVersion
	it('Return getCompany API action with "version" query parameter', () => {
		const id = '12345';
		const action = actions.getVersion(id);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_COMPANY_VERSION_REQUEST,
				id
			})
		);
	});
	//getGeneralInfo
	it('Return getGeneralInfo action', () => {
		const id = '12345';
		const action = actions.getGeneralInfo(id);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_COMPANY_GENERAL_INFO,
				id
			})
		);
	});
	//updateCompanyDetails
	it('Return updateCompanyAPI action', () => {
		const companyId = '12345';
		const payload = { size: 1, industry: 41, founded: 2015 };
		const action = actions.updateCompanyDetails(companyId, payload);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.UPDATE_COMPANY_DETAILS_REQUEST,
				id: companyId,
				payload
			})
		);
	});
	//getAchievements
	it('Return getAchievementsAPI action', () => {
		const companyId = '12345';
		const action = actions.getAchievements(companyId);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_COMPANY_ACHIEVEMENTS,
				id: companyId
			})
		);
	});
	//getFunding
	it('Return getFundingAPI action', () => {
		const companyId = '12345';
		const action = actions.getFunding(companyId);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_COMPANY_FUNDING,
				id: companyId
			})
		);
	});
	//getResources
	it('Return getResourcesAPI action', () => {
		const companyId = '12345';
		const action = actions.getResources(companyId);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_COMPANY_RESOURCES,
				id: companyId
			})
		);
	});
	//getPersonalInfo
	it('Return getPersonalInfoAPI action', () => {
		const userId = '123';
		const action = actions.getPersonalInfo(userId);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_USER_DETAILS_REQUEST,
				id: userId
			})
		);
	});
	//updatePersonalInfo
	it('Return updatePersonalInfoAPI action', () => {
		const userId = '123';
		const personalInfo = { full_name: 'Sandra Lee', job_title: 'Chief technology officer' };
		const action = actions.updatePersonalInfo(userId, personalInfo);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.UPDATE_USER_DETAILS_REQUEST,
				id: userId,
				personalInfo
			})
		);
	});
	//updatePassword
	it('Return updatePassword action', () => {
		const userId = '123';
		const payload = { oldPassword: 'bobo2016', newPassword: 'momo2017' };
		const action = actions.updatePassword(userId, payload.oldPassword, payload.newPassword);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.UPDATE_PASSWORD_REQUEST,
				id: userId,
				oldPassword: payload.oldPassword,
				newPassword: payload.newPassword
			})
		);
	});
	it('Return setCompanyTimestamp Action', () => {
		const timestamp = new Date().getTime();
		const action = actions.setCompanyTimestamp(timestamp);
		expect(action).toEqual(createAction(types.SET_COMPANY_TIMESTAMP, timestamp));
	});
	it('Return setUserTimestamp Action', () => {
		const timestamp = new Date().getTime();
		const action = actions.setUserTimestamp(timestamp);
		expect(action).toEqual(createAction(types.SET_USER_TIMESTAMP, timestamp));
	});
	it('Return inviteNewUser API Action', () => {
		const action = actions.getTeamUsers();
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_TEAM_USERS_REQUEST
			})
		);
	});
	it('Return updateTeamUser API Action', () => {
		const id = '1234';
		const userDetails = { role: 'user', status: 'inactive', version: '1' };
		const action = actions.updateTeamUser(id, userDetails);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.UPDATE_TEAM_USER_REQUEST,
				id,
				userDetails
			})
		);
	});
	it('Return removeUser API Action', () => {
		const id = '1234';
		const action = actions.removeUser(id);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.DELETE_TEAM_USER_REQUEST,
				id
			})
		);
	});
	it('Return inviteNewUser', () => {
		const userDetails = { role: 'user', status: 'inactive', version: '1' };
		const action = actions.inviteNewUser(userDetails);
		expect(action).toEqual(
			expect.objectContaining({
				type: types.CREATE_TEAM_USER_REQUEST,
				userDetails
			})
		);
	});
	it('Get the user subscription plan', () => {
		const action = actions.getSubscription();
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_SUBSCRIPTION_REQUEST
			})
		);
	});

	it('Get the usage per pilot', () => {
		const action = actions.getUsagePerPilot();
		const id = '1234';
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_USAGE_PER_PILOT_REQUEST,
				id
			})
		);
	});

	it('Get the global usage', () => {
		const action = actions.getGlobalUsage();
		expect(action).toEqual(
			expect.objectContaining({
				type: types.GET_SUBSCRIPTION_REQUEST
			})
		);
	});

});
