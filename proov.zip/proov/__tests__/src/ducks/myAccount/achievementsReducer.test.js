import * as types from 'ducks/myAccount/types';
import { achievements as reducer } from 'ducks/myAccount/reducers';


describe('my account achievements reducers', () => {
	const initialState = {
		pending: false,
		error: '',
		timestamp: ''
	};
	const section = 'foo';

	it('Return the initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it(`Return State ${types.GET_COMPANY_DETAILS_REQUEST}`, () => {
		expect(reducer(initialState, { type: types.GET_COMPANY_DETAILS_REQUEST })).toMatchSnapshot();
	});

	it(`Return State ${types.GET_COMPANY_DETAILS_SUCCESS}`, () => {
		expect(reducer(initialState, { type: types.GET_COMPANY_DETAILS_SUCCESS, meta: { section } })).toMatchSnapshot();
	});

	it(`Return State ${types.GET_COMPANY_DETAILS_FAILURE}`, () => {
		expect(reducer(initialState, { type: types.GET_COMPANY_DETAILS_FAILURE, payload:{ message: 'something went wrong' }, meta: { section: 'achievements' } })).toMatchSnapshot();
	});


	it(`Return State ${types.UPDATE_COMPANY_DETAILS_REQUEST}`, () => {
		expect(reducer(initialState, { type: types.UPDATE_COMPANY_DETAILS_REQUEST })).toMatchSnapshot();
	});

	it(`Return State ${types.UPDATE_COMPANY_DETAILS_SUCCESS}`, () => {
		expect(reducer(initialState, { type: types.UPDATE_COMPANY_DETAILS_SUCCESS, meta: { section } })).toMatchSnapshot();
	});

	it(`Return State ${types.UPDATE_COMPANY_DETAILS_FAILURE}`, () => {
		expect(reducer(initialState, { type: types.UPDATE_COMPANY_DETAILS_FAILURE, payload: { message: 'something went wrong' }, meta: { section: 'achievements' } })).toMatchSnapshot();
	});

	it(`Return State ${types.SET_COMPANY_TIMESTAMP}`, () => {
		expect(reducer(initialState, { type: types.SET_COMPANY_TIMESTAMP, payload: '017-02-28T07:38:54.020Z' })).toMatchSnapshot();
	});

});
