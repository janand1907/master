import * as types from 'ducks/myAccount/types';
import { avatar as reducer } from 'ducks/myAccount/reducers';


describe('my account general info reducers', () => {
	const initialState = {
		pending: false,
		error: '',
	};

	it('Return the initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it(`Return state ${types.MY_AVATAR_UPLOAD_REQUEST}`, () => {
		expect(reducer(initialState, { type: types.MY_AVATAR_UPLOAD_REQUEST })).toMatchSnapshot();
	});

	it(`Return state ${types.MY_AVATAR_UPLOAD_SUCCESS}`, () => {
		expect(reducer(initialState, { type: types.MY_AVATAR_UPLOAD_SUCCESS })).toMatchSnapshot();
	});

	it(`Return state ${types.MY_AVATAR_UPLOAD_FAILURE}`, () => {
		expect(reducer(initialState, { type: types.MY_AVATAR_UPLOAD_FAILURE, payload:{ message: 'something went wrong' } })).toMatchSnapshot();
	});
});
