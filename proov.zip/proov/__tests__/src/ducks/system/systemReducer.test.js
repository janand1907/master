import reducer, { initialState } from 'ducks/system/reducers';
import * as actionTypes from 'ducks/system/types';


const flags = {
	notifications: false,
	messages: false,
	account: false,
	menuMobile: false,
	isSFRegister: true
};


describe('systemReducer', () => {
	it('initial state', () => {
		expect(reducer(undefined, {})).toEqual(initialState);
	});

	it('CHUNK_LOADING', () => {
		expect(reducer(undefined, {
			type: actionTypes.CHUNK_LOADING
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, chunksCount: 1 } });
	});

	it('CHUNK_LOADED', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, chunksCount: 1 } }, {
			type: actionTypes.CHUNK_LOADED
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, chunksCount: 0 } });
	});

	it('SYSTEM_GET_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.SYSTEM_GET_REQUEST
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, get: true } });
	});

	it('SYSTEM_GET_SUCCESS', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.SYSTEM_GET_SUCCESS,
			payload: flags
		}))
			.toEqual({ ...initialState, flags });
	});

	it('SYSTEM_GET_FAILURE', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.SYSTEM_GET_FAILURE,
		}))
			.toEqual({ ...initialState });
	});

	it('DONT_SHOW_HELP_REQUEST', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.DONT_SHOW_HELP_REQUEST,
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, get: true } });
	});

	it('DONT_SHOW_HELP_SUCCESS', () => {
		expect(reducer({ ...initialState, flags }, {
			type: actionTypes.DONT_SHOW_HELP_SUCCESS,
		}))
			.toEqual({ ...initialState, flags: { ...flags, show_join_help: false } });
	});

	it('DONT_SHOW_HELP_FAILURE', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.DONT_SHOW_HELP_FAILURE,
		}))
			.toEqual({ ...initialState });
	});

	it('OPEN_POPOVER', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.OPEN_POPOVER,
			payload: 'notifications'
		}))
			.toEqual({ ...initialState, header: { ...initialState.header, 'notifications': true } });
	});

	it('CLOSE_POPOVER', () => {
		expect(reducer({ ...initialState, header: { ...initialState.header, 'notifications': true } }, {
			type: actionTypes.CLOSE_POPOVER,
			payload: 'notifications'
		}))
			.toEqual({ ...initialState, header: { ...initialState.header, 'notifications': false } });
	});

	it('CLOSE_ALL_POPOVERS', () => {
		expect(reducer({
			...initialState,
			header: {
				...initialState.header,
				notifications: true,
				messages: true,
				account: true,
				menuMobile: true
			}
		}, {
			type: actionTypes.CLOSE_ALL_POPOVERS,
		}))
			.toEqual({ ...initialState });
	});

	it('TOGGLE_POPOVER - OPEN', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.TOGGLE_POPOVER,
			payload: 'notifications'
		}))
			.toEqual({ ...initialState, header: { ...initialState.header, notifications: true } });
	});

	it('TOGGLE_POPOVER - CLOSE', () => {
		expect(reducer({ ...initialState, header: { ...initialState.header, notifications: true } }, {
			type: actionTypes.TOGGLE_POPOVER,
			payload: 'notifications'
		}))
			.toEqual({ ...initialState, header: { ...initialState.header, notifications: false } });
	});

	it('RESET_MESSAGES_REQUEST', () => {
		expect(reducer({ ...initialState, flags: { ...flags, new_messages_count: 2 } }, {
			type: actionTypes.RESET_MESSAGES_REQUEST,
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, get: true }, flags: { ...flags, new_messages_count: 0 } });
	});

	it('RESET_MESSAGES_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, get: true } }, {
			type: actionTypes.RESET_MESSAGES_SUCCESS,
		}))
			.toEqual({ ...initialState });
	});

	it('RESET_MESSAGES_FAILURE', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, get: true } }, {
			type: actionTypes.RESET_MESSAGES_FAILURE,
		}))
			.toEqual({ ...initialState });
	});

	it('RESET_NOTS_REQUEST', () => {
		expect(reducer({ ...initialState, flags: { ...flags, new_notifications_count: 2 } }, {
			type: actionTypes.RESET_NOTS_REQUEST,
		}))
			.toEqual({ ...initialState, pending: { ...initialState.pending, get: true }, flags: { ...flags, new_notifications_count: 0 } });
	});

	it('RESET_NOTS_SUCCESS', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, get: true } }, {
			type: actionTypes.RESET_NOTS_SUCCESS,
		}))
			.toEqual({ ...initialState });
	});

	it('RESET_NOTS_FAILURE', () => {
		expect(reducer({ ...initialState, pending: { ...initialState.pending, get: true } }, {
			type: actionTypes.RESET_NOTS_FAILURE,
		}))
			.toEqual({ ...initialState });
	});

	it('SET_MODULE', () => {
		expect(reducer({ ...initialState }, {
			type: actionTypes.SET_MODULE,
			payload: 'welcome'
		}))
			.toEqual({ ...initialState, currentModule: 'welcome' });
	});
});
