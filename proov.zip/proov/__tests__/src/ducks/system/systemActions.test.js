import * as actions from 'ducks/system/actions';
import * as types from 'ducks/system/types';

describe('actions', () => {

	it('should create an action to open a popover', () => {
		const payload = 'account';
		const expectedAction = {
			type: types.OPEN_POPOVER,
			payload
		};
		expect(actions.openPopover(payload)).toEqual(expectedAction);
	});

	it('should create an action to close a popover', () => {
		const payload = 'notifications';
		const expectedAction = {
			type: types.CLOSE_POPOVER,
			payload
		};
		expect(actions.closePopover(payload)).toEqual(expectedAction);
	});

	it('should create an action to close all popovers', () => {
		const expectedAction = {
			type: types.CLOSE_ALL_POPOVERS
		};
		expect(actions.closeAllPopovers()).toEqual(expectedAction);
	});
});
