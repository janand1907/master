import * as selectors from 'ducks/system/selectors';

const state = {
	system: {
		flags: {
			monetization: true,
			show_join_help: false,
			new_notifications_count: 0,
			new_messages_count: 0
		},
		pending: {
			get: false,
			chunksCount: 0
		},
		header: {
			notifications: false,
			messages: true,
			account: false,
			menuMobile: true
		},
		currentModule: 'admin'
	}
};

describe('system selectors', () => {
	it('getSystem', () => {
	  	expect(selectors.getSystem(state)).toEqual(state.system);
	});

	it('getFlags', () => {
		expect(selectors.getFlags(state)).toEqual(state.system.flags);
	});

	it('getHeader', () => {
		expect(selectors.getHeader(state)).toEqual(state.system.header);
	});

	it('isSystemPending', () => {
		expect(selectors.isSystemPending(state)).toEqual(state.system.pending.get);
	});

	it('isChunksCountPending', () => {
		expect(selectors.isSystemPending(state)).toEqual(state.system.pending.chunksCount > 0);
	});

	it('getSystemCurrentModule', () => {
		expect(selectors.getSystemCurrentModule(state)).toEqual(state.system.currentModule);
	});
});
