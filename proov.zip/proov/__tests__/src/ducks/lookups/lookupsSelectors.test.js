import * as lookupsSelectors from 'ducks/lookups/selectors';
import { country, industry, region, category, company_size } from '../../../../server/json/common';

const state = {
	lookups: {
		country: { pending: false, data: country },
		industry: { pending: true, data: industry },
		category: { pending: false, data: category },
		region: { pending: true, data: region },
		company_size: { pending: false, data: company_size }
	}
};

describe('lookups selectors', () => {
	it('getLookups', () => {
	  	expect(lookupsSelectors.getLookups(state)).toEqual(state.lookups);
	});

	it('getCountries', () => {
	  	expect(lookupsSelectors.getCountries(state)).toEqual(state.lookups.country);
	});

	it('getRegions', () => {
		  expect(lookupsSelectors.getRegions(state)).toEqual(state.lookups.region);
	});

	it('getCategories', () => {
	  	expect(lookupsSelectors.getCategories(state)).toEqual(state.lookups.category);
	});

	it('getIndustries', () => {
	  	expect(lookupsSelectors.getIndustries(state)).toEqual(state.lookups.industry);
	});

	it('getCompanySizes', () => {
	  	expect(lookupsSelectors.getCompanySizes(state)).toEqual(state.lookups.company_size);
	});
});
