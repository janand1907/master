import { getLookups } from 'ducks/lookups/actions';
import { LOOKUPS_FETCH_REQUEST } from 'ducks/lookups/types';

describe('actions', () => {

	it('should create an action getLookups', () => {
		const lookupTypes = 'industry';
		const action = getLookups(lookupTypes);

		expect(action).toEqual(
			expect.objectContaining({
				type: LOOKUPS_FETCH_REQUEST,
				lookupTypes: ['industry']
			})
		);

	});

});
