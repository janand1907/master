import * as datasetTypes from 'ducks/repository/deepMirroring/types';
import * as actions from 'ducks/repository/deepMirroring/actions';

describe('DeepMirroring Actions', () => {

	it('Create dataset draft', () => {
		const meta = [null, { mixpanel: { event: 'Deep Mirroring - Create Dataset' } }, null];


		expect(actions.createDraftDataset()).toEqual({
			type: datasetTypes.CREATE_DATASET_REQUEST,
			payload: null,
			meta
		});
	});

	it('Get generated dataset resource URL', () => {
		const resolve = jest.fn();
		const datasetId = '1234';

		expect(actions.getGeneratedDatasetURL(datasetId, resolve)).toEqual({
			type: datasetTypes.GET_GENERATED_DATASET_URL_REQUEST,
			datasetId,
			resolve
		});

	});

});

describe('DeepMirroring - Search Dataset Actions', () => {

	it('set Search Keyword action', () => {
		const keyword = 'fooooo';

		expect(actions.setSearchKeyword(keyword)).toEqual({
			type: datasetTypes.SET_DM_SEARCH_KEYWORD,
			payload: keyword
		});

	});

	it('set Search Filters action', () => {
		const filters = 'fooooo';

		expect(actions.setSearchFilters(filters)).toEqual({
			type: datasetTypes.SET_DM_SEARCH_FILTERS,
			payload: filters
		});

	});

	it('set Search sort action', () => {
		const sort = 'fooooo';

		expect(actions.setSearchSort(sort)).toEqual({
			type: datasetTypes.SET_DM_SEARCH_SORT,
			payload: sort
		});

	});

	it('Get datasets action', () => {

		expect(actions.getDatasets()).toEqual({
			type: datasetTypes.GET_DATASETS_REQUEST,
		});

	});
});
