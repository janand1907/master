/* global API_ROOT */

import * as types from 'ducks/pdfExport/types';
import * as actions from 'ducks/pdfExport/actions';

describe('pdfExport actions', () => {

	it('showHtml', () => {
		const template = 'pocReport';
		const data = { someProp: 1 };
		const action = actions.showHtml(template, data);

		expect(action).toEqual(
			expect.objectContaining({
				type: types.HTML_SHOW,
				payload: { template, data }
			})
		);
	});

	it('hideHtml', () => {
		const action = actions.hideHtml();
		expect(action).toEqual(expect.objectContaining({ type: types.HTML_HIDE }));
	});
});
