import * as types from 'ducks/pdfExport/types';
import reducer from 'ducks/pdfExport/reducers';

const initialState = {
	template: '',
	isExporting: false,
	data: null
};

describe('pdfExport reducer', () => {
	const template = 'pocReport';
	const data = { someProp: 1 };
	it(`Return State ${types.HTML_SHOW}`, () => {
		expect(reducer(initialState, { type: types.HTML_SHOW, payload: { template, data } })).toMatchSnapshot();
	});

	it(`Return State ${types.HTML_HIDE}`, () => {
		expect(reducer(initialState, { type: types.HTML_HIDE })).toMatchSnapshot();
	});
});
