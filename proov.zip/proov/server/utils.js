/* eslint-disable camelcase */

export function error(message, error_type, error_data) {
	return {
		errors: [
			{
				message,
				error_type,
				error_data
			}
		]
	};
}

export function ok(message) {
	return { status: 'ok', message: message || 'ok' };
}

export function requireAuth(req, res, next) {
	if (!req.session.user) {
		res.status(401).json(error(`You're not connected.`));
	} else {
		return next();
	}
}

export function take(array, limit, skip) {
	return array.slice(skip || 0, (skip || 0) + (limit || array.length));
}

export function fakeId(length = 5) {
	let text = '';
	let possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

	for (let i = 0; i < length; i++) {
		  text += possible.charAt(Math.floor(Math.random() * possible.length));
	}

	return text;
}
