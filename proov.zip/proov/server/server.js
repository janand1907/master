/* eslint-disable no-console */

import path from 'path';
import http from 'http';
import colors from 'colors/safe';
import express from 'express';
import session from 'express-session';
import bodyParser from 'body-parser';
import webpack from 'webpack';
import webpackDevMiddleware from 'webpack-dev-middleware';
import webpackHotMiddleware from 'webpack-hot-middleware';
import inquirer from 'inquirer';
import chalk from 'chalk';
import configDev from '../webpack.dev';
import configStage from '../webpack.stage';
import configProd from '../webpack.prod';
import resRouter from './res';
import apiRouter from './api';
import proxy from './proxy';

colors.setTheme({ error: 'red', info: 'green' });

inquirer
	.prompt([
		{
			type: 'list',
			message: 'Choose proxy for your local environment:',
			name: 'environment',
			choices: ['DEVELOPMENT', 'TESTING', 'STAGING', 'PRODUCTION']
		}
	])
	.then(answers => {
		const app = express();

		const webpackConfig = {
			DEVELOPMENT: configDev,
			TESTING: configStage,
			STAGING: configStage,
			PRODUCTION: configProd
		};

		const config = webpackConfig.DEVELOPMENT; // answers.environment
		const compiler = webpack(config);

		app.use(
			webpackDevMiddleware(compiler, {
				logLevel: 'warn',
				publicPath: config.output.publicPath,
				hot: true
			})
		);
		const isMultipartRequest = function (req) {
		
			let contentTypeHeader = req.headers['content-type'];
			return contentTypeHeader && contentTypeHeader.indexOf('multipart') > -1;
		  };
		  
		app.use(
			webpackHotMiddleware(compiler, {
				log: console.log,
				path: '/__webpack_hmr',
				heartbeat: 10 * 1000,
				reload: true
			})
		);
		const bodyParserJsonMiddleware = function () {
			return function (req, res, next) {
			  if (isMultipartRequest(req)) {
				console.log("isMultipartRequest",req.user);
				return next();
			  }
			  return bodyParser.json()(req, res, next);
			};
		  };
		  
		  app.use(bodyParserJsonMiddleware());
		// Enable JSON-encoded bodies
		

		app.use(
			session({
				secret: 'shh!',
				unset: 'destroy',
				resave: false,
				saveUninitialized: false,
				cookie: {
					maxAge: 1000 * 60 * 30 // 30 min
				},
				rolling: true
			})
		);

		switch (answers.environment) {
			case 'DEVELOPMENT':
				app.use('/api', apiRouter);
				break;
			case 'TESTING':
				app.use('/api', proxy('TEST'));
				break;
			case 'STAGING':
				app.use('/api', proxy('STAG'));
				break;
			case 'PRODUCTION':
				app.use('/api', proxy('PROD'));
				break;
		}

		app.use('/res', resRouter); // serves resources (user-uploads etc.)

		// https://github.com/ampedandwired/html-webpack-plugin/issues/145#issuecomment-170554832
		app.use('*', (req, res, next) => {
			const filename = path.join(compiler.outputPath, 'index.html');
			compiler.outputFileSystem.readFile(filename, (err, result) => {
				if (err) {
					return next(err);
				}
				res.set('content-type', 'text/html');
				res.send(result);
				res.end();
			});
		});

		let server = http.createServer(app);
		server.listen(process.env.PORT || 3000, () => {
			console.log(
				'\n==> Starting server on ' +
					chalk.cyan.underline(`http://localhost:${server.address().port}/\n`)
			);
		});
	});
