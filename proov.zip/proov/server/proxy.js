import createProxyMiddleware  from 'http-proxy-middleware';

const connectTo = {
	TEST: '//testingapp.proov.io',
	STAG: '//imda-app.proov.io',//'//stageapp.proov.io',
	PROD: '//app.proov.io'
};

let sessionId = '';

const proxyOptions = connection => createProxyMiddleware ({

	target: 'https:' + connectTo[connection],
	changeOrigin: true,
	onProxyReq: (proxyReq, req, res, options) => {
		proxyReq.setHeader(
			'Cookie',
			`${proxyReq.getHeader('Cookie')};${sessionId}`
		);
		if (
			req.headers['content-type'] &&
			req.headers['content-type'].match(/^multipart\/form-data/)
		) {
			// build a string in multipart/form-data format with the data you need
			const formdataUser =
				`--${req.headers['content-type'].replace(/^.*boundary=(.*)$/, '$1')}\r\n` +
				`Content-Disposition: form-data; name="reqUser"\r\n` +
				`\r\n` +
				`${JSON.stringify(req.user)}\r\n`
			// set the new content length
			proxyReq.setHeader(
				'Content-Length',
				parseInt(req.headers['content-length']) + Buffer.byteLength(formdataUser)
			)
			proxyReq.write(formdataUser)
		} else {
			if (
				(req.method == 'POST' || req.method == 'PUT' || req.method == 'PATCH') &&
				req.body
			) {
				proxyReq.write(JSON.stringify(req.body));
			}
			proxyReq.end();
		}
	
	},
	onProxyRes: (proxyRes, req, res) => {
		try {
			sessionId = proxyRes.headers['set-cookie']
				.join(';')
				.match(/(JSESSIONID[^\s;]*)/i)[0];
		} catch (err) { }
	}
});

export default proxyOptions;
