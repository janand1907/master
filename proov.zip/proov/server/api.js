/* eslint-disable import/newline-after-import, camelcase */

import express from 'express';
import colors from 'colors/safe';
import * as routes from './routes';
import { error } from './utils';

colors.setTheme({ error: 'red' });

const router = express.Router();

// Delay all responses
const delay = 500;
router.use((req, res, next) => {
	setTimeout(() => next(), delay);
});

// Register API routes
Object.keys(routes).forEach((key) => routes[key](router));

// Fallback route
router.use('*', (req, res) => {
	res.status(404);
	res.json(error('Not found'));
});

// Error handler
router.use((err, req, res, next) => {
	res.status(500);
	console.error(colors.error(err));
	res.json(error('Something went wrong :('));
});

export default router;
