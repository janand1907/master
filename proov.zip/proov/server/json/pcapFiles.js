import uniqid from 'uniqid';

const pcapFiles = [
	{
		id: uniqid(),
		file_name: 'File A',
		date_created: new Date('1/25/2016'),
		status: 'ready',
		type: 'pcap',
		is_generated: false,
		size: 200,
		meta: {
			original_ips: '82.81.87.206, 82.81.87.122'
		}
	},
	{
		id: uniqid(),
		file_name: 'File B File B File B File B File B File B File B File B File B File B',
		date_created: new Date('1/25/2015'),
		status: 'ready',
		type: 'pcap',
		is_generated: false,
		size: 178,
		meta: {
			original_ips: '82.81.87.206, 82.81.87.122'
		}
	},
	{
		id: uniqid(),
		file_name: 'File C',
		date_created: new Date('1/25/2016'),
		status: 'in_progress',
		type: 'pcap',
		is_generated: false,
		size: 562,
		meta: {
			original_ips: '82.81.87.206'
		}
	},
	{
		id: uniqid(),
		file_name: 'File D',
		date_created: new Date('1/25/2016'),
		status: 'failed',
		type: 'pcap',
		is_generated: false,
		size: 300,
		meta: {
			original_ips: '82.81.87.206'
		}
	},
	{
		id: uniqid(),
		file_name: 'File D',
		date_created: new Date('1/25/2016'),
		status: 'uploading',
		type: 'pcap',
		is_generated: false,
		size: 562,
		meta: {
			original_ips: '82.81.87.206'
		}
	}
];

export default pcapFiles;
