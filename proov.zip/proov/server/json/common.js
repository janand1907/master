/* eslint-disable camelcase */

export const industry = {
	'47': 'Accounting',
	'94': 'Airlines/Aviation',
	'120': 'Alternative Dispute Resolution',
	'125': 'Alternative Medicine',
	'127': 'Animation',
	'19': 'Apparel & Fashion',
	'50': 'Architecture & Planning',
	'111': 'Arts and Crafts',
	'53': 'Automotive',
	'52': 'Aviation & Aerospace',
	'41': 'Banking',
	'12': 'Biotechnology',
	'36': 'Broadcast Media',
	'49': 'Building Materials',
	'138': 'Business Supplies and Equipment',
	'129': 'Capital Markets',
	'54': 'Chemicals',
	'90': 'Civic & Social Organization',
	'51': 'Civil Engineering',
	'128': 'Commercial Real Estate',
	'118': 'Computer & Network Security',
	'109': 'Computer Games',
	'3': 'Computer Hardware',
	'5': 'Computer Networking',
	'4': 'Computer Software',
	'48': 'Construction',
	'24': 'Consumer Electronics',
	'25': 'Consumer Goods',
	'91': 'Consumer Services',
	'18': 'Cosmetics',
	'65': 'Dairy',
	'1': 'Defense & Space',
	'99': 'Design',
	'69': 'Education Management',
	'132': 'E-Learning',
	'112': 'Electrical/Electronic Manufacturing',
	'28': 'Entertainment',
	'86': 'Environmental Services',
	'110': 'Events Services',
	'76': 'Executive Office',
	'122': 'Facilities Services',
	'63': 'Farming',
	'43': 'Financial Services',
	'38': 'Fine Art',
	'66': 'Fishery',
	'34': 'Food & Beverages',
	'23': 'Food Production',
	'101': 'Fund-Raising',
	'26': 'Furniture',
	'29': 'Gambling & Casinos',
	'145': 'Glass, Ceramics & Concrete',
	'75': 'Government Administration',
	'148': 'Government Relations',
	'140': 'Graphic Design',
	'124': 'Health, Wellness and Fitness',
	'68': 'Higher Education',
	'14': 'Hospital & Health Care',
	'31': 'Hospitality',
	'137': 'Human Resources',
	'134': 'Import and Export',
	'88': 'Individual & Family Services',
	'147': 'Industrial Automation',
	'84': 'Information Services',
	'96': 'Information Technology and Services',
	'42': 'Insurance',
	'74': 'International Affairs',
	'141': 'International Trade and Development',
	'6': 'Internet',
	'45': 'Investment Banking',
	'46': 'Investment Management',
	'73': 'Judiciary',
	'77': 'Law Enforcement',
	'9': 'Law Practice',
	'10': 'Legal Services',
	'72': 'Legislative Office',
	'30': 'Leisure, Travel & Tourism',
	'85': 'Libraries',
	'116': 'Logistics and Supply Chain',
	'143': 'Luxury Goods & Jewelry',
	'55': 'Machinery',
	'11': 'Management Consulting',
	'95': 'Maritime',
	'97': 'Market Research',
	'80': 'Marketing and Advertising',
	'135': 'Mechanical or Industrial Engineering',
	'126': 'Media Production',
	'17': 'Medical Devices',
	'13': 'Medical Practice',
	'139': 'Mental Health Care',
	'71': 'Military',
	'56': 'Mining & Metals',
	'35': 'Motion Pictures and Film',
	'37': 'Museums and Institutions',
	'115': 'Music',
	'114': 'Nanotechnology',
	'81': 'Newspapers',
	'100': 'Non-Profit Organization Management',
	'57': 'Oil & Energy',
	'113': 'Online Media',
	'123': 'Outsourcing/Offshoring',
	'87': 'Package/Freight Delivery',
	'146': 'Packaging and Containers',
	'61': 'Paper & Forest Products',
	'39': 'Performing Arts',
	'15': 'Pharmaceuticals',
	'131': 'Philanthropy',
	'136': 'Photography',
	'117': 'Plastics',
	'107': 'Political Organization',
	'67': 'Primary/Secondary Education',
	'83': 'Printing',
	'105': 'Professional Training & Coaching',
	'102': 'Program Development',
	'79': 'Public Policy',
	'98': 'Public Relations and Communications',
	'78': 'Public Safety',
	'82': 'Publishing',
	'62': 'Railroad Manufacture',
	'64': 'Ranching',
	'44': 'Real Estate',
	'40': 'Recreational Facilities and Services',
	'89': 'Religious Institutions',
	'144': 'Renewables & Environment',
	'70': 'Research',
	'32': 'Restaurants',
	'27': 'Retail',
	'121': 'Security and Investigations',
	'7': 'Semiconductors',
	'58': 'Shipbuilding',
	'20': 'Sporting Goods',
	'33': 'Sports',
	'104': 'Staffing and Recruiting',
	'22': 'Supermarkets',
	'8': 'Telecommunications',
	'60': 'Textiles',
	'130': 'Think Tanks',
	'21': 'Tobacco',
	'108': 'Translation and Localization',
	'92': 'Transportation/Trucking/Railroad',
	'59': 'Utilities',
	'106': 'Venture Capital & Private Equity',
	'16': 'Veterinary',
	'93': 'Warehousing',
	'133': 'Wholesale',
	'142': 'Wine and Spirits',
	'119': 'Wireless',
	'103': 'Writing and Editing',
	'200': 'Other',
	'1123': 'Software B2B',
	'1124': 'Software B2C',
	'1125': 'Software B2B2C',
	'1126': 'Software Services',
	'1127': 'Hardware'
};

export const category = {
	'2c9f90d1582b308e01582b31554502e6': 'Advertising & Marketing',
	'2c9f90d1582b308e01582b31555d02e7': 'AR/VR',
	'2c9f90d1582b308e01582b31557602e8': 'Big Data',
	'2c9f90d1582b308e01582b31558e02e9': 'Business Intelligence',
	'2c9f90d1582b308e01582b3155a502ea': 'Communication',
	'2c9f90d1582b308e01582b3155bd02eb': 'Cyber Security',
	'2c9f90d1582b308e01582b3155d402ec': 'Healthcare',
	'2c9f90d1582b308e01582b3155ec02ed': 'Enterprise Software',
	'2c9f90d1582b308e01582b31560402ee': 'FinTech',
	'2c9f90d1582b308e01582b31561b02ef': 'Internet & Mobile',
	'2c9f90d1582b308e01582b31563202f0': 'IoT',
	'2c9f90d1582b308e01582b31564802f1': 'Machine Learning and AI',
	'2c9f90d1582b308e01582b31565f02f2': 'Other',
	'2c9f90d1582b308e01582b31567702f3': 'Storage & Cloud'
};

export const country = {
	'Afghanistan': {
		'code': 'AF',
		'dial_code': '93',
		'label': 'Afghanistan',
		'region': 'Asia'
	},
	'Albania': {
		'code': 'AL',
		'dial_code': '355',
		'label': 'Albania',
		'region': 'East Europe'
	},
	'Algeria': {
		'code': 'DZ',
		'dial_code': '213',
		'label': 'Algeria',
		'region': 'Africa'
	},
	'United States Minor Outlying Islands': {
		'code': 'UM',
		'dial_code': '1',
		'label': 'American Virgin Islands',
		'region': 'Latin America'
	},
	'Angola': {
		'code': 'AO',
		'dial_code': '244',
		'label': 'Angola',
		'region': 'Africa'
	},
	'Argentina': {
		'code': 'AR',
		'dial_code': '54',
		'label': 'Argentina',
		'region': 'Latin America'
	},
	'Armenia': {
		'code': 'AM',
		'dial_code': '374',
		'label': 'Armenia ',
		'region': 'Asia'
	},
	'Aruba': {
		'code': 'AW',
		'dial_code': '297',
		'label': 'Aruba',
		'region': 'Latin America'
	},
	'Australia': {
		'code': 'AU',
		'dial_code': '61',
		'label': 'Australia',
		'region': 'Oceania'
	},
	'Austria': {
		'code': 'AT',
		'dial_code': '43',
		'label': 'Austria',
		'region': 'West Europe'
	},
	'Azerbaijan': {
		'code': 'AZ',
		'dial_code': '994',
		'label': 'Azerbaijan',
		'region': 'Asia'
	},
	'Bahamas': {
		'code': 'BS',
		'dial_code': '1-242',
		'label': 'Bahamas',
		'region': 'Latin America'
	},
	'Bahrain': {
		'code': 'BH',
		'dial_code': '973',
		'label': 'Bahrain',
		'region': 'Middle East'
	},
	'Bangladesh': {
		'code': 'BD',
		'dial_code': '880',
		'label': 'Bangladesh',
		'region': 'Asia'
	},
	'Barbados': {
		'code': 'BB',
		'dial_code': '1-246',
		'label': 'Barbados',
		'region': 'Latin America'
	},
	'Belarus': {
		'code': 'BY',
		'dial_code': '375',
		'label': 'Belarus',
		'region': 'East Europe'
	},
	'Belgium': {
		'code': 'BE',
		'dial_code': '32',
		'label': 'Belgium',
		'region': 'West Europe'
	},
	'Belize': {
		'code': 'BZ',
		'dial_code': '501',
		'label': 'Belize',
		'region': 'Latin America'
	},
	'Benin': {
		'code': 'BJ',
		'dial_code': '229',
		'label': 'Benin',
		'region': 'Africa'
	},
	'Bhutan': {
		'code': 'BT',
		'dial_code': '975',
		'label': 'Bhutan',
		'region': 'Asia'
	},
	'Bolivia, Plurinational State of': {
		'code': 'BO',
		'dial_code': '591',
		'label': 'Bolivia',
		'region': 'Latin America'
	},
	'Bosnia and Herzegovina': {
		'code': 'BE',
		'dial_code': '387',
		'label': 'Bosnia and Herzegovina',
		'region': 'East Europe'
	},
	'Botswana': {
		'code': 'BW',
		'dial_code': '267',
		'label': 'Botswana',
		'region': 'Africa'
	},
	'Brazil': {
		'code': 'BR',
		'dial_code': '55',
		'label': 'Brazil',
		'region': 'Latin America'
	},
	'Brunei Darussalam': {
		'code': 'BN',
		'dial_code': '673',
		'label': 'Brunei Darussalam',
		'region': 'Asia'
	},
	'Bulgaria': {
		'code': 'BG',
		'dial_code': '359',
		'label': 'Bulgaria',
		'region': 'East Europe'
	},
	'Burkina Faso': {
		'code': 'BF',
		'dial_code': '226',
		'label': 'Burkina Faso',
		'region': 'Africa'
	},
	'Burundi': {
		'code': 'BI',
		'dial_code': '257',
		'label': 'Burundi',
		'region': 'Africa'
	},
	'Cambodia': {
		'code': 'KH',
		'dial_code': '855',
		'label': 'Cambodia',
		'region': 'Asia'
	},
	'Cameroon': {
		'code': 'CM',
		'dial_code': '237',
		'label': 'Cameroon',
		'region': 'Africa'
	},
	'Canada': {
		'code': 'CA',
		'dial_code': '1',
		'label': 'Canada',
		'region': 'North America'
	},
	'Cape Verde': {
		'code': 'CV',
		'dial_code': '238',
		'label': 'Cape Verde',
		'region': 'Africa'
	},
	'Central African Republic': {
		'code': 'CF',
		'dial_code': '236',
		'label': 'Central African Republic',
		'region': 'Africa'
	},
	'Chad': {
		'code': 'TD',
		'dial_code': '235',
		'label': 'Chad',
		'region': 'Africa'
	},
	'Channel Islands': {
		'code': 'UK',
		'dial_code': '11',
		'label': 'Channel Islands',
		'region': 'West Europe'
	},
	'Chile': {
		'code': 'CL',
		'dial_code': '56',
		'label': 'Chile',
		'region': 'Latin America'
	},
	'China': {
		'code': 'CN',
		'dial_code': '86',
		'label': 'China',
		'region': 'Asia'
	},
	'Colombia': {
		'code': 'CO',
		'dial_code': '57',
		'label': 'Colombia',
		'region': 'Latin America'
	},
	'Comoros': {
		'code': 'KM',
		'dial_code': '269',
		'label': 'Comoros',
		'region': 'Africa'
	},
	'Congo': {
		'code': 'CG',
		'dial_code': '242',
		'label': 'Congo',
		'region': 'Africa'
	},
	'Costa Rica': {
		'code': 'CR',
		'dial_code': '506',
		'label': 'Costa Rica',
		'region': 'Latin America'
	},
	"Cote D'ivoire": {
		'code': 'HR',
		'dial_code': '385',
		'label': "Cote D'ivoire",
		'region': 'Africa'
	},
	'Croatia': {
		'code': 'CU',
		'dial_code': '53',
		'label': 'Croatia',
		'region': 'East Europe'
	},
	'Cuba': {
		'code': 'CW',
		'dial_code': '599',
		'label': 'Cuba',
		'region': 'Latin America'
	},
	'Cyprus': {
		'code': 'CZ',
		'dial_code': '420',
		'label': 'Cyprus',
		'region': 'Middle East'
	},
	'Czech Republic': {
		'code': 'CI',
		'dial_code': '225',
		'label': 'Czech Republic',
		'region': 'East Europe'
	},
	'Denmark': {
		'code': 'DK',
		'dial_code': '45',
		'label': 'Denmark',
		'region': 'West Europe'
	},
	'Djibouti': {
		'code': 'DJ',
		'dial_code': '253',
		'label': 'Djibouti',
		'region': 'Africa'
	},
	'Dominican Republic': {
		'code': 'DO',
		'dial_code': '1',
		'label': 'Dominican Republic',
		'region': 'Latin America'
	},
	'Ecuador': {
		'code': 'EC',
		'dial_code': '593',
		'label': 'Ecuador',
		'region': 'Latin America'
	},
	'Egypt': {
		'code': 'EG',
		'dial_code': '20',
		'label': 'Egypt',
		'region': 'Middle East'
	},
	'El Salvador': {
		'code': 'SV',
		'dial_code': '503',
		'label': 'El Salvador',
		'region': 'Latin America'
	},
	'Equatorial Guinea': {
		'code': 'GQ',
		'dial_code': '240',
		'label': 'Equatorial Guinea',
		'region': 'Africa'
	},
	'Eritrea': {
		'code': 'ER',
		'dial_code': '291',
		'label': 'Eritrea',
		'region': 'Africa'
	},
	'Estonia': {
		'code': 'EE',
		'dial_code': '372',
		'label': 'Estonia',
		'region': 'East Europe'
	},
	'Ethiopia': {
		'code': 'ET',
		'dial_code': '251',
		'label': 'Ethiopia',
		'region': 'Africa'
	},
	'Fiji': {
		'code': 'FJ',
		'dial_code': '679',
		'label': 'Fiji',
		'region': 'Oceania'
	},
	'Finland': {
		'code': 'FI',
		'dial_code': '358',
		'label': 'Finland',
		'region': 'West Europe'
	},
	'France': {
		'code': 'FR',
		'dial_code': '33',
		'label': 'France',
		'region': 'West Europe'
	},
	'French Guiana': {
		'code': 'GF',
		'dial_code': '594',
		'label': 'French Guiana',
		'region': 'Latin America'
	},
	'French Polynesia': {
		'code': 'PF',
		'dial_code': '689',
		'label': 'French Polynesia',
		'region': 'Oceania'
	},
	'Gabon': {
		'code': 'GA',
		'dial_code': '241',
		'label': 'Gabon',
		'region': 'Africa'
	},
	'Gambia': {
		'code': 'GM',
		'dial_code': '220',
		'label': 'Gambia',
		'region': 'Africa'
	},
	'Georgia': {
		'code': 'GE',
		'dial_code': '995',
		'label': 'Georgia',
		'region': 'Asia'
	},
	'Germany': {
		'code': 'DE',
		'dial_code': '49',
		'label': 'Germany',
		'region': 'West Europe'
	},
	'Ghana': {
		'code': 'GH',
		'dial_code': '233',
		'label': 'Ghana',
		'region': 'Africa'
	},
	'Greece': {
		'code': 'GR',
		'dial_code': '30',
		'label': 'Greece',
		'region': 'West Europe'
	},
	'Grenada': {
		'code': 'GD',
		'dial_code': '1-473',
		'label': 'Grenada',
		'region': 'Latin America'
	},
	'Guadeloupe': {
		'code': 'GP',
		'dial_code': '590',
		'label': 'Guadeloupe',
		'region': 'Latin America'
	},
	'Guam': {
		'code': 'GU',
		'dial_code': '1-671',
		'label': 'Guam',
		'region': 'Oceania'
	},
	'Guatemala': {
		'code': 'GT',
		'dial_code': '502',
		'label': 'Guatemala',
		'region': 'Latin America'
	},
	'Guinea': {
		'code': 'GN',
		'dial_code': '224',
		'label': 'Guinea',
		'region': 'Africa'
	},
	'Guinea-bissau': {
		'code': 'GW',
		'dial_code': '245',
		'label': 'Guinea-Bissau',
		'region': 'Africa'
	},
	'Guyana': {
		'code': 'GY',
		'dial_code': '592',
		'label': 'Guyana',
		'region': 'Latin America'
	},
	'Haiti': {
		'code': 'HT',
		'dial_code': '509',
		'label': 'Haiti',
		'region': 'Latin America'
	},
	'Honduras': {
		'code': 'HN',
		'dial_code': '504',
		'label': 'Honduras',
		'region': 'Latin America'
	},
	'Hong Kong': {
		'code': 'HK',
		'dial_code': '852',
		'label': 'Hong Kong',
		'region': 'Asia'
	},
	'Hungary': {
		'code': 'HU',
		'dial_code': '36',
		'label': 'Hungary',
		'region': 'East Europe'
	},
	'Iceland': {
		'code': 'IS',
		'dial_code': '354',
		'label': 'Iceland',
		'region': 'West Europe'
	},
	'India': {
		'code': 'IN',
		'dial_code': '91',
		'label': 'India',
		'region': 'Asia'
	},
	'Indonesia': {
		'code': 'ID',
		'dial_code': '62',
		'label': 'Indonesia',
		'region': 'Asia'
	},
	'Iran, Islamic Republic of': {
		'code': 'IR',
		'dial_code': '98',
		'label': 'Iran',
		'region': 'Middle East'
	},
	'Iraq': {
		'code': 'IQ',
		'dial_code': '964',
		'label': 'Iraq',
		'region': 'Middle East'
	},
	'Ireland': {
		'code': 'IE',
		'dial_code': '353',
		'label': 'Ireland',
		'region': 'West Europe'
	},
	'Israel': {
		'code': 'IL',
		'dial_code': '972',
		'label': 'Israel',
		'region': 'Middle East'
	},
	'Italy': {
		'code': 'IT',
		'dial_code': '39',
		'label': 'Italy',
		'region': 'West Europe'
	},
	'Jamaica': {
		'code': 'JM',
		'dial_code': '1-876',
		'label': 'Jamaica',
		'region': 'Latin America'
	},
	'Japan': {
		'code': 'JP',
		'dial_code': '81',
		'label': 'Japan',
		'region': 'Asia'
	},
	'Jordan': {
		'code': 'JO',
		'dial_code': '962',
		'label': 'Jordan',
		'region': 'Middle East'
	},
	'Kazakhstan': {
		'code': 'KZ',
		'dial_code': '7',
		'label': 'Kazakhstan',
		'region': 'Asia'
	},
	'Kenya': {
		'code': 'KE',
		'dial_code': '254',
		'label': 'Kenya',
		'region': 'Africa'
	},
	'Kuwait': {
		'code': 'KW',
		'dial_code': '965',
		'label': 'Kuwait',
		'region': 'Middle East'
	},
	'Kyrgyzstan': {
		'code': 'KG',
		'dial_code': '996',
		'label': 'Kyrgyzstan',
		'region': 'Asia'
	},
	"Lao People's Democratic Republic": {
		'code': 'LA',
		'dial_code': '856',
		'label': 'Laos',
		'region': 'Asia'
	},
	'Latvia': {
		'code': 'LV',
		'dial_code': '371',
		'label': 'Latvia',
		'region': 'East Europe'
	},
	'Lebanon': {
		'code': 'LB',
		'dial_code': '961',
		'label': 'Lebanon',
		'region': 'Middle East'
	},
	'Lesotho': {
		'code': 'LS',
		'dial_code': '266',
		'label': 'Lesotho',
		'region': 'Africa'
	},
	'Liberia': {
		'code': 'LR',
		'dial_code': '231',
		'label': 'Liberia',
		'region': 'Africa'
	},
	'Libya': {
		'code': 'LY',
		'dial_code': '218',
		'label': 'Libya',
		'region': 'Africa'
	},
	'Lithuania': {
		'code': 'LT',
		'dial_code': '370',
		'label': 'Lithuania',
		'region': 'East Europe'
	},
	'Luxembourg': {
		'code': 'LU',
		'dial_code': '352',
		'label': 'Luxembourg',
		'region': 'West Europe'
	},
	'Macedonia, The Former Yugoslav Republic of': {
		'code': 'MK',
		'dial_code': '389',
		'label': 'Macedonia',
		'region': 'East Europe'
	},
	'Madagascar': {
		'code': 'MG',
		'dial_code': '261',
		'label': 'Madagascar',
		'region': 'Africa'
	},
	'Malawi': {
		'code': 'MW',
		'dial_code': '265',
		'label': 'Malawi',
		'region': 'Africa'
	},
	'Malaysia': {
		'code': 'MY',
		'dial_code': '60',
		'label': 'Malaysia',
		'region': 'Asia'
	},
	'Maldives': {
		'code': 'MV',
		'dial_code': '960',
		'label': 'Maldives',
		'region': 'Asia'
	},
	'Mali': {
		'code': 'ML',
		'dial_code': '223',
		'label': 'Mali',
		'region': 'Africa'
	},
	'Malta': {
		'code': 'MT',
		'dial_code': '356',
		'label': 'Malta',
		'region': 'West Europe'
	},
	'Martinique': {
		'code': 'MQ',
		'dial_code': '596',
		'label': 'Martinique',
		'region': 'Latin America'
	},
	'Mauritania': {
		'code': 'MR',
		'dial_code': '222',
		'label': 'Mauritania',
		'region': 'Africa'
	},
	'Mauritius': {
		'code': 'MU',
		'dial_code': '230',
		'label': 'Mauritius',
		'region': 'Africa'
	},
	'Mayotte': {
		'code': 'YT',
		'dial_code': '262',
		'label': 'Mayotte',
		'region': 'Africa'
	},
	'Mexico': {
		'code': 'MX',
		'dial_code': '52',
		'label': 'Mexico',
		'region': 'Latin America'
	},
	'Micronesia, Federated States of': {
		'code': 'FM',
		'dial_code': '691',
		'label': 'Micronesia',
		'region': 'Oceania'
	},
	'Moldova, Republic of': {
		'code': 'MD',
		'dial_code': '373',
		'label': 'Moldova',
		'region': 'East Europe'
	},
	'Mongolia': {
		'code': 'MN',
		'dial_code': '976',
		'label': 'Mongolia',
		'region': 'Asia'
	},
	'Montenegro': {
		'code': 'ME',
		'dial_code': '382',
		'label': 'Montenegro',
		'region': 'East Europe'
	},
	'Morocco': {
		'code': 'MA',
		'dial_code': '212',
		'label': 'Morocco',
		'region': 'Africa'
	},
	'Mozambique': {
		'code': 'MZ',
		'dial_code': '258',
		'label': 'Mozambique',
		'region': 'Africa'
	},
	'Myanmar': {
		'code': 'MM',
		'dial_code': '95',
		'label': 'Myanmar',
		'region': 'Asia'
	},
	'Namibia': {
		'code': 'NA',
		'dial_code': '264',
		'label': 'Namibia',
		'region': 'Africa'
	},
	'Nepal': {
		'code': 'NP',
		'dial_code': '977',
		'label': 'Nepal',
		'region': 'Asia'
	},
	'Netherlands': {
		'code': 'NL',
		'dial_code': '31',
		'label': 'Netherlands',
		'region': 'West Europe'
	},
	'Netherlands Antilles': {
		'code': 'AN',
		'dial_code': '599',
		'label': 'Netherlands Antilles',
		'region': 'Latin America'
	},
	'New Caledonia': {
		'code': 'NC',
		'dial_code': '687',
		'label': 'New Caledonia',
		'region': 'Oceania'
	},
	'New Zealand': {
		'code': 'NZ',
		'dial_code': '64',
		'label': 'New Zealand',
		'region': 'Oceania'
	},
	'Nicaragua': {
		'code': 'NI',
		'dial_code': '505',
		'label': 'Nicaragua',
		'region': 'Latin America'
	},
	'Niger': {
		'code': 'NE',
		'dial_code': '227',
		'label': 'Niger',
		'region': 'Africa'
	},
	'Nigeria': {
		'code': 'NG',
		'dial_code': '234',
		'label': 'Nigeria',
		'region': 'Africa'
	},
	"Korea, Democratic People's Republic of": {
		'code': 'KP',
		'dial_code': '850',
		'label': 'North Korea',
		'region': 'Asia'
	},
	'Norway': {
		'code': 'NO',
		'dial_code': '47',
		'label': 'Norway',
		'region': 'West Europe'
	},
	'Oman': {
		'code': 'OM',
		'dial_code': '968',
		'label': 'Oman',
		'region': 'Middle East'
	},
	'Pakistan': {
		'code': 'PK',
		'dial_code': '92',
		'label': 'Pakistan',
		'region': 'Asia'
	},
	'Panama': {
		'code': 'PA',
		'dial_code': '507',
		'label': 'Panama',
		'region': 'Latin America'
	},
	'Papua New Guinea': {
		'code': 'PG',
		'dial_code': '675',
		'label': 'Papua New Guinea',
		'region': 'Oceania'
	},
	'Paraguay': {
		'code': 'PY',
		'dial_code': '595',
		'label': 'Paraguay',
		'region': 'Latin America'
	},
	'Peru': {
		'code': 'PE',
		'dial_code': '51',
		'label': 'Peru',
		'region': 'Latin America'
	},
	'Philippines': {
		'code': 'PH',
		'dial_code': '63',
		'label': 'Philippines',
		'region': 'Asia'
	},
	'Poland': {
		'code': 'PL',
		'dial_code': '48',
		'label': 'Poland',
		'region': 'East Europe'
	},
	'Portugal': {
		'code': 'PT',
		'dial_code': '351',
		'label': 'Portugal',
		'region': 'West Europe'
	},
	'Puerto Rico': {
		'code': 'PR',
		'dial_code': '1',
		'label': 'Puerto Rico',
		'region': 'Latin America'
	},
	'Qatar': {
		'code': 'QA',
		'dial_code': '974',
		'label': 'Qatar',
		'region': 'Middle East'
	},
	'Romania': {
		'code': 'RO',
		'dial_code': '40',
		'label': 'Romania',
		'region': 'East Europe'
	},
	'Russian Federation': {
		'code': 'RU',
		'dial_code': '7',
		'label': 'Russia',
		'region': 'East Europe'
	},
	'Rwanda': {
		'code': 'RW',
		'dial_code': '250',
		'label': 'Rwanda',
		'region': 'Africa'
	},
	'Saint Lucia': {
		'code': 'LC',
		'dial_code': '1-758',
		'label': 'Saint Lucia',
		'region': 'Latin America'
	},
	'Saint Vincent and The Grenadines': {
		'code': 'VC',
		'dial_code': '1-784',
		'label': 'Saint Vincent',
		'region': 'Latin America'
	},
	'Samoa': {
		'code': 'WS',
		'dial_code': '685',
		'label': 'Samoa',
		'region': 'Oceania'
	},
	'Sao Tome and Principe': {
		'code': 'ST',
		'dial_code': '239',
		'label': 'Sao Tome and Principe',
		'region': 'Africa'
	},
	'Saudi Arabia': {
		'code': 'SA',
		'dial_code': '966',
		'label': 'Saudi Arabia',
		'region': 'Middle East'
	},
	'Senegal': {
		'code': 'SN',
		'dial_code': '221',
		'label': 'Senegal',
		'region': 'Africa'
	},
	'Serbia': {
		'code': 'RS',
		'dial_code': '381',
		'label': 'Serbia',
		'region': 'East Europe'
	},
	'Sierra Leone': {
		'code': 'SL',
		'dial_code': '232',
		'label': 'Sierra Leone',
		'region': 'Africa'
	},
	'Singapore': {
		'code': 'SG',
		'dial_code': '65',
		'label': 'Singapore',
		'region': 'Asia'
	},
	'Slovakia': {
		'code': 'SK',
		'dial_code': '421',
		'label': 'Slovakia',
		'region': 'East Europe'
	},
	'Slovenia': {
		'code': 'SI',
		'dial_code': '386',
		'label': 'Slovenia',
		'region': 'East Europe'
	},
	'Solomon Islands': {
		'code': 'SB',
		'dial_code': '677',
		'label': 'Solomon Islands',
		'region': 'Oceania'
	},
	'Somalia': {
		'code': 'SO',
		'dial_code': '252',
		'label': 'Somalia',
		'region': 'Africa'
	},
	'South Africa': {
		'code': 'ZA',
		'dial_code': '27',
		'label': 'South Africa',
		'region': 'Africa'
	},
	'Korea, Republic of': {
		'code': 'KR',
		'dial_code': '82',
		'label': 'South Korea',
		'region': 'Asia'
	},
	'Spain': {
		'code': 'ES',
		'dial_code': '34',
		'label': 'Spain',
		'region': 'West Europe'
	},
	'Sri Lanka': {
		'code': 'LK',
		'dial_code': '94',
		'label': 'Sri Lanka',
		'region': 'Asia'
	},
	'Sudan': {
		'code': 'SD',
		'dial_code': '249',
		'label': 'Sudan',
		'region': 'Africa'
	},
	'Suriname': {
		'code': 'SR',
		'dial_code': '597',
		'label': 'Suriname',
		'region': 'Latin America'
	},
	'Swaziland': {
		'code': 'SZ',
		'dial_code': '268',
		'label': 'Swaziland',
		'region': 'Africa'
	},
	'Sweden': {
		'code': 'SE',
		'dial_code': '46',
		'label': 'Sweden',
		'region': 'West Europe'
	},
	'Switzerland': {
		'code': 'CH',
		'dial_code': '41',
		'label': 'Switzerland',
		'region': 'West Europe'
	},
	'Syrian Arab Republic': {
		'code': 'SY',
		'dial_code': '963',
		'label': 'Syria',
		'region': 'Middle East'
	},
	'Tajikistan': {
		'code': 'TJ',
		'dial_code': '992',
		'label': 'Tajikistan',
		'region': 'Asia'
	},
	'Tanzania, United Republic of': {
		'code': 'TZ',
		'dial_code': '255',
		'label': 'Tanzania',
		'region': 'Africa'
	},
	'Thailand': {
		'code': 'TH',
		'dial_code': '66',
		'label': 'Thailand',
		'region': 'Asia'
	},
	'Timor-leste': {
		'code': 'TL',
		'dial_code': '670',
		'label': 'Timor-Leste',
		'region': 'Asia'
	},
	'Togo': {
		'code': 'TG',
		'dial_code': '228',
		'label': 'Togo',
		'region': 'Africa'
	},
	'Tonga': {
		'code': 'TO',
		'dial_code': '676',
		'label': 'Tonga',
		'region': 'Oceania'
	},
	'Trinidad and Tobago': {
		'code': 'TT',
		'dial_code': '1-868',
		'label': 'Trinidad and Tobago',
		'region': 'Latin America'
	},
	'Tunisia': {
		'code': 'TN',
		'dial_code': '216',
		'label': 'Tunisia',
		'region': 'Middle East'
	},
	'Turkey': {
		'code': 'TR',
		'dial_code': '90',
		'label': 'Turkey',
		'region': 'Middle East'
	},
	'Turkmenistan': {
		'code': 'TM',
		'dial_code': '993',
		'label': 'Turkmenistan',
		'region': 'Asia'
	},
	'Uganda': {
		'code': 'UG',
		'dial_code': '256',
		'label': 'Uganda',
		'region': 'Africa'
	},
	'Ukraine': {
		'code': 'UA',
		'dial_code': '380',
		'label': 'Ukraine',
		'region': 'East Europe'
	},
	'United Arab Emirates': {
		'code': 'AE',
		'dial_code': '971',
		'label': 'United Arab Emirates',
		'region': 'Middle East'
	},
	'United Kingdom': {
		'code': 'GB',
		'dial_code': '44',
		'label': 'United Kingdom',
		'region': 'West Europe'
	},
	'United States': {
		'code': 'US',
		'dial_code': '1',
		'label': 'United States',
		'region': 'North America'
	},
	'Uruguay': {
		'code': 'UY',
		'dial_code': '598',
		'label': 'Uruguay',
		'region': 'Latin America'
	},
	'Uzbekistan': {
		'code': 'UZ',
		'dial_code': '998',
		'label': 'Uzbekistan',
		'region': 'Asia'
	},
	'Vanuatu': {
		'code': 'VU',
		'dial_code': '678',
		'label': 'Vanuatu',
		'region': 'Oceania'
	},
	'Venezuela, Bolivarian Republic of': {
		'code': 'VE',
		'dial_code': '58',
		'label': 'Venezuela',
		'region': 'Latin America'
	},
	'Viet Nam': {
		'code': 'VN',
		'dial_code': '84',
		'label': 'Vietnam',
		'region': 'Asia'
	},
	'Western Sahara': {
		'code': 'EH',
		'dial_code': '212',
		'label': 'Western Sahara',
		'region': 'Africa'
	},
	'Yemen': {
		'code': 'YE',
		'dial_code': '967',
		'label': 'Yemen',
		'region': 'Middle East'
	},
	'Zambia': {
		'code': 'ZM',
		'dial_code': '260',
		'label': 'Zambia',
		'region': 'Africa'
	},
	'Zimbabwe': {
		'code': 'ZW',
		'dial_code': '263',
		'label': 'Zimbabwe',
		'region': 'Africa'
	}
};

export const region = {
	'north_america': 'North America',
	'latin_america': 'Latin America',
	'north_europe': 'Northern Europe',
	'south_europe': 'Southern Europe',
	'north_asia': 'North Asia',
	'south_asia': 'South Asia',
	'oceania': 'Oceania',
	'africa': 'Africa'
};

export const company_size = {
	'01-10': '1-10',
	'111-50': '11-50',
	'251-200': '51-200',
	'3201-500': '201-500',
	'4501-1000': '501-1000',
	'51001-5000': '1001-5000',
	'65001-10000': '5001-10,000',
	'710000+': '10,000+'
};

export const funding_stage = {
	'0bootstrapped': 'Bootstrapped',
	'1pre-seed': 'Pre-seed',
	'2seed Seed': 'Seed',
	'3round A': 'Round A',
	'4round B': 'Round B',
	'5round C': 'Round C',
	'6public': 'Public',
	'7established': 'Established',
	'8acquired': 'Acquired'
};

export const operating_system = {
	'windows': 'Windows',
	'linux': 'Linux'
};

export const aws_instance_type = {
	't2.large': 'Small (2 CPUs; 8GB Memory; Burstable)',
	'm4.large': 'Medium (2 CPUs; 8GB Memory)',
	'm4.xlarge': 'Large (4 CPUs; 16GB Memory)'
};

export const db_type = {
	'mysql': {
		'label': 'MySQL',
		'is_proov': true
	},
	'postgres': {
		'label': 'Postgres',
		'is_proov': true
	},
	'cassandra': {
		'label': 'Cassandra',
		'is_proov': false
	},
	'oracle': {
		'label': 'Oracle',
		'is_proov': false
	},
	'hbase': {
		'label': 'Hbase',
		'is_proov': false
	},
	'redshift': {
		'label': 'Redshift',
		'is_proov': false
	},
	'bigquery': {
		'label': 'Bigquery',
		'is_proov': false
	}
};

export const api_type = {
	rest: 'REST',
	soap: 'SOAP'
};

export const vpn_type = {
	openvpn: 'OpenVPN',
	hotspot: 'Hotspot Shield',
	gadmin: 'GAdmin',
	shrewsoft: 'Shrew Soft',
	viscosity: 'Viscosity',
	vpnx: 'VPN-X',
	juniper: 'Juniper'
};

export const budget = {
	up_to_10k: 'Up to $10,000',
	up_to_25k: 'Up to $25,000',
	up_to_50k: 'Up to $50,000',
	up_to_100k: 'Up to $100,000',
	up_to_250k: 'Up to $250,000',
	more_than_250k: 'More than $250,000'
};

export const product_stage = {
	mvp: 'MVP',
	alpha: 'Alpha',
	beta: 'Beta',
	launch: 'Launch',
	scale: 'Scale'
};

export const sales_stage = {
	pre: 'Pre-Sales',
	initial: 'Initial Sales',
	million: 'More than $1 Million/Year',
	million5: 'More than $5 Million/Year',
	not: 'Prefer not to disclose'
};

export const lookups = {
	industry,
	category,
	country,
	region,
	company_size,
	funding_stage,
	operating_system,
	aws_instance_type,
	db_type,
	api_type,
	vpn_type,
	budget,
	product_stage,
	sales_stage
};

export const tags = ['adaptive',
	'networked',
	'optimal',
	'client-driven',
	'maximized',
	'static',
	'software',
	'synergistic',
	'time-frame',
	'knowledge user',
	'object-oriented',
	'demand-driven',
	'implemented',
	'open architecture',
	'total',
	'infrastructure',
	'multi-channelled',
	'integrated',
	'heuristic',
	'middleware',
	'implementation',
	'open-source',
	'dynamic',
	'synchronised',
	'array',
	'ameliorated',
	'distributed',
	'actuating',
	'pre-emptive',
	'managed',
	'definition',
	'adapter',
	'fundamental',
	'cohesive',
	'groupware',
	'vision-oriented',
	'configurable',
	'portal',
	'optimizing',
	'interface',
	'challenge',
	'knowledge base',
	'function-based',
	'didactic',
	'exuding',
	'toolset',
	'graphical user interface',
	'stand-alone',
	'bandwidth-monitored',
	'local area network',
	'customer loyalty',
	'fault-tolerant',
	'5th generation',
	'exclusive',
	'motivating',
	'4th generation',
	'realigned',
	'horizontal',
	'impactful',
	'productivity',
	'help-desk',
	'local',
	'encompassing',
	'foreground',
	'user-friendly',
	'bi-directional',
	'flexibility',
	'circuit',
	'directional',
	'artificial intelligence',
	'attitude-oriented',
	'framework',
	'moderator',
	'team-oriented',
	'automated',
	'virtual',
	'radical',
	'ability',
	'homogeneous',
	'bifurcated',
	'functionalities',
	'matrices',
	'methodical',
	'throughput',
	'installation',
	'orchestration',
	'contingency',
	'reciprocal',
	'robust',
	'solution',
	'uniform',
	'non-volatile',
	'modular',
	'enhanced',
	'incremental',
	'parallelism',
	'neural-net',
	'mission-critical',
	'national',
	'solution-oriented',
	'synergized',
	'centralized',
	'persevering',
	'multi-tasking',
	'user-centric',
	'intranet',
	'archive',
	'responsive',
	'zero defect',
	'persistent',
	'hybrid',
	'architecture',
	'structure',
	'intuitive',
	'seamless',
	'success',
	'open system',
	'operative',
	'inverse',
	'process improvement',
	'versatile',
	'interactive',
	'organized',
	'initiative',
	'dedicated',
	'grid-enabled',
	'self-enabling',
	'executive',
	'algorithm',
	'expanded',
	'context-sensitive',
	'encoding',
	'fresh-thinking',
	'function',
	'matrix',
	'migration',
	'right-sized',
	'pricing structure',
	'analyzer',
	'fully-configurable',
	'reduced',
	'streamlined',
	'phased',
	'encryption',
	'global',
	'cross-platform',
	'moratorium',
	'graphic interface',
	'monitoring',
	'multi-layered',
	'proactive',
	'zero administration',
	'website',
	'explicit',
	'visionary',
	'instruction set',
	'reactive',
	'programmable',
	'enterprise-wide',
	'profit-focused',
	'open-architected',
	'secondary',
	'project',
	'multi-lateral',
	'access',
	'capability',
	'contextually-based',
	'monitored',
	'hardware',
	'24 hour',
	'holistic',
	'object-based',
	'de-engineered',
	'application',
	'intangible',
	'face to face',
	'profound',
	'attitude',
	'conglomeration',
	'emulation',
	'firmware',
	'needs-based',
	'protocol',
	'compatible',
	'public-key',
	'reverse-engineered',
	'switchable',
	'neutral',
	'asymmetric',
	'hierarchy',
	'progressive',
	'strategy',
	'regional',
	'business-focused',
	'system engine',
	'6th generation',
	'devolved',
	'24/7',
	'concept',
	'capacity',
	'well-modulated',
	'sharable',
	'product',
	'multimedia',
	'multi-state',
	'triple-buffered',
	'upward-trending',
	'organic',
	'projection',
	'ergonomic',
	'scalable',
	'real-time',
	'optional',
	'standardization',
	'frame',
	'superstructure',
	'approach',
	'human-resource',
	'multi-tiered',
	'full-range',
	'leverage',
	'bottom-line',
	'discrete',
	'tertiary',
	'utilisation',
	'budgetary management',
	'customer-focused',
	'synergy',
	'database',
	'task-force',
	'policy',
	'client-server',
	'advanced',
	'systematic',
	'benchmark',
	'asynchronous',
	'core',
	'logistical',
	'complexity',
	'stable',
	'future-proofed',
	'decentralized',
	'support',
	'extranet',
	'collaboration',
	'tangible',
	'zero tolerance',
	'digitized',
	'data-warehouse',
	'high-level',
	'info-mediaries',
	'service-desk',
	'methodology',
	'disintermediate',
	'cloned',
	'innovative',
	'mobile',
	're-contextualized',
	'model',
	'assimilated',
	'diverse',
	'extended',
	'value-added',
	'web-enabled',
	'focus group',
	'universal',
	'empowering',
	'customizable',
	'quality-focused',
	'mandatory',
	'cross-group',
	'secured line',
	'balanced',
	'systemic',
	'alliance',
	're-engineered',
	'leading edge',
	'next generation',
	'up-sized',
	'focused',
	'clear-thinking',
	'background',
	'intermediate',
	'composite',
	'even-keeled',
	'eco-centric',
	'forecast',
	'workforce',
	'paradigm',
	'coherent',
	'3rd generation',
	'down-sized',
	'system-worthy',
	'internet solution',
	'front-line'];
