/* eslint-disable camelcase */
export const searchJson = {
	pilot: {
		data: [
			{
				end_date: '1490950800000',
				snippet:
					"We are looking for cross-industry video intelligence solutions enabling real-time security, customer behavior insights, improve store operations and shopping experiences, employees' and assets protection, face and motion recognition and any new other functionality",
				country: ['United States', 'United States'],
				hidden: false,
				owner_id: '2c9f91cc581b679301582b2f36b000ee',
				company_website: '',
				description:
					"We are looking for cross-industry video intelligence solutions enabling real-time security, customer behavior insights, improve store operations and shopping experiences, employees' and assets protection, face and motion recognition and any new other functionality",
				industry: ['4', 'Internet & Software'],
				scenarios: '',
				pilot_name_flat: 'videoanalytics',
				last_date_to_join: '1490950800000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria: '',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc581b679301582b4053da00f8',
				tag: ['marketing & advertising', 'other'],
				start_date: '1478131200000',
				participants: 1,
				goals: '',
				date_created: '1478194385882',
				description_company:
					"Launched in 2006, Amazon Web Services (AWS) began exposing key infrastructure services to businesses in the form of web services -- now widely known as cloud computing. The ultimate benefit of cloud computing, and AWS, is the ability to leverage a new business model and turn capital infrastructure expenses into variable costs. Businesses no longer need to plan and procure servers and other IT resources weeks or months in advance. Using AWS, businesses can take advantage of Amazon's expertise and economies of scale to access resources when their business needs them, delivering results faster and at a lower cost. \n\nToday, Amazon Web Services provides a highly reliable, scalable, low-cost infrastructure platform in the cloud that powers hundreds of thousands of businesses in 190 countries around the world. With data center locations in the U.S., Europe, Singapore, and Japan, customers across all industries are taking advantage of our low cost, elastic, open and flexible, secure platform.\n",
				spec_doc_url:
					'https://res.cloudinary.com/scalabill-it/raw/upload/v1478194468/mweemujecboqusazbniy.docx',
				is_pilot_closed: false,
				company_name: 'Amazon Web Services (AWS)',
				target_vendors: '',
				name: 'Video Analytics',
				category: [
					'2c9f91cc596035e90159603744320328',
					'Machine Learning and AI'
				]
			},
			{
				end_date: '1486080000000',
				snippet:
					'We are interested in a feature rich computational fluid dynamics (CFD) analysis tool that is cost competitive.  Traditionally, CFD is not an everyday tool for TCF, and the cost of typical programs make the ROI, for our company, very low.\n\nComputational fluid dynamics (CFD) is a branch of fluid mechanics that uses numerical analysis and algorithms to solve and analyze problems that involve fluid flows. Computers are used to perform the calculations required to simulate the interaction of liquids and gases with surfaces defined by boundary conditions.  TFC is often confronted with aerodynamic conditions that affect the fan performance that are outside of our normal scope of supply.\nAn effective CFD tool would allow TCF to proactively show customers that the inlet and outlet conditions need adjustment, and prove that the poor fan performance is due to bad duct work design, and not the fan equipment.',
				country: ['United States', 'United States'],
				hidden: false,
				owner_id: '2c9f93d9549461bf0154ddd8ae190023',
				company_website: '',
				description:
					'We are interested in a feature rich computational fluid dynamics (CFD) analysis tool that is cost competitive.  Traditionally, CFD is not an everyday tool for TCF, and the cost of typical programs make the ROI, for our company, very low.\n\nComputational fluid dynamics (CFD) is a branch of fluid mechanics that uses numerical analysis and algorithms to solve and analyze problems that involve fluid flows. Computers are used to perform the calculations required to simulate the interaction of liquids and gases with surfaces defined by boundary conditions.  TFC is often confronted with aerodynamic conditions that affect the fan performance that are outside of our normal scope of supply.\nAn effective CFD tool would allow TCF to proactively show customers that the inlet and outlet conditions need adjustment, and prove that the poor fan performance is due to bad duct work design, and not the fan equipment.',
				industry: ['9', 'Other'],
				scenarios: '',
				pilot_name_flat: 'cfdanalysistool',
				last_date_to_join: '1486080000000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria:
					'["Vendor Demonstrations","Has paying customers","Low cpu usage","Low memory usage","sdfjhskffhlhl sdlfjhjhjh sdfjhjhjhjh", "Vendor Demonstrations","Has paying customers","Low cpu usage","Low memory usage","sdfjhskffhlhl sdlfjhjhjh sdfjhjhjhjh"]',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc581b679301582a7a67b900e1',
				tag: [
					'predictive analytics',
					'data mining',
					'sales',
					'iot',
					'big data & analytics'
				],
				start_date: '1478131200000',
				participants: 2,
				goals: '',
				date_created: '1478181414841',
				description_company:
					"Twin City Fan Companies, Ltd. is comprised of a diverse group of fan companies that manufacture a full spectrum of air moving equipment. The list of applications that utilize our products is practically endless and ranges from heavy duty custom fans for industrial applications to custom OEM fans to a wide variety of HVAC supply and exhaust fans for the commercial plan and spec market. \n\nWith the engineering and manufacturing capabilities to accommodate virtually every conceivable air moving application, Twin City Fan Companies has the knowledge and expertise to meet our customers’ exacting requirements.\n\nWe are looking for partners who can assist with several projects.  Those include the integration of sensors and the IoT's, business intelligence for our sales data/market trends, and software to help with the performance/analytics of our equipment (aerodynamics, sound and vibration.)\n",
				spec_doc_url:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1478181803/ykbwa13ewvnlynb8a2eg.pdf',
				is_pilot_closed: false,
				company_name: 'Twin City Fan',
				target_vendors: '',
				name: 'CFD Analysis Tool',
				category: ['2c9f91cc596035e90159603744430329', 'Other']
			},
			{
				end_date: '1490950800000',
				snippet:
					'Consumers are increasingly watching television content on multiple platforms, contributing to the fragmentation of the traditional viewing experience. \nThe blockchain technology can be applied to many domains, but mostly makes sure that money and other assets can be transmitted but not copied, and can be tracked.',
				country: ['United States', 'United States'],
				hidden: false,
				owner_id: '2c9f93d9570a74ea015722a8cc0b00ac',
				company_website: '',
				description:
					'Consumers are increasingly watching television content on multiple platforms, contributing to the fragmentation of the traditional viewing experience. \nThe blockchain technology can be applied to many domains, but mostly makes sure that money and other assets can be transmitted but not copied, and can be tracked.',
				industry: ['28', 'Media & Entertainment'],
				scenarios: '',
				pilot_name_flat: 'usingblockchaintechnologyformediatracking',
				last_date_to_join: '1490950800000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria: '',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f93d9570a74ea015725271c750580',
				tag: [
					'marketing & advertising',
					'advertising networks',
					'public relations',
					'augmented reality',
					'big data & analytics'
				],
				start_date: '1473724800000',
				participants: 0,
				goals: '',
				date_created: '1473797102709',
				description_company:
					'We are one of the world’s leading media and entertainment companies in the development, production, and marketing of entertainment, news and information to a global audience.\n\nNBCUniversal owns and operates a valuable portfolio of news and entertainment television networks, a premier motion picture company, significant television production operations, a leading television stations group, world-renowned theme parks, and a suite of leading Internet-based businesses. NBCUniversal is a subsidiary of Comcast Corporation.',
				spec_doc_url: '',
				is_pilot_closed: false,
				company_name: 'Universal Pictures',
				target_vendors: '',
				name: 'Using Blockchain technology for media tracking',
				category: ['2c9f91cc596035e90159603743d50324', 'Enterprise Software']
			},
			{
				end_date: '1490950800000',
				snippet:
					'We are looking for an innovative blockchain-based \nsystem for ownership and delivery of digital media content (video, audio, books, Paintings, etc.).',
				country: ['United States', 'United States'],
				hidden: false,
				owner_id: '2c9f91cc581b679301582b2f36b000ee',
				company_website: '',
				description:
					'We are looking for an innovative blockchain-based \nsystem for ownership and delivery of digital media content (video, audio, books, Paintings, etc.).',
				industry: ['4', 'Internet & Software'],
				scenarios:
					'The PoC includes two Windows instances. Each vendor will get the connection to both servers and will have to install the necessary parts to demo the solution.',
				pilot_name_flat: 'blockchaintechnologies',
				last_date_to_join: '1490950800000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria:
					'["Vendor Demonstrations","Has paying customers","Low cpu usage","Low memory usage","Ease of installation"]',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc581b679301582b41f8ee00fb',
				tag: ['marketing & advertising', 'other'],
				start_date: '1478131200000',
				participants: 0,
				goals:
					'We are looking for an innovative blockchain-based system for ownership and delivery of digital media content (video, audio, books, paintings, etc.).',
				date_created: '1478194493678',
				description_company:
					"Launched in 2006, Amazon Web Services (AWS) began exposing key infrastructure services to businesses in the form of web services -- now widely known as cloud computing. The ultimate benefit of cloud computing, and AWS, is the ability to leverage a new business model and turn capital infrastructure expenses into variable costs. Businesses no longer need to plan and procure servers and other IT resources weeks or months in advance. Using AWS, businesses can take advantage of Amazon's expertise and economies of scale to access resources when their business needs them, delivering results faster and at a lower cost. \n\nToday, Amazon Web Services provides a highly reliable, scalable, low-cost infrastructure platform in the cloud that powers hundreds of thousands of businesses in 190 countries around the world. With data center locations in the U.S., Europe, Singapore, and Japan, customers across all industries are taking advantage of our low cost, elastic, open and flexible, secure platform.\n",
				spec_doc_url:
					'https://res.cloudinary.com/scalabill-it/raw/upload/v1478194609/gpqy1sokonhzbhpmxcv2.docx',
				is_pilot_closed: false,
				company_name: 'Amazon Web Services (AWS)',
				target_vendors:
					'Blockchain platform or application vendors specializing in ownership and delivery control, with a solution for both on the cloud and on premise, which are at least one year in the market and with a 24/7 support team.',
				name: 'Blockchain Technologies',
				category: ['2c9f91cc596035e90159603744040326', 'Internet & Mobile']
			},
			{
				end_date: '1485820800000',
				snippet: 'Primary Goal: An easy to use BI tool on the cloud',
				country: null,
				hidden: false,
				owner_id: '4028b88150ccee980150cd29f3eb0006',
				company_website: '',
				description: 'Primary Goal: An easy to use BI tool on the cloud',
				industry: ['3', 'Electronics'],
				scenarios: '',
				pilot_name_flat: 'schneiderelectric-bi',
				last_date_to_join: '1485820800000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria: '',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc52a7cf4a0152e46b1808006c',
				tag: ['other'],
				start_date: '1455494400000',
				participants: 7,
				goals: '',
				date_created: '1455531169800',
				description_company:
					'The change in our world is more profound than ever, driven by a new scale and speed of urbanization, digitization, and industrialization. New technologies, enabling for the first time distributed and connected energy, challenge us to redefine the way we live.We believe access to energy is a basic human right. We want everyone on our planet to have access to reliable, safe, efficient, and sustainable energy. At Schneider Electric, we are committed to innovate solutions that address this energy paradox, balancing our planets carbon footprint and supporting the undisputable right of everyone to quality energy.',
				spec_doc_url:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1465224088/vnnhjk6wgrmnq3ue0sak.pdf',
				is_pilot_closed: false,
				company_name: 'Schneider-Electric',
				target_vendors: '',
				name: 'Schneider Electric - BI',
				category: null
			},
			{
				end_date: '1485993600000',
				snippet:
					'A Global leading consumer goods company with billions of dollars of annual revenue is looking to enhance its quantitative consumer survey analysis.',
				country: null,
				hidden: false,
				owner_id: '2c9f93d9570a74ea01571db69c8a0063',
				company_website: '',
				description:
					'A Global leading consumer goods company with billions of dollars of annual revenue is looking to enhance its quantitative consumer survey analysis.',
				industry: ['22', 'Food & Beverage'],
				scenarios: '',
				pilot_name_flat: 'consumersurveyanalytics',
				last_date_to_join: '1485993600000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria: '',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc581b67930158251ec9de0073',
				tag: ['retail', 'transportation', 'other'],
				start_date: '1478044800000',
				participants: 0,
				goals: '',
				date_created: '1478091524574',
				description_company:
					'Earthbound Israel is an innovation center based in Tel–Aviv. Earthbounds’ mission is to be an innovation arm for multinational brands, and the Big Box Retailers, supplying them with an unprecedented access to Israeli startups. As well as being a channel for Israeli startups to access multinational brands and guide them through the commercial process to fruition.\n\nEarthbound Israel scouts, incubates and facilitates need-driven, disruptive technologies for the world’s largest corporations in fields of: agro, food tech, health& wellness, personal care, Home care, digital, marketing, IoT, packaging and more.\n\nEarthbound Israel is a division of Earthbound LLC which is a strategic partner of leading retailers and CPG’s, managing a large portfolio of popular brands and patented products & technologies that are licensed directly to major retailers and large Multinationals, creating exclusive merchandising programs and differentiates them from competitors.\n\nFollowing several years of success in supplying innovation to our partners, in 2011, Earthbound Israel was chosen by Walmart to serve as their Anchor Innovation Partner. In 2013 Earthbound Israel was nominated by Unilever to be their Open Innovation Port in Israel and by Walmart, to serve as their Anchor Innovation Partner.',
				spec_doc_url:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1478091735/sst7pfxmhwbqhgrpffgr.pdf',
				is_pilot_closed: false,
				company_name: 'Earthbound',
				target_vendors: '',
				name: 'Consumer Survey Analytics',
				category: ['2c9f91cc596035e90159603743870320', 'Business Intelligence']
			},
			{
				end_date: '1490950800000',
				snippet:
					"We're looking for a Video streaming Solutions to help us share our content with any audience around the world, with the ability to disperse across multiple viewing channels, through secure connections optimized for the highest quality experience to our customers.\nThe solution should enable us to upload, maintain, and organize the video content, currently distributed through  multiple locations with an easy to operate application.",
				country: ['United States', 'United States'],
				hidden: false,
				owner_id: '2c9f93d9570a74ea015722a8cc0b00ac',
				company_website: '',
				description:
					"We're looking for a Video streaming Solutions to help us share our content with any audience around the world, with the ability to disperse across multiple viewing channels, through secure connections optimized for the highest quality experience to our customers.\nThe solution should enable us to upload, maintain, and organize the video content, currently distributed through  multiple locations with an easy to operate application.",
				industry: ['28', 'Media & Entertainment'],
				scenarios: '',
				pilot_name_flat: 'videostreamingsolution',
				last_date_to_join: '1490950800000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria: '',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f93d9570a74ea01572532a32c0584',
				tag: [
					'marketing & advertising',
					'advertising networks',
					'public relations',
					'augmented reality',
					'big data & analytics'
				],
				start_date: '1473724800000',
				participants: 0,
				goals: '',
				date_created: '1473797858092',
				description_company:
					'We are one of the world’s leading media and entertainment companies in the development, production, and marketing of entertainment, news and information to a global audience.\n\nNBCUniversal owns and operates a valuable portfolio of news and entertainment television networks, a premier motion picture company, significant television production operations, a leading television stations group, world-renowned theme parks, and a suite of leading Internet-based businesses. NBCUniversal is a subsidiary of Comcast Corporation.',
				spec_doc_url: '',
				is_pilot_closed: false,
				company_name: 'Universal Pictures',
				target_vendors: '',
				name: 'Video streaming solution',
				category: ['2c9f91cc596035e90159603743d50324', 'Enterprise Software']
			},
			{
				end_date: '1488276000000',
				snippet:
					"Street lights are an ideal platform for mounting sensors, they are connected to the power grid and their height has many benefits in terms of their birds' eye view as well as  making them ideal for transmitting wireless signals. We are looking for smart IoT solutions that leverage the advantages of city street lights.",
				country: null,
				hidden: false,
				owner_id: '2c9f93d9570a74ea015728a579c20593',
				company_website: '',
				description:
					"Street lights are an ideal platform for mounting sensors, they are connected to the power grid and their height has many benefits in terms of their birds' eye view as well as  making them ideal for transmitting wireless signals. We are looking for smart IoT solutions that leverage the advantages of city street lights.",
				industry: ['3', 'Electronics'],
				scenarios: '',
				pilot_name_flat: 'iotsolutionsforstreetlights',
				last_date_to_join: '1488276000000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria: '',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f93d9570a74ea0157af2cc37807ff',
				tag: ['power & energy'],
				start_date: '1476057600000',
				participants: 0,
				goals: '',
				date_created: '1476112728952',
				description_company:
					'Landis+Gyr is the leading global provider of integrated energy management solutions for the utility sector. \nOffering the broadest portfolio of products and services to address complex industry challenges, the company delivers comprehensive solutions for the foundation of a smarter grid including; smart metering, distribution network sensing and automation tools, load control, analytics and energy storage. \nLandis+Gyr operates in 31 countries across five continents as an independent growth platform of the Toshiba Corporation (TKY:6502) and is also 40% owned by the Innovation Network Corporation of Japan (INCJ). With annualized sales of more than US$1.5 billion, the company employs 5,700 people with the sole mission of helping the world manage energy better.\n\nFor more than a century, Landis+Gyr has helped utilities benefit from technology and innovation to meet requirements, and ultimately to manage energy better. Our meters and solutions empower utilities and end-customers to improve their energy efficiency, reduce their energy costs and contribute to a sustainable use of resources.\nWe are a world leader in electricity metering with a preeminent position in advanced or “smart metering systems” – an essential component in global efforts to upgrade energy distribution systems and enable more efficient and reliable distribution of power.\n',
				spec_doc_url: '',
				is_pilot_closed: false,
				company_name: 'Landis+Gyr',
				target_vendors: '',
				name: 'IoT Solutions for Street Lights',
				category: ['2c9f91cc596035e90159603744130327', 'IoT']
			},
			{
				end_date: '1487721600000',
				snippet:
					"This PoC is part of the Reboot.Forum Healthcare Innovation Competition and is intended for Israeli companies only. Please view 'Full Tech Spec' above for more details. Applicants that would like to participate in a PoC to increase their chances in the competition are required to register at the following link as well as clicking 'Join' on the right side of your screen: https://goo.gl/C6rxYs",
				country: ['Israel', 'Israel'],
				hidden: false,
				owner_id: '2c9f91cc581b67930158b1ca77640234',
				company_website: '',
				description:
					"This PoC is part of the Reboot.Forum Healthcare Innovation Competition and is intended for Israeli companies only. Please view 'Full Tech Spec' above for more details. Applicants that would like to participate in a PoC to increase their chances in the competition are required to register at the following link as well as clicking 'Join' on the right side of your screen: https://goo.gl/C6rxYs",
				industry: ['12', 'Healthcare & Biotech'],
				scenarios: '',
				pilot_name_flat: 'sustainablehealthcareforisrael',
				last_date_to_join: '1487721600000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria: '',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc581b67930158bed428b10253',
				tag: ['medical sw'],
				start_date: '1480550400000',
				participants: 3,
				goals: '',
				date_created: '1480670324913',
				description_company:
					'Reboot Forum is a public benefit initiative established in 2014. It is a multi-disciplinary action community aimed at promoting the academic discourse into an immediate implementation of programs and initiatives that can support the sustainability of the healthcare system in Israel, which eventually will contribute to extending healthy life years!Using ‘practical innovation’ principles, the forum encourages finding joint solutions to cope with future health challenges and assists in putting healthcare at the top of the national public agenda.Projects and initiatives selected by the forum are provided with a "Reboot Package" that includes personal advice from senior figures in the health system, academia and industry,  introduction and professional consulting, grant funds, initial support, guidance and mentoring, and professional/public exposure. The Israeli program is working in cooperation with the European program; "Roadmap To Sustainable Healthcare", led by representatives from academic institutes and healthcare systems from EU countries, which contributes international support, knowledge, and exchange of other resources.More information about the forum can be found at the Reboot Forum Hub',
				spec_doc_url:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1480671548/zggmsilajuezzixbd1nq.ai',
				is_pilot_closed: false,
				company_name: 'Reboot Forum',
				target_vendors: '',
				name: 'Sustainable Healthcare for Israel',
				category: ['2c9f91cc596035e90159603743c50323', 'Healthcare']
			},
			{
				end_date: '1490950800000',
				snippet:
					'We are looking to provide our customers with an easy and intuitive tool enabling them to gain meaningful insight from their data.',
				country: ['United States', 'United States'],
				hidden: false,
				owner_id: '2c9f91cc581b679301582b2f36b000ee',
				company_website: '',
				description:
					'We are looking to provide our customers with an easy and intuitive tool enabling them to gain meaningful insight from their data.',
				industry: ['4', 'Internet & Software'],
				scenarios: '',
				pilot_name_flat: 'salestrendsanalysisforretailbusiness',
				last_date_to_join: '1490950800000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria: '',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc581b679301582b31b3da00ef',
				tag: ['marketing & advertising', 'other'],
				start_date: '1478131200000',
				participants: 3,
				goals: '',
				date_created: '1478193427418',
				description_company:
					"Launched in 2006, Amazon Web Services (AWS) began exposing key infrastructure services to businesses in the form of web services -- now widely known as cloud computing. The ultimate benefit of cloud computing, and AWS, is the ability to leverage a new business model and turn capital infrastructure expenses into variable costs. Businesses no longer need to plan and procure servers and other IT resources weeks or months in advance. Using AWS, businesses can take advantage of Amazon's expertise and economies of scale to access resources when their business needs them, delivering results faster and at a lower cost. \n\nToday, Amazon Web Services provides a highly reliable, scalable, low-cost infrastructure platform in the cloud that powers hundreds of thousands of businesses in 190 countries around the world. With data center locations in the U.S., Europe, Singapore, and Japan, customers across all industries are taking advantage of our low cost, elastic, open and flexible, secure platform.\n",
				spec_doc_url:
					'https://res.cloudinary.com/scalabill-it/raw/upload/v1478193659/epuzmw5wwzph0hsfpizg.docx',
				is_pilot_closed: false,
				company_name: 'Amazon Web Services (AWS)',
				target_vendors: '',
				name: 'Sales Trends Analysis for Retail Business',
				category: ['2c9f91cc596035e90159603743870320', 'Business Intelligence']
			},
			{
				end_date: '1506762000000',
				snippet:
					'השבוע הוא רק הקדמה למערכת הסוערת שתגיע לאזורנו בתחילת השבוע הבא. במרכז הארץ ובדרומה ינשבו רוחות עזות במהירות של 50 עד 90 קמ"ש. לתחזית המלאה ולמכ"ם הגשם',
				country: null,
				hidden: false,
				owner_id: '2c9f91cc59613c230159613f222d0000',
				company_website: '',
				description:
					'השבוע הוא רק הקדמה למערכת הסוערת שתגיע לאזורנו בתחילת השבוע הבא. במרכז הארץ ובדרומה ינשבו רוחות עזות במהירות של 50 עד 90 קמ"ש. לתחזית המלאה ולמכ"ם הגשם',
				industry: ['22', 'Food & Beverage'],
				scenarios:
					'צרין 10-5, צפת 8-5, טבריה 16-8, נצרת 12-7, חיפה 15-9, ת"א 15-9, ירושלים 10-5, אשקלון 15-10, עין גדי 19-10, באר שבע 16-5, ערד 13-4, מצפה רמון 12-2 וא',
				pilot_name_flat: 'מזגהאווירהחורפי',
				last_date_to_join: '1506762000000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria:
					'["Vendor demonstrations","Has paying customers","Low CPU usage","Low memory usage"]',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc596449a101596507aafe0027',
				tag: [],
				start_date: '1483437600000',
				participants: 0,
				goals:
					"מערכת גשומה סוערת וקרה מחכה לנו בראשית השבוע הבא. אך עוד לפני כן, הערב (יום ג') והלילה יוסיף לרדת גשם בצפון הארץ ולאורך מישור החוף. בחרמון יירד שלג. בים התיכון תנשב רוח דרום-מזרחית במהירות של 10 עד 15 קמ\"ש. גובה הגלים בים ינוע בין 70 ל-150 סנטימטרים.",
				date_created: '1483458718462',
				description_company: '',
				spec_doc_url: '',
				is_pilot_closed: false,
				company_name: 'Two Enterprise',
				target_vendors:
					'מחברת "מטאו טק" נמסר כי אפיק רדוד מעל אזורנו גורם לגשם. הטמפרטורות החזויות להלילה ומחר: קריית שמונה 13-7',
				name: 'מזג האוויר החורפי',
				category: ['2c9f91cc596035e90159603744130327', 'IoT']
			},
			{
				end_date: '1506762000000',
				snippet:
					'השבוע הוא רק הקדמה למערכת הסוערת שתגיע לאזורנו בתחילת השבוע הבא. במרכז הארץ ובדרומה ינשבו רוחות עזות במהירות של 50 עד 90 קמ"ש. לתחזית המלאה ולמכ"ם הגשם',
				country: null,
				hidden: false,
				owner_id: '2c9f91cc59613c230159613f222d0000',
				company_website: '',
				description:
					'השבוע הוא רק הקדמה למערכת הסוערת שתגיע לאזורנו בתחילת השבוע הבא. במרכז הארץ ובדרומה ינשבו רוחות עזות במהירות של 50 עד 90 קמ"ש. לתחזית המלאה ולמכ"ם הגשם',
				industry: ['22', 'Food & Beverage'],
				scenarios:
					'צרין 10-5, צפת 8-5, טבריה 16-8, נצרת 12-7, חיפה 15-9, ת"א 15-9, ירושלים 10-5, אשקלון 15-10, עין גדי 19-10, באר שבע 16-5, ערד 13-4, מצפה רמון 12-2 וא',
				pilot_name_flat: 'מזגהאווירהחורפי',
				last_date_to_join: '1506762000000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria:
					'["Vendor demonstrations","Has paying customers","Low CPU usage","Low memory usage"]',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc596449a101596507aafe0027',
				tag: [],
				start_date: '1483437600000',
				participants: 0,
				goals:
					"מערכת גשומה סוערת וקרה מחכה לנו בראשית השבוע הבא. אך עוד לפני כן, הערב (יום ג') והלילה יוסיף לרדת גשם בצפון הארץ ולאורך מישור החוף. בחרמון יירד שלג. בים התיכון תנשב רוח דרום-מזרחית במהירות של 10 עד 15 קמ\"ש. גובה הגלים בים ינוע בין 70 ל-150 סנטימטרים.",
				date_created: '1483458718462',
				description_company: '',
				spec_doc_url: '',
				is_pilot_closed: false,
				company_name: 'Two Enterprise',
				target_vendors:
					'מחברת "מטאו טק" נמסר כי אפיק רדוד מעל אזורנו גורם לגשם. הטמפרטורות החזויות להלילה ומחר: קריית שמונה 13-7',
				name: 'מזג האוויר החורפי',
				category: ['2c9f91cc596035e90159603744130327', 'IoT']
			},
			{
				end_date: '1506762000000',
				snippet:
					'השבוע הוא רק הקדמה למערכת הסוערת שתגיע לאזורנו בתחילת השבוע הבא. במרכז הארץ ובדרומה ינשבו רוחות עזות במהירות של 50 עד 90 קמ"ש. לתחזית המלאה ולמכ"ם הגשם',
				country: null,
				hidden: false,
				owner_id: '2c9f91cc59613c230159613f222d0000',
				company_website: '',
				description:
					'השבוע הוא רק הקדמה למערכת הסוערת שתגיע לאזורנו בתחילת השבוע הבא. במרכז הארץ ובדרומה ינשבו רוחות עזות במהירות של 50 עד 90 קמ"ש. לתחזית המלאה ולמכ"ם הגשם',
				industry: ['22', 'Food & Beverage'],
				scenarios:
					'צרין 10-5, צפת 8-5, טבריה 16-8, נצרת 12-7, חיפה 15-9, ת"א 15-9, ירושלים 10-5, אשקלון 15-10, עין גדי 19-10, באר שבע 16-5, ערד 13-4, מצפה רמון 12-2 וא',
				pilot_name_flat: 'מזגהאווירהחורפי',
				last_date_to_join: '1506762000000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria:
					'["Vendor demonstrations","Has paying customers","Low CPU usage","Low memory usage"]',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc596449a101596507aafe0027',
				tag: [],
				start_date: '1483437600000',
				participants: 0,
				goals:
					"מערכת גשומה סוערת וקרה מחכה לנו בראשית השבוע הבא. אך עוד לפני כן, הערב (יום ג') והלילה יוסיף לרדת גשם בצפון הארץ ולאורך מישור החוף. בחרמון יירד שלג. בים התיכון תנשב רוח דרום-מזרחית במהירות של 10 עד 15 קמ\"ש. גובה הגלים בים ינוע בין 70 ל-150 סנטימטרים.",
				date_created: '1483458718462',
				description_company: '',
				spec_doc_url: '',
				is_pilot_closed: false,
				company_name: 'Two Enterprise',
				target_vendors:
					'מחברת "מטאו טק" נמסר כי אפיק רדוד מעל אזורנו גורם לגשם. הטמפרטורות החזויות להלילה ומחר: קריית שמונה 13-7',
				name: 'מזג האוויר החורפי',
				category: ['2c9f91cc596035e90159603744130327', 'IoT']
			},
			{
				end_date: '1506762000000',
				snippet:
					'השבוע הוא רק הקדמה למערכת הסוערת שתגיע לאזורנו בתחילת השבוע הבא. במרכז הארץ ובדרומה ינשבו רוחות עזות במהירות של 50 עד 90 קמ"ש. לתחזית המלאה ולמכ"ם הגשם',
				country: null,
				hidden: false,
				owner_id: '2c9f91cc59613c230159613f222d0000',
				company_website: '',
				description:
					'השבוע הוא רק הקדמה למערכת הסוערת שתגיע לאזורנו בתחילת השבוע הבא. במרכז הארץ ובדרומה ינשבו רוחות עזות במהירות של 50 עד 90 קמ"ש. לתחזית המלאה ולמכ"ם הגשם',
				industry: ['22', 'Food & Beverage'],
				scenarios:
					'צרין 10-5, צפת 8-5, טבריה 16-8, נצרת 12-7, חיפה 15-9, ת"א 15-9, ירושלים 10-5, אשקלון 15-10, עין גדי 19-10, באר שבע 16-5, ערד 13-4, מצפה רמון 12-2 וא',
				pilot_name_flat: 'מזגהאווירהחורפי',
				last_date_to_join: '1506762000000',
				type: 'pilot',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/c_crop,w_471,h_471,x_60,y_0/c_fit,w_80,h_80,c_pad/v1477557335/gc99pvwosbv5ij1zxcia.jpg',
				eval_criteria:
					'["Vendor demonstrations","Has paying customers","Low CPU usage","Low memory usage"]',
				oneliner: null,
				approvals: 'MANUAL',
				id: '2c9f91cc596449a101596507aafe0027',
				tag: [],
				start_date: '1483437600000',
				participants: 0,
				goals:
					"מערכת גשומה סוערת וקרה מחכה לנו בראשית השבוע הבא. אך עוד לפני כן, הערב (יום ג') והלילה יוסיף לרדת גשם בצפון הארץ ולאורך מישור החוף. בחרמון יירד שלג. בים התיכון תנשב רוח דרום-מזרחית במהירות של 10 עד 15 קמ\"ש. גובה הגלים בים ינוע בין 70 ל-150 סנטימטרים.",
				date_created: '1483458718462',
				description_company: '',
				spec_doc_url: '',
				is_pilot_closed: false,
				company_name: 'Two Enterprise',
				target_vendors:
					'מחברת "מטאו טק" נמסר כי אפיק רדוד מעל אזורנו גורם לגשם. הטמפרטורות החזויות להלילה ומחר: קריית שמונה 13-7',
				name: 'מזג האוויר החורפי',
				category: ['2c9f91cc596035e90159603744130327', 'IoT']
			}
		],
		metadata: {
			limit: 12,
			skip: 0,
			offset: 0,
			total_count: 13,
			keyword: '',
			filters: []
		}
	},

	vendor: {
		data: [
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1470586095/user-uploads/logo/o9cqtkryrhh9wg6tbguz.jpg',
				oneliner: 'sell better online using chatbot conversations',
				about_us:
					'Convia is a platform for creating chat bots that are focused on conversion (e.g. sales, leads, registrations, etc).  Using Convia, marketers can launch effective conversation-based campaigns on popular messaging applications (e.g. Facebook messenger).',
				id: '2c9f93d955f7f36a015665c539e801b5',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Convia'
			},
			{
				country: [
					{
						country: ['Israel', 'Israel'],
						funding_stage: '',
						resources: {},
						industry: [4, 'Computer Software'],
						tags: '',
						website_meta_tags: {
							viewport: 'width=device-width'
						},
						profile_image:
							'https://res.cloudinary.com/scalabill-it/image/upload/v1473582494/user-uploads/logo/ljrxgjryjjins0uf2niz.png',
						oneliner: 'mobile payments for organized marketplaces',
						about_us:
							"At KnuPo, we're solving the acceptance problem of mobile payments. We believe that there are two factors required for this: true user value, and full merchant coverage. With KnuPo we deliver both. We do this by creating high value for the management of a closed merchant ecosystem. This value drives management to create full merchant coverage, an ongoing stream of discounts and other customer value, and to operate their marketing channels to on board their customers. KnuPo also introduces some interesting security features both targeted at customer security perception, and at fraud management in a CNP environment.\n\ncontact us for more info.",
						id: '2c9f93d9570a74ea015711263ab20025',
						category: 'Fintech',
						company_size: '',
						type: 'vendor',
						name: 'KnuPo'
					}
				],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Reaction combines verbal customer support with media sharing. Consumer problems can now be solved faster than ever. Download the free app today!',
					'google-site-verification':
						'frcmx5Sy6DP6Uj4pC2yR09iywsa1aJi2qeTz4q4D-Ps',
					viewport: 'width=device-width, initial-scale=1.0',
					author: ' Bonaventure Barry'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474197008/user-uploads/logo/fbwww43utwbsgqugni3w.png',
				oneliner: 'We believe that a picture is worth 1000 words',
				about_us:
					'Reaction is a visual, data-based customer service platform designed to improve the customer’s experience. The ReactionApp allows users to share visual media with customer service agents, allowing both parties to see what’s happening. At the end of the call, rate your customer service experience with smilley face. We are going to let the business know about how you feel right after you ended the call.',
				id: '2c9f91cc56f416fa015707803c3b00f0',
				category: 'Mobile',
				company_size: '',
				type: 'vendor',
				name: 'Reaction'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1470586095/user-uploads/logo/o9cqtkryrhh9wg6tbguz.jpg',
				oneliner: 'sell better online using chatbot conversations',
				about_us:
					'Convia is a platform for creating chat bots that are focused on conversion (e.g. sales, leads, registrations, etc).  Using Convia, marketers can launch effective conversation-based campaigns on popular messaging applications (e.g. Facebook messenger).',
				id: '2c9f93d955f7f36a015665c539e801b5',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Convia'
			},
			{
				country: [
					{
						country: ['Israel', 'Israel'],
						funding_stage: '',
						resources: {},
						industry: [4, 'Computer Software'],
						tags: '',
						website_meta_tags: {
							viewport: 'width=device-width'
						},
						profile_image:
							'https://res.cloudinary.com/scalabill-it/image/upload/v1473582494/user-uploads/logo/ljrxgjryjjins0uf2niz.png',
						oneliner: 'mobile payments for organized marketplaces',
						about_us:
							"At KnuPo, we're solving the acceptance problem of mobile payments. We believe that there are two factors required for this: true user value, and full merchant coverage. With KnuPo we deliver both. We do this by creating high value for the management of a closed merchant ecosystem. This value drives management to create full merchant coverage, an ongoing stream of discounts and other customer value, and to operate their marketing channels to on board their customers. KnuPo also introduces some interesting security features both targeted at customer security perception, and at fraud management in a CNP environment.\n\ncontact us for more info.",
						id: '2c9f93d9570a74ea015711263ab20025',
						category: 'Fintech',
						company_size: '',
						type: 'vendor',
						name: 'KnuPo'
					}
				],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Reaction combines verbal customer support with media sharing. Consumer problems can now be solved faster than ever. Download the free app today!',
					'google-site-verification':
						'frcmx5Sy6DP6Uj4pC2yR09iywsa1aJi2qeTz4q4D-Ps',
					viewport: 'width=device-width, initial-scale=1.0',
					author: ' Bonaventure Barry'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474197008/user-uploads/logo/fbwww43utwbsgqugni3w.png',
				oneliner: 'We believe that a picture is worth 1000 words',
				about_us:
					'Reaction is a visual, data-based customer service platform designed to improve the customer’s experience. The ReactionApp allows users to share visual media with customer service agents, allowing both parties to see what’s happening. At the end of the call, rate your customer service experience with smilley face. We are going to let the business know about how you feel right after you ended the call.',
				id: '2c9f91cc56f416fa015707803c3b00f0',
				category: 'Mobile',
				company_size: '',
				type: 'vendor',
				name: 'Reaction'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1470586095/user-uploads/logo/o9cqtkryrhh9wg6tbguz.jpg',
				oneliner: 'sell better online using chatbot conversations',
				about_us:
					'Convia is a platform for creating chat bots that are focused on conversion (e.g. sales, leads, registrations, etc).  Using Convia, marketers can launch effective conversation-based campaigns on popular messaging applications (e.g. Facebook messenger).',
				id: '2c9f93d955f7f36a015665c539e801b5',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Convia'
			},
			{
				country: [
					{
						country: ['Israel', 'Israel'],
						funding_stage: '',
						resources: {},
						industry: [4, 'Computer Software'],
						tags: '',
						website_meta_tags: {
							viewport: 'width=device-width'
						},
						profile_image:
							'https://res.cloudinary.com/scalabill-it/image/upload/v1473582494/user-uploads/logo/ljrxgjryjjins0uf2niz.png',
						oneliner: 'mobile payments for organized marketplaces',
						about_us:
							"At KnuPo, we're solving the acceptance problem of mobile payments. We believe that there are two factors required for this: true user value, and full merchant coverage. With KnuPo we deliver both. We do this by creating high value for the management of a closed merchant ecosystem. This value drives management to create full merchant coverage, an ongoing stream of discounts and other customer value, and to operate their marketing channels to on board their customers. KnuPo also introduces some interesting security features both targeted at customer security perception, and at fraud management in a CNP environment.\n\ncontact us for more info.",
						id: '2c9f93d9570a74ea015711263ab20025',
						category: 'Fintech',
						company_size: '',
						type: 'vendor',
						name: 'KnuPo'
					}
				],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Reaction combines verbal customer support with media sharing. Consumer problems can now be solved faster than ever. Download the free app today!',
					'google-site-verification':
						'frcmx5Sy6DP6Uj4pC2yR09iywsa1aJi2qeTz4q4D-Ps',
					viewport: 'width=device-width, initial-scale=1.0',
					author: ' Bonaventure Barry'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474197008/user-uploads/logo/fbwww43utwbsgqugni3w.png',
				oneliner: 'We believe that a picture is worth 1000 words',
				about_us:
					'Reaction is a visual, data-based customer service platform designed to improve the customer’s experience. The ReactionApp allows users to share visual media with customer service agents, allowing both parties to see what’s happening. At the end of the call, rate your customer service experience with smilley face. We are going to let the business know about how you feel right after you ended the call.',
				id: '2c9f91cc56f416fa015707803c3b00f0',
				category: 'Mobile',
				company_size: '',
				type: 'vendor',
				name: 'Reaction'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'vendor',
				name: 'Nubo Software'
			}
		],
		metadata: {
			limit: 12,
			offset: 0,
			total_count: 344,
			keyword: '',
			filters: [
				{ type: 'country', id: 'us', label: 'United States' },
				{ type: 'industry', id: '43', label: 'Insurance' }
			]
		}
	},

	client: {
		data: [
			{
				country: ['Israel', 'Israel'],
				website_meta_tags: {
					copyright: '(c) Coca Cola',
					author: 'programming: skatrix.com',
					description: 'האתר הרשמי של קוקה-קולה ישראל',
					robots: 'index,follow',
					googlebot: 'index,follow'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474187181/user-uploads/logo/o4k2hh5pjgwuu58yhpez.png',
				about_us:
					"The Central Bottling Company Group holds the Coca-Cola franchise for Israel and is the nation's leading manufacturer and distributor of beverages. It is among Coca-Cola's largest bottling facilities worldwide and has grown into a group of companies which leads the Israeli beverage market, offering products ranging from mineral water to soft drinks, and all-natural fruit juices to beer. \n\nThe group, via subsidiaries and joint ventures, also holds the franchise for Carlsberg brands in Romania and Albania, as well as a license for the European dairy brand Müller in Israel, Romania, and Bulgaria. \n\nAccounting for a considerable share of Israel's large, dynamic beverages market, the Central Bottling Company is a group of companies with a combined annual turnover of over one billion dollars. The group's companies operate synergetically to the benefit of all its members. The group has become a significant player in the Israeli economy, with products aimed at the local market and also targeted for export. The group has holdings in additional companies, including the Israeli television channel 2 franchisee, Keshet.\n\nCBC has held the Israel franchise for Coca-Cola products since 1968, which today include Coca-Cola​, Diet Coca-Cola, Coca-Cola Zero, Fanta, Sprite, Fuze Tea, and Kinley Soda. It is among Coca-Cola's ten largest single-plant bottling facilities worldwide, and Israel has one of the world's highest per capita consumption of Coca-Cola products.",
				resources: {},
				industry: [22, 'Supermarkets'],
				id: '2c9f839550ec55ee0150fb59c31f00fa',
				category: 'Big Data & Analytics',
				company_size: '',
				tags: '',
				type: 'client',
				name: 'Coca-Cola'
			},
			{
				country: ['Israel', 'Israel'],
				website_meta_tags: {
					copyright: '(c) Coca Cola',
					author: 'programming: skatrix.com',
					description: 'האתר הרשמי של קוקה-קולה ישראל',
					robots: 'index,follow',
					googlebot: 'index,follow'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474187181/user-uploads/logo/o4k2hh5pjgwuu58yhpez.png',
				about_us:
					"The Central Bottling Company Group holds the Coca-Cola franchise for Israel and is the nation's leading manufacturer and distributor of beverages. It is among Coca-Cola's largest bottling facilities worldwide and has grown into a group of companies which leads the Israeli beverage market, offering products ranging from mineral water to soft drinks, and all-natural fruit juices to beer. \n\nThe group, via subsidiaries and joint ventures, also holds the franchise for Carlsberg brands in Romania and Albania, as well as a license for the European dairy brand Müller in Israel, Romania, and Bulgaria. \n\nAccounting for a considerable share of Israel's large, dynamic beverages market, the Central Bottling Company is a group of companies with a combined annual turnover of over one billion dollars. The group's companies operate synergetically to the benefit of all its members. The group has become a significant player in the Israeli economy, with products aimed at the local market and also targeted for export. The group has holdings in additional companies, including the Israeli television channel 2 franchisee, Keshet.\n\nCBC has held the Israel franchise for Coca-Cola products since 1968, which today include Coca-Cola​, Diet Coca-Cola, Coca-Cola Zero, Fanta, Sprite, Fuze Tea, and Kinley Soda. It is among Coca-Cola's ten largest single-plant bottling facilities worldwide, and Israel has one of the world's highest per capita consumption of Coca-Cola products.",
				resources: {},
				industry: [22, 'Supermarkets'],
				id: '2c9f839550ec55ee0150fb59c31f00fa',
				category: 'Big Data & Analytics',
				company_size: '',
				tags: '',
				type: 'client',
				name: 'Coca-Cola'
			},
			{
				country: ['Israel', 'Israel'],
				website_meta_tags: {
					copyright: '(c) Coca Cola',
					author: 'programming: skatrix.com',
					description: 'האתר הרשמי של קוקה-קולה ישראל',
					robots: 'index,follow',
					googlebot: 'index,follow'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474187181/user-uploads/logo/o4k2hh5pjgwuu58yhpez.png',
				about_us:
					"The Central Bottling Company Group holds the Coca-Cola franchise for Israel and is the nation's leading manufacturer and distributor of beverages. It is among Coca-Cola's largest bottling facilities worldwide and has grown into a group of companies which leads the Israeli beverage market, offering products ranging from mineral water to soft drinks, and all-natural fruit juices to beer. \n\nThe group, via subsidiaries and joint ventures, also holds the franchise for Carlsberg brands in Romania and Albania, as well as a license for the European dairy brand Müller in Israel, Romania, and Bulgaria. \n\nAccounting for a considerable share of Israel's large, dynamic beverages market, the Central Bottling Company is a group of companies with a combined annual turnover of over one billion dollars. The group's companies operate synergetically to the benefit of all its members. The group has become a significant player in the Israeli economy, with products aimed at the local market and also targeted for export. The group has holdings in additional companies, including the Israeli television channel 2 franchisee, Keshet.\n\nCBC has held the Israel franchise for Coca-Cola products since 1968, which today include Coca-Cola​, Diet Coca-Cola, Coca-Cola Zero, Fanta, Sprite, Fuze Tea, and Kinley Soda. It is among Coca-Cola's ten largest single-plant bottling facilities worldwide, and Israel has one of the world's highest per capita consumption of Coca-Cola products.",
				resources: {},
				industry: [22, 'Supermarkets'],
				id: '2c9f839550ec55ee0150fb59c31f00fa',
				category: 'Big Data & Analytics',
				company_size: '',
				tags: '',
				type: 'client',
				name: 'Coca-Cola'
			},
			{
				country: ['Israel', 'Israel'],
				website_meta_tags: {
					copyright: '(c) Coca Cola',
					author: 'programming: skatrix.com',
					description: 'האתר הרשמי של קוקה-קולה ישראל',
					robots: 'index,follow',
					googlebot: 'index,follow'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474187181/user-uploads/logo/o4k2hh5pjgwuu58yhpez.png',
				about_us:
					"The Central Bottling Company Group holds the Coca-Cola franchise for Israel and is the nation's leading manufacturer and distributor of beverages. It is among Coca-Cola's largest bottling facilities worldwide and has grown into a group of companies which leads the Israeli beverage market, offering products ranging from mineral water to soft drinks, and all-natural fruit juices to beer. \n\nThe group, via subsidiaries and joint ventures, also holds the franchise for Carlsberg brands in Romania and Albania, as well as a license for the European dairy brand Müller in Israel, Romania, and Bulgaria. \n\nAccounting for a considerable share of Israel's large, dynamic beverages market, the Central Bottling Company is a group of companies with a combined annual turnover of over one billion dollars. The group's companies operate synergetically to the benefit of all its members. The group has become a significant player in the Israeli economy, with products aimed at the local market and also targeted for export. The group has holdings in additional companies, including the Israeli television channel 2 franchisee, Keshet.\n\nCBC has held the Israel franchise for Coca-Cola products since 1968, which today include Coca-Cola​, Diet Coca-Cola, Coca-Cola Zero, Fanta, Sprite, Fuze Tea, and Kinley Soda. It is among Coca-Cola's ten largest single-plant bottling facilities worldwide, and Israel has one of the world's highest per capita consumption of Coca-Cola products.",
				resources: {},
				industry: [22, 'Supermarkets'],
				id: '2c9f839550ec55ee0150fb59c31f00fa',
				category: 'Big Data & Analytics',
				company_size: '',
				tags: '',
				type: 'client',
				name: 'Coca-Cola'
			},
			{
				country: ['Israel', 'Israel'],
				website_meta_tags: {
					copyright: '(c) Coca Cola',
					author: 'programming: skatrix.com',
					description: 'האתר הרשמי של קוקה-קולה ישראל',
					robots: 'index,follow',
					googlebot: 'index,follow'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474187181/user-uploads/logo/o4k2hh5pjgwuu58yhpez.png',
				about_us:
					"The Central Bottling Company Group holds the Coca-Cola franchise for Israel and is the nation's leading manufacturer and distributor of beverages. It is among Coca-Cola's largest bottling facilities worldwide and has grown into a group of companies which leads the Israeli beverage market, offering products ranging from mineral water to soft drinks, and all-natural fruit juices to beer. \n\nThe group, via subsidiaries and joint ventures, also holds the franchise for Carlsberg brands in Romania and Albania, as well as a license for the European dairy brand Müller in Israel, Romania, and Bulgaria. \n\nAccounting for a considerable share of Israel's large, dynamic beverages market, the Central Bottling Company is a group of companies with a combined annual turnover of over one billion dollars. The group's companies operate synergetically to the benefit of all its members. The group has become a significant player in the Israeli economy, with products aimed at the local market and also targeted for export. The group has holdings in additional companies, including the Israeli television channel 2 franchisee, Keshet.\n\nCBC has held the Israel franchise for Coca-Cola products since 1968, which today include Coca-Cola​, Diet Coca-Cola, Coca-Cola Zero, Fanta, Sprite, Fuze Tea, and Kinley Soda. It is among Coca-Cola's ten largest single-plant bottling facilities worldwide, and Israel has one of the world's highest per capita consumption of Coca-Cola products.",
				resources: {},
				industry: [22, 'Supermarkets'],
				id: '2c9f839550ec55ee0150fb59c31f00fa',
				category: 'Big Data & Analytics',
				company_size: '',
				tags: '',
				type: 'client',
				name: 'Coca-Cola'
			},
			{
				end_date: '2016-09-28T00:00:00.000Z',
				snippet: 'pilot 100',
				country: ['United States', 'United States'],
				date_created: '2016-09-04T11:08:50.297Z',
				owner_id: '2c9f91cc53385c390153386f48f00001',
				description: 'pilot 100',
				industry: [4, 'Computer Software'],
				last_date_to_join: '2016-09-28T00:00:00.000Z',
				tags: ['big data & analytics', 'data mining'],
				spec_doc_url: '',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1465465753/user-uploads/logo/gdhyctcnvfqnrgasyeu7.jpg',
				approvals: 'MANUAL',
				company_name: 'Nativ Ent4',
				operating_system: {},
				id: '2c9f91cc56f416fa0156f4e2f6e9000b',
				category: ['2c9f9be057adcb590157adcb7e030002', 'Big Data'],
				start_date: '2016-09-01T00:00:00.000Z',
				type: 'client',
				name: 'nate pilot 100'
			},
			{
				end_date: '2016-08-26T00:00:00.000Z',
				snippet: 'A Test',
				country: [
					'United Kingdom',
					'United Kingdom of Great Britain and Northern Ireland'
				],
				date_created: '2016-03-15T14:55:32.917Z',
				owner_id: '2c9f91cc533bf6ce015375ed52c7005d',
				description: 'A Test',
				industry: [8, 'Telecommunications'],
				last_date_to_join: '2016-08-26T00:00:00.000Z',
				tags: ['telecommunications'],
				spec_doc_url: '',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1458032087/aesffzpd9jhylfjqmc5m.png',
				approvals: 'OPEN',
				company_name: 'BT',
				operating_system: {},
				id: '2c9f91cc533bf6ce01537ac65a250061',
				category: ['2c9f9be057adcb590157adcb7e220004', 'Communication'],
				start_date: '2016-03-15T00:00:00.000Z',
				type: 'client',
				name: 'Test'
			},
			{
				end_date: '2020-12-31T00:00:00.000Z',
				snippet: 'Comsec<>Test<img src="">Test2',
				country: [0, 'NA'],
				date_created: '2016-06-01T14:42:13.811Z',
				owner_id: '2c9f91cc53385c390153386f48f00001',
				description: 'Comsec<>Test<img src="">Test2',
				industry: [4, 'Computer Software'],
				last_date_to_join: '2020-12-31T00:00:00.000Z',
				tags: ['smb', 'other'],
				spec_doc_url: '',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1465465753/user-uploads/logo/gdhyctcnvfqnrgasyeu7.jpg',
				approvals: 'MANUAL',
				company_name: 'Nativ Ent4',
				operating_system: {},
				id: '2c9f93d9550c50fd01550c6a30970000',
				category: ['2c9f9be057adcb590157adcb7e80000c', 'Other'],
				start_date: '2016-06-04T00:00:00.000Z',
				type: 'client',
				name: 'A new pilot<>01062016'
			},
			{
				end_date: '2016-08-26T00:00:00.000Z',
				snippet: 'Looking for innovative Digital Wallet Solutions',
				country: ['Israel', 'Israel'],
				date_created: '2016-05-26T15:19:32.936Z',
				owner_id: '4028b88150ccee980150cd16adf30002',
				description: 'Looking for innovative Digital Wallet Solutions',
				industry: [41, 'Banking'],
				last_date_to_join: '2016-08-26T00:00:00.000Z',
				tags: ['other', 'fintech'],
				spec_doc_url: '',
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474270439/user-uploads/logo/baru27l6zom6i4sf9ozy.png',
				approvals: 'OPEN',
				company_name: 'Isracard',
				operating_system: {},
				id: '2c9f93d9549461bf0154eda633480045',
				category: ['2c9f9be057adcb590157adcb7e510008', 'FinTech'],
				start_date: '2016-05-26T00:00:00.000Z',
				type: 'client',
				name: 'E-Wallet'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1470586095/user-uploads/logo/o9cqtkryrhh9wg6tbguz.jpg',
				oneliner: 'sell better online using chatbot conversations',
				about_us:
					'Convia is a platform for creating chat bots that are focused on conversion (e.g. sales, leads, registrations, etc).  Using Convia, marketers can launch effective conversation-based campaigns on popular messaging applications (e.g. Facebook messenger).',
				id: '2c9f93d955f7f36a015665c539e801b5',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'client',
				name: 'Convia'
			},
			{
				country: [
					{
						country: ['Israel', 'Israel'],
						funding_stage: '',
						resources: {},
						industry: [4, 'Computer Software'],
						tags: '',
						website_meta_tags: {
							viewport: 'width=device-width'
						},
						profile_image:
							'https://res.cloudinary.com/scalabill-it/image/upload/v1473582494/user-uploads/logo/ljrxgjryjjins0uf2niz.png',
						oneliner: 'mobile payments for organized marketplaces',
						about_us:
							"At KnuPo, we're solving the acceptance problem of mobile payments. We believe that there are two factors required for this: true user value, and full merchant coverage. With KnuPo we deliver both. We do this by creating high value for the management of a closed merchant ecosystem. This value drives management to create full merchant coverage, an ongoing stream of discounts and other customer value, and to operate their marketing channels to on board their customers. KnuPo also introduces some interesting security features both targeted at customer security perception, and at fraud management in a CNP environment.\n\ncontact us for more info.",
						id: '2c9f93d9570a74ea015711263ab20025',
						category: 'Fintech',
						company_size: '',
						type: 'client',
						name: 'KnuPo'
					}
				],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Reaction combines verbal customer support with media sharing. Consumer problems can now be solved faster than ever. Download the free app today!',
					'google-site-verification':
						'frcmx5Sy6DP6Uj4pC2yR09iywsa1aJi2qeTz4q4D-Ps',
					viewport: 'width=device-width, initial-scale=1.0',
					author: ' Bonaventure Barry'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1474197008/user-uploads/logo/fbwww43utwbsgqugni3w.png',
				oneliner: 'We believe that a picture is worth 1000 words',
				about_us:
					'Reaction is a visual, data-based customer service platform designed to improve the customer’s experience. The ReactionApp allows users to share visual media with customer service agents, allowing both parties to see what’s happening. At the end of the call, rate your customer service experience with smilley face. We are going to let the business know about how you feel right after you ended the call.',
				id: '2c9f91cc56f416fa015707803c3b00f0',
				category: 'Mobile',
				company_size: '',
				type: 'client',
				name: 'Reaction'
			},
			{
				country: ['Israel', 'Israel'],
				funding_stage: '',
				resources: {},
				industry: [4, 'Computer Software'],
				tags: '',
				website_meta_tags: {
					Description:
						'Nubo is a secure BYOD remote work environment for iOS and Android that enables you to work on your personal device.',
					viewport: 'width=device-width, initial-scale=1.0'
				},
				profile_image:
					'https://res.cloudinary.com/scalabill-it/image/upload/v1469963366/user-uploads/logo/sktvsgt7dkcqutnyopfo.png',
				oneliner: 'Stream any Mobile App with Zero Data Footprint',
				about_us:
					"The first company to develop Virtual Mobile Infrastructure (VMI) for enterprise mobility, Nubo Software has created one, secured remote virtual workspace that is tailor-made for today’s mobile workforce. From inception, Nubo's Virtual Mobile Infrastructure technology was built around mobile computing needs and founded on a data-centric approach to enterprise security.  \n \nNubo was founded in 2011 by Israel Lifshitz, founder and CEO of SysAid, an ITSM solution used by over 100,000 companies worldwide. Nubo’s innovative approach to mobile security stores zero data on personal devices while providing users with a native app experience and the freedom to choose their own applications.  \n \nWith Nubo, corporations own their data and applications, and employees own their devices.  Users from enterprise organizations can work on their personal devices with security, fun and great ease of use. At the same time, IT can easily manage every work environment of every employee in the organization, making mobility management and data compliance easy. ",
				id: '2c9f93d955f7f36a0155f8cc58b80004',
				category: 'Enterprise Solutions',
				company_size: '',
				type: 'client',
				name: 'Nubo Software'
			}
		],
		metadata: {
			limit: 12,
			offset: 0,
			total_count: 344,
			keyword: '',
			filters: [
				{ type: 'country', id: 'us', label: 'United States' },
				{ type: 'industry', id: '43', label: 'Insurance' }
			]
		}
	}
};

export const suggestionsJson = [
	{
		type: 'recent',
		label: 'Israeli companies',
		ref: '9f0e0741-aeef-5eb1-87b3-543bc43d0018'
	},
	{ type: 'recent', label: 'Israel', ref: '132' },
	{ type: 'keyword', label: 'Israeli customer', ref: 'Israeli customer' },
	{ type: 'tag', label: 'IsraTech', ref: 'IsraTech' },
	{ type: 'tag', label: 'Israeli innovation', ref: 'Israeli innovation' },
	{
		type: 'keyword',
		label: 'Isracard',
		ref: '38c80db0-b1e4-5883-bfdd-d1a7ffaab947'
	},
	{
		type: 'recent',
		label: 'Isrotel',
		ref: '5b16c706-83c1-5386-b55b-36f52e7271c2'
	}
];
