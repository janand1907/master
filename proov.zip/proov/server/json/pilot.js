import _pick from 'lodash/pick';
import * as joinableStatus from './../../src/constants/pilotJoinableStatus';
import { client, vendor, participants } from './company';
import { category } from './common';
import request from './pilotJoinRequest';
import APIs from './channels/lab/API';
import servers from './channels/lab/server';
import databases from './channels/lab/database';
import sftp from './channels/lab/sftp';
import storage from './channels/lab/storage';
import blockchain from './channels/lab/blockchain';
import securityRules from './securityRules';

const security_rules = securityRules.slice(0, 4);

const components = [
	APIs.soap_1,
	APIs.soap_2,
	APIs.soap_3,
	APIs.soap_4,
	APIs.soap_5,
	APIs.rest_1,
	APIs.rest_2,
	APIs.rest_3,
	APIs.rest_4,
	APIs.rest_5,
	APIs.rest_6,
	servers.proov_1,
	servers.proov_2,
	servers.proov_3,
	servers.proov_4,
	servers.proov_5,
	servers.proov_6,
	servers.proov_7,
	servers.proov_8,
	servers.proov_9,
	servers.proov_10,
	servers.user_1,
	servers.user_2,
	servers.user_3,
	...databases,
	...sftp,
	...storage,
	...blockchain
];

export const pilot = {
	id: '2c9f91cc581b679301582b31b3da00ef',
	company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
	user_id: 10,
	PoCType: 'Lab',
	created_at: '2079-01-24T04:21:34.002Z',
	updated_at: '2025-09-08T14:30:32.826Z',
	name: 'Adaptive Security Technology',
	status: 'active',
	is_public: false,
	description:
		'<p style="text-align:center;">Amapap ukpib jehimpug veswo wekeche obazub govablot rur ji casih gunelewor edjufco jidroun. Edaesu retuuk pus jaet fu janron mono rifzek cel cob wamgoh samlizco jutuviuna. Hotgu togfaen sewlunew tuziwpe wib bi kijha gaflum nobecpu ro afeon ollacdut. Giobiza oh heonacu aj uvgiwmej fizoctu ha wugsob nun sovas zaru lilfopa efojo kagoowu za mogonkef gobdaep.</p>',
	category: [
		'2c9f90d1582b308e01582b31558e02e9',
		category['2c9f90d1582b308e01582b31558e02e9']
	],
	country: ['Israel', 'Israel'],
	industry: client.industry,
	tags: ['information', 'technology', 'popular'],
	attachments_public: [],
	attachments_private: [],
	access_rights: 'full_access',
	region_policy: [
		{
			id: 'Japan',
			label: 'Japan',
			region: 'Asia'
		},
		{
			id: 'Jordan',
			label: 'Jordan',
			region: 'Middle East'
		}
	],
	instructions:
		'<p style="text-align:center;">This is instructi"ons,This is instructions,This is i"nstructions,This is instructions,This is instructions,This is instructions,This is instructions,This is instructions</p>↵',
	approval_policy: 'open',
	// start_time: '2018-05-03T12:00:00.000Z',
	// end_time: '2018-10-15T23:59:59.999Z',
	stages: {
		joining: {
			start_date: '2018-05-19T00:00:00.000Z',
			end_date: '2018-05-30T23:59:59.000Z'
		},
		preparation: {
			start_date: '2018-06-01T00:00:00.000Z',
			end_date: '2018-06-10T23:59:59.000Z'
		},
		execution: {
			start_date: '2018-06-11T00:00:00.000Z',
			end_date: '2018-07-25T23:59:59.000Z'
		},
		evaluation: {
			start_date: '2018-07-26T00:00:00.000Z',
			end_date: '2018-07-31T23:59:59.000Z'
		}
	},
	// last_join_time: '2018-10-15T21:20:00.793Z',
	max_vendors: 3,
	num_vendors: 0,
	nda: {
		id: '166f8a9ccec7e7972f30bbebc2bd6ff375bc546e',
		url: 'http://otinib.cu/jom',
		type: 'pdf',
		title: 'Jeorep wa meluce'
	},
	goals:
		'<p>Izais recuzbi mawe zi <b>favo hesicwep</b> su recus zuhom hezag ricit zus jofinpuv de.\nlines 2\nline3</p>',
	target_vendors: '<p style="text-align:center;">Biotech startups</p>',
	budget: ['up_to_50k', 'Up to $50,000'],
	eval_criteria: [
		'Data-oriented',
		'Innovative',
		'Low cost',
		'Self-explanatory'
	],
	approval_policy_desc: null,
	scenarios: '<p style="text-align:center;">This is the scenario field</p>',
	technology: ['Windows', 'Linux', 'Database', 'API'],
	tech_contact_name: 'Louise Griffin',
	tech_contact_email: 'mav@lek.tw',
	tech_contact_phone: {
		label: '+(092) 8610355',
		country_code: 'AF',
		phone_number: '8610355'
	},
	environment: components,
	security_rules,
	// joinable: 'open',
	joinable: joinableStatus.FREE,
	vendors: participants.reduce((acc, { id, name, profile_image }) => {
		acc.push({
			...acc,
			id: id,
			name: name,
			profile_image: profile_image
		});
		return acc;
	}, []),
	requests: [
		{
			..._pick(request, ['id', 'created_at', 'message', 'status']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		},
		{
			id: 'w9u4509wurtwuetwrt9u',
			message: 'this is a message.',
			status: 'denied',
			..._pick(request, ['created_at']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		},
		{
			id: 'w9u4509wurtwudfaawrt9u',
			message: null,
			status: 'PENDING',
			..._pick(request, ['created_at']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		},
		{
			id: 'w9u4509w555uetwrt9u',
			message: 'this is a message.',
			status: 'denied',
			..._pick(request, ['created_at']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		}
	],
	invitations: [
		{
			id: 'w9u4509wurtwuetwrt9u',
			message: 'this is a message.',
			..._pick(request, ['created_at']),
			to_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			]),
			is_joined: false
		},
		{
			id: 'w9u4509wurtwudfaawrt9u',
			message: null,
			..._pick(request, ['created_at']),
			to_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			]),
			is_joined: true
		},
		{
			id: 'w9u4509w555uetwrt9u',
			message: 'this is a message.',
			..._pick(request, ['created_at']),
			to_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			]),
			is_joined: true
		}
	],
	related: [
		{
			id: '4f2677730629f9791c3dd38c9d6d072f5f1fbaf2',
			name: 'Smart Cities: New urban innovations',
			company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
			category: [
				'2c9f90d1582b308e01582b31558e02e9',
				category['2c9f90d1582b308e01582b31558e02e9']
			],
			country: ['Andorra', 'Andorra'],
			industry: client.industry
		},
		{
			id: '4f2677730629f9791c3dd38c9d6d072f5f1fbaf2',
			name: 'Smart Cities: New urban innovations',
			company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
			category: [
				'2c9f90d1582b308e01582b31558e02e9',
				category['2c9f90d1582b308e01582b31558e02e9']
			],
			country: ['Andorra', 'Andorra'],
			industry: client.industry
		}
	],
	version: 1
};

export default pilot;
