export const activity = {
	'1f406f46f3a62396daca869754e1e9b02a93a776': { //1
		'name': 'channel_id1 1',
		'status': 'active',
		'host': '192.168.255.1',
		'targets': [
			{ 'host': '192.168.255.2', 'protocols': ['tcp', 'udp', 'http'] }
		],
		'activity': {
			'bytesSent': [
				{
					'timestamp': '2018-06-28T12:18:20Z',
					'value': 10
				}
			]
		}
	},
	'1f406f46f3a62396daca869754e1e9b02a93a777': {//2
		'name': '2353425',
		'status': 'active',
		'host': '192.168.255.2',
		'targets': [
			{ 'host': '192.168.255.1', 'protocols': ['tcp', 'udp'] },
			{ 'host': '192.168.255.3', 'protocols': ['tcp', 'udp'] },
			{ 'host': '192.168.255.4', 'protocols': ['tcp', 'udp'] }
		],
		'activity': {
			'bytesSent': [
				{
					'timestamp': '2018-06-28T12:18:20Z',
					'value': 20
				}
			]
		}
	},
	'1f406f46f3a62396daca869754e1e9b02a93a778': {//3
		'name': 'server 3',
		'status': 'active',
		'host': '192.168.255.3',
		'targets': [],
		'activity': {
			'bytesSent': [
				{
					'timestamp': '2018-06-28T12:18:20Z',
					'value': 20
				}
			]
		}
	},
	'1f406f46f3a62396daca869754e1e9b02a93a779': {//4
		'name': 'server 4',
		'status': 'active',
		'host': '192.168.255.4',
		'targets': [],
		'activity': {
			'bytesSent': [
				{
					'timestamp': '2018-06-28T12:18:20Z',
					'value': 20
				}
			]
		}
	},
	'1f406f46f3a62396daca869754e1e9b02a93a783': { //5
		'name': 'server 4',
		'status': 'active',
		'host': '192.168.255.5',
		'targets': [
			{ 'host': '192.168.255.4', 'protocols': ['tcp', 'udp'] }
		],
		'activity': {
			'bytesSent': [
				{
					'timestamp': '2018-06-28T12:18:20Z',
					'value': 20
				}
			]
		}
	},
	'1f406f46f3a62396daca869754e1e9b02a93a784': { //6
		'name': 'server 4',
		'status': 'active',
		'host': '192.168.255.6',
		'targets': [
			{ 'host': '192.168.255.5', 'protocols': ['tcp', 'udp'] }
		],
		'activity': {
			'bytesSent': [
				{
					'timestamp': '2018-06-28T12:18:20Z',
					'value': 20
				}
			]
		}
	},
	// '1f406f46f3a62396daca869754e1e9b02a93a785': {
	// 	'name': 'server 4',
	// 	'status': 'active',
	// 	'host': '192.168.255.255',
	// 	'targets': ['1f406f46f3a62396daca869754e1e9b02a93a777', '1f406f46f3a62396daca869754e1e9b02a93a776'],
	// 	'activity': {
	// 		'bytesSent': [
	// 			{
	// 				'timestamp': '2018-06-28T12:18:20Z',
	// 				'value': 20
	// 			}
	// 		]
	// 	}
	// },
	// '1f406f46f3a62396daca869754e1e9b02a93a786': {
	// 	'name': 'server 4',
	// 	'status': 'active',
	// 	'host': '192.168.255.255',
	// 	'targets': ['1f406f46f3a62396daca869754e1e9b02a93a777', '1f406f46f3a62396daca869754e1e9b02a93a776'],
	// 	'activity': {
	// 		'bytesSent': [
	// 			{
	// 				'timestamp': '2018-06-28T12:18:20Z',
	// 				'value': 20
	// 			}
	// 		]
	// 	}
	// },
	// '1f406f46f3a62396daca869754e1e9b02a93a787': {
	// 	'name': 'server 4',
	// 	'status': 'active',
	// 	'host': '192.168.255.255',
	// 	'targets': ['1f406f46f3a62396daca869754e1e9b02a93a777', '1f406f46f3a62396daca869754e1e9b02a93a776'],
	// 	'activity': {
	// 		'bytesSent': [
	// 			{
	// 				'timestamp': '2018-06-28T12:18:20Z',
	// 				'value': 20
	// 			}
	// 		]
	// 	}
	// }
};
