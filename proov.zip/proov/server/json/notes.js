export default [
	{
		id: 1,
		title: 'Environment updated',
		description: 'Just want to let you know that i have updated the environment',
		author: 'John Doe',
		date_created: '2018-04-23T14:07:20.468Z',
	},
	{
		id: 2,
		title: 'Approved new vendors',
		description: 'I approved 2 new vendors to take part in this pilot',
		author: 'John Doe',
		date_created: '2018-05-23T14:07:20.468Z',
	},
	{
		id: 3,
		title: 'Test',
		description: 'This is a test note',
		author: 'John Doe',
		date_created: '2018-05-23T14:07:20.468Z',
	}
];
