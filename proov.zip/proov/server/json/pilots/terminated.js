/* eslint-disable import/no-commonjs, camelcase */
import uuid from 'uuid';
import _pick from 'lodash/pick';
import { client, vendor } from '../company';
import { category } from '../common';
import request from '../pilotJoinRequest';
import {
	API,
	server,
	database,
	sftp,
	storage,
	blockchain,
	docker
} from '../channels/lab';
import securityRules from '../securityRules';
import * as joinableStatus from '../pilotJoinableStatus';

const security_rules = securityRules.slice(0, 4);

export default {
	id: uuid(),
	company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
	user_id: 10,
	created_at: '2079-01-24T04:21:34.002Z',
	updated_at: '2025-09-08T14:30:32.826Z',
	name: 'prooV Terminated',
	pilot_type: 'lab',
	status: 'terminated',
	is_public: false,
	description:
		'<p style="text-align:center;">Amapap ukpib jehimpug veswo wekeche obazub govablot rur ji casih gunelewor edjufco jidroun. Edaesu retuuk pus jaet fu janron mono rifzek cel cob wamgoh samlizco jutuviuna. Hotgu togfaen sewlunew tuziwpe wib bi kijha gaflum nobecpu ro afeon ollacdut. Giobiza oh heonacu aj uvgiwmej fizoctu ha wugsob nun sovas zaru lilfopa efojo kagoowu za mogonkef gobdaep.</p>',
	category: [
		'2c9f90d1582b308e01582b31558e02e9',
		category['2c9f90d1582b308e01582b31558e02e9']
	],
	country: ['Israel', 'Israel'],
	industry: client.industry,
	tags: ['information', 'technology', 'popular'],
	attachments_public: [],
	attachments_private: [],
	region_policy: [
		{
			id: 'Japan',
			label: 'Japan',
			region: 'Asia'
		},
		{
			id: 'Jordan',
			label: 'Jordan',
			region: 'Middle East'
		}
	],
	instructions:
		'<p style="text-align:center;">This is instructi"ons,This is instructions,This is i"nstructions,This is instructions,This is instructions,This is instructions,This is instructions,This is instructions</p>↵',
	approval_policy: 'open',
	stages: {
		joining: {
			start_date: '2018-05-19T00:00:00.000Z',
			end_date: '2018-05-30T23:59:59.000Z'
		},
		preparation: {
			start_date: '2018-06-01T00:00:00.000Z',
			end_date: '2018-06-10T23:59:59.000Z'
		},
		execution: {
			start_date: '2018-06-11T00:00:00.000Z',
			end_date: '2018-07-25T23:59:59.000Z'
		},
		evaluation: {
			start_date: '2018-07-26T00:00:00.000Z',
			end_date: '2018-07-31T23:59:59.000Z'
		}
	},
	max_vendors: 3,
	num_vendors: 3,
	nda: {
		id: '166f8a9ccec7e7972f30bbebc2bd6ff375bc546e',
		url: 'http://otinib.cu/jom',
		type: 'pdf',
		title: 'Jeorep wa meluce'
	},
	goals:
		'<p>Izais recuzbi mawe zi <b>favo hesicwep</b> su recus zuhom hezag ricit zus jofinpuv de.\nlines 2\nline3</p>',
	target_vendors: '<p style="text-align:center;">Biotech startups</p>',
	budget: ['up_to_50k', 'Up to $50,000'],
	eval_criteria: ['Data-oriented', 'Innovative', 'Low cost', 'Self-explanatory'],
	approval_policy_desc: null,
	scenarios: '<p style="text-align:center;">This is the scenario field</p>',
	technology: ['Windows', 'Linux', 'Database', 'API'],
	tech_contact_name: 'Louise Griffin',
	tech_contact_email: 'mav@lek.tw',
	tech_contact_phone: {
		label: '+(092) 8610355',
		country_code: 'AF',
		phone_number: '8610355'
	},
	environment: [
		...API,
		...server,
		...database,
		...sftp,
		...storage,
		...blockchain,
		...docker
	],
	security_rules,
	joinable: joinableStatus.FREE,
	vendors: [
		{
			id: '1',
			name: 'Boston Robotics',
			profile_image: `/res/avatar/b2cd961e13904dae9617f3955534657b`
		},
		{
			id: '2',
			name: 'TailorMed',
			profile_image: '/res/avatar/29cbfdb50d7342bca19715e898639ecb'
		},
		{
			id: '3',
			name: 'Innovate',
			profile_image: '/res/avatar/35947547175645838f775c0d6dccd117'
		}
	],
	requests: [
		{
			..._pick(request, ['id', 'created_at', 'message', 'status']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		},
		{
			id: 'w9u4509wurtwuetwrt9u',
			message: 'this is a message.',
			status: 'denied',
			..._pick(request, ['created_at']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		},
		{
			id: 'w9u4509wurtwudfaawrt9u',
			message: null,
			status: 'PENDING',
			..._pick(request, ['created_at']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		},
		{
			id: 'w9u4509w555uetwrt9u',
			message: 'this is a message.',
			status: 'denied',
			..._pick(request, ['created_at']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		}
	],
	invitations: [
		{
			id: 'w9u4509wurtwuetwrt9u',
			message: 'this is a message.',
			..._pick(request, ['created_at']),
			to_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			]),
			is_joined: false
		},
		{
			id: 'w9u4509wurtwudfaawrt9u',
			message: null,
			..._pick(request, ['created_at']),
			to_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			]),
			is_joined: true
		},
		{
			id: 'w9u4509w555uetwrt9u',
			message: 'this is a message.',
			..._pick(request, ['created_at']),
			to_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			]),
			is_joined: true
		}
	],
	related: [
		{
			id: '4f2677730629f9791c3dd38c9d6d072f5f1fbaf2',
			name: 'Smart Cities: New urban innovations',
			company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
			category: [
				'2c9f90d1582b308e01582b31558e02e9',
				category['2c9f90d1582b308e01582b31558e02e9']
			],
			country: ['Andorra', 'Andorra'],
			industry: client.industry
		},
		{
			id: '4f2677730629f9791c3dd38c9d6d072f5f1fbaf2',
			name: 'Smart Cities: New urban innovations',
			company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
			category: [
				'2c9f90d1582b308e01582b31558e02e9',
				category['2c9f90d1582b308e01582b31558e02e9']
			],
			country: ['Andorra', 'Andorra'],
			industry: client.industry
		}
	],
	version: 1
};
