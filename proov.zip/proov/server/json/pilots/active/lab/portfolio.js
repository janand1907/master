export default {
	portfolio_name: 'Portfolio',
	vpc_config: [
		{
			value: 'vpc-048499244b5096514',
			label: 'VPC ID',
		},
		{
			value: '13.10.0.0/16',
			label: 'VPC CIDR',
		},
		{
			value: ['sg-04b70c6a3ce2d08ce'],
			label: 'Security Group IDs',
		},
		{
			value: 'subnet-0f2a53cb9ea410ed6',
			label: 'Subnet ID',
		},
		{
			value: null,
			label: 'Subnet CIDR',
		},
		{
			value: '435515967074',
			label: 'AWS Account ID',
		},
		{
			value: null,
			label: 'Key Name',
		},
	],
	products: {
		'XNM-12FBN34DID': {
			name: 'test-product-v1',
			owner: 'demo@proov.io',
			description: 'Description AWS Service catalog template',
			status: 'config',
			artifactId: 'pa-atls5bijxigqy',
			createdTime: 'Sep 16, 2019 6:59:49 PM',
			parameters: {
				NetworkStack: {
					Default: 'NetworkStack',
					Type: 'String',
					NoEcho: false,
					Description:
						'Name of an active CloudFormation stack that contains the networking resources, such as the subnet and security group, that will be used in this stack.',
					AllowedValues: [],
					isDefault: false,
				},
				CIDR: {
					Type: 'String',
					NoEcho: false,
					Description: 'Please provide CIDR',
					AllowedValues: [],
					isDefault: false,
				},
				InstanceSize: {
					Default: 't2.micro',
					Type: 'String',
					NoEcho: false,
					Description: 'Windows Instance type',
					AllowedValues: ['t2.micro', 't2.small'],
					isDefault: false,
				},
				DBInstanceSize: {
					Default: 'db.t2.micro',
					Type: 'String',
					NoEcho: false,
					AllowedValues: ['db.t2.micro', 'db.t2.small'],
					isDefault: false,
				},
				SubnetName: {
					Default: 'Standart subnet',
					Type: 'String',
					NoEcho: false,
					AllowedValues: [],
					isDefault: false,
				},
				DBPassword: {
					Default: 'DefaultPassword',
					type: 'String',
					NoEcho: false,
					AllowedValues: [],
					isDefault: false,
				},
				DynamoDBTableName: {
					Default: 'ExampleTable',
					Type: 'String',
					NoEcho: false,
					Description: 'Name of the new table',
					AllowedValues: [],
					isDefault: false,
				},
				DefaultVpcSecurityGroup: {
					Default: 'sg-0b0524a53df10327f',
					Type: 'String',
					NoEcho: false,
					AllowedValues: [],
					isDefault: false,
				},
			},
		},
	},
};
