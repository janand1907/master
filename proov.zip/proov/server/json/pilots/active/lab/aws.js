/* eslint-disable import/no-commonjs, camelcase */
import uuid from 'uuid';
import { pick, flattenDepth } from 'lodash';
import { client, vendor } from '../../../company';
import { category } from '../../../common';
import request from '../../../pilotJoinRequest';
import securityRules from '../../../securityRules';
import * as joinableStatus from '../../../pilotJoinableStatus';
import * as aws_environment from '../../../../json/channels/aws';
import portfolio from '../../../../json/pilots/active/lab/portfolio';

const security_rules = securityRules.slice(0, 4);

export default {
	id: uuid(),
	company: pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
	user_id: 10,
	name: 'AWS Service Catalog',
	pilot_type: 'aws_sc',
	status: 'deployment',
	is_public: false,
	description:
		'<p style="text-align:center;">Amapap ukpib jehimpug veswo wekeche obazub govablot rur ji casih gunelewor edjufco jidroun. Edaesu retuuk pus jaet fu janron mono rifzek cel cob wamgoh samlizco jutuviuna. Hotgu togfaen sewlunew tuziwpe wib bi kijha gaflum nobecpu ro afeon ollacdut. Giobiza oh heonacu aj uvgiwmej fizoctu ha wugsob nun sovas zaru lilfopa efojo kagoowu za mogonkef gobdaep.</p>',
	category: [
		'2c9f90d1582b308e01582b31558e02e9',
		category['2c9f90d1582b308e01582b31558e02e9'],
	],
	country: ['Israel', 'Israel'],
	industry: client.industry,
	tags: ['information', 'technology', 'popular'],
	attachments_public: [],
	attachments_private: [],
	region_policy: [
		{
			id: 'Japan',
			label: 'Japan',
			region: 'Asia',
		},
		{
			id: 'Jordan',
			label: 'Jordan',
			region: 'Middle East',
		},
	],
	instructions:
		'<p style="text-align:center;">This is instructi"ons,This is instructions,This is i"nstructions,This is instructions,This is instructions,This is instructions,This is instructions,This is instructions</p>↵',
	approval_policy: 'open',
	created_at: '2016-01-01T00:00:00.000Z',
	start_time: '2019-01-01T00:00:00.000Z',
	updated_at: '2019-01-01T00:00:00.000Z',
	end_time: '3000-01-01T00:00:00.000Z',
	stages: {
		joining: {
			start_date: '2016-01-01T00:00:00.000Z',
			end_date: '2018-01-01T00:00:00.000Z',
		},
		preparation: {
			start_date: '2018-01-01T00:00:00.000Z',
			end_date: '2019-01-01T00:00:00.000Z',
		},
		execution: {
			start_date: '2019-01-01T00:00:00.000Z',
			end_date: '2020-01-01T00:00:00.000Z',
		},
		evaluation: {
			start_date: '2020-01-01T00:00:00.000Z',
			end_date: '2021-01-01T00:00:00.000Z',
		},
	},
	max_vendors: 3,
	num_vendors: 3,
	nda: {
		id: uuid(),
		url: 'http://otinib.cu/jom',
		type: 'pdf',
		title: 'Jeorep wa meluce',
	},
	goals:
		'<p>Izais recuzbi mawe zi <b>favo hesicwep</b> su recus zuhom hezag ricit zus jofinpuv de.\nlines 2\nline3</p>',
	target_vendors: '<p style="text-align:center;">Biotech startups</p>',
	budget: ['up_to_50k', 'Up to $50,000'],
	eval_criteria: [
		'Data-oriented',
		'Innovative',
		'Low cost',
		'Self-explanatory',
	],
	approval_policy_desc: null,
	scenarios: '<p style="text-align:center;">This is the scenario field</p>',
	technology: ['Windows', 'Linux', 'Database', 'API'],
	tech_contact_name: 'Louise Griffin',
	tech_contact_email: 'mav@lek.tw',
	tech_contact_phone: {
		label: '+(092) 8610355',
		country_code: 'AF',
		phone_number: '8610355',
	},
	environment: [...flattenDepth(Object.values(aws_environment), 1)],
	environment_params: portfolio,
	security_rules,
	joinable: joinableStatus.FREE,
	vendors: [
		{
			id: '1',
			name: 'Boston Robotics',
			profile_image: `/res/avatar/b2cd961e13904dae9617f3955534657b`,
		},
		{
			id: '2',
			name: 'TailorMed',
			profile_image: '/res/avatar/29cbfdb50d7342bca19715e898639ecb',
		},
		{
			id: '3',
			name: 'Innovate',
			profile_image: '/res/avatar/35947547175645838f775c0d6dccd117',
		},
	],
	requests: [
		{
			...pick(request, ['id', 'created_at', 'message', 'status']),
			from_company: pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country',
			]),
		},
		{
			id: uuid(),
			message: 'this is a message.',
			status: 'denied',
			...pick(request, ['created_at']),
			from_company: pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country',
			]),
		},
		{
			id: uuid(),
			message: null,
			status: 'PENDING',
			...pick(request, ['created_at']),
			from_company: pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country',
			]),
		},
	],
	invitations: [
		{
			id: uuid(),
			message: 'this is a message.',
			...pick(request, ['created_at']),
			to_company: pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country',
			]),
			is_joined: false,
		},
		{
			id: uuid(),
			message: null,
			...pick(request, ['created_at']),
			to_company: pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country',
			]),
			is_joined: true,
		},
	],
	related: [
		{
			id: uuid(),
			name: 'Smart Cities: New urban innovations',
			company: pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
			category: [
				'2c9f90d1582b308e01582b31558e02e9',
				category['2c9f90d1582b308e01582b31558e02e9'],
			],
			country: ['Andorra', 'Andorra'],
			industry: client.industry,
		},
		{
			id: uuid(),
			name: 'Smart Cities: New urban innovations',
			company: pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
			category: [
				'2c9f90d1582b308e01582b31558e02e9',
				category['2c9f90d1582b308e01582b31558e02e9'],
			],
			country: ['Andorra', 'Andorra'],
			industry: client.industry,
		},
	],
	version: 1,
};
