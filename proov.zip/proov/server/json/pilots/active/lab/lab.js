/* eslint-disable import/no-commonjs, camelcase */
import uuid from 'uuid';
import _pick from 'lodash/pick';
import { client, vendor, participants } from '../../../company';
import { category } from '../../../common';
import request from '../../../pilotJoinRequest';
import {
	API,
	server,
	database,
	sftp,
	storage,
	blockchain,
	docker
} from '../../../channels/lab';
import securityRules from '../../../securityRules';
import * as joinableStatus from '../../../pilotJoinableStatus';

const security_rules = securityRules.slice(0, 4);

export default {
	id: uuid(),
	company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
	user_id: 10,
	name: 'Lab',
	pilot_type: 'lab',
	status: 'execution',
	is_public: false,
	description:
		'<p style="text-align:center;">Quisque sed leo risus. Donec suscipit ante eget porta gravida. Maecenas tincidunt ex vel ipsum facilisis sollicitudin.</p>',
	category: [
		'2c9f90d1582b308e01582b31558e02e9',
		category['2c9f90d1582b308e01582b31558e02e9']
	],
	country: ['Israel', 'Israel'],
	industry: client.industry,
	tags: ['information', 'technology', 'popular'],
	attachments_public: [],
	attachments_private: [],
	region_policy: [
		{
			id: 'Japan',
			label: 'Japan',
			region: 'Asia'
		},
		{
			id: 'Jordan',
			label: 'Jordan',
			region: 'Middle East'
		}
	],
	instructions:
		'<p style="text-align:center;">Nulla id cursus diam, eget ornare nisi. Maecenas ac tincidunt orci. Mauris in purus in justo pellentesque dictum. Aliquam sagittis lorem non turpis rhoncus euismod. Aenean ullamcorper purus mi, in viverra mauris cursus vitae. Nullam ac nunc ut elit ullamcorper elementum in eget dui. Aenean id tortor ultricies, luctus odio mollis, sollicitudin augue. Sed molestie posuere augue at fringilla. Suspendisse quis hendrerit nulla. Morbi eget venenatis elit. Nullam arcu nisi, eleifend vitae tempor ac, volutpat in nisi. Quisque iaculis diam ut mollis tincidunt. Phasellus vitae consectetur velit, et mollis velit. Suspendisse ac ipsum sed turpis varius feugiat. Suspendisse egestas pellentesque velit.</p>↵',
	approval_policy: 'open',
	created_at: '2016-01-01T00:00:00.000Z',
	start_time: '2019-01-01T00:00:00.000Z',
	updated_at: '2019-01-01T00:00:00.000Z',
	end_time: '3000-01-01T00:00:00.000Z',
	stages: {
		joining: {
			start_date: '2016-01-01T00:00:00.000Z',
			end_date: '2018-01-01T00:00:00.000Z'
		},
		preparation: {
			start_date: '2018-01-01T00:00:00.000Z',
			end_date: '2019-01-01T00:00:00.000Z'
		},
		execution: {
			start_date: '2019-01-01T00:00:00.000Z',
			end_date: '2020-01-01T00:00:00.000Z'
		},
		evaluation: {
			start_date: '2020-01-01T00:00:00.000Z',
			end_date: '2021-01-01T00:00:00.000Z'
		}
	},
	max_vendors: 3,
	num_vendors: 3,
	nda: {
		id: '166f8a9ccec7e7972f30bbebc2bd6ff375bc546e',
		url: 'http://otinib.cu/jom',
		type: 'pdf',
		title: 'Jeorep wa meluce'
	},
	goals:
		'<p>Izais recuzbi mawe zi <b>favo hesicwep</b> su recus zuhom hezag ricit zus jofinpuv de.\nlines 2\nline3</p>',
	target_vendors: '<p style="text-align:center;">Biotech startups</p>',
	budget: ['up_to_50k', 'Up to $50,000'],
	eval_criteria: ['Data-oriented', 'Innovative', 'Low cost', 'Self-explanatory'],
	approval_policy_desc: null,
	scenarios: '<p style="text-align:center;">This is the scenario field</p>',
	technology: ['Windows', 'Linux', 'Database', 'API'],
	tech_contact_name: 'Louise Griffin',
	tech_contact_email: 'mav@lek.tw',
	tech_contact_phone: {
		label: '+(092) 8610355',
		country_code: 'AF',
		phone_number: '8610355'
	},
	environment: [
		...API,
		...server,
		...database,
		...sftp,
		...storage,
		...blockchain,
		...docker
	],
	security_rules,
	joinable: joinableStatus.FREE,
	vendors: [_pick(participants[1], ['id', 'name', 'profile_image'])],
	requests: [
		{
			id: uuid(),
			message: 'this is a message.',
			status: 'denied',
			..._pick(request, ['created_at']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		},
		{
			id: uuid(),
			message: null,
			status: 'pending',
			..._pick(request, ['created_at']),
			from_company: _pick(vendor, [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			])
		}
	],
	invitations: [
		{
			id: uuid(),
			message: 'Pending vendor request confirmation',
			..._pick(request, ['created_at']),
			to_company: _pick(participants[0], [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			]),
			is_joined: false
		},
		{
			id: uuid(),
			message: null,
			..._pick(request, ['created_at']),
			to_company: _pick(participants[1], [
				'id',
				'name',
				'profile_image',
				'oneliner',
				'industry',
				'country'
			]),
			is_joined: true
		}
	],
	related: [
		{
			id: uuid(),
			name: 'Smart Cities: New urban innovations',
			company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
			category: [
				'2c9f90d1582b308e01582b31558e02e9',
				category['2c9f90d1582b308e01582b31558e02e9']
			],
			country: ['Andorra', 'Andorra'],
			industry: client.industry
		},
		{
			id: uuid(),
			name: 'Smart Cities: New urban innovations',
			company: _pick(client, ['id', 'name', 'type', 'profile_image', 'about']),
			category: [
				'2c9f90d1582b308e01582b31558e02e9',
				category['2c9f90d1582b308e01582b31558e02e9']
			],
			country: ['Andorra', 'Andorra'],
			industry: client.industry
		}
	],
	version: 1
};
