/* eslint-disable camelcase */

import { client, vendor } from './company';

export const vendorNotifications = [
	{
		id: 1001,
		company_id: vendor.id,
		created_at: '2016-07-22T00:00:00+00:00',
		type: 'pilot_env_changed',
		is_read: true,
		title: 'Pilot Environment changed',
		message: 'Pilot Environment changed message',
		image: '/assets_proov/images/notif_alert.png',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 895,
		company_id: vendor.id,
		created_at: '2016-03-21T00:00:00+00:00',
		type: 'pilot_period_changed',
		is_read: false,
		title: 'Pilot Period changed',
		message: 'Pilot Period changed message',
		image: '/assets_proov/images/notif_completed.png',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 896,
		company_id: vendor.id,
		created_at: '2016-03-20T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/assets_proov/images/notif_proov.png',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 897,
		company_id: vendor.id,
		created_at: '2016-03-19T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 901,
		company_id: vendor.id,
		created_at: '2016-03-18T00:00:00+00:00',
		type: 'pilot_period_changed',
		is_read: false,
		title: 'Pilot Period changed',
		message: 'Pilot Period changed message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 902,
		company_id: vendor.id,
		created_at: '2016-03-17T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 903,
		company_id: vendor.id,
		created_at: '2016-03-16T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 904,
		company_id: vendor.id,
		created_at: '2016-03-15T00:00:00+00:00',
		type: 'pilot_period_changed',
		is_read: false,
		title: 'Pilot Period changed',
		message: 'Pilot Period changed message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 905,
		company_id: vendor.id,
		created_at: '2016-03-14T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 906,
		company_id: vendor.id,
		created_at: '2016-03-13T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 907,
		company_id: vendor.id,
		created_at: '2016-03-12T00:00:00+00:00',
		type: 'pilot_period_changed',
		is_read: false,
		title: 'Pilot Period changed',
		message: 'Pilot Period changed message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 908,
		company_id: vendor.id,
		created_at: '2016-03-11T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 909,
		company_id: vendor.id,
		created_at: '2016-03-10T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 910,
		company_id: vendor.id,
		created_at: '2016-03-09T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 911,
		company_id: vendor.id,
		created_at: '2016-03-08T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 912,
		company_id: vendor.id,
		created_at: '2016-03-07T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 913,
		company_id: vendor.id,
		created_at: '2016-03-06T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 914,
		company_id: vendor.id,
		created_at: '2016-03-05T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 915,
		company_id: vendor.id,
		created_at: '2016-03-04T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 916,
		company_id: vendor.id,
		created_at: '2016-03-03T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 917,
		company_id: vendor.id,
		created_at: '2016-03-02T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 918,
		company_id: vendor.id,
		created_at: '2016-03-01T00:00:00+00:00',
		type: 'process_name_reminder',
		is_read: false,
		title: 'Process Name needs to be filled',
		message: 'Process Name needs to be filled message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 919,
		company_id: vendor.id,
		created_at: '2016-02-28T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 920,
		company_id: vendor.id,
		created_at: '2016-02-27T00:00:00+00:00',
		type: 'pilot_env_ready',
		is_read: false,
		title: 'Pilot Environment ready',
		message: 'Pilot Environment ready message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	},
	{
		id: 899,
		company_id: vendor.id,
		created_at: '2016-02-26T00:00:00+00:00',
		type: 'pilot_env_error',
		is_read: false,
		title: 'Something wrong with the environment',
		message: 'Something wrong with the environment message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: { 'Check what is wrong': '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2' }
	}
];

export const clientNotifications = [
	{
		id: 894,
		company_id: client.id,
		created_at: '2016-03-19T00:00:00+00:00',
		type: 'pilot_ended',
		is_read: false,
		title: 'Pilot ended',
		message: 'Pilot ended message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/a80f8e69fd7837b9f18dba1d6966d79ed31fc669'
	},
	{
		id: 900,
		company_id: client.id,
		created_at: '2016-03-18T00:00:00+00:00',
		type: 'pilot_env_error',
		is_read: false,
		title: 'Something wrong with the environment',
		message: 'Something wrong with the environment message',
		image: '/res/avatar/93f529bedc11afbb6e2ceafc65243680',
		cta: '/marketplace/pilot/4f2677730629f9791c3dd38c9d6d072f5f1fbaf2'
	}
];
