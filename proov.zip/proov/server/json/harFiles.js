import uniqid from 'uniqid';

const harFiles = [
	{
		id: uniqid(),
		file_name: 'har_file_1.har',
		date_created: new Date('1/25/2016'),
		status: 'ready',
		type: 'har',
		is_generated: true,
		size: 200
	},
	{
		id: uniqid(),
		file_name: 'har_file_1.har',
		date_created: new Date('1/25/2015'),
		status: 'in_progress',
		type: 'har',
		is_generated: false,
		size: 178
	},
	{
		id: uniqid(),
		file_name: 'har_file_1.har',
		date_created: new Date('1/25/2014'),
		status: 'ready',
		type: 'har',
		is_generated: false,
		size: 562
	},
	{
		id: uniqid(),
		file_name: 'har_file_4.har',
		date_created: new Date('1/25/2013'),
		status: 'uploading',
		type: 'har',
		is_generated: false,
		size: 300
	},
	{
		id: uniqid(),
		file_name: 'har_file_5.har',
		date_created: new Date('1/25/2012'),
		status: 'failed',
		type: 'har',
		is_generated: false,
		size: 562
	}
];

export default harFiles;
