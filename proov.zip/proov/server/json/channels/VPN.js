import uuid from 'uuid';

export default {
	// Q: Types of VPNs?
	// A: openvpn | hotspot | gadmin | shrewsoft | viscosity | vpnx | juniper
	vpn_1: {
		id: uuid(),
		status: 'ready',
		type: 'vpn',
		vpn_type: 'openvpn',
		name: 'VPN no. 1',
		ip_address: '159.72.201.9',
		port: 4032,
		username: 'go@zav.np',
		password: '&8A+Z?!&',
		version: 1
	}
};
