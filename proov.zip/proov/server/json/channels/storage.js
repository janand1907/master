import uuid from 'uuid';

export default [
	{
		id: uuid(),
		type: 'storage',
		name: 'S3 Route Proov',
		status: 'ready',
		is_user_owned: false,
		is_read_only: true,
		aws: {
			access_key: 'PNQV398YUT4M',
			secret_key: 'O3W847YNFTCOH3F',
			region: 'aws::huston-rockets:::james-harden',
			bucket_path: 'aws\\bucket\\for\\james-harden'
		},
		ip_address: '66.249.76.19',
		username: 'user2',
		password: 'HW9!8e7REI',
		port: 80,
		version: 1
	},
	{
		id: uuid(),
		type: 'storage',
		name: 'S3 Route Private',
		status: 'ready',
		is_user_owned: true,
		is_read_only: false,
		aws: {
			access_key: 'BODM9FRYU85',
			secret_key: 'BSDON5YNT40NTYV',
			region: 'aws::us-west::goldenstate-worriors-stephcurry',
			bucket_path: 'aws\\bucket\\for\\steph-curry'
		},
		ip_address: '66.249.76.19',
		username: 'user2',
		password: 'HW9!8e7REI',
		port: 80,
		version: 1
	},
	{
		id: uuid(),
		type: 'storage',
		name: 'S3 Route | aws fields null',
		status: 'ready',
		is_user_owned: false,
		is_read_only: false,
		aws: {
			access_key: null,
			secret_key: null,
			region: null,
			bucket_path: null
		},
		ip_address: '66.249.76.19',
		username: 'user2',
		password: 'HW9!8e7REI',
		port: 80,
		version: 1
	},
	{
		id: uuid(),
		type: 'storage',
		name: 'S3 Route | pending credentials',
		status: 'pending',
		is_user_owned: false,
		is_read_only: false,
		aws: {
			access_key: null,
			secret_key: null,
			region: null,
			bucket_path: null
		},
		ip_address: '66.249.76.19',
		username: 'user2',
		password: 'HW9!8e7REI',
		port: 80,
		version: 1
	}
];
