import uuid from 'uuid';
import servers from './servers';
// Q: What are User SOAP auth options?
// A: None and basic
//
export default {
	soap_1: {
		id: uuid(),
		name: 'User SOAP Auth Basic',
		is_dedicated: true,
		servers: [servers.proov_1, servers.proov_2, servers.proov_3],
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'deleted',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null,
		version: 1
	},
	soap_2: {
		id: uuid(),
		name: 'User SOAP | Auth None | URL',
		is_user_owned: true,
		is_dedicated: true,
		servers: [servers.proov_1, servers.proov_2],
		type: 'api',
		auth: {
			type: 'none'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: {
			label: 'Click for open',
			url:
				'http://chittagongit.com//images/check-image-icon/check-image-icon-5.jpg'
		},
		version: 1
	},
	soap_3: {
		id: uuid(),
		name: 'User SOAP | Auth None | Spec',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'none'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'soap',
		api_url: null,
		file_resource: 'http://kapob.nu/mi',
		version: 1
	},
	soap_4: {
		id: uuid(),
		name: 'SOAP API Pending',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'pending',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null,
		version: 1
	},
	soap_5: {
		id: uuid(),
		name: 'Proov SOAP API',
		is_user_owned: false,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null,
		version: 1
	},
	rest_1: {
		id: uuid(),
		name: 'RESTful API | oAuth2.0 | URL',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'oauth2.0',
			client_id: 'asdfjasdljfasdkjf',
			client_secret: '1912308409123890',
			grant_type: 'client_credentials',
			token_url: 'https://YOUR_AUTH0_DOMAIN/oauth2/token'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'rest',
		api_url: 'http://ti.si/wasle',
		file_resource: null,
		version: 1
	},
	rest_2: {
		id: uuid(),
		name: 'RESTful API | oAuth2.0 | Spec',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'oauth2.0',
			client_id: 'asdfjasdljfasdkjf',
			client_secret: '1912308409123890',
			grant_type: 'password',
			token_url: 'https://YOUR_AUTH0_DOMAIN/oauth2/token',
			username: 'hello',
			password: 'goodbye123'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'rest',
		api_url: null,
		file_resource: {
			label: 'prooV_swagger.json',
			url: 'http://jsonviewer.stack.hu/'
		},
		version: 1
	},
	rest_3: {
		id: uuid(),
		name: 'RESTful API no. 1',
		is_user_owned: true,
		type: 'api',
		auth: { type: 'none' },
		endpoints: ['/loan'],
		status: 'pending',
		api_type: 'rest',
		api_url: null,
		file_resource: {
			label: 'prooV_swagger.json',
			url: 'http://jsonviewer.stack.hu/'
		},
		version: 1
	},
	rest_4: {
		id: uuid(),
		name: 'RESTful API no. 1',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'rest',
		api_url: 'http://www.api.com',
		file_resource: null,
		version: 1
	},
	rest_5: {
		id: uuid(),
		name: 'RESTful API no. 1',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'pending',
		api_type: 'rest',
		api_url: 'http://www.api.com',
		file_resource: null,
		version: 1
	},
	rest_6: {
		id: uuid(),
		name: 'RESTful API no. 1',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'failed',
		api_type: 'rest',
		api_url: 'http://www.api.com',
		file_resource: null,
		version: 1
	}
};
