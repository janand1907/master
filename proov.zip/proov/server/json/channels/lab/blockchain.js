import uuid from 'uuid';
import { participants } from '../../company';

export default [
	{
		id: uuid(),
		type: 'blockchain',
		name: 'Ethereum [Basic]',
		status: 'ready',
		blockchain_type: 'ethereum',
		node_num: 50,
		init_balance: 10000,
		ip_address: '32.1.1.31',
		port: 80,
		account: 'account no. 1',
		password: 'HW9!8e7REI',
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		type: 'blockchain',
		name: 'Ethereum [Intermidiate]',
		status: 'ready',
		blockchain_type: 'ethereum',
		node_num: 20,
		init_balance: 12346,
		ip_address: '32.1.1.31',
		port: 80,
		account: 'account no. 2',
		password: 'HW9!8e7REI',
		isv_access: [],
		version: 1
	},
	{
		id: uuid(),
		type: 'blockchain',
		name: 'Ethereum [Pro]',
		status: 'ready',
		blockchain_type: 'ethereum',
		node_num: 2,
		init_balance: 654321,
		ip_address: '32.1.1.31',
		port: 80,
		account: 'account no. 3',
		password: 'HW9!8e7REI',
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		type: 'blockchain',
		name: 'Ethereum [Master]',
		status: 'ready',
		blockchain_type: 'ethereum',
		node_num: 8,
		init_balance: 10000,
		ip_address: '32.1.1.31',
		port: 80,
		account: 'account no. 4',
		password: 'HW9!8e7REI',
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	}
];
