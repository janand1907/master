import uuid from 'uuid';
import { participants } from '../../company';

export default [
	{
		id: uuid(),
		type: 'docker',
		name: 'prooV Docker Channel 1',
		status: 'ready',
		is_user_owned: false,
		is_dedicated: false,
		is_assingning_credentials: true,
		Entity: 't2.large',
		os: 'linux',
		aws_instance: 't2.large',
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: null,
		password_file: null,
		username: 'user2',
		password: 'HW9!8e7REI',
		processes_names: ['KNWD', 'knWD2'],
		credentials: [
			{
				username: 'alnas@proov.io',
				password: 'FHH234D',
				is_assgined: true,
				assignee: 'Foo vendor inc'
			},
			{
				username: 'wrnwes@proov.io',
				password: 'FHKF324mD',
				is_assgined: true,
				assignee: 'very very long long fooooooooo inc'
			}
		],
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		type: 'docker',
		name: 'prooV Docker Channel 2',
		status: 'pending',
		is_user_owned: false,
		is_dedicated: false,
		os: 'linux',
		aws_instance: 't2.large',
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: null,
		password_file: null,
		username: 'user2',
		password: 'HW9!8e7REI',
		processes_names: ['KNWD', 'knWD2'],
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 2
	},
	{
		id: uuid(),
		type: 'docker',
		name: 'prooV Docker Channel 3',
		status: 'failed',
		is_user_owned: false,
		is_dedicated: false,
		os: 'linux',
		aws_instance: 't2.large',
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: null,
		password_file: null,
		username: 'user2',
		password: 'HW9!8e7REI',
		processes_names: ['KNWD', 'knWD2'],
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 3
	}
];
