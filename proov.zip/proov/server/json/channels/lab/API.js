import uuid from 'uuid';
import { participants } from '../../company';

// Q: What are User SOAP auth options?
// A: None and basic
//
export default [
	{
		id: '5a94ae09-4a44-4cc5-9a00-0a498b323fbe', // used in dashboard
		name: 'User SOAP Auth Basic',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'deleted',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: {
			label: 'Click for open',
			url:
				'http://chittagongit.com//images/check-image-icon/check-image-icon-5.jpg'
		},
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		name: 'User SOAP | Auth None | URL',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'none'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null,
		isv_access: [],
		version: 1
	},
	{
		id: uuid(),
		name: 'User SOAP | Auth None | Spec',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'none'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'soap',
		api_url: null,
		file_resource: 'http://kapob.nu/mi',
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		name: 'SOAP API Pending',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'pending',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null,
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		name: 'Proov SOAP API',
		is_user_owned: false,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: null,
		isv_access: [],
		version: 1
	},
	{
		id: uuid(),
		name: 'RESTful API | oAuth2.0 | URL',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'oauth2.0',
			client_id: 'asdfjasdljfasdkjf',
			client_secret: '1912308409123890',
			grant_type: 'client_credentials',
			token_url: 'https://YOUR_AUTH0_DOMAIN/oauth2/token'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'rest',
		api_url: 'http://ti.si/wasle',
		file_resource: null,
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		name: 'RESTful API | oAuth2.0 | Spec',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'oauth2.0',
			client_id: 'asdfjasdljfasdkjf',
			client_secret: '1912308409123890',
			grant_type: 'password',
			token_url: 'https://YOUR_AUTH0_DOMAIN/oauth2/token',
			username: 'hello',
			password: 'goodbye123'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'rest',
		har_file_name: 'prooV.har',
		api_url: null,
		file_resource: {
			label: 'prooV_swagger.json',
			url: 'http://jsonviewer.stack.hu/'
		},
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		name: 'REST @ Database | prooV',
		is_user_owned: false,
		type: 'api',
		auth: { type: 'none' },
		endpoints: ['/loan'],
		status: 'pending',
		api_type: 'rest',
		api_url: null,
		file_resource: {
			label: 'prooV_swagger.json',
			url: 'http://jsonviewer.stack.hu/'
		},
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		name: 'REST | User Owned',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'ready',
		api_type: 'rest',
		api_url: 'http://www.api.com',
		file_resource: null,
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	{
		id: uuid(),
		name: 'RESTful API no. 1',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'pending',
		api_type: 'rest',
		har_file_name: 'prooV.har',
		api_url: 'http://www.api.com',
		file_resource: null,
		isv_access: [],
		version: 1
	},
	{
		id: uuid(),
		name: 'RESTful API no. 1',
		is_user_owned: true,
		type: 'api',
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		status: 'failed',
		api_type: 'rest',
		har_file_name: 'prooV.har',
		api_url: 'http://www.api.com',
		file_resource: null,
		isv_access: [],
		version: 1
	}
];
