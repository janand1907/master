import uuid from 'uuid';
import { participants } from '../../company';

export default [
	// Q: What type of DB proov provide?
	// A: mySQL, postgras

	// proov type postgres
	{
		id: '40bc69dc-e4e7-426c-af98-5b9d1815ca3e', // used in dashboard
		type: 'db',
		name: 'Proov DB | With Dataset deployed',
		status: 'ready',
		is_user_owned: false,
		is_pop: 'true',
		ip_address: '82.81.87.206',
		port: 80,
		username: 'username',
		password: '2$654645%$',
		db_name: 'Bob Sponge',
		db_type: 'postgres',
		dataset: {
			dataset_id: '1234',
			name: 'IoT Data',
			deployment_status: 'success'
		},
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},

	// proov type mysql
	{
		id: uuid(),
		type: 'db',
		name: 'Proov DB | No Dataset Deployed',
		status: 'ready',
		is_user_owned: false,
		ip_address: '82.81.87.206',
		port: 80,
		username: 'username',
		password: '2$654645%$',
		db_name: 'Bob Sponge',
		db_type: 'mysql',
		dataset: null,
		isv_access: [],
		version: 1
	},

	// proov type postgres | pending
	{
		id: uuid(),
		type: 'db',
		name: 'Proov DB | No Dataset Deployed',
		status: 'pending',
		is_user_owned: false,
		ip_address: '82.81.87.206',
		port: 80,
		username: 'username',
		password: '2$654645%$',
		db_name: 'Bob Sponge',
		db_type: 'mysql',
		dataset: null,
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},

	//USER Type: redshift
	{
		id: uuid(),
		type: 'db',
		name: 'My Redshift DB',
		status: 'ready',
		is_user_owned: true,
		db_type: 'postgres',
		ip_address: '218.183.46.210',
		port: 8080,
		username: 'administrator',
		password: '?%aqndJZ',
		db_name: 'proovrs',
		restrict_tables: false,
		dataset: {
			dataset_id: '1234',
			name: 'Finance Data',
			deployment_status: 'fail'
		},
		tables: [],
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	},
	//USER Type: bigquery
	{
		id: uuid(),
		type: 'db',
		name: 'My BigQuery DB',
		status: 'ready',
		is_user_owned: true,
		db_type: 'bigquery',
		ip_address: '1.161.187.17',
		port: 21,
		username: 'dude',
		password: null,
		credentials_file: 'http://www.credentials.json',
		credentials_file_name: 'credentials.json',
		db_name: 'project123',
		restrict_tables: false,
		tables: [],
		dataset: null,
		isv_access: [],
		version: 1
	},
	//USER Type: mysql
	{
		id: uuid(),
		type: 'db',
		name: 'User DB no. 1',
		status: 'ready',
		is_user_owned: true,
		is_assingning_credentials: true,
		db_type: 'mysql',
		ip_address: '1.161.187.17',
		port: 4005,
		username: 'eguwason',
		password: 'mh?GT#BD?T',
		db_name: 'TEST1',
		dataset: null,
		credentials: [
			{
				username: 'client@proov.io',
				password: '12341234',
				is_assgined: true,
				assignee: 'Foo vendor inc'
			},
			{
				username: 'boris+startup1@proov.io',
				password: 'Proov2016',
				assignee: null
			},
			{
				username: 'boris+sta11rtup1@proov.io',
				password: 'Proov2016',
				assignee: null
			},
			{
				username: 'vendor@proov.io',
				password: '12341234',
				is_assgined: true,
				assignee: 'fooo very very very long company name inc'
			},
			{ username: 'demo@proov.io', password: 'demo@proov.io1', assignee: null }
		],
		restrict_tables: true,
		tables: ['tblUser', 'tblAddress'],
		isv_access: participants.map(({ id }) => ({ id: id })),
		version: 1
	}
];
