import uuid from 'uuid';

export default [
	{
		id: uuid(),
		type: 'blockchain',
		name: 'Ethereum',
		status: 'ready',
		blockchain_type: 'ethereum',
		node_num: 20,
		init_balance: 12346,
		ip_address: '32.1.1.31',
		port: 80,
		account: 'account no. 2',
		password: 'HW9!8e7REI',
		version: 1
	}
];
