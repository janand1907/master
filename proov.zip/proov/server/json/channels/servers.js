import uuid from 'uuid';

export default {
	// Proov, RDC, READY, Password
	proov_1: {
		id: uuid(),
		type: 'server',
		name: "Proov's | RDC | READY | password",
		status: 'ready',
		is_user_owned: false,
		is_dedicated: true,
		os: 'windows',
		aws_instance: 't2.large',
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: null,
		password_file: null,
		username: 'user2',
		password: 'HW9!8e7REI',
		processes_names: ['KNWD', 'knWD2'],
		bm: {
			enabled: true,
			status: 'failed',
			DM_enabled: false,
			file_id: '123459',
			original_ips: '82.81.87.206'
		},
		version: 2
	},
	// Proov, RDC, PENDING, Password
	proov_2: {
		id: uuid(),
		type: 'server',
		name: "Proov's | RDC | PENDING | password",
		status: 'pending',
		is_user_owned: false,
		os: 'windows',
		aws_instance: 't2.large',
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: null,
		password_file: null,
		username: 'user2',
		password: 'HW9!8e7REI',
		processes_names: ['KNWD'],
		bm: {
			enabled: true,
			status: 'in_progress',
			DM_enabled: false,
			file_id: '123458',
			original_ips: '82.81.87.206'
		},
		version: 3
	},
	// Proov, SSH, READY, Password
	proov_3: {
		id: uuid(),
		type: 'server',
		name: "Proov's | SSH | READY | password",
		status: 'ready',
		is_user_owned: false,
		os: 'linux',
		aws_instance: 'm4.large',
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: 'pem.com',
		password_file: 'http://www.pem.com',
		username: 'user2',
		password: null,
		processes_names: ['KNWD', 'knWD2', 'knWD3'],
		version: 4
	},
	// Proov, SSH, PENDING, Password
	proov_4: {
		id: uuid(),
		type: 'server',
		name: "Proov's | SSH | PENDING | password",
		status: 'ready',
		is_user_owned: false,
		os: 'linux',
		aws_instance: null,
		ip_address: null,
		port: null,
		password_file_name: null,
		password_file: null,
		username: null,
		password: null,
		processes_names: null,
		version: 5
	},
	proov_5: {
		id: uuid(),
		type: 'server',
		name: "Proov's dedicated",
		status: 'ready',
		ip_address: '66.249.76.19',
		is_user_owned: false,
		processes_names: ['KNWD', 'knWD2', 'knWD3'],
		os: 'linux',
		version: 5,
		servers: [
			{
				customer_id: '1',
				id: '1',
				status: 'ready',
				aws_instance: 'm4.large',
				ip_address: '66.249.76.19',
				port: 21,
				password_file_name: 'pem.com',
				password_file: 'http://www.pem.com',
				username: 'user2',
				password: null
			},
			{
				customer_id: '2',
				id: '2',
				aws_instance: 'm4.large',
				ip_address: '66.249.76.20',
				port: 21,
				status: 'ready',
				password_file_name: 'pem2.com',
				password_file: 'http://www.pem2.com',
				username: 'user2',
				password: null
			}
		],
		bm: {
			enabled: true,
			status: 'active',
			DM_enabled: false,
			file_id: '123457',
			original_ips: '82.81.87.206, 82.81.87.122'
		}
	},
	proov_6: {
		id: uuid(),
		type: 'server',
		name: "Proov's | SSH | PENDING | password",
		status: 'ready',
		is_user_owned: false,
		os: 'linux',
		aws_instance: null,
		ip_address: '66.249.76.19',
		port: null,
		password_file_name: null,
		password_file: null,
		username: null,
		password: null,
		processes_names: null,
		version: 5
	},
	proov_7: {
		id: uuid(),
		type: 'server',
		name: "Proov's | SSH | PENDING | password",
		status: 'ready',
		is_user_owned: false,
		os: 'linux',
		aws_instance: null,
		ip_address: '66.249.76.19',
		port: null,
		password_file_name: null,
		password_file: null,
		username: null,
		password: null,
		processes_names: null,
		version: 5
	},
	proov_8: {
		id: uuid(),
		type: 'server',
		name: "Proov's | SSH | PENDING | password",
		status: 'ready',
		is_user_owned: false,
		os: 'linux',
		aws_instance: null,
		ip_address: '66.249.76.19',
		port: null,
		password_file_name: null,
		password_file: null,
		username: null,
		password: null,
		processes_names: null,
		version: 5
	},
	proov_9: {
		id: uuid(),
		type: 'server',
		name: "Proov's | SSH | PENDING | password",
		status: 'ready',
		is_user_owned: false,
		os: 'linux',
		aws_instance: null,
		ip_address: '66.249.76.19',
		port: null,
		password_file_name: null,
		password_file: null,
		username: null,
		password: null,
		processes_names: null,
		version: 5
	},
	proov_10: {
		id: uuid(),
		type: 'server',
		name: "Proov's | SSH | PENDING | password",
		status: 'ready',
		is_user_owned: false,
		os: 'linux',
		aws_instance: null,
		ip_address: '66.249.76.19',
		port: null,
		password_file_name: null,
		password_file: null,
		username: null,
		password: null,
		processes_names: null,
		version: 5
	},
	// User, SSH, READY, Password
	user_1: {
		id: uuid(),
		type: 'server',
		name: 'User | SSH, READY, password',
		status: 'ready',
		is_user_owned: true,
		is_assingning_credentials: true,
		os: 'linux',
		aws_instance: null,
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: null,
		password_file: null,
		username: 'user2',
		password: 'dsd%$^d]ds$',
		processes_names: ['KNWD', 'knWD2', 'knWD3'],
		credentials: [
			{
				username: 'client@proov.io',
				password: '12341234',
				is_assgined: true,
				assignee: 'Foo vendor inc'
			},
			{ username: 'boris+startup1@proov.io', password: 'Proov2016' },
			{ username: 'boris+startup1@proov.io', password: 'Proov2016' },
			{
				username: 'vendor@proov.io',
				password: '12341234',
				is_assgined: true,
				assignee: 'very very long long fooooooooo inc'
			},
			{ username: 'demo@proov.io', password: 'demo@proov.io1', assignee: null }
		],
		version: 6
	},
	// User, SSH, READY, PEM
	user_2: {
		id: uuid(),
		type: 'server',
		name: 'Proov server no. 1',
		status: 'ready',
		is_user_owned: true,
		is_assingning_credentials: false,
		os: 'linux',
		aws_instance: null,
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: 'my_pem',
		password_file: 'http://www.pem.com',
		username: 'user2',
		password: null,
		processes_names: ['KNWD', 'knWD2', 'knWD3'],
		version: 1
	},
	// User, SSH, PENDING, PEM
	user_3: {
		id: uuid(),
		ip_address: '1.1.1.1',
		type: 'server',
		status: 'ready',

		is_user_owned: true,
		os: 'linux',
		password_file:
			'https://stageapp.proov.io/startup/downloadPem/2c9f9be05c86dd7a015c86e2773b0003',
		port: 123,
		name: 'linux 2',
		password_file_name: '1234567.pem',
		username: 'user',
		password: null,
		version: 1
	}
};
