import uuid from 'uuid';

export default [
	{
		id: uuid(),
		status: 'ready',
		type: 'sftp',
		name: 'Storage Password',
		ip_address: '159.72.201.9',
		port: 4032,
		username: 'go@zav.np',
		password: '&8A+Z?!&',
		password_file: null,
		password_file_name: null,
		version: 1
	},
	{
		id: uuid(),
		status: 'ready',
		type: 'sftp',
		name: 'Storage Credential',
		ip_address: '159.72.201.9',
		port: 4032,
		username: 'go@zav.np',
		password: null,
		password_file: 'my storage',
		password_file_name: 'http://www.sotrage.com',
		version: 1
	}
];
