import uuid from 'uuid';

export default [
	{
		id: uuid(),
		type: 'aws_sns',
		status: 'ready',
		is_user_owned: true,
		product_id: 'XNM-12FBN34DID',
		arn: 'arn:aws:sns:us-west-2:021856343615:cf_topic',
		name: 'snsTopic',
		topic_display_name: '',
		version: 1
	}
];
