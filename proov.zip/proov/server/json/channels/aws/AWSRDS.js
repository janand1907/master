import uuid from 'uuid';

export default [
	{
		id: uuid(),
		type: 'aws_rds',
		status: 'ready',
		is_user_owned: true,
		product_id: 'XNM-12FBN34DID',
		url: 'sr8zg0k4g06c1g.cbq646tqfgcf.us-west-2.rds.amazonaws.com',
		port: 5432,
		username: 'dbUser',
		password: '',
		engine: 'postgres',
		instance_type: 'db.t2.micro',
		name: 'Default_Schema',
		version: 1
	}
];
