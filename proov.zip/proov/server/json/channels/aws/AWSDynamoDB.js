import uuid from 'uuid';

export default [
	{
		id: uuid(),
		type: 'aws_dynamo_db',
		status: 'ready',
		credentials: {},
		arn: 'arn:aws:dynamodb:us-west-2:021856343615:table/SomeTable',
		is_user_owned: true,
		product_id: 'XNM-12FBN34DID',
		primary_partition_key: [{ AttributeName: 'record_id', KeyType: 'HASH' }],
		name: 'SomeTable',
		version: 1
	}
];
