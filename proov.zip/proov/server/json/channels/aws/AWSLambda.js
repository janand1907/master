import uuid from 'uuid';

export default [
	{
		id: uuid(),
		type: 'aws_lambda',
		status: 'ready',
		is_user_owned: true,
		product_id: 'NVL-MOC678DNFI',
		arn: 'arn:aws:lambda:us-west-2:021856343615:function:TestLambda1',
		name: 'TestLambda1',
		version: 1
	}
];
