export AWSDynamoDB from './AWSDynamoDB';
export AWSSQS from './AWSSQS';
export AWSEC2 from './AWSEC2';
export AWSLambda from './AWSLambda';
export AWSRDS from './AWSRDS';
export AWSS3Bucket from './AWSS3Bucket';
export AWSSNS from './AWSSNS';
