import uuid from 'uuid';

export default [
	{
		id: uuid(),
		name: 'AWS EC2',
		type: 'aws_ec2',
		status: 'ready',
		is_user_owned: true,
		product_id: 'NVL-MOC678DNFI',
		username: 'ubuntu',
		instance_type: 't2.micro',
		password: '',
		port: 22,
		key_name: 'safeduard',
		public_ip: '34.10.2.256',
		private_ip: [
			{
				Primary: true,
				PrivateDnsName: 'ip-10-0-0-138.us-west-2.compute.internal',
				PrivateIpAddress: '10.0.0.138'
			}
		],
		version: 1
	}
];
