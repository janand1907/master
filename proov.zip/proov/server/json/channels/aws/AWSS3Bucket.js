import uuid from 'uuid';

export default [
	{
		id: uuid(),
		type: 'aws_s3',
		status: 'ready',
		is_user_owned: true,
		product_id: 'XNM-12FBN34DID',
		name: 's3-bucket-proov',
		is_public: true,
		version: 1
	}
];
