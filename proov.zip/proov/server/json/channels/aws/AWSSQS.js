import uuid from 'uuid';

export default [
	{
		id: uuid(),
		product_id: 'NVL-MOC678DNFI',
		type: 'aws_sqs',
		status: 'ready',
		is_user_owned: true,
		product_id: 'XNM-12FBN34DID',
		arn: 'arn:aws:sqs:us-west-2:021856343615:cf_queue',
		name: 'cf_queue',
		version: 1
	}
];
