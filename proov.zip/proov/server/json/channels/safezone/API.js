export default [
	{
		id: 'd967aa7492063499f22e401e2e8f7b80ca2abe1f',
		name: 'User SOAP Auth Basic',
		type: 'api',
		status: 'ready',
		target: {
			ip_address: '66.249.76.19',
			port: '22',
	    user: 'pokemon',
			password: '1234'
		},
		safe_zone: {
			ip_address: '82.81.87.206',
			active: true,
		},
		user_owned: {
			ip_address: 'https://petstore.swagger.io/v2',
			active: false,
		},
		auth: {
			type: 'basic',
			username: 'username',
			password: '2#$5fd5d'
		},
		endpoints: ['/loan'],
		api_type: 'soap',
		api_url: 'http://kapob.nu/mi',
		file_resource: {
			label: 'Click for open',
			url: 'http://chittagongit.com//images/check-image-icon/check-image-icon-5.jpg'
		},
		har_file_name: 'har_file.har',
		version: 1
	}
];
