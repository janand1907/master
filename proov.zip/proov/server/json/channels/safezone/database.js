export default [
	{
		id: '1f406f46f3a62396daca869754e1e9b02a93a776',
		type: 'db',
		db_type: 'postgres',
		db_name: 'Bob Sponge',

		name: 'Postgres',
		safe_zone: {
			ip_address: '82.81.87.206',
			port: 80,
			active: true
		},
		user_owned: {
			ip_address: '21.13.46.210',
			port: 8080
		},
		status: 'ready',
		restrict_tables: true,
		tables: ['tblUser', 'tblAddress'],
		is_assingning_credentials: true,
		isv_access: [],
		credentials: [
			{
				username: 'client@proov.io',
				password: '12341234',
				is_assgined: true,
				assignee: 'Foo vendor inc'
			},
			{ username: 'boris+startup1@proov.io', password: 'Proov2016' },
			{ username: 'boris+startup1@proov.io', password: 'Proov2016' },
			{
				username: 'vendor@proov.io',
				password: '12341234',
				is_assgined: true,
				assignee: 'very very long long fooooooooo inc'
			},
			{ username: 'demo@proov.io', password: 'demo@proov.io1', assignee: null }
		],
		version: 1
	},
	// proov type mysql
	{
		db_type: 'mysql',
		is_user_owned: true,
		credentials: [
			{
				username: 'proovuser1',
				password: 'proov1123',
				is_assgined: true,
				assignee: 'Tesla',
				password_file_name: null
			},
			{
				username: 'proovuser2',
				password: 'proov2123',
				is_assgined: false,
				assignee: null,
				password_file_name: null
			}
		],
		restrict_tables: false,
		ip_address: '35.160.176.143',
		type: 'db',
		password: 'proov123',
		tables: [],
		is_pop: true,
		is_dedicated: false,
		db_name: 'proovdb',
		port: 3306,
		name: 'MySQL',
		is_assingning_credentials: true,
		id: 'ff8081816d90f4c9016db3a9fad61062',
		dataset: null,
		status: 'ready',
		username: 'qa',
		isv_access: [
			{ id: '8a244a75bbb158a10b394888efa337500181bbf3' },
			{ id: '3' },
			{ id: '4' },
			{ id: '5' }
		],
		version: 1
	}
];
