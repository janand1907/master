export default [
	{
		id: '1f406f46f3a62396daca869754e1e9b02a93a476',
		type: 'server',
		name: 'Proov\'s | RDC | READY | password',
		status: 'ready',
		os: 'windows',
		ip_address: '66.249.76.19',
		port: 22,
		username: 'user2',
		password: 'HW9!8e7REI',
		password_file_name: null,
		password_file: null,
		processes_names: ['KNWD'],
		bm: {
			enabled: true,
			status: 'in_progress',
			DM_enabled: false,
			file_id: '123458',
			original_ips: '82.81.87.206'

		},
		isv_access: [],
		version: 1
	},
	// User, SSH, READY, Password
	{
		id: '1f406f46f3a62396daca869754e1e9b02a93a780',
		type: 'server',
		name: 'User | SSH, READY, password',
		status: 'ready',
		is_assingning_credentials: true,
		os: 'linux',
		aws_instance: null,
		ip_address: '66.249.76.19',
		port: 21,
		password_file_name: null,
		password_file: null,
		username: 'user2',
		password: 'dsd%$^d]ds$',
		processes_names: ['KNWD', 'knWD2', 'knWD3'],
		credentials: [{ 'username': 'client@proov.io', 'password': '12341234', 'is_assgined': true, 'assignee': 'Foo vendor inc' }, { 'username': 'boris+startup1@proov.io', 'password': 'Proov2016' }, { 'username': 'boris+startup1@proov.io', 'password': 'Proov2016' }, { 'username': 'vendor@proov.io', 'password': '12341234', 'is_assgined': true, 'assignee': 'very very long long fooooooooo inc' }, { 'username': 'demo@proov.io', 'password': 'demo@proov.io1', 'assignee': null }],
		version: 6
	},
	{
		id: '2c9f9be05c86dd7a0asgsdgf15c86e2773b0003',
		ip_address: '1.1.1.1',
		type: 'server',
		status: 'ready',
		is_user_owned: true,
		is_dedicated: false,
		os: 'linux',
		password_file:
			'https://stageapp.proov.io/startup/downloadPem/2c9f9be05c86dd7a015c86e2773b0003',
		port: 123,
		name: 'RD-5970: Linux User owned Option To Add pem File per Vendor',
		password_file_name: '1234567.pem',
		username: 'user',
		password: null,
		isv_access: [{ id: '4' }],
		is_assingning_credentials: true,
		credentials: [
			{
				username: 'client@proov.io',
				password_file_name: 'some.pem',
			},
			{
				username: 'vendor@proov.io',
				password_file_name: 'pimpam.pem',
			}
		],
		version: 1
	}
];
