export default {
	'eval_criteria':
		[
			'Vendor Demonstrations',
			'Has paying customers',
			'Low cpu usage',
			'Low memory usage'
		]
};
