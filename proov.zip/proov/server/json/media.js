/* eslint-disable camelcase */

export default {
	id: 'b4d37b4b98b7e66dc2b556adab55bc4c7821954c',
	created_at: '2062-01-02T05:23:52.549Z',
	updated_at: '2062-01-02T05:23:52.549Z',
	url: 'http://zazzewgu.vu/gom',
	format: 'pdf',
	resource_type: 'raw',
	title: 'Title of my file',
	version: 1
};
