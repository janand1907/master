/* eslint-disable camelcase */
import uuid from 'uuid';

export const enterprise = {
	id: '90f44900-501e-4d6e-ac7b-8dbf58f6610f',
	full_name: 'Elon Musk',
	email: 'enterprise@proov.io',
	profile_image: '/res/avatar/e5e64232ec7a424d8d3e9ae2e79b1f44?v=1234',
	company_id: 'beb285138f1249d2a71fb8424fd508a7',
	company_name: 'spaceX',
	first_name: 'Elon',
	last_name: 'Musk',
	company_type: 'client',
	companies: [
		{
			company_name: 'spaceX',
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			profile_image: '/res/avatar/e5e64232ec7a424d8d3e9ae2e79b1f44?v=1234'
		},
		{
			company_name: 'Tesla',
			company_id: '5e7e3e2fd6ef46268dc173726b4d9869',
			profile_image: '/res/avatar/5e7e3e2fd6ef46268dc173726b4d9869?v=1234'
		},
		{
			company_name: 'The Boring Company',
			company_id: '35947547175645838f775c0d6dccd117',
			profile_image: '/res/avatar/35947547175645838f775c0d6dccd117?v=1234'
		}
	],
	company_industry: ['41', 'Accounting'],
	auth_type: 'proov',
	role: 'owner',
	status: 'active'
};

export const startups = [
	{
		id: uuid(),
		first_name: 'Elon',
		last_name: 'Musk',
		email: 'startup@tesla.com',
		profile_image: '/res/avatar/5e7e3e2fd6ef46268dc173726b4d9869?v=1234',
		company_id: '5e7e3e2fd6ef46268dc173726b4d9869',
		company_name: 'Tesla',
		company_type: 'vendor',
		company_industry: ['41', 'Accounting'],
		auth_type: 'proov',
		role: 'admin',
		status: 'active'
	},
	{
		id: uuid(),
		first_name: 'Elon',
		last_name: 'Musk',
		email: 'startup@theboringcompany.io',
		profile_image: '/res/avatar/35947547175645838f775c0d6dccd117?v=1234',
		company_id: '35947547175645838f775c0d6dccd117',
		company_name: 'The Boring Company',
		company_type: 'vendor',
		company_industry: ['41', 'Accounting'],
		auth_type: 'proov',
		role: 'admin',
		status: 'active'
	}
];
