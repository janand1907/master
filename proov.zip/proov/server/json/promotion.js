/* eslint-disable import/no-commonjs, camelcase */

export default {
	id: '3ff19d0c09fc46cda6a4e6d431195c66',
	title: 'You have been noticed!',
	text: 'Your profile has been viewed by 9 startups!',
	cta: [ { 'View all': '/joinpilot/id/3' } ],
	image: '//www.gravatar.com/avatar/93f529bedc11afbb6e2ceafc65243680'
};

export const promotions = [
	{
		id: '3ff19d0c09fc46cda6a4e6d431195c66',
		title: 'You have been noticed!',
		text: 'Your profile has been viewed by 9 startups!',
		cta: [ { 'View all': '/joinpilot/id/3' } ],
		image: '//www.gravatar.com/avatar/93f529bedc11afbb6e2ceafc65243680'
	},
	{
		id: '3ff19dasdf78asd7f087adsf089asd7f',
		title: 'Your word has spread! ',
		text: 'Your invitation was read by X SU`s!',
		cta: [ { 'View all': '/joinpilot/id/3' } ],
		image: '//www.gravatar.com/avatar/93f529bedc11afbb6e2ceafc65243680'
	}
];
