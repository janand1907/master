/* eslint-disable camelcase */
import { client } from './company';

export default {
	id: '97493d48737f4356a7a8dcb553ab946a',
	to_company_id: client.id,
	created_at: '2016-09-17T03:04:04+00:00',
	is_paid: true,
	payment_id: 9004,
	message_id: 10542
};
