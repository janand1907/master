/* eslint-disable camelcase */
import Chance from 'chance';
import uuid from 'uuid';
import { meanBy, minBy, maxBy } from 'lodash';
import { pilot } from './pilot';

export const charts = [
	{
		id: uuid(),
		label: 'Chart name 1',
		metric_group_id: '0cd0940c-40ca-11e9-b210-d663bd873d93',
		channel_ids: [
			{ channel_id: '0cd097ae-40ca-11e9-b210-d663bd873d93', kpi_id: '123' },
			{ channel_id: '0cd097ae-40ca-11e9-b210-d663bd873d95', kpi_id: '345' }
		]
	},
	{
		id: '25fdcc52-40ca-11e9-b210-d663bd873d92',
		label: 'Chart name 2',
		metric_group_id: '4cd0940c-40ca-11e9-b210-d663bd873d94',
		channel_ids: [
			{ channel_id: '0cd097ae-40ca-11e9-b210-d663bd873d93', kpi_id: '123' },
			{ channel_id: '0cd097ae-40ca-11e9-b210-d663bd873d95', kpi_id: '345' }
		]
	}
];

export const standardParameters = [
	{
		id: '127455',
		name: 'x127455',
		label: 'HTTP Requests Per User',
		endpoint_label: 'GET /user/logout',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127451',
		name: 'x127451',
		label: 'Request Response Length',
		endpoint_label: 'GET /user/logout',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127439',
		name: 'x127439',
		label: 'HTTP Requests Per User',
		endpoint_label: 'POST /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127466',
		name: 'x127466',
		label: 'HTTP Requests Per User',
		endpoint_label: 'POST /user',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127393',
		name: 'x127393',
		label: 'Request Response Time',
		endpoint_label: 'POST /user/createWithList',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127471',
		name: 'x127471',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'PUT /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127394',
		name: 'x127394',
		label: 'Request Payload Size',
		endpoint_label: 'POST /user/createWithList',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127422',
		name: 'x127422',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'DELETE /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127474',
		name: 'x127474',
		label: 'Request Response Time',
		endpoint_label: 'POST /pet',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127433',
		name: 'x127433',
		label: 'HTTP Requests Per User',
		endpoint_label: 'GET /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127420',
		name: 'x127420',
		label: 'Request Response Time',
		endpoint_label: 'DELETE /user/{username}',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127418',
		name: 'x127418',
		label: 'HTTP Requests Per User',
		endpoint_label: 'PUT /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127472',
		name: 'x127472',
		label: 'HTTP Requests Per User',
		endpoint_label: 'PUT /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127403',
		name: 'x127403',
		label: 'Request Response Length',
		endpoint_label: 'GET /store/inventory',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127388',
		name: 'x127388',
		label: 'Request Payload Size',
		endpoint_label: 'POST /user/createWithArray',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127383',
		name: 'x127383',
		label: 'HTTP success responses',
		endpoint_label: 'DELETE /store/order/{orderId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127458',
		name: 'x127458',
		label: 'HTTP success responses',
		endpoint_label: 'GET /user/login',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127421',
		name: 'x127421',
		label: 'HTTP success responses',
		endpoint_label: 'DELETE /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127461',
		name: 'x127461',
		label: 'Request Response Length',
		endpoint_label: 'POST /user',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127373',
		name: 'x127373',
		label: 'HTTP success responses',
		endpoint_label: 'POST /pet/{petId}/uploadImage',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127408',
		name: 'x127408',
		label: 'Request Response Length',
		endpoint_label: 'GET /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127407',
		name: 'x127407',
		label: 'HTTP Requests Per User',
		endpoint_label: 'GET /store/inventory',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127470',
		name: 'x127470',
		label: 'HTTP success responses',
		endpoint_label: 'PUT /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127370',
		name: 'x127370',
		label: 'Request Response Length',
		endpoint_label: 'POST /pet/{petId}/uploadImage',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127416',
		name: 'x127416',
		label: 'HTTP success responses',
		endpoint_label: 'PUT /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127402',
		name: 'x127402',
		label: 'HTTP Requests Per User',
		endpoint_label: 'GET /pet/findByStatus',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127469',
		name: 'x127469',
		label: 'Request Payload Size',
		endpoint_label: 'PUT /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127419',
		name: 'x127419',
		label: 'Request Response Length',
		endpoint_label: 'DELETE /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127452',
		name: 'x127452',
		label: 'Request Response Time',
		endpoint_label: 'GET /user/logout',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127400',
		name: 'x127400',
		label: 'HTTP success responses',
		endpoint_label: 'GET /pet/findByStatus',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127385',
		name: 'x127385',
		label: 'HTTP Requests Per User',
		endpoint_label: 'DELETE /store/order/{orderId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127377',
		name: 'x127377',
		label: 'Request Response Time',
		endpoint_label: 'GET /store/order/{orderId}',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127463',
		name: 'x127463',
		label: 'Request Payload Size',
		endpoint_label: 'POST /user',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127448',
		name: 'x127448',
		label: 'HTTP success responses',
		endpoint_label: 'POST /store/order',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127473',
		name: 'x127473',
		label: 'Request Response Length',
		endpoint_label: 'POST /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127465',
		name: 'x127465',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'POST /user',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127428',
		name: 'x127428',
		label: 'HTTP Requests Per User',
		endpoint_label: 'GET /pet/findByTags',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127387',
		name: 'x127387',
		label: 'Request Response Time',
		endpoint_label: 'POST /user/createWithArray',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127429',
		name: 'x127429',
		label: 'Request Response Length',
		endpoint_label: 'GET /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127391',
		name: 'x127391',
		label: 'HTTP Requests Per User',
		endpoint_label: 'POST /user/createWithArray',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127376',
		name: 'x127376',
		label: 'Request Response Length',
		endpoint_label: 'GET /store/order/{orderId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127380',
		name: 'x127380',
		label: 'HTTP Requests Per User',
		endpoint_label: 'GET /store/order/{orderId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127372',
		name: 'x127372',
		label: 'Request Payload Size',
		endpoint_label: 'POST /pet/{petId}/uploadImage',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127374',
		name: 'x127374',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'POST /pet/{petId}/uploadImage',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127449',
		name: 'x127449',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'POST /store/order',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127405',
		name: 'x127405',
		label: 'HTTP success responses',
		endpoint_label: 'GET /store/inventory',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127423',
		name: 'x127423',
		label: 'HTTP Requests Per User',
		endpoint_label: 'DELETE /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127432',
		name: 'x127432',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'GET /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127453',
		name: 'x127453',
		label: 'HTTP success responses',
		endpoint_label: 'GET /user/logout',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127460',
		name: 'x127460',
		label: 'HTTP Requests Per User',
		endpoint_label: 'GET /user/login',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127411',
		name: 'x127411',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'GET /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127396',
		name: 'x127396',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'POST /user/createWithList',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127467',
		name: 'x127467',
		label: 'Request Response Length',
		endpoint_label: 'PUT /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127384',
		name: 'x127384',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'DELETE /store/order/{orderId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127478',
		name: 'x127478',
		label: 'HTTP Requests Per User',
		endpoint_label: 'POST /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127440',
		name: 'x127440',
		label: 'Request Response Length',
		endpoint_label: 'DELETE /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127413',
		name: 'x127413',
		label: 'Request Response Length',
		endpoint_label: 'PUT /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127381',
		name: 'x127381',
		label: 'Request Response Length',
		endpoint_label: 'DELETE /store/order/{orderId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127441',
		name: 'x127441',
		label: 'Request Response Time',
		endpoint_label: 'DELETE /pet/{petId}',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127477',
		name: 'x127477',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'POST /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127445',
		name: 'x127445',
		label: 'Request Response Length',
		endpoint_label: 'POST /store/order',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127456',
		name: 'x127456',
		label: 'Request Response Length',
		endpoint_label: 'GET /user/login',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127404',
		name: 'x127404',
		label: 'Request Response Time',
		endpoint_label: 'GET /store/inventory',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127438',
		name: 'x127438',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'POST /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127450',
		name: 'x127450',
		label: 'HTTP Requests Per User',
		endpoint_label: 'POST /store/order',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127410',
		name: 'x127410',
		label: 'HTTP success responses',
		endpoint_label: 'GET /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127382',
		name: 'x127382',
		label: 'Request Response Time',
		endpoint_label: 'DELETE /store/order/{orderId}',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127390',
		name: 'x127390',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'POST /user/createWithArray',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127386',
		name: 'x127386',
		label: 'Request Response Length',
		endpoint_label: 'POST /user/createWithArray',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127444',
		name: 'x127444',
		label: 'HTTP Requests Per User',
		endpoint_label: 'DELETE /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127417',
		name: 'x127417',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'PUT /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127406',
		name: 'x127406',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'GET /store/inventory',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127459',
		name: 'x127459',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'GET /user/login',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127389',
		name: 'x127389',
		label: 'HTTP success responses',
		endpoint_label: 'POST /user/createWithArray',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127437',
		name: 'x127437',
		label: 'HTTP success responses',
		endpoint_label: 'POST /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127430',
		name: 'x127430',
		label: 'Request Response Time',
		endpoint_label: 'GET /pet/{petId}',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127399',
		name: 'x127399',
		label: 'Request Response Time',
		endpoint_label: 'GET /pet/findByStatus',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127435',
		name: 'x127435',
		label: 'Request Response Time',
		endpoint_label: 'POST /pet/{petId}',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127415',
		name: 'x127415',
		label: 'Request Payload Size',
		endpoint_label: 'PUT /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127442',
		name: 'x127442',
		label: 'HTTP success responses',
		endpoint_label: 'DELETE /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127379',
		name: 'x127379',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'GET /store/order/{orderId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127414',
		name: 'x127414',
		label: 'Request Response Time',
		endpoint_label: 'PUT /user/{username}',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127475',
		name: 'x127475',
		label: 'Request Payload Size',
		endpoint_label: 'POST /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127464',
		name: 'x127464',
		label: 'HTTP success responses',
		endpoint_label: 'POST /user',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127454',
		name: 'x127454',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'GET /user/logout',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127426',
		name: 'x127426',
		label: 'HTTP success responses',
		endpoint_label: 'GET /pet/findByTags',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127371',
		name: 'x127371',
		label: 'Request Response Time',
		endpoint_label: 'POST /pet/{petId}/uploadImage',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127398',
		name: 'x127398',
		label: 'Request Response Length',
		endpoint_label: 'GET /pet/findByStatus',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127427',
		name: 'x127427',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'GET /pet/findByTags',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127409',
		name: 'x127409',
		label: 'Request Response Time',
		endpoint_label: 'GET /user/{username}',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127412',
		name: 'x127412',
		label: 'HTTP Requests Per User',
		endpoint_label: 'GET /user/{username}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127476',
		name: 'x127476',
		label: 'HTTP success responses',
		endpoint_label: 'POST /pet',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127431',
		name: 'x127431',
		label: 'HTTP success responses',
		endpoint_label: 'GET /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127446',
		name: 'x127446',
		label: 'Request Response Time',
		endpoint_label: 'POST /store/order',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127447',
		name: 'x127447',
		label: 'Request Payload Size',
		endpoint_label: 'POST /store/order',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127392',
		name: 'x127392',
		label: 'Request Response Length',
		endpoint_label: 'POST /user/createWithList',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127457',
		name: 'x127457',
		label: 'Request Response Time',
		endpoint_label: 'GET /user/login',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127468',
		name: 'x127468',
		label: 'Request Response Time',
		endpoint_label: 'PUT /pet',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127443',
		name: 'x127443',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'DELETE /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127375',
		name: 'x127375',
		label: 'HTTP Requests Per User',
		endpoint_label: 'POST /pet/{petId}/uploadImage',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127378',
		name: 'x127378',
		label: 'HTTP success responses',
		endpoint_label: 'GET /store/order/{orderId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127425',
		name: 'x127425',
		label: 'Request Response Time',
		endpoint_label: 'GET /pet/findByTags',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127434',
		name: 'x127434',
		label: 'Request Response Length',
		endpoint_label: 'POST /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127436',
		name: 'x127436',
		label: 'Request Payload Size',
		endpoint_label: 'POST /pet/{petId}',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127401',
		name: 'x127401',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'GET /pet/findByStatus',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127397',
		name: 'x127397',
		label: 'HTTP Requests Per User',
		endpoint_label: 'POST /user/createWithList',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127424',
		name: 'x127424',
		label: 'Request Response Length',
		endpoint_label: 'GET /pet/findByTags',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127395',
		name: 'x127395',
		label: 'HTTP success responses',
		endpoint_label: 'POST /user/createWithList',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127462',
		name: 'x127462',
		label: 'Request Response Time',
		endpoint_label: 'POST /user',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080b294a078a',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127589',
		name: 'x127589',
		label: 'Request Response Length',
		endpoint_label: 'POST read',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080c3a10078e',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127588',
		name: 'x127588',
		label: 'Request Response Time',
		endpoint_label: 'POST read',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080c3a10078e',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127591',
		name: 'x127591',
		label: 'HTTP success responses',
		endpoint_label: 'POST read',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080c3a10078e',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127590',
		name: 'x127590',
		label: 'Request Payload Size',
		endpoint_label: 'POST read',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080c3a10078e',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127593',
		name: 'x127593',
		label: 'HTTP Requests Per User',
		endpoint_label: 'POST read',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		channel_id: 'ff8081816b04243c016b080c3a10078e',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	},
	{
		id: '127592',
		name: 'x127592',
		label: 'HTTP Error Code Responses',
		endpoint_label: 'POST read',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		channel_id: 'ff8081816b04243c016b080c3a10078e',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi',
		value_type: 'Double'
	}
];

export const customParameters = [
	{
		id: uuid(),
		name: 'vector',
		description: 'Temperature in moscow',
		type: 'DB',
		category: 'Custom',
		ttl: 90,
		locator: {
			host: 'sasha-mysql.cqdl930auxp3.us-west-2.rds.amazonaws.com',
			port: '3306',
			db_name: 'MySQL',
			db_type: 'MySQL',
			query: 'select magic from *'
		},
		status: 'ready',
		resp_type: 'vector',
		resp_example: {
			data: [
				[
					12.5,
					10,
					14,
					10,
					15,
					6,
					2,
					0,
					0,
					-2,
					-1,
					0,
					1,
					1,
					12.5,
					10,
					14,
					10,
					15,
					6,
					2,
					0,
					0,
					-2,
					-1,
					0,
					1,
					1
				]
			],
			meta: [{ temperature: 'double' }],
			type: 'Vector'
		}
	},
	{
		id: uuid(),
		name: 'value',
		type: 'SOAP',
		category: 'Custom',
		description: 'Value to show in a graph',
		ttl: 90,
		locator: {
			api_type: 'SOAP',
			path: 'Envelope/Body/GetIndexValueResponse/GetIndexValueResult',
			url: 'http://webservices.gama-system.com/stockquotes.asmx',
			envelope_body:
				'<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:web="http://www.gama-system.com/webservices">\n   <soap:Header/>\n   <soap:Body>\n      <web:GetIndexValue>\n         <!--Optional:-->\n         <web:strStockExchange>NASDAQ<\u002fweb:strStockExchange>\n         <!--Optional:-->\n         <web:strIndex>APPL<\u002fweb:strIndex>\n         <!--Optional:-->\n         <web:strDateTime>?<\u002fweb:strDateTime>\n      <\u002fweb:GetIndexValue>\n   <\u002fsoap:Body>\n<\u002fsoap:Envelope>',
			optional_headers: []
		},
		status: 'ready',
		resp_type: 'value',
		resp_example: {
			data: [[4]],
			meta: [
				{
					type: 'Integer'
				}
			],
			type: 'Value'
		}
	},
	{
		id: '1fce5fba-e0e5-4c75-9d97-d2d1cdd50af6',
		name: 'table',
		type: 'DB',
		category: 'Custom',
		param_type: 'custom_param',
		description: 'Table of employees by date',
		ttl: 90,
		locator: {
			host: 'sasha-mysql.cqdl930auxp3.us-west-2.rds.amazonaws.com',
			port: '3306',
			db_name: 'MySQL',
			db_type: 'MySQL',
			query: 'select magic from *'
		},
		status: 'ready',
		resp_type: 'table',
		resp_example: {
			data: [
				['1', '38', '(200)205 5169', '1996-03-25'],
				['2', '32', '(200)213-6391', '1997-01-13'],
				['3', '76', '(200)2029603', '1995-10-17'],
				['4', '75', '(200)211 3230', '1993-10-09'],
				['5', '74', '(200)216-0387', '1995-10-19'],
				['6', '59', '(200)204-4932', '1995-07-11'],
				['7', '51', '(200)209 1680', '1997-12-23'],
				['8', '6', '(200)203 8825', '1995-07-19'],
				['9', '52', '(200)211-9450', '1997-03-08'],
				['10', '18', '(200)201 4562', '1996-05-02']
			],
			meta: [
				{
					name: 'account_id',
					type: 'BIGINT'
				},
				{
					name: 'district_id',
					type: 'BIGINT'
				},
				{
					name: 'frequency',
					type: 'VARCHAR'
				},
				{
					name: 'date',
					type: 'DATE'
				}
			],
			type: 'Table'
		}
	},
	{
		id: 'ff8081816c6cdca5016c6ce2fd070002',
		name: 'softworld',
		ttl: 300000,
		locator: {
			url: 'https://petstore.swagger.io/v2/pet/1',
			type: 'api.rest'
		},
		type: 'rest',
		status: 'ready',
		resp_type: 'value',
		resp_example: {
			data: [
				[
					'{"id":1,"category":{"id":0,"name":"softworld"},"name":"doggie","photoUrls":["string"],"tags":[{"id":0,"name":"string"}],"status":"available"}'
				]
			],
			meta: [
				{
					name: 'result',
					type: 'string'
				}
			],
			type: 'Value'
		},
		param_type: 'custom_param'
	},
	{
		id: 'ff8081816c6ce822016c6cea2d460001',
		name: 'shark',
		ttl: 300000,
		locator: {
			url: 'https://petstore.swagger.io/v2/pet/5',
			type: 'api.rest'
		},
		type: 'rest',
		status: 'ready',
		resp_type: 'value',
		resp_example: {
			data: [
				[
					'{"id":5,"category":{"id":5,"name":"shark"},"name":"bigshark","photoUrls":["string"],"tags":[{"id":5,"name":"tag"}],"status":"swimming"}'
				]
			],
			meta: [
				{
					name: 'result',
					type: 'string'
				}
			],
			type: 'Value'
		},
		param_type: 'custom_param'
	},
	{
		id: 'ff8081816c242d7b016c2430334b0003',
		name: 'testPetSingle100',
		ttl: 300000,
		locator: {
			url: 'https://petstore.swagger.io/v2/pet/100',
			path: 'id',
			type: 'api.rest'
		},
		type: 'rest',
		status: 'ready',
		resp_type: 'value',
		resp_example: {
			data: [[100]],
			meta: [
				{
					name: 'result',
					type: 'number'
				}
			],
			type: 'Value'
		},
		param_type: 'custom_param'
	},
	{
		id: 'ff8081816c13b24a016c13e3bc0e0009',
		name: 'testPetSingle1',
		ttl: 300000,
		locator: {
			url: 'https://petstore.swagger.io/v2/pet/2',
			path: 'id',
			type: 'api.rest'
		},
		type: 'rest',
		status: 'ready',
		resp_type: 'value',
		resp_example: {
			data: [[2]],
			meta: [
				{
					name: 'result',
					type: 'number'
				}
			],
			type: 'Value'
		},
		param_type: 'custom_param'
	},
	{
		id: 'ff8081816c42a14c016c42a3308f0003',
		name: 'getInform',
		ttl: 300000,
		locator: {
			host: 'sasha-mysql.cqdl930auxp3.us-west-2.rds.amazonaws.com',
			port: '3306',
			type: 'db',
			query: 'select * from account',
			db_name: 'financial',
			db_type: 'mysql'
		},
		type: 'db',
		status: 'ready',
		resp_type: 'table',
		resp_example: {
			data: [
				[1, 38, '(200)205 5169', '1996-03-25'],
				[2, 32, '(200)213-6391', '1997-01-13'],
				[3, 76, '(200)2029603', '1995-10-17'],
				[4, 75, '(200)211 3230', '1993-10-09'],
				[5, 74, '(200)216-0387', '1995-10-19'],
				[6, 59, '(200)204-4932', '1995-07-11'],
				[7, 51, '(200)209 1680', '1997-12-23'],
				[8, 6, '(200)203 8825', '1995-07-19'],
				[9, 52, '(200)211-9450', '1997-03-08'],
				[10, 18, '(200)201 4562', '1996-05-02'],
				[11, 37, '(200)210 2176', '1995-02-07'],
				[12, 58, '(200)2140199', '1995-05-14'],
				[13, 3, '(200)215 8841', '1993-12-22'],
				[14, 50, '(200)211-6788', '1997-12-03'],
				[15, 24, '(200)2091847', '1995-11-28'],
				[16, 76, '(200)216-6858', '1997-09-14'],
				[17, 56, '(200)2019200', '1995-08-30'],
				[18, 28, '(200)213-2629', '1993-05-24'],
				[19, 20, '(200)2023979', '1997-08-25'],
				[20, 8, '(200)2073034', '1996-04-30'],
				[21, 26, '(200)209 1006', '1994-06-06'],
				[22, 25, '(200)2088062', '1995-04-04'],
				[23, 60, '(200)206-6405', '1993-05-12'],
				[24, 17, '(200)2057029', '1997-07-30'],
				[25, 58, '(200)214-1588', '1995-07-25'],
				[26, 44, '(200)216-6861', '1994-07-16'],
				[27, 41, '(200)210-8906', '1997-09-08'],
				[29, 67, '(200)2098367', '1995-04-08'],
				[30, 60, '(200)2162957', '1995-06-21'],
				[31, 38, '(200)204 1501', '1993-08-20'],
				[32, 2, '(200)2102365', '1995-04-20'],
				[33, 69, '(200)2122788', '1996-03-05'],
				[34, 2, '(200)210 6312', '1994-08-13'],
				[35, 56, '(200)201 0642', '1995-04-22'],
				[36, 56, '(200)2125345', '1993-05-10'],
				[37, 74, '(200)208 6354', '1997-10-10'],
				[38, 67, '(200)213-3550', '1994-06-28'],
				[39, 32, '(200)2078045', '1994-07-28'],
				[40, 9, '(200)204-6004', '1993-06-19'],
				[41, 12, '(200)212 2530', '1997-10-18'],
				[42, 58, '(200)210 9847', '1997-08-09'],
				[43, 74, '(200)204-9019', '1994-05-27'],
				[44, 52, '(200)2069185', '1993-12-10'],
				[45, 24, '(200)216-4247', '1994-12-07'],
				[47, 71, '(200)204 4267', '1993-07-29'],
				[48, 65, '(200)203 0770', '1997-06-10'],
				[49, 73, '(200)2128764', '1997-06-04'],
				[50, 77, '(200)2167679', '1995-09-13'],
				[51, 55, '(200)2050236', '1997-09-10'],
				[52, 55, '(200)212-4818', '1993-04-02'],
				[53, 54, '(200)2116271', '1997-02-16'],
				[54, 19, '(200)213-4516', '1995-05-08'],
				[55, 55, '(200)212 9035', '1996-03-15'],
				[56, 38, '(200)2143894', '1996-08-26'],
				[57, 18, '(200)204 0806', '1995-01-02'],
				[58, 28, '(200)209 0287', '1993-07-21'],
				[59, 31, '(200)214-4359', '1995-12-22'],
				[61, 52, '(200)213-0756', '1996-05-04'],
				[62, 37, '(200)205-1401', '1993-06-01'],
				[63, 67, '(200)200-2787', '1994-06-04'],
				[64, 47, '(200)2016603', '1995-10-13'],
				[65, 66, '(200)205-4634', '1997-12-07'],
				[66, 12, '(200)208 5892', '1994-05-11'],
				[67, 62, '(200)215 6914', '1997-04-03'],
				[68, 24, '(200)201-7726', '1996-03-13'],
				[69, 36, '(200)2125263', '1994-05-15'],
				[70, 15, '(200)202-1442', '1996-10-03'],
				[71, 37, '(200)206-7144', '1995-11-18'],
				[72, 48, '(200)215-3574', '1994-06-22'],
				[73, 45, '(200)205-1459', '1995-10-11'],
				[75, 13, '(200)209 5443', '1995-12-04'],
				[76, 77, '(200)215-1362', '1995-04-12'],
				[77, 54, '(200)2107284', '1996-11-12'],
				[78, 2, '(200)206-7853', '1995-01-14'],
				[79, 53, '(200)214-7196', '1995-02-05'],
				[80, 42, '(200)209-0368', '1997-06-16'],
				[81, 20, '(200)207-4831', '1993-07-25'],
				[82, 76, '(200)2092562', '1993-03-13'],
				[83, 25, '(200)2114213', '1997-11-07'],
				[84, 2, '(200)209-6377', '1993-10-09'],
				[85, 24, '(200)209-1640', '1997-06-18'],
				[86, 56, '(200)215-5439', '1996-12-04'],
				[88, 27, '(200)207 9997', '1994-09-28'],
				[89, 62, '(200)208 3947', '1997-01-21'],
				[90, 73, '(200)205 5541', '1994-05-05'],
				[91, 72, '(200)210-0227', '1994-02-12'],
				[93, 11, '(200)207-0186', '1997-06-08'],
				[95, 33, '(200)213 7139', '1995-07-01'],
				[96, 47, '(200)214 3977', '1996-05-02'],
				[97, 25, '(200)2011978', '1997-09-20'],
				[98, 64, '(200)201-5574', '1993-07-01'],
				[99, 71, '(200)214-2025', '1995-07-21'],
				[100, 34, '(200)203 1350', '1995-10-15'],
				[101, 71, '(200)212 8672', '1997-04-21'],
				[102, 45, '(200)215 6092', '1996-12-22'],
				[103, 4, '(200)2087824', '1993-10-05'],
				[104, 8, '(200)208 7049', '1997-10-16'],
				[105, 3, '(200)2113005', '1994-06-18'],
				[106, 6, '(200)205-0301', '1996-04-28'],
				[107, 74, '(200)215 1371', '1995-03-31']
			],
			meta: [
				{
					name: 'account_id',
					type: 'number'
				},
				{
					name: 'district_id',
					type: 'number'
				},
				{
					name: 'frequency',
					type: 'string'
				},
				{
					name: 'date_',
					type: 'string'
				}
			],
			type: 'Table'
		},
		param_type: 'custom_param'
	},
	{
		id: 'ff8081816c4c391e016c4c8589050001',
		name: 'district',
		ttl: 300000,
		locator: {
			host: 'sasha-mysql.cqdl930auxp3.us-west-2.rds.amazonaws.com',
			port: '3306',
			type: 'db',
			query: 'select district_id from account',
			db_name: 'financial',
			db_type: 'mysql'
		},
		type: 'db',
		status: 'ready',
		resp_type: 'table',
		resp_example: {
			data: [
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[1],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2],
				[2]
			],
			meta: [
				{
					name: 'district_id',
					type: 'number'
				}
			],
			type: 'Table'
		},
		param_type: 'custom_param'
	},
	{
		id: 'ff8081816c48bdfd016c48c5e8ce0001',
		name: 'pets',
		ttl: 300000,
		locator: {
			url: 'https://petstore.swagger.io/v2/pet/findByStatus?status=sold',
			type: 'api.rest'
		},
		type: 'rest',
		status: 'ready',
		resp_type: 'value',
		resp_example: {
			data: [
				[
					'[{"id":9223372036854775807,"category":{"id":26,"name":"РєРѕС‚"},"name":"","photoUrls":[],"tags":[],"status":"sold"},{"id":45556,"category":{"id":233956,"name":"fish"},"name":"","photoUrls":["https://photo1.jpg","https://photo2.jpg"],"tags":[{"id":235434,"name":"best"}],"status":"sold"},{"id":7777777,"category":{"id":0,"name":"my new dog test"},"name":"blabla","photoUrls":["https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn.shopify.com%2Fs%2Ffiles%2F1%2F0010%2F9215%2F7503%2Ft%2F10%2Fassets%2Fcbt2%2Fimages%2Fresult-clipboard.png%3F3037&imgrefurl=https%3A%2F%2Fenchroma.com%2Fpages%2Fcolor-blindness-test&docid=FsMcYBrbkqKD2M&tbnid=S_tIVPGUei2JFM%3A&vet=10ahUKEwjrz56BpN_jAhXkmFwKHT7hDYEQMwh3KAEwAQ..i&w=400&h=502&bih=901&biw=1589&q=test&ved=0ahUKEwjrz56BpN_jAhXkmFwKHT7hDYEQMwh3KAEwAQ&iact=mrc&uact=8"],"tags":[{"id":0,"name":"string"}],"status":"sold"},{"id":63780,"category":{"id":30,"name":"RvJdC"},"name":"VYclRnU","photoUrls":["SORny"],"tags":[{"id":90,"name":"uDIIx"}],"status":"sold"},{"id":1122338471359,"category":{"id":5436,"name":"soaspec_test"},"name":"Charlie","photoUrls":["string"],"tags":[{"id":1,"name":"string"}],"status":"sold"},{"id":1122338442802,"category":{"id":5436,"name":"soaspec_test"},"name":"Charlie","photoUrls":["string"],"tags":[{"id":1,"name":"string"}],"status":"sold"},{"id":-832,"category":{"id":935,"name":"d061_TPGl8Cr59ST"},"name":"doggie","photoUrls":["ITQYlI7cy62aQeia","zLl3-xT_NABvX-Uj","WB2vdAlro8X5lxIe","_Ko1b7kqKJSI7NWJ","voRGYCTrw1KciztL","DlTbegfRDgOnzm5S","BOvNSrhxnSVevsZd","sqZkyR2V-8tEmo9H","DbSoHi8A-t2Fbw3S"],"tags":[{"id":599,"name":"Fq7_-M5YZur7lsZT"},{"id":875,"name":"3zhcvFNyjNlF19Yr"},{"id":-720,"name":"x015kcC4ozhbyJ6n"},{"id":-971,"name":"PndPjNNPE8peuEMV"},{"id":142,"name":"4cwXdAgnkcG-HcYA"}],"status":"sold"},{"id":-727,"category":{"id":-321,"name":"Zj8jIzbm6HBB8n8c"},"name":"doggie","photoUrls":["y0uicUJNuG96Zfy0","AZZv3-35ZH_pRlsz","exKZbzYTHbIjqEw1","fZXCd8l9QCzo8Uh8","tkC1P5nV5-f5eU9y"],"tags":[{"id":-778,"name":"a5e1rPjyEHN2AgH8"},{"id":-529,"name":"4b20Ha4fAuLhQ3EP"},{"id":341,"name":"Vw-Cm_eXfhcVpf34"},{"id":-998,"name":"5RjMHcrQvOjBhPle"},{"id":105,"name":"5g7Zpq1Nq3OC8MXY"}],"status":"sold"},{"id":-751,"category":{"id":-805,"name":"WBhfW2jEvp55ak2U"},"name":"doggie","photoUrls":["LrW3EPKCvfaGwEUp"],"tags":[{"id":430,"name":"nMlvzbp7w5VJShfj"},{"id":-876,"name":"AGegAkzUexeB_Zz1"},{"id":-241,"name":"YI8xDl1OENnbBlxh"},{"id":-380,"name":"pdKdWdNq4dQ49yLW"},{"id":-603,"name":"y0TtD8Y8AcQp0s0_"}],"status":"sold"},{"id":2599201450,"category":{"id":14655551,"name":"dog"},"name":"hello kity","photoUrls":["http://foo.bar.com/1","http://foo.bar.com/2"],"tags":[{"id":3056427142,"name":"blank"}],"status":"sold"},{"id":560481333,"category":{"id":1842386393,"name":"dog"},"name":"hello kity","photoUrls":["http://foo.bar.com/1","http://foo.bar.com/2"],"tags":[{"id":1263458562,"name":"blank"}],"status":"sold"},{"id":2931020763,"category":{"id":3564115416,"name":"dog"},"name":"hello kity","photoUrls":["http://foo.bar.com/1","http://foo.bar.com/2"],"tags":[{"id":4154049075,"name":"blank"}],"status":"sold"},{"id":2914505803,"category":{"id":1706239510,"name":"dog"},"name":"hello kity","photoUrls":["http://foo.bar.com/1","http://foo.bar.com/2"],"tags":[{"id":1926806591,"name":"blank"}],"status":"sold"},{"id":2173761267,"category":{"id":274067810,"name":"dog"},"name":"hello kity","photoUrls":["http://foo.bar.com/1","http://foo.bar.com/2"],"tags":[{"id":1669472420,"name":"blank"}],"status":"sold"},{"id":3919822428,"category":{"id":3327862814,"name":"dog"},"name":"hello kity","photoUrls":["http://foo.bar.com/1","http://foo.bar.com/2"],"tags":[{"id":1599205524,"name":"blank"}],"status":"sold"},{"id":3811287362,"category":{"id":1272773782,"name":"dog"},"name":"hello kity","photoUrls":["http://foo.bar.com/1","http://foo.bar.com/2"],"tags":[{"id":126228136,"name":"blank"}],"status":"sold"},{"id":15435006001660,"category":{"id":2432432,"name":"category_name"},"name":"5239423","photoUrls":["test URL"],"tags":[{"id":5,"name":"fact tag"}],"status":"sold"},{"id":1122338466544,"category":{"id":5436,"name":"soaspec_test"},"name":"Charlie","photoUrls":["string"],"tags":[{"id":1,"name":"string"}],"status":"sold"},{"id":569694,"category":{"id":20002,"name":"category test"},"name":"new name","photoUrls":[],"tags":[{"id":30002,"name":"tag test"}],"status":"sold"},{"id":-8287332784406528,"category":{"id":-7746001083301888,"name":"WfpKklDa"},"name":"GfFxB","photoUrls":["OYfRRfEcpBF"],"tags":[{"id":6068242829279232,"name":"OGji"}],"status":"sold"},{"id":9249,"category":{"id":82,"name":"zfuTU"},"name":"JsXbRQX","photoUrls":["TltSB"],"tags":[{"id":62,"name":"LODyI"}],"status":"sold"},{"id":78652,"category":{"id":82,"name":"zfuTU"},"name":"JsXbRQX","photoUrls":["TltSB"],"tags":[{"id":62,"name":"LODyI"}],"status":"sold"},{"id":6855,"category":{"id":91686,"name":"oUzuu"},"name":"YarMGHj","photoUrls":["iEcpZ"],"tags":[{"id":49,"name":"ySHHp"}],"status":"sold"},{"id":4818,"category":{"id":70,"name":"BJPXzFF"},"name":"vpUCeCT","photoUrls":["iosIE"],"tags":[{"id":9,"name":"DOACc"}],"status":"sold"},{"id":-517,"category":{"id":611,"name":"CbM6JcRgKDZVUhh2"},"name":"doggie","photoUrls":["g2vGdYmkjqNaS_Kv","xcy6tO0uQc_qnnpW","TiD62nvVMxB1niVb","V1r46PHfrGIxpTX8","8aXiNO0iHmrAaTNA","PXPNFsuqE1bGh3OL","prGXK5Zfrcv_XfNI","2Ac8qb0LPn4yvkaB","UinkxqJwOe3wiQAn"],"tags":[{"id":776,"name":"lO0wvnlEDfmTPKgE"},{"id":975,"name":"HEvuIfHFuJ7Oub37"},{"id":-211,"name":"YkcLY4q7pQw5hcOO"},{"id":-873,"name":"FKf5WKejbSrYZ3CA"},{"id":-133,"name":"T_Rz8RTXDwR5QTzp"},{"id":542,"name":"jRigW5tple5fX8Ho"},{"id":183,"name":"bCIFRRhesIw21sUS"},{"id":184,"name":"sAPY-Bn9YyUUIC6g"}],"status":"sold"},{"id":5786,"category":{"id":70313,"name":"pxLnB"},"name":"FfdwxLZ","photoUrls":["WgTeb"],"tags":[{"id":7,"name":"IFfBg"}],"status":"sold"},{"id":3803,"category":{"id":54,"name":"kcZwzHj"},"name":"MHhAFwc","photoUrls":["WvDtJ"],"tags":[{"id":2,"name":"xoKRh"}],"status":"sold"},{"id":4097,"category":{"id":20,"name":"QvhkUXm"},"name":"mMfVXLW","photoUrls":["ICeng"],"tags":[{"id":35,"name":"trtJM"}],"status":"sold"},{"id":5392,"category":{"id":40,"name":"xgPjB"},"name":"hTpYWSp","photoUrls":["bLrbp"],"tags":[{"id":55,"name":"WGSeJ"}],"status":"sold"},{"id":3555,"category":{"id":43875,"name":"chGrt"},"name":"uKKYgBY","photoUrls":["JCugy"],"tags":[{"id":37,"name":"GqSpp"}],"status":"sold"},{"id":7516,"category":{"id":38,"name":"aWOqY"},"name":"jkpYzyc","photoUrls":["EpDtw"],"tags":[{"id":16,"name":"iGVBb"}],"status":"sold"},{"id":4697,"category":{"id":38,"name":"aWOqY"},"name":"jkpYzyc","photoUrls":["EpDtw"],"tags":[{"id":16,"name":"iGVBb"}],"status":"sold"},{"id":7488,"category":{"id":86593,"name":"xkWIi"},"name":"GOoPRKP","photoUrls":["nzKDQ"],"tags":[{"id":13,"name":"drBco"}],"status":"sold"},{"id":8297,"category":{"id":14,"name":"igxcu"},"name":"SscMDfJ","photoUrls":["QKqtM"],"tags":[{"id":99,"name":"dczUp"}],"status":"sold"},{"id":2981,"category":{"id":4,"name":"GOFFJbL"},"name":"GNZCfSi","photoUrls":["VYVat"],"tags":[{"id":96,"name":"JsxuM"}],"status":"sold"},{"id":1508,"category":{"id":39325,"name":"tkAUE"},"name":"RhhjqIr","photoUrls":["xgetP"],"tags":[{"id":44951,"name":"rvCQa"}],"status":"sold"},{"id":19520,"category":{"id":39325,"name":"tkAUE"},"name":"RhhjqIr","photoUrls":["xgetP"],"tags":[{"id":44951,"name":"rvCQa"}],"status":"sold"},{"id":4224,"category":{"id":76297,"name":"CZfJV"},"name":"PEbSzHu","photoUrls":["FHkuD"],"tags":[{"id":16491,"name":"Mvasg"}],"status":"sold"},{"id":7248,"category":{"id":33273,"name":"WyDmiSi"},"name":"ZlPqzwL","photoUrls":["QBZQH"],"tags":[{"id":74400,"name":"OdKDT"}],"status":"sold"},{"id":5203,"category":{"id":31582,"name":"VmkXa"},"name":"WErCnIM","photoUrls":["UqyhJ"],"tags":[{"id":71432,"name":"wZonj"}],"status":"sold"},{"id":7108,"category":{"id":68069,"name":"osRxv"},"name":"UubGkhw","photoUrls":["tlnMc"],"tags":[{"id":52048,"name":"QDYgd"}],"status":"sold"},{"id":2332,"category":{"id":55697,"name":"MSRRoKr"},"name":"RersfgW","photoUrls":["BDzVi"],"tags":[{"id":82034,"name":"BkNRf"}],"status":"sold"},{"id":72341,"category":{"id":51284,"name":"jBSmy"},"name":"OJKOvNm","photoUrls":["WiFMd"],"tags":[{"id":49758,"name":"CMPgT"}],"status":"sold"},{"id":43482,"category":{"id":51284,"name":"jBSmy"},"name":"OJKOvNm","photoUrls":["WiFMd"],"tags":[{"id":49758,"name":"CMPgT"}],"status":"sold"},{"id":23264,"category":{"id":78449,"name":"rxpnkEw"},"name":"EHtwLGm","photoUrls":["jkVlb"],"tags":[{"id":18260,"name":"ESBxp"}],"status":"sold"},{"id":14289,"category":{"id":46159,"name":"IuBYvFN"},"name":"CpvSEyV","photoUrls":["dxdgF"],"tags":[{"id":30861,"name":"TZyxx"}],"status":"sold"},{"id":25023,"category":{"id":19782,"name":"qFyCz"},"name":"HhSGnRu","photoUrls":["tzQoC"],"tags":[{"id":55760,"name":"SfrTm"}],"status":"sold"},{"id":9748,"category":{"id":19782,"name":"qFyCz"},"name":"HhSGnRu","photoUrls":["tzQoC"],"tags":[{"id":55760,"name":"SfrTm"}],"status":"sold"},{"id":39171,"category":{"id":31687,"name":"naBtU"},"name":"PZZmkMM","photoUrls":["FEgbs"],"tags":[{"id":76633,"name":"oYERK"}],"status":"sold"},{"id":33754,"category":{"id":11197,"name":"lNbNDgP"},"name":"AwejYeu","photoUrls":["aacju"],"tags":[{"id":49216,"name":"oRUiU"}],"status":"sold"},{"id":72182,"category":{"id":79801,"name":"tUICj"},"name":"cVbGLPY","photoUrls":["LyiDO"],"tags":[{"id":25443,"name":"jtITi"}],"status":"sold"},{"id":43120,"category":{"id":55249,"name":"lwAsx"},"name":"LLVVFaJ","photoUrls":["ZidpM"],"tags":[{"id":44714,"name":"CXidM"}],"status":"sold"},{"id":58806,"category":{"id":55249,"name":"lwAsx"},"name":"LLVVFaJ","photoUrls":["ZidpM"],"tags":[{"id":44714,"name":"CXidM"}],"status":"sold"},{"id":69576,"category":{"id":38421,"name":"cJWsfRf"},"name":"WpxSzwC","photoUrls":["IFFrG"],"tags":[{"id":33100,"name":"fLnmA"}],"status":"sold"},{"id":729201904,"category":{"id":0,"name":"Category 04"},"name":"Kitty 01","photoUrls":["String"],"tags":[],"status":"sold"},{"id":729201903,"category":{"id":0,"name":"Category 03"},"name":"Pet 003","photoUrls":["String"],"tags":[],"status":"sold"},{"id":14695,"category":{"id":36050,"name":"Tbrdd"},"name":"lDGmowo","photoUrls":["rohaG"],"tags":[{"id":20550,"name":"AWtTT"}],"status":"sold"},{"id":65395,"category":{"id":36050,"name":"Tbrdd"},"name":"lDGmowo","photoUrls":["rohaG"],"tags":[{"id":20550,"name":"AWtTT"}],"status":"sold"},{"id":79353,"category":{"id":8628,"name":"thxbO"},"name":"utyogKF","photoUrls":["OUiff"],"tags":[{"id":71754,"name":"dPyjt"}],"status":"sold"},{"id":43696,"category":{"id":37410,"name":"viAVqZn"},"name":"rJAtJcP","photoUrls":["nDCVT"],"tags":[{"id":94489,"name":"aoEif"}],"status":"sold"},{"id":49949,"category":{"id":73042,"name":"SiUUb"},"name":"xodSEAC","photoUrls":["UGhQr"],"tags":[{"id":68482,"name":"CyvJb"}],"status":"sold"},{"id":92451,"category":{"id":4252,"name":"pWFPi"},"name":"JhzLPHh","photoUrls":["JWpQZ"],"tags":[{"id":91708,"name":"ceumh"}],"status":"sold"},{"id":58782,"category":{"id":4252,"name":"pWFPi"},"name":"JhzLPHh","photoUrls":["JWpQZ"],"tags":[{"id":91708,"name":"ceumh"}],"status":"sold"},{"id":13032,"category":{"id":6137,"name":"lXDVB"},"name":"EwZuIjc","photoUrls":["dockm"],"tags":[{"id":35592,"name":"DzGwE"}],"status":"sold"},{"id":30693,"category":{"id":40355,"name":"YeWIz"},"name":"rKFjLpL","photoUrls":["LFZqO"],"tags":[{"id":85023,"name":"CpnjV"}],"status":"sold"},{"id":93700,"category":{"id":10014,"name":"hayQR"},"name":"meQSyHw","photoUrls":["VQnqh"],"tags":[{"id":90482,"name":"muXrp"}],"status":"sold"},{"id":33077,"category":{"id":74341,"name":"mBHCI"},"name":"TPiLIiZ","photoUrls":["quzkS"],"tags":[{"id":72451,"name":"XWfkf"}],"status":"sold"},{"id":53318,"category":{"id":88930,"name":"sEShi"},"name":"mJhdARp","photoUrls":["GohXh"],"tags":[{"id":11307,"name":"pFCaC"}],"status":"sold"},{"id":5002,"category":{"id":88930,"name":"sEShi"},"name":"mJhdARp","photoUrls":["GohXh"],"tags":[{"id":11307,"name":"pFCaC"}],"status":"sold"},{"id":24065,"category":{"id":66889,"name":"NnBVE"},"name":"fIftWGI","photoUrls":["fSFga"],"tags":[{"id":99004,"name":"iGnWz"}],"status":"sold"},{"id":82706,"category":{"id":31699,"name":"UYyyM"},"name":"ZXpvGJJ","photoUrls":["AIElR"],"tags":[{"id":48523,"name":"kMGJH"}],"status":"sold"},{"id":17223,"category":{"id":21565,"name":"oUMfZ"},"name":"fvwLiJg","photoUrls":["mfiLp"],"tags":[{"id":77951,"name":"oQAHR"}],"status":"sold"},{"id":49204,"category":{"id":51035,"name":"LLkfO"},"name":"CmwfDRQ","photoUrls":["LyJwG"],"tags":[{"id":49287,"name":"EwWgQ"}],"status":"sold"},{"id":58437,"category":{"id":4829,"name":"ovrPf"},"name":"IHArsej","photoUrls":["ZEIMy"],"tags":[{"id":74357,"name":"gznSA"}],"status":"sold"},{"id":2430,"category":{"id":4829,"name":"ovrPf"},"name":"IHArsej","photoUrls":["ZEIMy"],"tags":[{"id":74357,"name":"gznSA"}],"status":"sold"},{"id":60251,"category":{"id":61523,"name":"XQTNv"},"name":"sKcJGuo","photoUrls":["TIbfb"],"tags":[{"id":51796,"name":"tzTRk"}],"status":"sold"},{"id":25007,"category":{"id":25793,"name":"lEpmF"},"name":"AdXmRrk","photoUrls":["SCsjs"],"tags":[{"id":3689,"name":"iALUD"}],"status":"sold"},{"id":11273,"category":{"id":10203,"name":"lukKf"},"name":"EOQlATr","photoUrls":["YhEbO"],"tags":[{"id":47518,"name":"tUDkF"}],"status":"sold"},{"id":10001,"name":"update pet with form","photoUrls":[],"tags":[],"status":"sold"},{"id":85229,"category":{"id":38954,"name":"yUYxf"},"name":"aesBoEn","photoUrls":["uExWL"],"tags":[{"id":4464,"name":"FNwzJ"}],"status":"sold"},{"id":25940,"category":{"id":38954,"name":"yUYxf"},"name":"aesBoEn","photoUrls":["uExWL"],"tags":[{"id":4464,"name":"FNwzJ"}],"status":"sold"},{"id":44974,"category":{"id":79088,"name":"LqyGx"},"name":"axjBJnZ","photoUrls":["ZmvMX"],"tags":[{"id":16036,"name":"fLdBI"}],"status":"sold"},{"id":8193,"category":{"id":36912,"name":"OdtLC"},"name":"VaVCayu","photoUrls":["snnQZ"],"tags":[{"id":62884,"name":"UIPsV"}],"status":"sold"},{"id":67743,"category":{"id":36912,"name":"OdtLC"},"name":"VaVCayu","photoUrls":["snnQZ"],"tags":[{"id":62884,"name":"UIPsV"}],"status":"sold"},{"id":26276,"category":{"id":2959,"name":"zxzZE"},"name":"igtDLki","photoUrls":["Ihvlv"],"tags":[{"id":99202,"name":"rTYEt"}],"status":"sold"},{"id":12989,"category":{"id":57989,"name":"cnMgU"},"name":"vSGBGmH","photoUrls":["PQAFU"],"tags":[{"id":54322,"name":"tvxAb"}],"status":"sold"},{"id":65255,"category":{"id":43956,"name":"hFEgt"},"name":"AdLjHqi","photoUrls":["gUfNP"],"tags":[{"id":18489,"name":"Wotpq"}],"status":"sold"},{"id":79979,"category":{"id":35332,"name":"xrEnB"},"name":"RXCJppa","photoUrls":["fhefK"],"tags":[{"id":68056,"name":"bwaCt"}],"status":"sold"},{"id":19198,"category":{"id":16231,"name":"VJnmd"},"name":"SMjHXPG","photoUrls":["SSvbx"],"tags":[{"id":63486,"name":"zqaWg"}],"status":"sold"}]'
				]
			],
			meta: [
				{
					name: 'result',
					type: 'string'
				}
			],
			type: 'Value'
		},
		param_type: 'custom_param'
	},
	{
		id: 'ff8081816bfb297d016bfb2ec1920000',
		name: 'petstore_id',
		ttl: 300000,
		locator: {
			url: 'https://petstore.swagger.io/v2/pet/findByStatus?status=sold',
			path: '[0].id',
			type: 'api.rest'
		},
		type: 'rest',
		status: 'ready',
		resp_type: 'value',
		resp_example: {
			data: [[9223372036854775807]],
			meta: [
				{
					name: 'result',
					type: 'number'
				}
			],
			type: 'Value'
		},
		param_type: 'custom_param'
	},
	{
		id: 'ff8081816c6ccd35016c6cd82ba90000',
		name: 'CustomersCount',
		ttl: 300000,
		locator: {
			host:
				'ch2c9f93d961462fb001614c9b3995098de-prod-demo-proov-io-chatbot.cqdl930auxp3.us-west-2.rds.amazonaws.com',
			port: '3306',
			type: 'db',
			query: 'SELECT count(*) FROM customers',
			db_name: 'Chatbot',
			db_type: 'mysql'
		},
		type: 'db',
		status: 'ready',
		resp_type: 'table',
		resp_example: {
			data: [[324610]],
			meta: [
				{
					name: 'count(*)',
					type: 'number'
				}
			],
			type: 'Table'
		},
		param_type: 'custom_param'
	}
];

export const MetricArguments = [
	{
		id: uuid(),
		type: 'custom_param',
		variable: 'testPetSingle100',
		channel_id: null
	},
	{
		id: uuid(),
		type: 'custom_param',
		variable: 'testPetSingle1',
		channel_id: null
	},
	{
		id: '1',
		type: 'standard_kpi',
		variable: 'x1',
		channel_id: uuid()
	},
	{
		id: '2',
		type: 'standard_kpi',
		variable: 'x2',
		channel_id: uuid()
	},
	{
		id: '3',
		type: 'standard_kpi',
		variable: 'x3',
		channel_id: uuid()
	}
];

export const metrics = [
	{
		id: uuid(),
		description: 'This is a description',
		name: 'Business KPI Chart',
		args: [
			{
				id: uuid(),
				type: 'custom_param',
				variable: 'testPetSingle100',
				channel_id: null
			},
			{
				id: uuid(),
				type: 'custom_param',
				variable: 'testPetSingle1',
				channel_id: null
			}
		],
		script: 'testPetSingle100+testPetSingle1',
		script_type: 'formula',
		schedule: '0 * * ? * *',
		trigger: null,
		status: 'ready',
		param_type: 'custom_kpi',
		resp_type: 'value',
		resp_example: {
			data: [[101]],
			meta: [
				{
					name: 'formula_result',
					type: 'number'
				}
			],
			type: 'Value'
		}
	},
	{
		id: '6b44c828-272e-4e84-9f28-4fb8217ce6f1',
		name: 'Business KPI Table',
		description: 'This is a description',
		args: [customParameters[2]],
		script:
			"function func() {\nreturn new Value([[testPetSingle1.getValue() + testPetSingle100.getValue() + x1.getValue()+ x163.getValue() + x1.getValue()]], [{name: 'res', type: 'int'}]);\n}",
		script_type: 'js6',
		schedule: '0 * * ? * *',
		trigger: null,
		status: 'ready',
		param_type: 'custom_kpi',
		resp_type: 'table',
		resp_example: {
			data: [
				['1', '38', '(200)205 5169', '1996-03-25'],
				['2', '32', '(200)213-6391', '1997-01-13'],
				['3', '76', '(200)2029603', '1995-10-17'],
				['4', '75', '(200)211 3230', '1993-10-09'],
				['5', '74', '(200)216-0387', '1995-10-19'],
				['6', '59', '(200)204-4932', '1995-07-11'],
				['7', '51', '(200)209 1680', '1997-12-23'],
				['8', '6', '(200)203 8825', '1995-07-19'],
				['9', '52', '(200)211-9450', '1997-03-08'],
				['10', '18', '(200)201 4562', '1996-05-02']
			],
			meta: [
				{
					name: 'account_id',
					type: 'BIGINT'
				},
				{
					name: 'district_id',
					type: 'BIGINT'
				},
				{
					name: 'frequency',
					type: 'VARCHAR'
				},
				{
					name: 'date',
					type: 'DATE'
				}
			],
			type: 'Table'
		}
	},
	{
		id: uuid(),
		name: 'Business KPI Vector',
		description: 'This is a description',
		args: [customParameters[0]],
		script:
			"function func() {\nreturn new Value([[testPetSingle1.getValue() + testPetSingle100.getValue() + x1.getValue()+ x163.getValue() + x1.getValue()]], [{name: 'res', type: 'int'}]);\n}",
		script_type: 'js6',
		schedule: '0 * * ? * *',
		trigger: null,
		status: 'ready',
		param_type: 'custom_kpi',
		resp_type: 'vector',
		resp_example: {
			data: [
				[
					12.5,
					10,
					14,
					10,
					15,
					6,
					2,
					0,
					0,
					-2,
					-1,
					0,
					1,
					1,
					12.5,
					10,
					14,
					10,
					15,
					6,
					2,
					0,
					0,
					-2,
					-1,
					0,
					1,
					1,
					12.5,
					10,
					14,
					10,
					15,
					6,
					2,
					0,
					0,
					-2,
					-1,
					0,
					1,
					1,
					12.5,
					10,
					14,
					10,
					15,
					6,
					2,
					0,
					0,
					-2,
					-1,
					0,
					1,
					1
				]
			],
			meta: [{ name: 'temperature', type: 'number' }],
			type: 'Vector'
		}
	},
	{
		id: uuid(),
		name: 'Business KPI Vector',
		description: 'This is a description',
		args: MetricArguments,
		script:
			"function func() {\nreturn new Value([[testPetSingle1.getValue() + testPetSingle100.getValue() + x1.getValue()+ x163.getValue() + x1.getValue()]], [{name: 'res', type: 'int'}]);\n}",
		script_type: 'js6',
		schedule: '0 0/30 * 1/1 * ? *',
		trigger: null,
		status: 'ready',
		param_type: 'custom_kpi',
		resp_type: 'value',
		resp_example: {
			data: [[117.5]],
			meta: [
				{
					name: 'res',
					type: 'int'
				}
			],
			type: 'value'
		}
	},
	{
		id: uuid(),
		description: 'This is a description',
		name: 'ttttes',
		args: MetricArguments,
		script: 'function func(){\n\treturn\tparam;\n}',
		script_type: 'js6',
		schedule: '0 /5 ? * *',
		trigger: null,
		status: 'failed',
		resp_type: 'table',
		resp_example: {}
	},
	{
		id: '190',
		name: 'x190',
		label: 'Proc Stat Threads Windows',
		category: 'PROC STAT',
		unit: '%',
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '192',
		name: 'x192',
		label: 'Proc Stat Total Windows',
		category: 'PROC STAT',
		unit: '%',
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '194',
		name: 'x194',
		label: 'Proc Stat Zombie Windows',
		category: 'PROC STAT',
		unit: null,
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '150',
		name: 'x150',
		label: 'Disk Usage Read Bytes Windows',
		category: 'DISK USAGE',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '196',
		name: 'x196',
		label: 'Resource Limit Core Cur Win',
		category: 'RESOURCE LIMIT',
		unit: 'Mhz',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '152',
		name: 'x152',
		label: 'Disk Usage Reads Windows',
		category: 'DISK USAGE',
		unit: null,
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '230',
		name: 'x230',
		label: 'TCP Passive Opens Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 1000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '198',
		name: 'x198',
		label: 'Resource Limit Core Max Win',
		category: 'RESOURCE LIMIT',
		unit: null,
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '154',
		name: 'x154',
		label: 'Disk Usage Service Time Win',
		category: 'DISK USAGE',
		unit: 'ms',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '110',
		name: 'x110',
		label: 'CPU Stolen Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '232',
		name: 'x232',
		label: 'TCP Retrans Segs Windows',
		category: 'TCP',
		unit: 'byte',
		range: [0.0, 1000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '156',
		name: 'x156',
		label: 'Disk Usage Write Bytes Windows',
		category: 'DISK USAGE',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '112',
		name: 'x112',
		label: 'CPU Sys Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '234',
		name: 'x234',
		label: 'Thread CPU Sys Windows',
		category: 'THREAD CPU',
		unit: '$',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null
	},
	{
		id: '158',
		name: 'x158',
		label: 'Disk Usage Writes Windows',
		category: 'DISK USAGE',
		unit: null,
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '114',
		name: 'x114',
		label: 'CPU Total Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '236',
		name: 'x236',
		label: 'Thread CPU Total Windows',
		category: 'THREAD CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '116',
		name: 'x116',
		label: 'CPU User Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '238',
		name: 'x238',
		label: 'Thread CPU User Windows',
		category: 'THREAD CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '118',
		name: 'x118',
		label: 'CPU Wait Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '15',
		name: 'x15',
		label: 'CPU Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '16',
		name: 'x16',
		label: 'Free Memory Windows',
		category: 'REMOTE KPI',
		unit: 'Gb',
		range: [0.0, 32.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '17',
		name: 'x17',
		label: 'Free DiskSpace Windows',
		category: 'REMOTE KPI',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '18',
		name: 'x18',
		label: 'Used CPU  By Process',
		category: 'REMOTE KPI',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '19',
		name: 'x19',
		label: 'Used Memory By Process Windows',
		category: 'REMOTE KPI',
		unit: 'Gb',
		range: [0.0, 32.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '160',
		name: 'x160',
		label: 'Mem Actual Free Windows',
		category: 'MEMORY',
		unit: 'Gb',
		range: [0.0, 32.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '162',
		name: 'x162',
		label: 'Mem Actual Used Windows',
		category: 'MEMORY',
		unit: 'Gb',
		range: [0.0, 32.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '240',
		name: 'x240',
		label: 'File System Usage Disk Queue',
		category: 'FILE SYSTEM USAGE',
		unit: 'Gb',
		range: [0.0, 1000000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '164',
		name: 'x164',
		label: 'Mem Free Percent Windows',
		category: 'MEMORY',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '120',
		name: 'x120',
		label: 'CPU Info List Cache Size Win',
		category: 'CPU',
		unit: 'Mb',
		range: [0.0, 1024.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '242',
		name: 'x242',
		label: 'File System Usage Disk Read By',
		category: 'FILE SYSTEM USAGE',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '166',
		name: 'x166',
		label: 'Mem Ram Windows',
		category: 'MEMORY',
		unit: 'Gb',
		range: [0.0, 32.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '122',
		name: 'x122',
		label: 'CPU Info List Cores Per Socket',
		category: 'CPU',
		unit: null,
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '244',
		name: 'x244',
		label: 'File System Usage Disk Reads',
		category: 'FILE SYSTEM USAGE',
		unit: null,
		range: [0.0, 1000000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '200',
		name: 'x200',
		label: 'Resource Limit Open Files Cur',
		category: 'RESOURCE LIMIT',
		unit: null,
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '168',
		name: 'x168',
		label: 'Mem Total Windows',
		category: 'MEMORY',
		unit: 'Gb',
		range: [0.0, 32.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '124',
		name: 'x124',
		label: 'CPU Info List Mhz Windows',
		category: 'CPU',
		unit: 'Mhz',
		range: [0.0, 10000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '246',
		name: 'x246',
		label: 'File System Usage Disk Service',
		category: 'FILE SYSTEM USAGE',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '202',
		name: 'x202',
		label: 'Resource Limit Open Files Max',
		category: 'RESOURCE LIMIT',
		unit: null,
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '126',
		name: 'x126',
		label: 'CPU Info List Total Cores',
		category: 'CPU',
		unit: null,
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '248',
		name: 'x248',
		label: 'File System Usage Disk Write',
		category: 'FILE SYSTEM USAGE',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '204',
		name: 'x204',
		label: 'Swap Free Windows',
		category: 'SWAP',
		unit: 'Gb',
		range: [0.0, 64.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '128',
		name: 'x128',
		label: 'CPU Info List Total Sockets',
		category: 'CPU',
		unit: null,
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '206',
		name: 'x206',
		label: 'Swap Page In Windows',
		category: 'SWAP',
		unit: 'Gb',
		range: [0.0, 64.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '208',
		name: 'x208',
		label: 'Swap Page Out Windows',
		category: 'SWAP',
		unit: 'Gb',
		range: [0.0, 64.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '170',
		name: 'x170',
		label: 'Mem Used Windows',
		category: 'MEMORY',
		unit: 'Gb',
		range: [0.0, 32.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '172',
		name: 'x172',
		label: 'Mem Used Percent Windows',
		category: 'MEMORY',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '250',
		name: 'x250',
		label: 'File System Usage Disk Writes',
		category: 'FILE SYSTEM USAGE',
		unit: null,
		range: [0.0, 1000000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '174',
		name: 'x174',
		label: 'Net Stat All Inbound Total',
		category: 'NET STAT',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '130',
		name: 'x130',
		label: 'CPU Info List Length Windows',
		category: 'CPU',
		unit: null,
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '252',
		name: 'x252',
		label: 'File System Usage Files Win',
		category: 'FILE SYSTEM USAGE',
		unit: null,
		range: [0.0, 1000000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '176',
		name: 'x176',
		label: 'Net Stat All Outbound Total',
		category: 'NET STAT',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '132',
		name: 'x132',
		label: 'CPU Perc Combined Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '254',
		name: 'x254',
		label: 'File System Usage Free Windows',
		category: 'FILE SYSTEM USAGE',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '210',
		name: 'x210',
		label: 'Swap Total Windows',
		category: 'SWAP',
		unit: 'Gb',
		range: [0.0, 64.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '178',
		name: 'x178',
		label: 'Net Stat TCP Inbound Total',
		category: 'NET STAT',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '134',
		name: 'x134',
		label: 'CPU Perc Idle Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '256',
		name: 'x256',
		label: 'File System Usage Total Win',
		category: 'FILE SYSTEM USAGE',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '212',
		name: 'x212',
		label: 'Swap Used Windows',
		category: 'SWAP',
		unit: 'Gb',
		range: [0.0, 64.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '136',
		name: 'x136',
		label: 'CPU Perc Irq Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '258',
		name: 'x258',
		label: 'File System Usage Used Windows',
		category: 'FILE SYSTEM USAGE',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '214',
		name: 'x214',
		label: 'TCP Active Opens Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 128000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '138',
		name: 'x138',
		label: 'CPU Perc Nice Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '216',
		name: 'x216',
		label: 'TCP Attempt Fails Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 128000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '218',
		name: 'x218',
		label: 'TCP Curr Estab Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 1024.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '180',
		name: 'x180',
		label: 'Net Stat TCP Outbound Total',
		category: 'NET STAT',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '182',
		name: 'x182',
		label: 'Proc Stat Idle Windows',
		category: 'PROC STAT',
		unit: null,
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '260',
		name: 'x260',
		label: 'File System Usage Percent',
		category: 'FILE SYSTEM USAGE',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '184',
		name: 'x184',
		label: 'Proc Stat Running Windows',
		category: 'PROC STAT',
		unit: null,
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '140',
		name: 'x140',
		label: 'CPU Perc Soft Irq Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '186',
		name: 'x186',
		label: 'Proc Stat Sleeping Windows',
		category: 'PROC STAT',
		unit: null,
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '142',
		name: 'x142',
		label: 'CPU Perc Stolen Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '220',
		name: 'x220',
		label: 'TCP Estab Resets Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 2048.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '188',
		name: 'x188',
		label: 'Proc Stat Stopped Windows',
		category: 'PROC STAT',
		unit: null,
		range: [0.0, 65536.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '144',
		name: 'x144',
		label: 'CPU Perc Sys Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '222',
		name: 'x222',
		label: 'TCP In Errs Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 1000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '102',
		name: 'x102',
		label: 'CPU Idle Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '146',
		name: 'x146',
		label: 'CPU Perc Wait Windows',
		category: 'CPU',
		unit: '%',
		range: [0.0, 100.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '224',
		name: 'x224',
		label: 'TCP In Segs Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 1000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '148',
		name: 'x148',
		label: 'Disk Usage Queue Windows',
		category: 'DISK USAGE',
		unit: 'Gb',
		range: [0.0, 500.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '104',
		name: 'x104',
		label: 'CPU Irq Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '226',
		name: 'x226',
		label: 'TCP Out Rsts Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 1000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '106',
		name: 'x106',
		label: 'CPU Nice Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '228',
		name: 'x228',
		label: 'TCP Out Segs Windows',
		category: 'TCP',
		unit: null,
		range: [0.0, 1000.0],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: '108',
		name: 'x108',
		label: 'CPU Soft Irq Windows',
		category: 'CPU',
		unit: 'ms',
		range: [0.0, 1.0e9],
		expression: null,
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: uuid(),
		label: 'test graph 1',
		category: 'Custom Graph',
		unit: '',
		range: [0.0, 32.0],
		channel_ids: ['1', '2', '3'],
		expression: '',
		expression_to_display: '',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	},
	{
		id: uuid(),
		label: 'test graph 2',
		category: 'Custom Graph',
		unit: '',
		range: [0.0, 32.0],
		channel_ids: ['1', '2'],
		expression: '',
		expression_to_display: '',
		description: null,
		success_criteria: null,
		param_type: 'standard_kpi'
	}
];

export const endpoints = [
	{
		id: '10554',
		name: 'x10554',
		label: '/account',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 100000.0],
		expression: null,
		channel_id: uuid()
	},
	{
		id: '10546',
		name: 'x10546',
		label: '/account',
		category: 'STANDARD',
		unit: 'ms',
		range: [0.0, 100000.0],
		expression: null,
		channel_id: uuid()
	},
	{
		id: '10550',
		name: 'x10550',
		label: '/account',
		category: 'STANDARD',
		unit: '',
		range: [0.0, 1000000.0],
		expression: null,
		channel_id: uuid()
	}
];

export const customGraphMetrics = [
	{
		id: uuid(),
		category: 'CPU',
		label: 'CPU Utilization',
		config: [
			{
				os: 'windows',
				type: 'server',
				is_pop: true,
				kpi_id: '15',
				is_user_owned: true
			},
			{
				os: 'linux',
				type: 'server',
				is_pop: true,
				kpi_id: '1',
				is_user_owned: true
			},
			{ os: 'windows', type: 'server', kpi_id: '15', is_user_owned: false },
			{ os: 'linux', type: 'server', kpi_id: '1', is_user_owned: false },
			{ os: 'windows', type: 'server', kpi_id: '442', is_user_owned: true },
			{ os: 'linux', type: 'server', kpi_id: '402', is_user_owned: true },
			{ type: 'storage', kpi_id: '472' }
		]
	},
	{
		id: uuid(),
		category: 'CPU',
		label: 'Used CPU By Process',
		config: [
			{
				os: 'windows',
				type: 'server',
				is_pop: true,
				kpi_id: '454',
				is_user_owned: true
			},
			{
				os: 'linux',
				type: 'server',
				is_pop: true,
				kpi_id: '457',
				is_user_owned: true
			},
			{ os: 'windows', type: 'server', kpi_id: '454', is_user_owned: false },
			{ os: 'linux', type: 'server', kpi_id: '457', is_user_owned: false },
			{ os: 'windows', type: 'server', kpi_id: '18', is_user_owned: true },
			{ os: 'linux', type: 'server', kpi_id: '4', is_user_owned: true }
		]
	},
	{
		id: uuid(),
		category: 'Memory',
		label: 'Used Memory By Process',
		config: [
			{
				os: 'windows',
				type: 'server',
				is_pop: true,
				kpi_id: '455',
				is_user_owned: true
			},
			{
				os: 'linux',
				type: 'server',
				is_pop: true,
				kpi_id: '458',
				is_user_owned: true
			},
			{ os: 'windows', type: 'server', kpi_id: '455', is_user_owned: false },
			{ os: 'linux', type: 'server', kpi_id: '458', is_user_owned: false },
			{ os: 'windows', type: 'server', kpi_id: '19', is_user_owned: true },
			{ os: 'linux', type: 'server', kpi_id: '5', is_user_owned: true }
		]
	},
	{
		id: uuid(),
		category: 'DB',
		label: 'DB Deletes',
		config: [{ type: 'db', kpi_id: '405' }]
	},
	{
		id: uuid(),
		category: 'DB',
		label: 'DB Inserts',
		config: [{ type: 'db', kpi_id: '6' }]
	},
	{
		id: uuid(),
		category: 'DB',
		label: 'DB Selects',
		config: [{ type: 'db', kpi_id: '9' }]
	},
	{
		id: uuid(),
		category: 'DB',
		label: 'DB Updates',
		config: [{ type: 'db', kpi_id: '404' }]
	}
];

let chance = new Chance();

export function generate(from, to, resolution = 'hourly') {
	const fromInMs = new Date(from).getTime();
	const toInMs = new Date(to).getTime();

	const resolutionToMs = {
		live: 20000,
		hourly: 3600000,
		daily: 3600000 * 24,
		weekly: 3600000 * 24 * 7
	};
	const samples = [];

	for (
		let start = fromInMs;
		start < toInMs;
		start = start + resolutionToMs[resolution]
	) {
		const sample = chance.bool({ likelihood: 98 })
			? chance.floating({ min: 0, max: 3 })
			: null;

		samples.push({ x: new Date(start).toISOString(), y: sample });
	}

	return samples;
}

export function extractMeta(samples) {
	const min = minBy(samples, item => {
		return item.y;
	}).y;
	const max = maxBy(samples, item => {
		return item.y;
	}).y;
	const avg = meanBy(samples, item => {
		return item.y;
	});

	return { avg, min, max };
}

export function getPeriodic(from, to, resolution) {
	const toDate = to || new Date().toISOString();
	const companies = pilot.vendors.map(({ id }) => id);
	let processCounter = 1;
	return companies.map(c => {
		// timestamps may varry between serieses, add a random initial delay
		const values = ['Process A', 'Process B'].map(process => {
			const samples = generate(from, toDate, resolution);
			const { min, max, avg } = extractMeta(samples);
			return { id: processCounter++, name: process, min, max, avg, samples };
		});

		return { company_id: c, per_process: values.length !== 1, values };
	});
}

export const simulator = {
	x1: [
		{
			...metrics[0],
			children: [metrics[1], metrics[2], metrics[3]]
		},
		{
			...metrics[4],
			children: [metrics[5], metrics[6], metrics[7]]
		}
	],
	y: '100',
	cpp_id: uuid()
};
