export const OPEN = 'open';
export const FREE = 'free'; // flagged by back office user (admin panel) as free - no payment required
export const PENDING_APPROVAL = 'pending_approval';// pending => pendig_approval
export const PENDING_SUBSCR = 'pending_subscr'; // subscr_expired => pending_subscr
export const SUBSCRIBED = 'subscribed'; // approved => subscribed
export const MISSING_INFO = 'missing_info';
export const PROFILE_INCOMPLETE = 'profile_incomplete';
export const DENIED = 'denied';
export const MAX_PILOTS = 'max_pilots';
export const INVALID_REGION = 'invalid_region';
export const JOIN_DATE_DUE = 'join_date_due';
export const MAX_VENDORS = 'max_vendors';
export const FUTURE = 'future';
export const TERMINATED = 'terminated';
