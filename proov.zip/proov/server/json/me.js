export default {
	monetization: false,
	picture_url:
		'https://worldsummit.ai/wp-content/uploads/sites/4/2018/07/apple-logo-transparent.png',
	icon: 'https://www.iconsdb.com/icons/download/soylent-red/nike-16.ico',
	show_join_help: true,
	new_notifications_count: 2,
	new_messages_count: 1,
	privileges: {
		team_management: true,
	},
};
