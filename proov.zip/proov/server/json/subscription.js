export const essentials = {
	icon_type: 'starter',
	name: 'Premium',
	config: {
		limit_type: {
			limit: 'soft'
		},
		firewall: {
			limit: true
		},
		repository: {
			limit: false
		},
		reporting: {
			limit: true
		},
		vendor_access_control: {
			limit: true
		},
		dedicated: {
			limit: true
		},
		blockchain: {
			limit: true
		},
		safe_zone: {
			limit: true
		},
		red_cloud: {
			limit: false
		},
		service_catalog: {
			limit: true
		},
		har_mirroring: {
			limit: false
		},
		behavior_mirroring: {
			limit: false
		},
		deep_mirroring: {
			limit: true
		},
		support: {
			limit: 'DEDICATED_TEAM',
			contact: {
				name: 'Shirley Yaniv',
				phone: '+9725408226546',
				email: 'shirly.ya@proov.io',
				img: 'https://cloudinary.com/proov_support.png'
			}
		}
	},
	total: {
		generations: {
			limit: 10,
			usage: 10
		},
		instance: {
			limit: 2,
			usage: 54.0
		},
		business_kpi: {
			limit: 1,
			usage: 0
		},
		custom_params: {
			limit: null,
			usage: 38.0
		},
		users_count: {
			limit: 3,
			usage: 64.0
		},
		isvs_count: {
			limit: 2,
			usage: 64.0
		},
		security_rule: {
			limit: 1,
			usage: 64.0
		},
		db: {
			limit: 1,
			usage: 64.0
		},
		docker: {
			limit: null,
			usage: 64.0
		},
		server: {
			limit: null,
			usage: 64.0
		},
		storage: {
			limit: 1,
			usage: 64.0
		},
		api: {
			limit: 1,
			usage: 64.0
		},
		blockchain: {
			limit: null,
			usage: 64.0
		}
	}
};

export const advantage = {
	icon_type: 'starter',
	name: 'Premium',
	config: {
		limit_type: {
			limit: 'soft'
		},
		firewall: {
			limit: true
		},
		repository: {
			limit: false
		},
		reporting: {
			limit: true
		},
		vendor_access_control: {
			limit: true
		},
		dedicated: {
			limit: true
		},
		blockchain: {
			limit: true
		},
		safe_zone: {
			limit: true
		},
		red_cloud: {
			limit: false
		},
		service_catalog: {
			limit: true
		},
		har_mirroring: {
			limit: true
		},
		behavior_mirroring: {
			limit: true
		},
		deep_mirroring: {
			limit: true
		},
		support: {
			limit: 'DEDICATED_TEAM',
			contact: {
				name: 'Shirley Yaniv',
				phone: '+9725408226546',
				email: 'shirly.ya@proov.io',
				img: 'https://cloudinary.com/proov_support.png'
			}
		}
	},
	total: {
		generations: {
			limit: 10,
			usage: 10
		},
		instance: {
			limit: 5,
			usage: 54.0
		},
		business_kpi: {
			limit: 2,
			usage: 0
		},
		custom_params: {
			limit: null,
			usage: 38.0
		},
		users_count: {
			limit: 8,
			usage: 64.0
		},
		isvs_count: {
			limit: 5,
			usage: 64.0
		},
		security_rule: {
			limit: 3,
			usage: 64.0
		},
		db: {
			limit: 3,
			usage: 64.0
		},
		docker: {
			limit: null,
			usage: 64.0
		},
		server: {
			limit: null,
			usage: 64.0
		},
		storage: {
			limit: 2,
			usage: 64.0
		},
		api: {
			limit: 3,
			usage: 64.0
		},
		blockchain: {
			limit: 5,
			usage: 64.0
		}
	}
};

export const premier = {
	icon_type: 'starter',
	name: 'Premium',
	config: {
		limit_type: {
			limit: 'soft'
		},
		firewall: {
			limit: false
		},
		repository: {
			limit: true
		},
		reporting: {
			limit: true
		},
		vendor_access_control: {
			limit: false
		},
		dedicated: {
			limit: true
		},
		blockchain: {
			limit: true
		},
		safe_zone: {
			limit: true
		},
		red_cloud: {
			limit: false
		},
		service_catalog: {
			limit: true
		},
		har_mirroring: {
			limit: true
		},
		behavior_mirroring: {
			limit: true
		},
		deep_mirroring: {
			limit: true
		},
		support: {
			limit: 'DEDICATED_TEAM',
			contact: {
				name: 'Shirley Yaniv',
				phone: '+9725408226546',
				email: 'shirly.ya@proov.io',
				img: 'https://cloudinary.com/proov_support.png'
			}
		}
	},
	total: {
		generations: {
			limit: 10,
			usage: 0
		},
		instance: {
			limit: 12,
			usage: 0
		},
		business_kpi: {
			limit: 12,
			usage: 0
		},
		custom_params: {
			limit: 5,
			usage: 0
		},
		users_count: {
			limit: 7,
			usage: 0
		},
		isvs_count: {
			limit: 12,
			usage: 0
		},
		security_rule: {
			limit: 6,
			usage: 6
		},
		db: {
			limit: 5,
			usage: 0
		},
		docker: {
			limit: 12,
			usage: 0
		},
		server: {
			limit: 12,
			usage: 0
		},
		storage: {
			limit: 5,
			usage: 0
		},
		api: {
			limit: 8,
			usage: 0
		},
		blockchain: {
			limit: 5,
			usage: 0
		}
	}
};
