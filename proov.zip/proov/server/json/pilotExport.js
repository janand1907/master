/* eslint-disable camelcase */

export default {
	portfolio_name: '[proov] Adaptive Security Technology',
	update_date: '2016-11-22T13:00:55.998Z',
	link: 'http://www.proov.io',
	status: 'success'
};
