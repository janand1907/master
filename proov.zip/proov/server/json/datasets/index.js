import uuid from 'uuid';

export default [
	{
		id: uuid(),
		type: 'benchmark',
		name: 'Metropoline IoT',
		status: 'in_progress',
		entities_count: 10,
		downloadable: false
	},
	{
		id: uuid(),
		type: 'custom',
		name:
			'Hospital Infection Rates Hospital Infection Rates Hospital Infection Rates', // could be empty
		status: 'success',
		entities_count: 29,
		downloadable: true
	},
	{
		id: '8272bbd6-5e34-5e9d-abb6-322b5847219c',
		type: 'custom',
		name: 'Habitable Zone Planets', // could be empty
		status: 'success',
		entities_count: 29,
		downloadable: false
	},
	{
		id: uuid(),
		type: 'custom',
		name: 'Habitable Zone Planets', // could be empty
		status: 'new',
		entities_count: null,
		downloadable: false
	},
	{
		id: uuid(),
		type: 'benchmark',
		name: 'Metropoline IoT',
		status: 'in_progress',
		entities_count: 10,
		downloadable: false
	},
	{
		id: uuid(),
		type: 'custom',
		name:
			'Hospital Infection Rates Hospital Infection Rates Hospital Infection Rates', // could be empty
		status: 'success',
		entities_count: 29,
		downloadable: true
	},
	{
		id: uuid(),
		type: 'custom',
		name: 'Habitable Zone Planets', // could be empty
		status: 'success',
		entities_count: 29,
		downloadable: false
	},
	{
		id: uuid(),
		type: 'custom',
		name: 'Habitable Zone Planets', // could be empty
		status: 'new',
		entities_count: null,
		downloadable: false
	},
	{
		id: uuid(),
		type: 'custom',
		name: 'Go Green', // could be empty
		status: 'new',
		entities_count: null,
		downloadable: false
	}
];
