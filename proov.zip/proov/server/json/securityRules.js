import uniqid from 'uniqid';

export default [
	{ id: uniqid(), label: 'Rule A', rule: '10.0.0.1' },
	{ id: uniqid(), label: 'Rule B', rule: '10.0.0.1/24' },
	{ id: uniqid(), label: 'Rule C', rule: '10.0.10.1/36' },
	{ id: uniqid(), label: 'Rule D', rule: '10.0.20.1/36' },
	{ id: uniqid(), label: 'Rule F', rule: '10.0.0.24' }
];
