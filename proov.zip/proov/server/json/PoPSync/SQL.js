export default [
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-10 05:35:21.919752'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-10 04:18:32.331046'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-10 04:05:20.42604'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-10 03:50:32.838163'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-10 03:31:54.959023'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-07 05:12:31.079025'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-07 04:58:10.621163'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-07 04:42:20.647754'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-07 04:22:37.066093'
	},
	{
		isv_id: '35947547175645838f775c0d6dccd117',
		isv_db_user: 'proovuser1',
		query:
			"SELECT EVENT_NAME FROM information_schema.EVENTS WHERE EVENT_SCHEMA = 'proovdb'",
		timestamp: '2019-10-03 11:25:54.944555'
	}
];
