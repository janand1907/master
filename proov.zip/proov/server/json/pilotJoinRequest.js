/* eslint-disable camelcase */

import { vendor } from './company';

export default {
	id: '173345daf2637a243c0206fc184d481d15caacfb',
	pilot_id: '833a29c998d058db0d72c928d5be59f3b1159b1e',
	from_user_id: 54,
	from_company_id: vendor.id,
	from_company: vendor,
	created_at: '2017-02-21T09:33:18.173Z',
	is_paid: false,
	payment_id: null,
	self_evaluation: {
		'Vendor demonstration': -1,
		'Has paying customers': 4,
		'Low CPU usage': 4,
		'Low memory usage': 3
	},
	message: 'Tufut zik zitju ti macet emi ifi amej kutjawo omo zosub gu eh gebam vi soc ku.',
	status: 'pending'
};
