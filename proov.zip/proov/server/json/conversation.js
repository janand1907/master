/* eslint-disable camelcase */
import { pick } from 'lodash';
import { client } from './company';

const clientJson = pick(client, ['id', 'name', 'type', 'profile_image']);

export default [
	{
		id: 3211,
		company: { ...clientJson, name: 'Kaspersky Labs', profile_image: `/res/avatar/6a0734f18e6c09fd67936da99ede7505c2d1f7e1`, id: '6a0734f18e6c09fd67936da99ede7505c2d1f7e1' },
		created_at: '2056-03-29T13:31:38.302Z',
		updated_at: '2016-12-15T16:17:04.699Z',
		is_new: true,
		can_reply: true,
		snippet: 'Gi sos kufo sierome hitecepi ojuwoha cuzowo kawek jocjo kalvelir ekeku kelkurbam pa helde de...'
	},
	{
		id: 3425,
		company: { ...clientJson, name: 'Bank Hapoalim', profile_image: `/res/avatar/6407cbdb6c01de7e8fec4cc26855542ca46aa4a0`, id: '6407cbdb6c01de7e8fec4cc26855542ca46aa4a0' },
		created_at: '2056-03-29T13:31:38.302Z',
		updated_at: '2016-12-14T06:17:04.699Z',
		is_new: true,
		can_reply: true,
		snippet: 'Du fac puje cuj toroza witwo kulo sipmi ok we behmusi oski lupis.'
	},
	{
		id: 3323,
		company: { ...clientJson, name: 'Isracard', profile_image: `/res/avatar/1ae1ed7a3c298d3bbbbf5818a9e858063f15894e`, id: '1ae1ed7a3c298d3bbbbf5818a9e858063f15894e' },
		created_at: '2056-03-29T13:31:38.302Z',
		updated_at: '2016-12-14T06:17:04.699Z',
		is_new: true,
		can_reply: true,
		snippet: 'Hajkifbac ve men se heahosu lotse cepok ulube ofive vic wibuiwa oz co ha. Piz le kukdovva fijepte doaz jo...'
	},
	{
		id: 3928,
		company: { ...clientJson, name: 'Bank of America', profile_image: `/res/avatar/e62dd668b331911151f337c6b444da16406228a7`, id: 'e62dd668b331911151f337c6b444da16406228a7' },
		created_at: '2056-03-29T13:31:38.302Z',
		updated_at: '2016-12-06T06:17:04.699Z',
		is_new: false,
		can_reply: true,
		snippet: 'Rizosid jalalic ki vazpahu cu facil ohje dihotow ruhdaju vudpu haz azigez nohura wuecla nobmukmi.'
	},
	{
		id: 3422,
		company: { ...clientJson, name: 'AIG', profile_image: `/res/avatar/507ac8ed24edbb4831ea4d2ec361a2757c606c39`, id: '507ac8ed24edbb4831ea4d2ec361a2757c606c39' },
		created_at: '2064-07-30T12:59:15.491Z',
		updated_at: '2016-11-01T12:42:41.791Z',
		is_new: false,
		can_reply: false,
		snippet: 'Ti vifzeibi atpe!'
	}
];
