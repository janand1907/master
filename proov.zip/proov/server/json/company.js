/* eslint-disable camelcase */

export const vendor = {
	id: 'b9a3f491e64b4d8c85000e4031f6d18f',
	type: 'vendor',
	created_at: '2016-01-26T05:24:27.428Z',
	updated_at: '2016-09-25T12:57:25.481Z',
	name: 'Boston Dynamics',
	profile_image: '/res/avatar/b9a3f491e64b4d8c85000e4031f6d18f?v=1234',
	about:
		'Giwopocec ohcizgor vamino oziciw ga \n pudam iz kulke lijacah newdihamu azdosid cimmez adaduuro ocpul lufubkih jim ame fuzeftow. Ido fo tujoluc maenof tafzip duc poeglo pu efitomhu kialrow ugigucur gejti utunom jassi lekukaca ini vaoz.\n Ari hu cud repemec ojboru orene cive ladbejez hiovibo ni igdim ita. Mawow vedcamja mi wemoj no vurondij ruvdeiv hitrajume vonup ufdi owicifuv fehazduj igo pan vev.',
	founded: 2006,
	website: 'http://wimkazah.bb/neh',
	industry: [47, 'Accounting'],
	country: ['Albania', 'Albania'],
	allow_suggestions: true,
	size: [501, '501-1000 Employees'],
	tags: ['bi', 'solutions'],
	oneliner:
		'Ewlap wekril wibereda wer kedo keubomad nu zop worik comasolez zilmime ajdamjoz huron.',
	resources: [
		{
			version: 1,
			id: '12345',
			url: 'www.flickr.com',
			resource_type: 'image',
			format: 'jpg',
			bytes: 1200000,
			title: 'company image'
		}
	],
	pilot_count_completed: 0,
	pilot_count_ongoing: 0,
	rating: 4.3,
	version: 1,
	category: null,
	top_customers: ['IBM'],
	awards: ['some award 1', 'some award 2'],
	patents: [
		{
			title: 'patent 1',
			url: 'www.google.com'
		},
		{
			title: 'patent 2',
			url: 'www.google.com'
		}
	],
	funding: {
		stage: ['0bootstrapped', 'Bootstrapped'],
		total: 870000,
		num_investors: 4,
		recent_month: 10,
		recent_year: 2016
	}
};

export const participants = [
	{
		id: '35947547175645838f775c0d6dccd117',
		type: 'vendor',
		created_at: '2016-01-26T05:24:27.428Z',
		updated_at: '2016-09-25T12:57:25.481Z',
		name: 'The Boring Company',
		profile_image: '/res/avatar/35947547175645838f775c0d6dccd117?v=1234',
		about:
			'Giwopocec ohcizgor vamino oziciw ga \n pudam iz kulke lijacah newdihamu azdosid cimmez adaduuro ocpul lufubkih jim ame fuzeftow. Ido fo tujoluc maenof tafzip duc poeglo pu efitomhu kialrow ugigucur gejti utunom jassi lekukaca ini vaoz.\n Ari hu cud repemec ojboru orene cive ladbejez hiovibo ni igdim ita. Mawow vedcamja mi wemoj no vurondij ruvdeiv hitrajume vonup ufdi owicifuv fehazduj igo pan vev.',
		founded: 2006,
		website: 'https://www.boringcompany.com/',
		industry: [47, 'Accounting'],
		country: ['Albania', 'Albania'],
		allow_suggestions: true,
		size: [501, '501-1000 Employees'],
		tags: ['bi', 'solutions'],
		oneliner:
			'Ewlap wekril wibereda wer kedo keubomad nu zop worik comasolez zilmime ajdamjoz huron.',
		resources: [
			{
				version: 1,
				id: '12345',
				url: 'www.flickr.com',
				resource_type: 'image',
				format: 'jpg',
				bytes: 1200000,
				title: 'company image'
			}
		],
		pilot_count_completed: 0,
		pilot_count_ongoing: 0,
		rating: 4.3,
		version: 1,
		category: null,
		top_customers: ['IBM'],
		awards: ['some award 1', 'some award 2'],
		patents: [
			{
				title: 'patent 1',
				url: 'www.google.com'
			},
			{
				title: 'patent 2',
				url: 'www.google.com'
			}
		],
		funding: {
			stage: ['0bootstrapped', 'Bootstrapped'],
			total: 870000,
			num_investors: 4,
			recent_month: 10,
			recent_year: 2016
		}
	},
	{
		id: '5e7e3e2fd6ef46268dc173726b4d9869',
		type: 'vendor',
		created_at: '2016-01-26T05:24:27.428Z',
		updated_at: '2016-09-25T12:57:25.481Z',
		name: 'Tesla',
		profile_image: '/res/avatar/5e7e3e2fd6ef46268dc173726b4d9869?v=1234',
		about:
			'Giwopocec ohcizgor vamino oziciw ga \n pudam iz kulke lijacah newdihamu azdosid cimmez adaduuro ocpul lufubkih jim ame fuzeftow. Ido fo tujoluc maenof tafzip duc poeglo pu efitomhu kialrow ugigucur gejti utunom jassi lekukaca ini vaoz.\n Ari hu cud repemec ojboru orene cive ladbejez hiovibo ni igdim ita. Mawow vedcamja mi wemoj no vurondij ruvdeiv hitrajume vonup ufdi owicifuv fehazduj igo pan vev.',
		founded: 2006,
		website: 'https://www.tesla.com/',
		industry: [47, 'Accounting'],
		country: ['Albania', 'Albania'],
		allow_suggestions: true,
		size: [501, '501-1000 Employees'],
		tags: ['bi', 'solutions'],
		oneliner:
			'Ewlap wekril wibereda wer kedo keubomad nu zop worik comasolez zilmime ajdamjoz huron.',
		resources: [
			{
				version: 1,
				id: '12345',
				url: 'https://www.tesla.com/',
				resource_type: 'image',
				format: 'jpg',
				bytes: 1200000,
				title: 'company image'
			}
		],
		pilot_count_completed: 0,
		pilot_count_ongoing: 0,
		rating: 4.3,
		version: 1,
		// category: [2491, 'BI'],
		category: null,
		top_customers: ['IBM'],
		awards: ['some award 1', 'some award 2'],
		patents: [
			{
				title: 'patent 1',
				url: 'www.google.com'
			},
			{
				title: 'patent 2',
				url: 'www.google.com'
			}
		],
		funding: {
			// stage: ['seed', 'Seed'],
			stage: ['0bootstrapped', 'Bootstrapped'],
			total: 870000,
			num_investors: 4,
			recent_month: 10,
			recent_year: 2016
		}
	}
];

export const client = {
	id: 'b9a3f491e64b4d8c85000e4031f6d18f',
	created_at: '2016-01-26T05:24:27.428Z',
	updated_at: '2016-09-25T12:57:25.481Z',
	profile_image: '/res/avatar/b9a3f491e64b4d8c85000e4031f6d18f?v=1234',
	about:
		'Giwopocec ohcizgor vamino oziciw ga \n pudam iz kulke lijacah newdihamu azdosid cimmez adaduuro ocpul lufubkih jim ame fuzeftow. Ido fo tujoluc maenof tafzip duc poeglo pu efitomhu kialrow ugigucur gejti utunom jassi lekukaca ini vaoz.\n Ari hu cud repemec ojboru orene cive ladbejez hiovibo ni igdim ita. Mawow vedcamja mi wemoj no vurondij ruvdeiv hitrajume vonup ufdi owicifuv fehazduj igo pan vev.',
	founded: 2006,
	website: 'http://wimkazah.bb/neh',
	industry: [47, 'Accounting'],
	country: ['Albania', 'Albania'],
	size: [501, '501-1000 Employees'],
	tags: ['bi', 'solutions'],
	oneliner:
		'Ewlap wekril wibereda wer kedo keubomad nu zop worik comasolez zilmime ajdamjoz huron.',
	resources: [
		{
			version: 1,
			id: '12345',
			url: 'www.flickr.com',
			resource_type: 'image',
			format: 'jpg',
			bytes: 1200000,
			title: 'company image'
		}
	],
	pilot_count_completed: 0,
	pilot_count_ongoing: 0,
	rating: 4.3,
	version: 1,
	type: 'client',
	name: 'Kaspersky Labs',
	allow_suggestions: false,
	pilots: [
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		},
		{
			category: [2491, 'BI'],
			company_id: 'beb285138f1249d2a71fb8424fd508a7',
			company_name: 'Mastermind',
			country: ['Albania', 'Albania'],
			snippet: 'testtesttest',
			id: 'a80f8e69fd7837b9f18dba1d6966d79ed31fc669',
			name:
				'Nulej adgoh tepsode kow lawusid lumamohav eme nabvope tu tammoilo neru roleji.',
			profile_image: null,
			industry: [47, 'Accounting']
		}
	]
};

export const companies = [participants, client, vendor];

export default vendor;
