import { find } from 'lodash';
import { participants } from './company';
import DBs from './channels/lab/database';
import APIs from './channels/lab/API';
import { metrics, endpoints } from './analytics';

export default {
	config: {
		fj90ewr: {
			type: 'serial_metric',
			channelId: DBs[0].id,
			endpointLabel: null,
			metricId: metrics[12].id,
			selectedVendors: participants.map(({ id }) => id)
		},
		x24khjr: {
			type: 'serial_metric',
			channelId: DBs[0].id,
			endpointLabel: null,
			metricId: metrics[10].id,
			selectedVendors: participants.map(({ id }) => id)
		},
		j3409hl: {
			type: 'serial_metric',
			channelId: APIs[0].id,
			endpointLabel: APIs[0].endpoints[0],
			metricId: endpoints[0].id,
			selectedVendors: participants.map(({ id }) => id)
		},
		j3409h9: {
			type: 'serial_metric',
			channelId: null,
			endpointLabel: null,
			metricId: find(metrics, metric => (metric.category = 'Business KPI')).id,
			selectedVendors: participants.map(({ id }) => id)
		},
		xcv1df3: {
			type: 'table',
			channelId: null,
			endpointLabel: null,
			metricId: find(metrics, metric => (metric.category = 'Business KPI')).id,
			selectedVendors: participants.map(({ id }) => id)
		},
		v1xas3i: {
			type: 'vector',
			channelId: null,
			endpointLabel: null,
			metricId: find(metrics, metric => (metric.category = 'Business KPI')).id,
			selectedVendors: participants.map(({ id }) => id)
		},
		n1xala3: {
			type: 'custom_chart',
			channelId: null,
			endpointLabel: null,
			metricId: find(metrics, metric => (metric.category = 'Business KPI')).id,
			selectedVendors: participants.map(({ id }) => id)
		}
	},
	order: [
		'fj90ewr',
		'x24khjr',
		'j3409hl',
		'j3409h9',
		'xcv1df3',
		'v1xas3i',
		'n1xala3'
	]
};
