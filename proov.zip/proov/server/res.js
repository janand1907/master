import express from 'express';
import request from 'request';

const router = express.Router();

// const sizes = {
// 	default: 80,
// 	large: 148,
// 	small: 96,
// 	mini: 48
// };

router
	.route(`/avatar/:id`)
	.get((req, res) => {
		// let width = sizes.default, hires = false;
		let size = req.query.s || req.query.size;
		// if (size) {
		// 	if (size.substr(-3) === '@2x') {
		// 		hires = true;
		// 		size = size.substr(0, size.length - 3);
		// 	}
		// 	if (parseInt(size) == size) {
		// 		width = parseInt(size);
		// 	} else if (sizes.hasOwnProperty(size)) {
		// 		width = sizes[size];
		// 	}
		// }
		// if (hires) { width *= 2 }

		const url = `http://www.gravatar.com/avatar/${req.params.id}?d=retro&s=${size}`;
		// const url = `https://api.adorable.io/avatars/${size}/${req.params.id}`;
		// res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
		// res.header('Expires', '-1');
		// res.header('Pragma', 'no-cache');
		request.get(url).pipe(res);
	});

export default router;
