/* eslint-disable camelcase */

import { enterprise, startups } from '../json/auth';
import { error, ok } from '../utils';

const errors = {
	secret: `Password length must be between 8-12 characters.`
};

const validatePassword = pwd => pwd.length >= 8 && pwd.length <= 12;

export default router => {
	// /auth/login
	router.route('/auth/login').post((req, res) => {
		if (req.body.auth_type === 'linkedin' && req.body.code) {
			const resJson = enterprise;
			// add linkedin data to response
			resJson.auth_type = 'linkedin';
			resJson.auth_token = 'linkedinRecivedAccessToken1234';

			req.session.user = resJson;
			res.json(resJson);
		} else if (!validatePassword(req.body.secret)) {
			res.status(400);
			res.json(error('Invalid data.', 'ValidationError', { 'payload.secret': errors.secret }));
		} else if (
			(req.body.email !== enterprise.email && startups.find(startup => startup.email === req.body.email)) ||
			req.body.secret != '12341234'
		) {
			res.status(400);
			res.json(error(`Whoops, there's no match.`, 'AuthError'));
		} else {
			const json =
				req.body.email === enterprise.email
					? enterprise
					: startups.find(startup => startup.email === req.body.email);
			req.session.user = json;
			res.json(json);
		}
	});

	router.route('/auth/login/:company_id').post((req, res) => {
		const json =
			req.params.company_id === enterprise.company_id
				? enterprise
				: startups.find(startup => startup.company_id === req.params.company_id);
		req.session.user = json;
		res.json(json);
	});

	// /auth/logout
	router.route('/auth/logout').post((req, res) => {
		req.session.destroy();
		res.json(ok('Bye bye!'));
	});

	// /auth/register and register-lead
	router.route('/auth/register').post((req, res) => {
		res.json(
			ok(
				'We review each request individually. Rube wenjiz rocudbi al tac kem muas imi gemmooc eczeknuz enojowuk furi ehurakuwi.'
			)
		);
	});

	// /auth/validate_password
	router.route('/auth/validate_password').post((req, res, next) => {
		if (validatePassword(req.body.password)) {
			res.json(ok('Password seems ok.'));
		} else {
			res.status(400).json(error(errors.password, 'InvalidPasswordError'));
		}
	});
	// /auth/validate_email
	router.route('/auth/validate_email').post((req, res, next) => {
		if (validatePassword(req.body.email)) {
			res.json(ok('Email seems ok.'));
		} else {
			res.status(400).json(error(errors.password, 'InvalidEmailError'));
		}
	});

	// /auth/password
	router.route('/auth/password').post((req, res) => {
		res.json(
			ok(
				`Your request has been received! Shortly, we will send you an email with instructions on how to reset your password.`
			)
		);
	});

	router.route('/auth/reset_password').get((req, res) => {
		res.status(200);
		res.json({ email: 'tomerlevi@proov.io', password: 'NDF1X5SJ7' });
	});

	// .get((req, res) => {
	// 	const { email, full_name, profile_image } = req.session.user;
	// 	res.json({ email, full_name, profile_image });
	// })
	// .put((req, res) => {
	// 	if (validatePassword(req.body.new_password)) {
	// 		res.json(ok('Password changed succesfully.'));
	// 	} else {
	// 		res.status(400);
	// 		res.json(error('Invalid data.', 'ValidationError', { new_password: errors.password }));
	// 	}
	// });
};
