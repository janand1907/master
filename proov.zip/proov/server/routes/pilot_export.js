/* eslint-disable camelcase */
import catalogJson from '../json/pilotExport';
import { ok, requireAuth } from '../utils';

export default (router) => {

	router.all(`/pilot_export*`, requireAuth);

	// /pilot_export
	router
		.route(`/pilot_export`)
		.post((req, res) => {
			res.json(ok('Changes saved.'));
		});

	// /pilot_export/:id
	router
		.route(`/pilot_export/:id`)
		.get((req, res) => {
			res.json(catalogJson);
		});
};
