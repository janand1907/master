/* eslint-disable camelcase */

import pcapFiles from '../json/pcapFiles';
import { activity } from '../json/networkActivity';
import { requireAuth } from '../utils';

export default router => {

	router.all(`/bm*`, requireAuth);

	router
		.route(`/bm/:pilot_id/activity`)
		.get((req, res) => {
			res.status(200);
			res.json(activity);
		});

	router
		.route(`/bm/:id/generate`)
		// generate pcap file
		.post((req, res) => {
			const file = pcapFiles.filter(file => file.id === req.params.id)[0];
			res.status(201);
			res.json({ ...file, multiplier: 0 });
		});
};
