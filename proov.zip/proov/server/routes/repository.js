/* eslint-disable camelcase */
import uuidv1 from 'uuid/v1';
import pcapFiles from '../json/pcapFiles';
import harFiles from '../json/harFiles';
import SQL from '../json/PoPSync/SQL';
import HTTP from '../json/PoPSync/HTTP';
import dm from '../json/datasets';
import { ok } from '../utils';
import securityRules from '../json/securityRules';

export default router => {
	// Get Security Rules list
	router
		.route('/repository/security-rules')
		.get((req, res) => {
			res.json(securityRules);
		})
		.post((req, res) => {
			const { label, rule } = req.body;
			res.status(201).json({
				id: uuidv1(),
				label,
				rule
			});
		})
		.patch((req, res) => {
			const { label, rule } = req.body;
			res.status(201).json({
				label,
				rule
			});
		});

	router.route('/repository/security-rules/:id').patch((req, res) => {
		const { label, rule } = req.body;
		const { id } = req.params;
		res.status(201).json({
			id,
			label,
			rule
		});
	});

	// Get dataset list
	router.route('/repository/dm').get((req, res) => {
		res.json(dm);
	});

	// Get PCAP file list
	router
		.route('/repository/bm')
		.get((req, res) => {
			res.json(pcapFiles);
		})
		// Upload .pcap file
		.post((req, res) => {
			const { name, original_ips } = req.body;
			res.status(200).json({
				id: uuidv1(),
				file_name: name,
				meta: {
					original_ips
				},
				status: 'in_progress',
				is_generated: false,
				type: 'pcap',
				date_created: new Date('1/25/2016'),
				size: 512
			});
		});

	// Generate from .pcap file
	router.route('bm/:id/generate').post((req, res) => {
		res.status(200).json({
			id: req.params.id,
			file_name: 'gererated.pcap',
			meta: null,
			status: 'ready',
			is_generated: true,
			type: 'pcap',
			date_created: new Date('1/25/2016'),
			size: 512
		});
	});

	// Get .har files list
	router.route('/repository/har').get((req, res) => {
		res.json(harFiles);
	});

	router
		.route('/repository/:id/generate')
		// Generate From HAR file
		.post((req, res) => {
			const { file_name } = req.body;
			res.status(200).json({
				id: req.params.id,
				file_name,
				date_created: new Date('1/25/2016'),
				status: 'in_progress',
				type: 'har',
				is_generated: false,
				size: 178
			});
		});

	router.route('/repository/:id').delete((req, res) => {
		switch (req.query.type) {
			case 'security_rule':
				res.json(ok('security rule deleted successfully'));
				break;
			case 'dataset':
				res.json(ok('dataset deleted successfully'));
				break;
			case 'har':
				res.json(ok('har file deleted successfully'));
				break;
			case 'pcap':
				res.json(ok('pcap file deleted successfully'));
				break;
		}
	});

	router
		.route('/popsync/db-queries/:channelId')
		.get((req, res) => {
			let { keyword, limit, skip } = req.query;
			let queries = SQL;

			if (!limit) {
				limit = 20;
			}
			if (!skip) {
				skip = 0;
			}
			if (keyword) {
				queries = SQL.filter(({ query }) => query.includes(keyword));
			}
			res.status(200).json(queries.slice(0, 0 + limit));
		})
		.post((req, res) => {
			res.status(200).json(ok('Changes saved.'));
		});

	router
		.route('/popsync/api-calls/:channelId')
		.get((req, res) => {
			let { keyword, limit, skip } = req.query;
			let queries = HTTP;

			if (!limit) {
				limit = 20;
			}
			if (!skip) {
				skip = 0;
			}
			if (keyword) {
				queries = HTTP.filter(({ query }) => query.includes(keyword));
			}
			res.status(200).json(queries.slice(0, 0 + limit));
		})
		.post((req, res) => {
			res.status(200).json(ok('Changes saved.'));
		});
};
