/* eslint-disable camelcase */
import { ok } from '../utils';

export default router => {
	router.route('/signup/aws').post((req, res) => {
		res.json(ok('registration completed successfully'));
	});

	// signup/register and register-lead
	router.route('/signup/register').post((req, res) => {
		res.json(
			ok(
				'We review each request individually. Rube wenjiz rocudbi al tac kem muas imi gemmooc eczeknuz enojowuk furi ehurakuwi.'
			)
		);
	});

	router.route('/signup/aws-sc').post((req, res) => {
		res.json(ok('registration completed successfully'));
	});

	// signup/signup-linkedin and fill form with linkedin user detals
	router.route(`/signup/linkedin`).post((req, res) => {
		res.status(200).json({
			emailAddress: 'jorge.borges@post.com',
			companyName: 'Bioclinica',
			companySize: '1001-5000',
			firstName: 'Luis',
			lastName: 'Borges',
			linkedinuuid: 'xZWpeozuVM'
		});
	});
};
