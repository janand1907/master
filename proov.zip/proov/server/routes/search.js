/* eslint-disable camelcase */
import { searchJson, suggestionsJson } from '../json/search';
import datasets from '../json/datasets';
import pcapFiles from '../json/pcapFiles';
import { requireAuth } from '../utils';

export default router => {

	router.all(`/search/*`, requireAuth);

	/**
    * Search for Deep mirroring datasets in marketplace
	* Filter and sort
 	*/
	 router
	 .route(`/search/deep-mirroring`)
	 .get((req, res) => { res.json(datasets) });

	/**
    * Search for Behavior mirroring pcap file
	* Filter and sort
 	*/
	 router
	 .route(`/search/behavior-mirroring`)
	 .get((req, res) => { res.json(pcapFiles) });


	router
		.route(`/search/:type/suggest`)
		.get((req, res) => { res.json(suggestionsJson) });

	router
		.route(`/search/:type/suggest/:id/hide`)
		.patch((req, res) => {
			res.json(suggestionsJson.filter(item => {
				return item.id || (item.ref !== req.params.id);
			}));
		});

	router
		.route('/search/:type')
		.get((req, res) => {
			let offset = Number(req.query.skip);
			let data = searchJson[req.params.type].data.slice(offset, (Number(req.query.skip) + Number(req.query.limit)));
			let metadata = searchJson[req.params.type].metadata;
			metadata.offset = offset;
			metadata.skip = offset;
			res.json({ data, metadata });
		});


	/**
    * Search for Behavior mirroring pcap files in marketplace
	* Filter and sort
 	*/
	// router
	// 	.route(`/search/behavior-mirroring`)
	// 	.get((req, res) => { res.json(pcapFiles) });


};
