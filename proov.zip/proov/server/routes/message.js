import { requireAuth, error } from '../utils';
import messageArr from '../json/message';
import mediaJson from '../json/media';

export default router => {

	router.all(`/message*`, requireAuth);

	// /message
	router.post(`/message`, (req, res) => {
		// res.status(400).json(error('Validation failed', 'ValidationError', {
		// 	'payload.message': 'Message can be up to 1000 characters'
		// }));

		/* eslint-disable camelcase */
		let msg = {
			...messageArr[0],
			id: Math.floor(Math.random() * 10000 + 1000),
			created_at: new Date().toISOString(),
			message: req.body.message,
			attachment: req.body.attachment
				? { ...mediaJson, id: req.attachment }
				: null
		};
		/* eslint-enable camelcase */

		res.status(201).json(msg);
	});

};
