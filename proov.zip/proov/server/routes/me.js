import { pick } from 'lodash';
import authJson from '../json/auth';
import promotionJson from '../json/promotion';
import flags from '../json/me';
import * as pilots from '../json/pilots';
import { searchJson } from '../json/search';
import { usagePerPilot, premier, exceeded } from '../json/subscription';
import { ok, requireAuth } from '../utils';

export default (router) => {
	router.all(`/me/*`, requireAuth);

	// /me/ping (previously /auth/ping)
	router.route('/me/ping').get((req, res) => {
		res.json(req.session.user);
	});

	// /me/user
	router.use('/me/user', (req, res) => {
		req.url = `/user/${authJson.id}`;
		router.handle(req, res);
	});

	// /me/company
	router.use('/me/company', (req, res) => {
		req.url = `/company/${authJson.company_id}`;
		router.handle(req, res);
	});

	router.route('/me/recommended/companies').get((req, res) => {
		res.json(
			searchJson[
				req.session.user.company_type === 'vendor' ? 'client' : 'vendor'
			].data.slice(0, 6)
		);
	});

	router.route('/me/recommended/pilots').get((req, res) => {
		res.json(searchJson.pilot.data.slice(0, 5));
	});

	// /me/promotion/:id
	router.route('/me/promotion/:id').get((req, res) => {
		res.json(promotionJson);
	});

	// /me/promotion/:id
	router.route('/me/promotion').get((req, res) => {
		res.json(promotionJson);
	});

	// /me/pilots
	router.route('/me/pilots').get((req, res) => {
		res.json(Object.values(pilots));
	});

	// /me/pilots/:id
	router.route('/me/pilots/:id').get((req, res) => {
		req.url = `/pilot/${req.params.id}`;
		router.handle(req, res);
	});

	// /me/flags
	router
		.route('/me/flags')
		.get((req, res) => {
			const defaultFields = [
				'monetization',
				'show_join_help',
				'new_notifications_count',
				'new_messages_count',
				'privileges',
			];
			const fields = req.query.fields
				? req.query.fields.split(',')
				: defaultFields;
			const json = pick(flags, fields);
			res.json(json);
		})
		.patch((req, res) => {
			res.json(ok('Changes saved.'));
		});

	// /me/subscription
	router.route('/me/subscription').get((req, res) => {
		res.json(premier);
	});

	// router.route('/me/subscription/usage').get((req, res) => {
	// 	res.json(premier);
	// });
	router.route('/me/subscription/usage/:pilot_id').get((req, res) => {
		res.json(usagePerPilot);
	});
};
