import { pick, filter, sampleSize } from 'lodash';
import { lookups as lookupsJson, tags as tagsArray } from '../json/common';
import { ok, error, requireAuth } from '../utils';

export default router => {

	// /common/lookups/:type
	router
		.route(`/common/lookups/:type`)
		.get((req, res) => {
			if (!lookupsJson.hasOwnProperty(req.params.type)) {
				res.status(404).json(error('Lookup could not be found.'));
			} else {
				res.json(lookupsJson[req.params.type]);
			}
		});

	// /common/lookups
	router
		.route(`/common/lookups`)
		.get(requireAuth, (req, res) => {
			let json = {};
			if (req.query.types) {
				json = pick(lookupsJson, req.query.types.split(','));
			}
			res.json(json);
		});

	// /common/tags/suggest
	router
		.route(`/common/tags/suggest`)
		.get(requireAuth, (req, res) => {
			let tags = !req.query.keyword ?
				tags :
				filter(tagsArray, t => t.toLowerCase().indexOf(req.query.keyword.toLowerCase()) > -1);
			tags = sampleSize(tags, 10);
			res.json(tags);
		});

	// /common/eval_criteria/suggest
	router
		.route(`/common/eval_criteria/suggest`)
		.get(requireAuth, (req, res) => {
			let tags = !req.query.keyword ?
				tags :
				filter(tagsArray, t => t.toLowerCase().indexOf(req.query.keyword.toLowerCase()) > -1);
			tags = sampleSize(tags, 10);
			res.json(tags);
		});

	// Request Support
	router
		.route(`/common/contact_support`)
		.post((req, res) => {
			res.json(ok('Request Recived'));
		});

};
