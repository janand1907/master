/* eslint-disable camelcase */

import { vendorNotifications, clientNotifications } from '../json/notification';
import { take, requireAuth, ok } from '../utils';

export default (router) => {

	router.all(`/message*`, requireAuth);

  // /notification
	router
		.route(`/notification`)
		.get((req, res) => {
			const { company_type } = req.session.user;
			res.json(take(company_type === 'client' ? clientNotifications : vendorNotifications, parseInt(req.query.limit), parseInt(req.query.skip)));
		});

	// /notification/:id/mark_as_read
	router
		.route(`/notification/:id/mark_as_read`)
		.patch((req, res) => {
			res.json(ok('Changes saved.'));
		});
};
