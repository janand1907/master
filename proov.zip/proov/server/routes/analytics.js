/* eslint-disable camelcase */
import uuid from 'uuid';
import { requireAuth, ok, error } from '../utils';
import {
	metrics,
	customGraphMetrics,
	endpoints,
	customParameters,
	standardParameters,
	simulator,
	getPeriodic,
	charts
} from '../json/analytics';

const base = `/pilot/:id/analytics`;

export default router => {
	router.all(`${base}*`, requireAuth);

	function getRandomInt(max) {
		return Math.floor(Math.random() * Math.floor(max));
	}
	//For development
	router.post(`/prediction`, (req, res) => {
		const [x, y] = Object.values(req.body.params);
		const val = (x * x + y * y) / 11000 + 150;
		res.json({ predictedValue: val, predictionError: getRandomInt(5) });
	});

	// /pilot/:id/analytics/validate/metric
	router.route(`${base}/validate/metric`).post((req, res) => {
		// Dummy validation.
		if (req.body.expression === 'lambda' || req.body.expression === 'system') {
			res.status(400).json(
				req.body.expression === 'lambda'
					? error('Expression not valid', 'LambdaError', {
						message: 'Expression not valid',
						error_type: 'LambdaError'
					  })
					: error('error_type', 'SystemError', {
						message: 'Server is down',
						error_type: 'SystemError'
					  })
			);
		} else {
			res.json(ok('Expression is ok.'));
		}
	});

	// /pilot/:id/analytics/validate/parameter
	router.route(`${base}/validate/parameter`).post((req, res) => {
		// Dummy validation.
		if (
			(req.body.locator.type === 'db' && req.body.locator.port === '1') ||
			req.body.locator.port === '2' ||
			(req.body.locator.type === 'api' && req.body.locator.url.length === 0)
		) {
			res.status(400).json(
				req.body.locator.port === '1'
					? error('Expression not valid', 'LambdaError', {
						message: 'Expression not valid',
						error_type: 'LambdaError'
					  })
					: error('Server is down', 'SystemError', {
						message: 'Server is down',
						error_type: 'SystemError'
					  })
			);
		} else {
			const response = {
				result: 10
			};
			res.status(201).json(response);
		}
	});

	// /pilot/:id/analytics/metrics/:id
	router.route(`${base}/metrics/:metricId`).delete((req, res) => {
		res.json(ok('Metric deleted successfully.'));
	});

	// /pilot/:id/analytics/metrics?channel_id=123
	router
		.route(`${base}/metrics`)
		.get((req, res) => {
			let filteredMetrics;
			if (req.query.channel_id) {
				if (req.query.endpoint_label) {
					filteredMetrics = endpoints;
				} else {
					filteredMetrics = metrics.filter(
						m => m.category !== 'Business KPI' && m.category !== 'Custom Graph'
					);
				}
			} else {
				filteredMetrics = metrics.filter(m => m.category !== 'Custom Graph');
			}

			res.json(filteredMetrics);
		})
		.post((req, res) => {
			const { label, description, expression, expression_type } = req.body;

			if (label.length < 3 || description.length < 3) {
				res
					.status(400)
					.json(
						error(
							'Invalid formula. For additional information, refer to f(x)',
							'ValidationError',
							{ 'payload.expression': 'Invalid formula' }
						)
					);
			} else {
				const created = {
					id: uuid(),
					label,
					description,
					category: 'Business KPI',
					unit: '',
					range: [0, 100],
					expression,
					expression_type
				};
				res.status(201).json(created);
			}
		});

	// /pilot/:id/analytics/metrics/:metricId/edit
	router.route(`${base}/metrics/:metricId/edit`).patch((req, res) => {
		const { label, description, expression, expression_type } = req.body;

		if (label.length < 3 || description.length < 3) {
			res
				.status(400)
				.json(
					error(
						'Invalid formula. For additional information, refer to f(x)',
						'ValidationError',
						{ 'payload.expression': 'Invalid formula' }
					)
				);
		} else {
			const created = {
				id: uuid(),
				label,
				description,
				category: 'Business KPI',
				unit: '',
				range: [0, 100],
				expression,
				expression_type
			};
			res.status(201).json(created);
		}
	});

	// /pilot/:id/analytics/charts
	router.route(`${base}/custom-charts`).get((req, res) => {
		res.status(200).json(charts);
	});

	// /pilot/:id/analytics/charts
	router.route(`${base}/custom-charts`).post((req, res) => {
		const { label } = req.body;

		if ((label || '').length < 3) {
			res.status(400).json(
				error('Error Message', 'ValidationError', {
					'payload.label': 'Invalid label'
				})
			);
		} else {
			const created = {
				result: 201
			};
			res.status(201).json(created);
		}
	});

	router.route(`${base}/custom-charts/metrics`).get((req, res) => {
		res.json(customGraphMetrics);
	});

	// /pilot/:id/analytics/charts/:id
	router.route(`${base}/custom-charts/:chartId`).delete((req, res) => {
		res.json(ok('Chart deleted successfully.'));
	});

	router.route(`${base}/metrics/:metricId`).patch((req, res) => {
		const created = {
			description: req.body.description,
			success_criteria: req.body.success_criteria
		};
		res.status(201).json(created);
	});

	// /pilot/:id/analytics/parameters
	router
		.route(`${base}/parameters`)
		.get((req, res) => {
			const parameters = [...standardParameters, ...customParameters];
			res.json(parameters);
		})
		.post((req, res) => {
			if (req.body.label === 'error') {
				res.status(400).json(
					error(
						'Connection to the db was failed, please verify the provided information',
						'ValidationError',
						{
							'payload.locator.url': 'Invalid url',
							'payload.auth.password': 'Invalid password'
						}
					)
				);
			} else {
				const created = {
					id: uuid(),
					name: '$456',
					label: 'test',
					category: 'Custom',
					unit: '?'
				};
				res.status(201).json(created);
			}
		});

	router.route(`${base}/metrics/export`).post((req, res) => {
		if (!req.body) {
			res.status(400).json(
				error('Invalid credentials', 'LambdaError', {
					message: 'Missing credentials information, please check again',
					error_type: 'LambdaError'
				})
			);
		} else {
			res.json(ok('Expression is ok.'));
		}
	});
	// /pilot/:id/analytics/metrics/:metricId/simulator
	router.get(`${base}/metrics/:metricId/simulator`, (req, res) => {
		res.json(simulator);
	});

	// /pilot/:id/analytics/metrics/:metricId/periodic
	router.get(`${base}/metrics/:metricId/periodic`, (req, res) => {
		const { from, to, resolution } = req.query;
		const body = getPeriodic(from, to, resolution);
		res.json(body);
	});

	// /pilot/:id/analytics/metrics/:metricId/calculate-now
	router.route(`${base}/:metricId/calculate-now`).post((req, res) => {
		res.json(ok('metric data re-calculated successfully'));
	});
};
