/* eslint-disable camelcase */
import { serviceCatalog } from '../json/pilotExport';
import { ok, requireAuth } from '../utils';

export default (router) => {

	router.all(`/join_request*`, requireAuth);

	//accept join [pilot request
	router
		.route(`/pilot_export`)
		.post((req, res) => {
			res.json(ok('Changes saved.'));
		});

	router
		.route(`/pilot_export/:id`)
		.get((req, res) => {
			res.json(serviceCatalog);
		});
};
