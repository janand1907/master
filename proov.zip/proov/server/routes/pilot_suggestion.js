/* eslint-disable camelcase */
import { requireAuth, error } from '../utils';
import suggestion from '../json/pilotSuggestion';
import { flags } from '../json/me';

export default router => {

	router.all(`/pilot_suggestion/*`, requireAuth);

	// /pilot_suggestion
	router.post(`/pilot_suggestion`, (req, res) => {
		if (req.body.message.length === 4) {
			res.status(400).json(error('Max suggestions limit = 2.'));
			return;
		}

		if (req.body.message.length <= 5) {
			res.status(400).json(error('Some data is invalid.', 'ValidationError', { 'payload.message': 'Message is too short!' }));
			return;
		}

		if (flags.monetization && !req.body.stripe_token) {
			res.status(400).json(error('No valid payment token found', 'ValidationError', { 'payload.stripe_token': 'Invalid stripe_token' }));
			return;
		}

		const json = {
			...suggestion,
			from_user_id: req.session.user.id,
			from_company_id: req.session.company_id
		};
		res.status(201).json([json]);
	});

};
