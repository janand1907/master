import { requireAuth } from '../utils';

export default router => {

	router.all(`/aws*`, requireAuth);
	// S3 bucket credentials
	router
		.route(`/aws/s3/credentials`)
		.get((req, res) => {
			res.status(200).json({
				access_key: 'AKIAIZTQH2OSBFGBP46A',
				secret: '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',
				session_token: '',
				s3_bucket: 'networking-test-proov',
				s3_key: '1121212/pending',
				aws_region: 'us-west-2',
				ttl: 10800000
			});
		});
};
