import { requireAuth, ok } from '../utils';
import mediaJson from '../json/media';

export default router => {
	router.all(`/media*`, requireAuth);

	// /media/:id
	router
		.route('/media/:id')
		.get((req, res) => {
			res.json({ ...mediaJson, id: req.params.id });
		})
		.patch((req, res) => {
			res.json(ok('Updated.'));
		});

	// /media/:pilotId/file
	router.post('/media/:pilotId/file', (req, res) => {
		if (Math.round(req.headers['content-length'] / 1024) > 0) {
			// TODO: parse body using `muter` and assign title here
			res.status(201).json(mediaJson);
		} else {
			res.status(400).json({
				errors: [
					{
						message: 'Validation Failed.',
						error_type: 'ValidationError',
						error_data: {
							'payload.file': 'The file you are trying to upload is empty'
						}
					}
				]
			});
		}
	});

	// /media/url
	router.post('/media/url', (req, res) => {
		const json = { ...mediaJson, ...req.body }; // merge metadata
		res.status(201).json(json);
	});
};
