/* eslint-disable camelcase */

import { enterprise, startups } from '../json/auth';
import { users } from '../json/user';
import { ok, error, requireAuth } from '../utils';

const validate = {
	id: 1,
	company_id: 'some@thing.com',
	company_name: 'some@thing.com',
	first_name: 'John',
	last_name: 'Doe',
	is_user_exist: true,
	phone: {
		label: '+(092) 86103344',
		country_code: 'AF',
		phone_number: '86103344'
	},
	job_title: 'CTO',
	role: 'admin',
	status: 'active'
};

export default router => {
	// /user/validate_invitation
	router.route('/user/validate_invitation').post((req, res) => {
		res.json({ ...validate });
		// res.status(400);
		// res.json(error('Validation Failed'));
	});

	router.route('/user/complete_invitation').post((req, res) => {
		res.json(ok('REDIRECT TO LOGIN!'));
	});

	router.route('/user/complete_registration').post((req, res) => {
		const json =
			req.body.email === enterprise.email
				? enterprise
				: startups.find(startup => startup.email === req.body.email);
		req.session.user = json;
		res.json(json);
	});

	router.all(`/user/*`, requireAuth);

	// /user
	router
		.route('/user')
		.get((req, res) => res.json(users))
		.post((req, res) => {
			res.json(ok('User created.'));
			// res.status(500);
			// res.json(error('Validation Failed'));
		});

	// /user/:id/reset_password
	router.route('/user/:id/reset_password').get((req, res) => {
		res.json(ok('Password reset successfully!'));
	});

	// /user/:id/send_invite
	router.route('/user/:id/send_invite').get((req, res) => {
		res.json(ok('Your invitation have been sent successfully!'));
	});

	// /user/:id
	router
		.route('/user/:id')
		.get((req, res) => {
			const user = users.find(({ id }) => id === req.params.id);
			const update = Object.assign({}, user, req.body);
			res.status(200).json(update);
		})
		.patch((req, res) => {
			res.json(ok('Changes saved.'));
		})
		.delete((req, res) => {
			res.json(ok('User removed.'));
		});

	//change password
	router.route('/user/:id/change_password').post((req, res) => {
		res.json(ok('Password successfully changed!'));
	});
};
