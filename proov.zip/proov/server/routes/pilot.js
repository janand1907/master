import { pick, flattenDepth } from 'lodash';
import { error, ok, requireAuth } from '../utils';
import * as pilots from '../json/pilots';
import lab from '../json/pilots/active/lab/lab';
import safezone from '../json/pilots/active/safezone/safezone';
import * as aws_environment from '../json/channels/aws';
import * as lab_environment from '../json/channels/lab';

export default (router) => {
	router.all(`/pilot*`, requireAuth);
	// /pilot/:id
	router
		.route(`/pilot/:id`)
		.get((req, res) => {
			const defaultFields = [
				'id',
				'company',
				'user_id',
				'created_at',
				'updated_at',
				'name',
				'is_public',
				'category',
				'country',
				'tags',
				'start_time',
				'end_time',
				'last_join_time',
			];
			const pilot = Object.values(pilots).find(
				(item) => item.id === req.params.id
			);
			let fields = req.query.fields
				? req.query.fields.split(',')
				: defaultFields;

			// AWS portfolio deployed successfully
			if (
				req.query.fields.split(',').length === 4 &&
				pilot.pilot_type === 'aws_sc'
			) {
				const products = Object.entries(
					pilot.environment_params.products
				).reduce((acc, [id, product]) => {
					return {
						...acc,
						[id]: { ...product, status: 'success' },
					};
				}, {});

				const portfolio = { ...pilot.environment_params, products };

				res.json({
					...pick(pilot, ['version']),
					environment: [...flattenDepth(Object.values(aws_environment), 1)],
					environment_params: portfolio,
					status: 'execution',
				});
				return;
			} else if (
				req.query.fields.split(',').length === 4 &&
				pilot.pilot_type !== 'aws_sc'
			) {
				res.json({
					...pick(pilot, ['version']),
					environment: [...flattenDepth(Object.values(lab_environment), 1)],
					status: 'execution',
				});
				return;
			}

			res.json({
				...pick(pilot, fields),
			});
		})
		.patch((req, res) => {
			res.json(ok('Changes saved.'));
		})
		.delete((req, res) => {
			res.json(ok('verification code sent'));
		});

	// /pilot
	router.post(`/pilot`, (req, res) => {
		const { goals } = req.body;

		// dummy validation and failure
		let errorData = {};
		if (goals && goals.length < 25) {
			errorData['payload.goals'] =
				'goals is too short, fill at least 25 characters';
		}
		if (Object.keys(errorData).length) {
			res.status(400);
			res.json(error('Validation Failed.', 'ValidationError', errorData));
			return;
		}

		// success
		const fields = [
			'id',
			'user_id',
			'name',
			'is_public',
			'description',
			'category',
			'country',
			'tags',
			'region_policy',
			'approval_policy',
			'stages',
			'attachments_private',
			'attachments_public',
			'goals',
			'target_vendors',
			'budget',
			'eval_criteria',
			'approval_policy_desc',
			'scenarios',
			'tech_contact_name',
			'tech_contact_email',
			'tech_contact_phone',
			'environment',
		];
		const timestamp = new Date().toISOString();
		const json = {
			...(req.body.pilot_type === 'lab' ? lab : safezone),
			...req.body,
			created_at: timestamp,
			updated_at: timestamp,
		};

		res.status(201).json(pick(json, fields));
	});

	router.route(`/pilot/:id/terminate`).post((req, res) => {
		res.json(ok('pilot terminated successfully'));
	});

	router.route(`/pilot/:id/delete`).delete((req, res) => {
		res.json(ok('pilot deleted successfully'));
	});

	router.route(`/pilot/:id/verify`).get((req, res) => {
		req.query.code === '123456'
			? res.json(ok('valid'))
			: res
					.status(400)
					.json(error('Invalid Verification Code', 'ValidationError'));
	});

	// /pilot/:id/join
	router
		.route(`/pilot/:id/join`)
		.get((req, res) => {
			if (req.params.id == 2) {
				res.status(400);
				res.json(
					error('The number of participants has exceeded.', 'joinPilotError', {
						joinable: 'max_vendors',
					})
				);
			} else {
				res.json(eval_criteria);
			}
		})
		.post((req, res) => {
			res.status(201).json({
				id: 'ca860237088b4fd78e1dead7eece3200',
				pilot_id: '2e7a09cf3d6a49bfae98028c360b2503',
				from_company_id: '1f440bb66bb64945b45a709d28ba07cb',
				created_at: '2016-09-12T13:22:45+00:00',
				is_paid: true,
				payment_id: 9005,
				message: 'I would like to join',
				status: 'pending',
			});
		});

	// /pilot/:id/notes
	router
		.route(`/pilot/:id/notes`)
		.get((req, res) => {
			res.json(notes);
		})
		.post((req, res) => {
			res.status(201).json({
				id: '1234',
				author: 'John Doe',
				date_created: '2015-12-22T00:00:00+00:00',
				title: req.body.title,
				description: req.body.description,
			});
		});

	// /pilot/:id/invite
	router.route(`/pilot/:id/invite`).post((req, res) => {
		if (req.body.message.length <= 10) {
			res.status(400);
			res.json(
				error('Error message here.', 'ValidationError', {
					message: 'Message is too short!',
				})
			);
		} else {
			res.json({
				status: 'ok',
				message: 'Changes saved.',
			});
		}
	});

	// /pilot/:id/checkout
	router.route(`/pilot/:id/checkout`).post((req, res) => {
		const pilot = getPilot(req.body.pilot_id);
		const { instructions, environment } = pilot;

		res.status(201).json({
			environment,
			instructions,
			joinable: 'subscribed',
		});
		// res.status(400).json(error('The card was refused by processing center'));
	});

	// /pilot/:id/environment`
	router
		.route(`/pilot/:id/environments/environment`)
		.get((req, res) => {
			const pilot = Object.values(pilots).find(
				(item) => item.id === req.params.id
			);

			if (pilot.pilot_type === 'aws_sc') {
				res.json(flattenDepth(Object.values(aws_environment), 1));
			} else {
				res.json(flattenDepth(Object.values(lab_environment), 1));
			}
		})
		.patch((req, res) => {
			res.json(ok('Changes saved!'));
		})
		.post((req, res) => {
			if (req.body.name.length <= 2) {
				res.status(400);
				res.json(
					error('Message is too short!', 'ValidationError', {
						'payload.name': 'Message is too short',
					})
				);
			} else {
				res.json({
					status: 'ok',
					message: 'Channel added.',
				});
			}
		});

	router
		.route(`/pilot/:id/environment/:channel_id`)
		.patch((req, res) => {
			const environment = [...flattenDepth(Object.values(lab_environment), 1)];
			const channel = environment.find(
				(channel) => channel.id === req.params.channel_id
			);
			const update = Object.assign({}, channel, req.body);
			res.status(200).json(update);
		})
		.delete((req, res) => {
			res.json(ok('Channel Deleted!'));
		});

	router
		.route(`/pilot/:id/environment/:channel_id/deploy/:dataset_id`)
		.post((req, res) => {
			res.json({
				id: req.params.channel_id,
				status: 'deploying_dataset',
				dataset: {
					dataset_id: req.params.dataset_id,
					name: 'Finance Data',
					deployment_status: 'success',
				},
			});
		});

	router.route(`/pilot/:id/launch`).post((req, res) => {
		const products = Object.entries(
			pilots.AWS.environment_params.products
		).reduce((acc, [id, product]) => {
			if (Object.keys(req.body).includes(id)) {
				return {
					...acc,
					[id]: { ...product, status: 'deploy' },
				};
			} else {
				return {
					...acc,
					[id]: { ...product },
				};
			}
		}, {});

		const portfolio = { ...pilots.AWS.environment_params, products };

		res.json({
			...pick(pilots.AWS, ['version']),
			environment: [...flattenDepth(Object.values(aws_environment), 1)],
			environment_params: portfolio,
			status: 'execution',
		});
	});
};
