/* eslint-disable camelcase */
import { requireAuth, ok, error } from '../utils';
import dashboard from '../json/dashboard';

const base = `/pilot/:id/dashboard`;

export default router => {

	router.all(`${base}*`, requireAuth);

	router.route(`${base}`)
		.get((req, res) => { res.json(dashboard) })
		.post((req, res) => { res.json(ok('Dashboard changed.')) });
};
