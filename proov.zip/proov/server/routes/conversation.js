/* eslint-disable camelcase */
import { pick, find, sampleSize } from 'lodash';
import { take, ok, requireAuth } from '../utils';
import convArray from '../json/conversation';
import msgsArray from '../json/message';
import { companies } from '../json/company';

export default (router) => {

	router.all(`/conversation*`, requireAuth);

	// /conversation
	router.get(`/conversation`, (req, res) => {
		res.json(take(convArray, parseInt(req.query.limit), parseInt(req.query.skip)));
	});

	// /converation/suggest
	router.get(`/conversation/suggest`, (req, res) => {
		const convs = sampleSize(convArray, 3);
		const comps = companies.map(c => pick(c, ['id', 'type', 'name', 'profile_image']));
		res.json({ conversations: convs, companies: comps });
	});

	// /conversation/with/:id
	router.get(`/conversation/with/:id`, (req, res) => {
		let conv = find(convArray, (conv) => conv.company.id === req.params.id);
		if (!conv) {
			const sample = convArray[0];
			conv = {
				...sample,
				id: Math.random() * 10000 + 1000,
				company: { ...sample.company, id: req.params.id },
				is_new: false,
				can_reply: true,
				snippet: ''
			};
		}
		res.json(conv);
	});

	// /conversation/:id/messages
	router.get(`/conversation/:id/messages`, (req, res) => {
		const all = msgsArray.map(msg => ({ ...msg, conversation_id: parseInt(req.params.id) }));
		res.json(take(all, parseInt(req.query.limit), parseInt(req.query.skip)));
	});

	// /conversation/:id/mark_as_read
	router.patch(`/conversation/:id/mark_as_read`, (req, res) => {
		res.json(ok('Marked as read.'));
	});

	// /conversation/:id/send
	router.post(`/conversation/:id/send`, (req, res) => {
		req.url = `/message`;
		router.handle(req, res);
	});

	// /conversation/:id
	router.get(`/conversation/:id`, (req, res, next) => {
		const conv = find(convArray, c => c.id == req.params.id);
		if (conv) { res.json(conv) }
		else { next() }
	});

};
