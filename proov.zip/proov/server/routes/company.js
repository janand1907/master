/* eslint-disable camelcase */
import { pick } from 'lodash';
import companyJson, { companies } from '../json/company';
import { ok, requireAuth } from '../utils';

export default router => {
	router.route(`/company/aws-account-id`).get((req, res) => {
		res.json({ aws_account_id: 'DF63G4TG734XF' });
	});

	router.all(`/company/*`, requireAuth);

	// /company/suggest
	router.get(`/company/suggest/:intent`, (req, res) => {
		res.json(companies.map(c => pick(c, ['id', 'type', 'name', 'profile_image'])));
	});

	// /company/:id/profile_image
	router.post(`/company/:id/profile_image`, (req, res) => {
		res.json({ profile_image: `/res/avatar/${req.params.id}?v=${Date.now()}` });
	});

	// /company/:id
	router
		.route(`/company/:id`)
		.get((req, res) => {
			let json = { ...companyJson, id: req.params.id };
			const fields = req.query.fields
				? req.query.fields.split(',')
				: ['id', 'type', 'name', 'profile_image'];
			json = pick(json, fields);
			res.json(json);
		})
		.patch((req, res) => {
			res.json(ok('Changes saved.'));
		});
};
