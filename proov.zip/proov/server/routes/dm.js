/* eslint-disable camelcase */
import datasets from '../json/datasets';

export default router => {
	router.post(`/dm/dataset`, (req, res) => {
		res.status(201).json(datasets[2]);
	});

	router.get(`/dm/dataset/:id/download`, (req, res) => {
		res.status(200).json({ url: 'http://samplecsvs.s3.amazonaws.com/SalesJan2009.csv' });
	});

};
