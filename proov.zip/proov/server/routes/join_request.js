/* eslint-disable camelcase */

import { ok, requireAuth } from '../utils';

export default router => {
	router.all(`/join_request*`, requireAuth);

	//accept join pilot request
	router.route(`/join_request/:id/accept`).post((req, res) => {
		res.json(ok('Changes saved.'));
	});

	router.route(`/join_request/:id/deny`).post((req, res) => {
		res.json(ok('Changes saved.'));
	});

	router.route(`/pilot/:id/vendor/:vendorId`).delete((req, res) => {
		res.json(ok('Changes saved.'));
	});
};
