var mongoose = require("mongoose");

var UserSchema = new mongoose.Schema({
    id: {
        type: String,
        index: true
    },
    created_at: { type: Date, default: Date.now },
    updated_at: {
        type: Date,
        index: true
    },
    email: {
        type: String,
        index: true
    },
    email_verified: {
        type: Boolean,
        index: true
    },
    company_id: {
        type: String,
        index: true
    },
    phone: {
        type: String,
        index: true
    },
    job_title: {
        type: String,
        index: true
    },
    department: {
        type: String,
        index: true
    },
    marketing_emails_enabled: {
        type: Boolean,
        index: true
    },
    auth_type: {
        type: String,
        index: true
    },
    role: {
        type: String,
        index: true
    },
    status: {
        type: String,
        index: true
    },
    version: {
        type: Number,
        index: true
    }
});

var User = mongoose.model('User', UserSchema);

module.exports = User;